(function () {
  'use strict';

  var screen = document.body.getAttribute('data-screen');
  var lastTicker;
  var cards = document.querySelectorAll('.pc');
  var icons = ['fa1', 'fa2', 'rise', 'sun', 'pc', 'set', 'moon'];

  function perform(action) {
    if (window.MosqueActions && typeof window.MosqueActions.perform === 'function') {
      window.MosqueActions.perform(action);
    }
  }

  function setText(id, value) {
    var element = document.getElementById(id);
    if (element) element.textContent = value == null ? '' : String(value);
  }

  function bind(element, action) {
    if (!element) return;
    element.onclick = function () { perform(action); };
    element.setAttribute('role', 'button');
    element.setAttribute('tabindex', '0');
    element.addEventListener('keydown', function (event) {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        perform(action);
      }
    });
  }

  function measureTicker() {
    var flash = document.getElementById('flash');
    var span = flash && flash.firstElementChild;
    if (!span || !flash.clientWidth || !span.offsetWidth) return;
    span.style.setProperty('--from', -flash.clientWidth + 'px');
    span.style.setProperty('--to', span.offsetWidth + 'px');
    span.style.setProperty('--dur', ((flash.clientWidth + span.offsetWidth) / 80).toFixed(2) + 's');
  }

  if (screen === 'dashboard') {
    bind(document.getElementById('settings'), 'settings');
    bind(document.getElementById('yearTimes'), 'schedule');
    Array.prototype.forEach.call(cards, function (card) {
      card.setAttribute('role', 'button');
      card.setAttribute('tabindex', '0');
      card.onclick = function () {
        if (card.dataset.prayerId) perform('prayer:' + card.dataset.prayerId);
      };
      card.addEventListener('keydown', function (event) {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          card.click();
        }
      });
    });
  } else if (screen === 'adhkar') {
    bind(document.getElementById('gbtn'), 'settings');
    bind(document.getElementById('xbtn'), 'dismiss');
  } else {
    bind(document.getElementById('btnGear'), 'settings');
    bind(document.getElementById('btnX'), 'dismiss');
  }

  // All dynamic values come from the app. The HTML never calculates prayer times
  // or persists its own settings, so the existing native schedule stays in charge.
  window.renderMosqueState = function (state) {
    if (!state || typeof state !== 'object') return;
    if (screen === 'dashboard') {
      var title = document.querySelector('.title');
      if (title) title.textContent = state.mosqueName == null ? '' : String(state.mosqueName);
      setText('clk', state.time);
      setText('ap', state.amPm);
      setText('hij', state.hijriDate);
      setText('bar', state.dateLine);
      setText('nx', state.adhanTime);
      setText('nxn', state.adhanName);
      setText('iq', state.iqamaTime);
      setText('iqn', state.iqamaName);

      var rows = Array.isArray(state.rows) ? state.rows : [];
      Array.prototype.forEach.call(cards, function (card, index) {
        var row = rows[index];
        card.style.display = row ? '' : 'none';
        if (!row) {
          delete card.dataset.prayerId;
          return;
        }
        card.dataset.prayerId = String(row.id);
        card.querySelector('.n').textContent = row.name == null ? '' : String(row.name);
        card.querySelector('.t').textContent = row.time == null ? '' : String(row.time);
        card.classList.toggle('hl', !!row.isNext);
        var icon = String(row.icon || '').replace(/^#/, '');
        if (icons.indexOf(icon) !== -1) card.querySelector('use').setAttribute('href', '#' + icon);
      });

      var message = state.tickerMessage == null ? '' : String(state.tickerMessage);
      if (message !== lastTicker) {
        lastTicker = message;
        document.querySelector('#flash span').textContent = message;
        measureTicker();
        requestAnimationFrame(measureTicker);
      }
    } else if (screen === 'adhkar') {
      setText('tm', state.countdown);
    } else {
      setText('time', state.countdown);
      if (screen === 'iqama') setText('badgeName', state.prayerName);
    }
  };
})();
