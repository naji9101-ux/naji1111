package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.util.AutoLaunchManager
import com.example.util.KioskManager
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import android.content.pm.ActivityInfo
import android.view.WindowManager
import com.example.alarm.PrayerAlarmScheduler
import com.example.ui.MainMosqueScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.PrayerTimesViewModel

class MainActivity : ComponentActivity() {

    private val prayerTimesViewModel: PrayerTimesViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Keep screen on continuously for digital mosque prayer display
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        enableEdgeToEdge()

        // Make app fill 100% of the screen by hiding system status and navigation bars
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)
        val insetsController = androidx.core.view.WindowCompat.getInsetsController(window, window.decorView)
        insetsController.systemBarsBehavior = androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        insetsController.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())

        try {
            com.example.audio.AudioRegistry.initialize(this)
            PrayerAlarmScheduler.scheduleAllPrayers(this)
        } catch (e: Exception) {
            Log.e("MainActivity", "Failed to schedule prayer alarms on startup", e)
        }

        // وضع الشاشة الثابتة: تطبيق Lock Task الحقيقي عند تغيّر الخيار، ويُستعاد تلقائياً بعد كل تشغيل
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                prayerTimesViewModel.settings
                    .map { it.isKioskModeEnabled }
                    .distinctUntilChanged()
                    .collect { kioskEnabled ->
                        KioskManager.apply(this@MainActivity, kioskEnabled)
                    }
            }
        }

        setContent {
            MyApplicationTheme {
                // Request notification permission on Android 13+
                val notificationPermissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission()
                ) { isGranted ->
                    Log.d("MainActivity", "Notification permission granted: $isGranted")
                }

                LaunchedEffect(Unit) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        if (ContextCompat.checkSelfPermission(
                                this@MainActivity,
                                Manifest.permission.POST_NOTIFICATIONS
                            ) != PackageManager.PERMISSION_GRANTED
                        ) {
                            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    }
                }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF082D59)
                ) {
                    MainMosqueScreen(
                        viewModel = prayerTimesViewModel,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // إكمال خطوات إعداد التشغيل التلقائي (إذن العرض ثم اختيار الشاشة الرئيسية)
        AutoLaunchManager.onActivityResumed(this)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            val insetsController = androidx.core.view.WindowCompat.getInsetsController(window, window.decorView)
            insetsController.systemBarsBehavior = androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            insetsController.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
        }
    }
}
