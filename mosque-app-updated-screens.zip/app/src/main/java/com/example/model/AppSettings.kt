package com.example.model

const val DEFAULT_FAJR_FIRST_ID = "fajr_haram"
const val DEFAULT_FAJR_FIRST_NAME = "أذان الفجر - المسجد الحرام"
const val DEFAULT_FAJR_FIRST_URI = "asset:///AdhanFajr/أذان الفجر - المسجد الحرام.mp3"

const val DEFAULT_CLOCK_SIZE_SP = 64
const val DEFAULT_CLOCK_COLOR = "#E8D28A"
const val DEFAULT_CLOCK_DIGITS_COLOR = DEFAULT_CLOCK_COLOR
const val DEFAULT_CLOCK_MARKER_COLOR = DEFAULT_CLOCK_COLOR

data class AudioFileItem(
    val id: String,
    val name: String,
    val uri: String,
    val isBuiltIn: Boolean = true,
    val isDefault: Boolean = false
)

data class IqamaScreenCustomConfig(
    val backgroundColorHex: String = "#EAF5EF", // Calm light mint green
    val frameColorHex: String = "#C9A646", // Mosque gold
    val frameOuterThicknessDp: Int = 4,
    val frameInnerThicknessDp: Int = 2,
    val titleText: String = "الصلاة قائمة",
    val titleSizeSp: Int = 46,
    val instructionText: String = "أغلقوا الهواتف أثابكم الله",
    val instructionSizeSp: Int = 46,
    val iconSizeDp: Int = 90
)

data class PeriodInterfaceConfig(
    val periodId: String,
    val displayName: String,
    val enabled: Boolean = true,
    val designPreset: String = "ISLAMIC_ARCH",
    val customImageUri: String? = null,
    val bgGradientStartHex: String = "#09241B",
    val bgGradientEndHex: String = "#04150F",
    val frameColorHex: String = "#C9A646",
    val frameThicknessDp: Int = 3,
    val customTitle: String = "",
    val customDhikr: String = "",
    val iconName: String = "DEFAULT",
    val opacity: Float = 0.85f
)

data class SinglePrayerConfig(
    val prayerId: String,
    val adhanEnabled: Boolean = true,
    val adhanSoundUri: String? = null,
    val adhanSoundPreset: String = "",
    val adhanSoundName: String? = null,
    val adhanOffsetMinutes: Int = 0,
    val iqamaEnabled: Boolean = true,
    val iqamaMinutes: Int = 15,
    val manualIqamaTime: String? = null,
    val isManualIqama: Boolean = false,
    val iqamaSoundUri: String? = null,
    val iqamaSoundPreset: String = "",
    val iqamaSoundName: String? = null,
    val prePrayerEnabled: Boolean = true,
    val prePrayerMinutes: Int = 10,
    val customBackgroundUri: String? = null,
    val customIconUri: String? = null,
    val prayerScreenEnabled: Boolean = true,
    val prayerScreenUri: String? = null,
    val iqamaScreenEnabled: Boolean = true,
    val iqamaScreenUri: String? = null,
    val iqamaScreenDurationMinutes: Int = 5,
    val iqamaScreenCustomConfig: IqamaScreenCustomConfig = IqamaScreenCustomConfig()
)

data class AppSettings(
    val mosqueName: String = "اسم المسجد",
    val titleText: String = "مواقيت الصلاة",
    val titleSizeSp: Int = 24,
    val logoScale: Float = 1.0f,
    val showLogo: Boolean = true,
    val customLogoUri: String? = null,

    // Layout
    val swapLayoutSides: Boolean = false,

    // Clock & Date
    val showSeconds: Boolean = true,
    val is24Hour: Boolean = false,
    val isTimeCorrectionEnabled: Boolean = false,
    val timeOffsetHours: Int = 0,
    val timeOffsetMinutes: Int = 0,
    val isDateCorrectionEnabled: Boolean = false,
    val gregorianDayOffset: Int = 0,
    val hijriDayOffset: Int = 0,
    val isFridayKhutbahMode: Boolean = true,
    val fridayKhutbahDurationMinutes: Int = 25,
    val clockSizeSp: Int = DEFAULT_CLOCK_SIZE_SP,
    val clockColorHex: String = DEFAULT_CLOCK_COLOR,
    val clockDigitsColorHex: String = clockColorHex,
    val clockMarkerColorHex: String = clockColorHex,
    val clockBold: Boolean = true,
    val showDate: Boolean = true,
    val showCountdowns: Boolean = true,
    val showIcons: Boolean = true,
    val showTitle: Boolean = true,

    // Adhan System - OFF by default as required
    val useCommonAdhan: Boolean = false,
    val commonAdhanSound: String = "",
    val commonAdhanName: String = "",
    val savedAdhanSounds: List<AudioFileItem> = emptyList(),
    val savedFajrAdhanSounds: List<AudioFileItem> = emptyList(),

    // Iqama System - OFF by default as required
    val applyIqamaSoundToAll: Boolean = false,
    val defaultIqamaSound: String = "",
    val defaultIqamaName: String = "",
    val globalIqamaScreenDurationMinutes: Int = 5,
    val savedIqamaSounds: List<AudioFileItem> = emptyList(),
    val iqamaScreenCustomConfig: IqamaScreenCustomConfig = IqamaScreenCustomConfig(),

    // First Adhans System
    val firstAdhansMasterEnabled: Boolean = true,
    val isFajrFirstEnabled: Boolean = true,
    val isFajrTwoAdhans: Boolean = true,
    val fajrIntervalMinutes: Int = 15,
    val isFridayFirstEnabled: Boolean = true,
    val fridayFirstAdhanOffsetMinutes: Int = 15,
    val fridayCustomMessage: String = "يوم الجمعة عيد الأسبوع - أكثروا من الصلاة على النبي ﷺ",
    val fridayFirstAdhanSoundUri: String? = null,
    val fridaySecondAdhanSoundUri: String? = null,
    val fridayIqamaMinutes: Int = 15,

    // Pre-prayer notice
    val defaultPrePrayerMinutes: Int = 10,

    // Prayer Interfaces Master Switch (Default is OFF)
    val prayerInterfacesMasterEnabled: Boolean = true,
    // Secondary Main Mosque Interface (Toggle & Selection)
    val secondHomeInterfaceEnabled: Boolean = false,
    val selectedHomeInterface: String = "ABBASI_BLUE_GOLD",
    val periodConfigs: Map<String, PeriodInterfaceConfig> = emptyMap(),

    // Screen & Display
    val keepScreenAwake: Boolean = true,
    val fullscreenMode: Boolean = true,
    val orientationMode: String = "LANDSCAPE",
    val nightMode: String = "AUTO",
    val backgroundOpacity: Float = 0.5f,
    val overlayColorName: String = "DARK_GREEN",
    val isAnimatedBackground: Boolean = false,
    val highlightCurrentPrayer: Boolean = false,
    val prayerTableElementsSize: Int = 18,
    val postPrayerAdhkarEnabled: Boolean = true,
    val postPrayerAdhkarDurationMinutes: Int = 5,

    // Admin & Security
    val isAdminPinEnabled: Boolean = false,
    val adminPin: String = "1234",
    val isKioskModeEnabled: Boolean = false,
    val isAutoStartHomeEnabled: Boolean = false,

    // Ticker messages
    val tickerMessages: List<String> = listOf(
        "أهلاً بكم في بيت الله - نرجو المحافظة على نظافة المسجد والهدوء",
        "قال رسول الله ﷺ: «أَحَبُّ البِقاعِ إلى اللهِ مَساجِدُها»",
        "تذكير: يرجى وضع الهواتف النقالة على الوضع الصامت أثناء الصلاة",
        "فضل الصف الأول: لو يعلم الناس ما في النداء والصف الأول لاستهموا عليه"
    ),
    val tickerRotationSeconds: Int = 12,
    val isTickerRotating: Boolean = true,
    val showTicker: Boolean = true,

    // Per prayer configs
    val prayerConfigs: Map<String, SinglePrayerConfig> = emptyMap(),

    // GPS & Calculation Settings
    val savedLocation: GpsLocationData? = null,
    val calculationMethod: String = "MWL",
    val asrMethod: String = "STANDARD",

    // Simulation Mode for testing
    val simulationModeEnabled: Boolean = false,
    val simulatedState: PrayerState = PrayerState.NORMAL,
    val simulatedPrayerType: PrayerType = PrayerType.MAGHRIB
) {
    fun withClockColor(hex: String): AppSettings {
        return copy(
            clockColorHex = hex,
            clockDigitsColorHex = hex,
            clockMarkerColorHex = hex
        )
    }
    /**
     * Resolves the URI or sound key to play for Adhan for this prayer.
     * Rules:
     * - Fajr First is ALWAYS independent and uses its own sound (from Fajr library).
     * - Sunrise is independent.
     * - If useCommonAdhan is true (and not Fajr 1 or Sunrise), uses commonAdhanSound.
     * - If neither is set, returns null (no sound).
     */
    val isFridayFirstActive: Boolean
        get() = firstAdhansMasterEnabled && isFridayFirstEnabled

    fun getPrayerDisplayName(type: PrayerType): String {
        return type.displayName(isFridayFirstActive)
    }

    fun getResolvedAdhanSound(type: PrayerType): String? {
        val cfg = getPrayerConfig(type)
        if (type == PrayerType.FAJR_FIRST) {
            val custom = cfg.adhanSoundUri?.takeIf { it.isNotEmpty() }
            if (custom != null) return custom
            val preset = cfg.adhanSoundPreset.takeIf { it.isNotEmpty() }
            if (preset != null) return preset
            return null
        }
        if (type == PrayerType.SUNRISE) {
            return null
        }
        if (useCommonAdhan && commonAdhanSound.isNotEmpty()) {
            return commonAdhanSound
        }
        val custom = cfg.adhanSoundUri?.takeIf { it.isNotEmpty() }
        if (custom != null) return custom
        val preset = cfg.adhanSoundPreset.takeIf { it.isNotEmpty() }
        if (preset != null) return preset
        if (type == PrayerType.FRIDAY_SECOND && !isFridayFirstActive) {
            return getResolvedAdhanSound(PrayerType.DHUHR)
        }
        return null
    }

    /**
     * Resolves the human-readable display title for the Adhan sound.
     * If no sound is chosen, returns "لم يتم اختيار صوت".
     */
    fun getResolvedAdhanTitle(type: PrayerType): String {
        val soundUri = getResolvedAdhanSound(type) ?: return "لم يتم اختيار صوت"
        val cfg = getPrayerConfig(type)
        if (type == PrayerType.FAJR_FIRST) {
            if (cfg.adhanSoundName?.isNotBlank() == true) {
                return cfg.adhanSoundName
            }
            val fajrItem = savedFajrAdhanSounds.find { it.uri == soundUri }
            if (fajrItem != null) return fajrItem.name
            if (DEFAULT_FAJR_FIRST_URI.isNotEmpty() && (soundUri == DEFAULT_FAJR_FIRST_URI || soundUri.contains("المسجد الحرام") || soundUri.contains("Yaseen Al Aassaf", ignoreCase = true) || soundUri.contains("fajr_assaf"))) {
                return DEFAULT_FAJR_FIRST_NAME
            }
        }
        if (cfg.adhanSoundName?.isNotBlank() == true && !useCommonAdhan) {
            return cfg.adhanSoundName
        }
        if (useCommonAdhan && type != PrayerType.FAJR_FIRST && type != PrayerType.SUNRISE) {
            if (commonAdhanName.isNotBlank()) return commonAdhanName
            val item = savedAdhanSounds.find { it.uri == soundUri }
            if (item != null) return item.name
        }
        val item = savedAdhanSounds.find { it.uri == soundUri }
            ?: savedFajrAdhanSounds.find { it.uri == soundUri }
        if (item != null) return item.name
        val nameFromUri = soundUri.substringAfterLast("/")
        return if (nameFromUri.isNotBlank()) nameFromUri else "لم يتم اختيار صوت"
    }

    /**
     * Resolves the URI or sound key to play for Iqama for this prayer.
     * If applyIqamaSoundToAll is true, uses defaultIqamaSound.
     * Otherwise uses prayer-specific sound. If none, returns null.
     */
    fun getResolvedIqamaSound(type: PrayerType): String? {
        if (applyIqamaSoundToAll && defaultIqamaSound.isNotEmpty()) {
            return defaultIqamaSound
        }
        val cfg = getPrayerConfig(type)
        val custom = cfg.iqamaSoundUri?.takeIf { it.isNotEmpty() }
        if (custom != null) return custom
        return cfg.iqamaSoundPreset.takeIf { it.isNotEmpty() }
    }

    /**
     * Resolves the human-readable display title for the Iqama sound.
     * If no sound is chosen, returns "لم يتم اختيار صوت".
     */
    fun getResolvedIqamaTitle(type: PrayerType): String {
        val soundUri = getResolvedIqamaSound(type) ?: return "لم يتم اختيار صوت"
        val cfg = getPrayerConfig(type)
        if (cfg.iqamaSoundName?.isNotBlank() == true && !applyIqamaSoundToAll) {
            return cfg.iqamaSoundName
        }
        if (applyIqamaSoundToAll) {
            if (defaultIqamaName.isNotBlank()) return defaultIqamaName
            val item = savedIqamaSounds.find { it.uri == soundUri }
            if (item != null) return item.name
        }
        val item = savedIqamaSounds.find { it.uri == soundUri }
        if (item != null) return item.name
        val nameFromUri = soundUri.substringAfterLast("/")
        return if (nameFromUri.isNotBlank()) nameFromUri else "لم يتم اختيار صوت"
    }

    fun getIqamaScreenDurationMinutes(type: PrayerType): Int {
        val cfg = getPrayerConfig(type)
        return cfg.iqamaScreenDurationMinutes
    }

    fun getIqamaScreenCustomConfig(type: PrayerType): IqamaScreenCustomConfig {
        val cfg = getPrayerConfig(type)
        return cfg.iqamaScreenCustomConfig
    }

    fun getPrayerConfig(type: PrayerType): SinglePrayerConfig {
        val existing = prayerConfigs[type.id]
        if (existing != null) {
            return existing
        }
        val defaultMinutes = when (type) {
            PrayerType.FAJR_FIRST -> fajrIntervalMinutes
            PrayerType.FAJR_SECOND -> 20
            PrayerType.DHUHR -> 15
            PrayerType.FRIDAY_FIRST -> 0
            PrayerType.FRIDAY_SECOND -> fridayIqamaMinutes
            PrayerType.ASR -> 15
            PrayerType.MAGHRIB -> 10
            PrayerType.ISHA -> 15
            PrayerType.SUNRISE -> 0
        }
        val defaultIqamaScreenDuration = when (type) {
            PrayerType.FAJR_SECOND -> 20
            PrayerType.DHUHR -> 15
            PrayerType.ASR -> 15
            PrayerType.MAGHRIB -> 10
            PrayerType.ISHA -> 15
            PrayerType.FRIDAY_SECOND -> 15
            else -> globalIqamaScreenDurationMinutes
        }
        val defaultAdhanUri: String? = null
        val defaultAdhanPreset = ""
        val defaultAdhanName: String? = null
        val defaultAdhanEnabled = when (type) {
            PrayerType.FAJR_FIRST -> isFajrFirstEnabled
            PrayerType.FRIDAY_FIRST -> isFridayFirstEnabled
            else -> type.hasAdhan
        }
        return SinglePrayerConfig(
            prayerId = type.id,
            adhanEnabled = defaultAdhanEnabled,
            adhanSoundUri = defaultAdhanUri,
            adhanSoundPreset = defaultAdhanPreset,
            adhanSoundName = defaultAdhanName,
            iqamaEnabled = type.hasIqama,
            iqamaMinutes = defaultMinutes,
            iqamaScreenDurationMinutes = defaultIqamaScreenDuration,
            iqamaScreenCustomConfig = iqamaScreenCustomConfig
        )
    }

    fun withPrayerConfig(config: SinglePrayerConfig): AppSettings {
        val updated = prayerConfigs.toMutableMap()
        updated[config.prayerId] = config
        val updatedFridayIqama = if (config.prayerId == PrayerType.FRIDAY_SECOND.id) config.iqamaMinutes else fridayIqamaMinutes
        val updatedFajrInterval = if (config.prayerId == PrayerType.FAJR_FIRST.id) config.iqamaMinutes else fajrIntervalMinutes
        val updatedFajrFirstEnabled = if (config.prayerId == PrayerType.FAJR_FIRST.id) config.adhanEnabled else isFajrFirstEnabled
        val updatedFridayFirstEnabled = if (config.prayerId == PrayerType.FRIDAY_FIRST.id) config.adhanEnabled else isFridayFirstEnabled
        return copy(
            prayerConfigs = updated,
            fridayIqamaMinutes = updatedFridayIqama,
            fajrIntervalMinutes = updatedFajrInterval,
            isFajrFirstEnabled = updatedFajrFirstEnabled,
            isFajrTwoAdhans = updatedFajrFirstEnabled,
            isFridayFirstEnabled = updatedFridayFirstEnabled
        )
    }

    fun withFajrFirstEnabled(enabled: Boolean): AppSettings {
        val fajrCfg = getPrayerConfig(PrayerType.FAJR_FIRST).copy(adhanEnabled = enabled)
        val updatedConfigs = prayerConfigs.toMutableMap()
        updatedConfigs[PrayerType.FAJR_FIRST.id] = fajrCfg
        return copy(
            isFajrFirstEnabled = enabled,
            isFajrTwoAdhans = enabled,
            prayerConfigs = updatedConfigs
        )
    }

    fun withFridayFirstEnabled(enabled: Boolean): AppSettings {
        val fridayCfg = getPrayerConfig(PrayerType.FRIDAY_FIRST).copy(adhanEnabled = enabled)
        val updatedConfigs = prayerConfigs.toMutableMap()
        updatedConfigs[PrayerType.FRIDAY_FIRST.id] = fridayCfg
        return copy(
            isFridayFirstEnabled = enabled,
            prayerConfigs = updatedConfigs
        )
    }

    fun withFajrIntervalMinutes(minutes: Int): AppSettings {
        val coerced = minutes.coerceIn(1, 120)
        val updatedConfigs = prayerConfigs.toMutableMap()
        val fajrFirstCfg = getPrayerConfig(PrayerType.FAJR_FIRST).copy(iqamaMinutes = coerced)
        updatedConfigs[PrayerType.FAJR_FIRST.id] = fajrFirstCfg
        return copy(
            fajrIntervalMinutes = coerced,
            prayerConfigs = updatedConfigs
        )
    }

    fun getPeriodConfig(periodId: String): PeriodInterfaceConfig {
        val normalizedId = when (periodId) {
            "fajr_first", "fajr" -> "fajr_second"
            "sunrise" -> "shuruq"
            else -> periodId
        }
        val existing = periodConfigs[normalizedId] ?: periodConfigs[periodId]
        if (existing != null) return existing
        return when (normalizedId) {
            "fajr_second" -> PeriodInterfaceConfig(
                periodId = "fajr_second",
                displayName = "الفجر الثاني",
                designPreset = "DAWN_RADIANCE",
                bgGradientStartHex = "#0C2E24",
                bgGradientEndHex = "#041812",
                frameColorHex = "#C9A646",
                customTitle = "الصلاة خير من النوم",
                customDhikr = "أصبحنا وأصبح الملك لله والحمد لله",
                iconName = "CRESCENT"
            )
            "shuruq" -> PeriodInterfaceConfig(
                periodId = "shuruq",
                displayName = "الشروق",
                designPreset = "SUNSET_GLOW",
                bgGradientStartHex = "#1F2F2B",
                bgGradientEndHex = "#0A1813",
                frameColorHex = "#E8D28A",
                customTitle = "وأشرقت الأرض بنور ربها",
                customDhikr = "الحمد لله الذي أحيانا بعد ما أماتنا وإليه النشور",
                iconName = "SUN"
            )
            "dhuhr" -> PeriodInterfaceConfig(
                periodId = "dhuhr",
                displayName = "الظهر",
                designPreset = "ISLAMIC_ARCH",
                bgGradientStartHex = "#0E382A",
                bgGradientEndHex = "#071F17",
                frameColorHex = "#D4AF37",
                customTitle = "حي على الصلاة حي على الفلاح",
                customDhikr = "اللهم إني أسألك من فضلك ورحمتك",
                iconName = "SUN"
            )
            "asr" -> PeriodInterfaceConfig(
                periodId = "asr",
                displayName = "العصر",
                designPreset = "MINIMAL_GOLD",
                bgGradientStartHex = "#133C2E",
                bgGradientEndHex = "#092219",
                frameColorHex = "#C9A646",
                customTitle = "حافظوا على الصلوات والصلاة الوسطى",
                customDhikr = "سبحان الله وبحمده عدد خلقه ورضا نفسه",
                iconName = "MOSQUE"
            )
            "maghrib" -> PeriodInterfaceConfig(
                periodId = "maghrib",
                displayName = "المغرب",
                designPreset = "SUNSET_GLOW",
                bgGradientStartHex = "#1F2F2B",
                bgGradientEndHex = "#0A1813",
                frameColorHex = "#E8D28A",
                customTitle = "اللهم هذا إقبال ليلك وإدبار نهارك",
                customDhikr = "أمسينا وأمسى الملك لله رب العالمين",
                iconName = "KAABA"
            )
            "isha" -> PeriodInterfaceConfig(
                periodId = "isha",
                displayName = "العشاء",
                designPreset = "NIGHT_SKY",
                bgGradientStartHex = "#081E17",
                bgGradientEndHex = "#020D0A",
                frameColorHex = "#C9A646",
                customTitle = "وجعلنا الليل لباساً",
                customDhikr = "لا إله إلا أنت سبحانك إني كنت من الظالمين",
                iconName = "CRESCENT"
            )
            else -> PeriodInterfaceConfig(
                periodId = normalizedId,
                displayName = "الفترة",
                customTitle = ""
            )
        }
    }

    fun withPeriodConfig(config: PeriodInterfaceConfig): AppSettings {
        val updated = periodConfigs.toMutableMap()
        updated[config.periodId] = config
        return copy(periodConfigs = updated)
    }
}
