package com.example.model

enum class PrayerType(
    val id: String,
    val defaultName: String,
    val hasAdhan: Boolean,
    val hasIqama: Boolean = true
) {
    FAJR_FIRST("fajr_first", "الفجر الأول", true, false),
    FAJR_SECOND("fajr_second", "الفجر الثاني", true, true),
    SUNRISE("sunrise", "الشروق", false, false),
    DHUHR("dhuhr", "الظهر", true, true),
    FRIDAY_FIRST("friday_first", "الأذان الأول", true, false),
    FRIDAY_SECOND("friday_second", "الأذان الثاني", true, true),
    ASR("asr", "العصر", true, true),
    MAGHRIB("maghrib", "المغرب", true, true),
    ISHA("isha", "العشاء", true, true);

    fun displayName(isFridayFirstEnabled: Boolean): String {
        return when (this) {
            FRIDAY_FIRST -> "الأذان الأول"
            FRIDAY_SECOND -> if (isFridayFirstEnabled) "الأذان الثاني" else "الظهر"
            else -> defaultName
        }
    }
}

enum class PrayerState {
    NORMAL,
    PRE_PRAYER,
    ADHAN,
    AFTER_ADHAN,
    IQAMA,
    AFTER_PRAYER,
    FRIDAY_NORMAL,
    FRIDAY_PRE_FIRST,
    FRIDAY_FIRST_ADHAN,
    FRIDAY_BETWEEN_ADHANS,
    FRIDAY_SECOND_ADHAN,
    FRIDAY_IQAMA,
    FRIDAY_AFTER
}

data class DayPrayers(
    val day: Int,
    val fajrFirst: String,
    val fajrSecond: String,
    val sunrise: String,
    val dhuhr: String,
    val asr: String,
    val maghrib: String,
    val isha: String
)

data class MonthPrayers(
    val month: Int,
    val days: List<DayPrayers>
)

data class MosqueSchedule(
    val mosque: String = "اسم المسجد",
    val version: String = "2.0",
    val description: String = "",
    val months: List<MonthPrayers> = emptyList()
)

data class PrayerRowItem(
    val type: PrayerType,
    val name: String,
    val adhanTime: String,
    val iqamaTime: String,
    val isCurrent: Boolean,
    val isNext: Boolean,
    val isFriday: Boolean = false,
    val customIconUri: String? = null
)

data class ActiveCountdown(
    val title: String,
    val formattedTime: String,
    val secondsLeft: Long,
    val prayerName: String,
    val isIqamaCountdown: Boolean = false
)

data class GpsLocationData(
    val cityName: String,
    val latitude: Double,
    val longitude: Double,
    val calculationMethod: String = "MWL",
    val timestamp: Long = System.currentTimeMillis()
)
