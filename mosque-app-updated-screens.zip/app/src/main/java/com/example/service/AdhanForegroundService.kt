package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.database.ContentObserver
import android.media.AudioManager
import android.media.VolumeProvider
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.util.Log
import android.view.KeyEvent
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.audio.PrayerAudioPlaybackManager

class AdhanForegroundService : Service() {

    companion object {
        private const val TAG = "AdhanForegroundService"
        const val CHANNEL_ID = "prayer_times_adhan_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START_ADHAN = "com.example.action.START_ADHAN"
        const val ACTION_STOP_ADHAN = "com.example.action.STOP_ADHAN"

        const val EXTRA_PRAYER_ID = "extra_prayer_id"
        const val EXTRA_PRAYER_NAME = "extra_prayer_name"
        const val EXTRA_PRAYER_TIME = "extra_prayer_time"
        const val EXTRA_MOSQUE_NAME = "extra_mosque_name"
        const val EXTRA_IS_IQAMA = "extra_is_iqama"
        const val EXTRA_SOUND = "extra_sound"
    }

    private var wakeLock: PowerManager.WakeLock? = null
    private var mediaSession: MediaSession? = null
    private var isReceiverRegistered = false
    private var volumeObserver: ContentObserver? = null
    private var serviceStartTime = 0L

    private var initialMusicVolume = -1
    private var initialAlarmVolume = -1

    // BroadcastReceiver for system-wide volume button change notifications
    private val volumeChangeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == "android.media.VOLUME_CHANGED_ACTION") {
                val elapsed = System.currentTimeMillis() - serviceStartTime
                if (elapsed > 600L && PrayerAudioPlaybackManager.isAnyAudioPlaying()) {
                    Log.d(TAG, "Volume key change broadcast received (VOLUME_CHANGED_ACTION). Stopping audio.")
                    stopAdhanAndSelf()
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        serviceStartTime = System.currentTimeMillis()

        // 1. Acquire partial wake lock to keep CPU awake while phone screen is off
        val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
        wakeLock = powerManager?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MosquePrayer::AdhanWakeLock")
        try {
            wakeLock?.acquire(10 * 60 * 1000L) // Max 10 minutes safety cap
        } catch (e: Exception) {
            Log.w(TAG, "Could not acquire wake lock", e)
        }

        createNotificationChannel()

        // 2. Set up MediaSession with remote VolumeProvider to intercept hardware Volume Up / Down buttons
        setupMediaSession()

        // 3. Register broadcast receiver for volume changes
        registerVolumeChangeReceiver()

        // 4. Register content observer for system volume settings
        registerVolumeObserver()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_ADHAN) {
            stopAdhanAndSelf()
            return START_NOT_STICKY
        }

        val prayerId = intent?.getStringExtra(EXTRA_PRAYER_ID) ?: ""
        val prayerName = intent?.getStringExtra(EXTRA_PRAYER_NAME) ?: "الصلاة"
        val prayerTime = intent?.getStringExtra(EXTRA_PRAYER_TIME) ?: ""
        val mosqueName = intent?.getStringExtra(EXTRA_MOSQUE_NAME) ?: "المسجد"
        val isIqama = intent?.getBooleanExtra(EXTRA_IS_IQAMA, false) ?: false
        val sound = intent?.getStringExtra(EXTRA_SOUND)

        val notification = buildNotification(prayerName, prayerTime, mosqueName, isIqama)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        val played = if (isIqama) {
            PrayerAudioPlaybackManager.playIqamaOnce(
                context = applicationContext,
                prayerId = prayerId,
                soundUri = sound
            ) {
                stopAdhanAndSelf()
            }
        } else {
            PrayerAudioPlaybackManager.playAdhan(
                context = applicationContext,
                prayerId = prayerId,
                soundUri = sound
            ) {
                stopAdhanAndSelf()
            }
        }

        if (!played) {
            // Already played today, expired, or empty sound -> finish cleanly
            Handler(Looper.getMainLooper()).postDelayed({
                stopAdhanAndSelf()
            }, 1200L)
        }

        return START_NOT_STICKY
    }

    private fun setupMediaSession() {
        try {
            mediaSession = MediaSession(this, "AdhanVolumeInterceptorSession").apply {
                setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS or MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS)

                val playbackState = PlaybackState.Builder()
                    .setActions(
                        PlaybackState.ACTION_PLAY or
                        PlaybackState.ACTION_PAUSE or
                        PlaybackState.ACTION_STOP or
                        PlaybackState.ACTION_PLAY_PAUSE
                    )
                    .setState(PlaybackState.STATE_PLAYING, PlaybackState.PLAYBACK_POSITION_UNKNOWN, 1.0f)
                    .build()
                setPlaybackState(playbackState)

                // Remote volume provider: intercept volume up / down while session is active
                val volumeProvider = object : VolumeProvider(VOLUME_CONTROL_RELATIVE, 100, 50) {
                    override fun onAdjustVolume(direction: Int) {
                        val elapsed = System.currentTimeMillis() - serviceStartTime
                        if (elapsed > 300L && PrayerAudioPlaybackManager.isAnyAudioPlaying()) {
                            Log.d(TAG, "Hardware volume key pressed via MediaSession VolumeProvider (direction=$direction). Stopping audio.")
                            Handler(Looper.getMainLooper()).post {
                                stopAdhanAndSelf()
                            }
                        }
                    }
                }
                setPlaybackToRemote(volumeProvider)

                setCallback(object : MediaSession.Callback() {
                    override fun onStop() {
                        stopAdhanAndSelf()
                    }

                    override fun onPause() {
                        stopAdhanAndSelf()
                    }

                    override fun onMediaButtonEvent(mediaButtonIntent: Intent): Boolean {
                        val keyEvent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            mediaButtonIntent.getParcelableExtra(Intent.EXTRA_KEY_EVENT, KeyEvent::class.java)
                        } else {
                            @Suppress("DEPRECATION")
                            mediaButtonIntent.getParcelableExtra(Intent.EXTRA_KEY_EVENT)
                        }
                        if (keyEvent?.action == KeyEvent.ACTION_DOWN) {
                            when (keyEvent.keyCode) {
                                KeyEvent.KEYCODE_VOLUME_UP,
                                KeyEvent.KEYCODE_VOLUME_DOWN,
                                KeyEvent.KEYCODE_HEADSETHOOK,
                                KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
                                KeyEvent.KEYCODE_MEDIA_PAUSE,
                                KeyEvent.KEYCODE_MEDIA_STOP -> {
                                    Log.d(TAG, "Media key event ${keyEvent.keyCode} received. Stopping audio.")
                                    stopAdhanAndSelf()
                                    return true
                                }
                            }
                        }
                        return super.onMediaButtonEvent(mediaButtonIntent)
                    }
                })

                isActive = true
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize MediaSession", e)
        }
    }

    private fun registerVolumeChangeReceiver() {
        if (!isReceiverRegistered) {
            try {
                val filter = IntentFilter("android.media.VOLUME_CHANGED_ACTION")
                ContextCompat.registerReceiver(
                    this,
                    volumeChangeReceiver,
                    filter,
                    ContextCompat.RECEIVER_EXPORTED
                )
                isReceiverRegistered = true
            } catch (e: Exception) {
                Log.w(TAG, "Could not register volume change receiver", e)
            }
        }
    }

    private fun registerVolumeObserver() {
        try {
            val audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            initialMusicVolume = audioManager?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: -1
            initialAlarmVolume = audioManager?.getStreamVolume(AudioManager.STREAM_ALARM) ?: -1

            volumeObserver = object : ContentObserver(Handler(Looper.getMainLooper())) {
                override fun onChange(selfChange: Boolean) {
                    super.onChange(selfChange)
                    val elapsed = System.currentTimeMillis() - serviceStartTime
                    if (elapsed > 600L && PrayerAudioPlaybackManager.isAnyAudioPlaying()) {
                        val currMusic = audioManager?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: -1
                        val currAlarm = audioManager?.getStreamVolume(AudioManager.STREAM_ALARM) ?: -1
                        if (currMusic != initialMusicVolume || currAlarm != initialAlarmVolume) {
                            Log.d(TAG, "Volume change detected via ContentObserver. Stopping audio.")
                            stopAdhanAndSelf()
                        }
                    }
                }
            }
            contentResolver.registerContentObserver(
                Settings.System.CONTENT_URI,
                true,
                volumeObserver!!
            )
        } catch (e: Exception) {
            Log.w(TAG, "Could not register volume ContentObserver", e)
        }
    }

    private fun stopAdhanAndSelf() {
        PrayerAudioPlaybackManager.stopAll()

        if (isReceiverRegistered) {
            try {
                unregisterReceiver(volumeChangeReceiver)
            } catch (_: Exception) {}
            isReceiverRegistered = false
        }

        volumeObserver?.let {
            try {
                contentResolver.unregisterContentObserver(it)
            } catch (_: Exception) {}
            volumeObserver = null
        }

        mediaSession?.let {
            try {
                it.isActive = false
                it.release()
            } catch (_: Exception) {}
            mediaSession = null
        }

        if (wakeLock?.isHeld == true) {
            try {
                wakeLock?.release()
            } catch (_: Exception) {}
        }

        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun buildNotification(prayerName: String, prayerTime: String, mosqueName: String, isIqama: Boolean): Notification {
        val title = if (isIqama) "حان موعد إقامة $prayerName" else "حان موعد أذان $prayerName"
        val content = if (prayerTime.isNotEmpty()) "الوقت: $prayerTime | $mosqueName" else mosqueName

        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, AdhanForegroundService::class.java).apply {
            action = ACTION_STOP_ADHAN
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(content)
            .setSubText(mosqueName)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(openPendingIntent)
            .addAction(android.R.drawable.ic_media_pause, "إيقاف الصوت", stopPendingIntent)
            .setAutoCancel(false)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "تنبيهات الأذان والإقامة"
            val descriptionText = "قناة إشعارات أذان وإقامة المسجد بصوت مرتفع"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
                enableVibration(true)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        stopAdhanAndSelf()
    }
}
