package com.example.audio

import android.content.Context
import android.util.Log
import com.example.model.AudioFileItem
import com.example.model.DEFAULT_FAJR_FIRST_ID
import com.example.model.DEFAULT_FAJR_FIRST_NAME
import com.example.model.DEFAULT_FAJR_FIRST_URI
import java.io.File

/**
 * Metadata for any discovered audio file on the device or inside the project assets.
 */
data class DiscoveredAudio(
    val baseName: String,          // e.g. "أذان المسجد الأقصى - القدس" (extension removed)
    val normalizedKey: String,     // Normalized spaces, trimmed
    val fullFileName: String,      // e.g. "أذان المسجد الأقصى - القدس.mp3"
    val isAsset: Boolean,          // True if bundled in APK assets
    val assetPath: String? = null, // e.g. "Adhan/أذان المسجد الأقصى - القدس.mp3"
    val file: File? = null,        // File pointer if stored on filesystem
    val extension: String,         // "mp3", "wav", etc.
    val priority: Int              // MP3 = 1, WAV = 2, M4A = 3, OGG = 4
) {
    val uriString: String
        get() = if (isAsset) "asset:///${assetPath?.trimStart('/')}" else file?.absolutePath ?: ""
}

/**
 * Normalization helper adhering strictly to Arabic and audio matching rules:
 * 1. Strips extensions (.mp3, .wav, .m4a, .ogg, .aac, etc.)
 * 2. Normalizes whitespace and dashes
 * 3. Handles clean Arabic letter normalization for reliable matching
 */
object AudioNameNormalizer {
    private val EXTENSIONS = listOf(".mp3", ".wav", ".m4a", ".ogg", ".aac", ".flac", ".opus", ".m4r", ".wma")

    fun stripExtension(fileName: String): String {
        var name = fileName.trim()
        val lower = name.lowercase()
        for (ext in EXTENSIONS) {
            if (lower.endsWith(ext)) {
                return name.substring(0, name.length - ext.length).trim()
            }
        }
        val dotIndex = name.lastIndexOf('.')
        return if (dotIndex > 0) name.substring(0, dotIndex).trim() else name
    }

    fun getExtension(fileName: String): String {
        val dotIndex = fileName.lastIndexOf('.')
        return if (dotIndex >= 0 && dotIndex < fileName.length - 1) {
            fileName.substring(dotIndex + 1).lowercase().trim()
        } else ""
    }

    fun normalizeSpaces(text: String): String {
        return text.trim()
            .replace('\u00A0', ' ')
            .replace(Regex("\\s+"), " ")
    }

    fun normalizeArabic(text: String): String {
        return normalizeSpaces(text)
            .replace("ـ", "")
            .replace("[أإآ]".toRegex(), "ا")
            .replace("ة", "ه")
            .replace("ى", "ي")
            .replace("–", "-")
            .replace("—", "-")
            .replace("_", " ")
    }

    fun calculatePriority(extension: String): Int {
        return when (extension.lowercase()) {
            "mp3" -> 1
            "wav" -> 2
            "m4a" -> 3
            "ogg" -> 4
            "aac" -> 5
            else -> 10
        }
    }
}

/**
 * Built-in sound definition mapping project assets directly to their exact paths and identifiers.
 */
data class BuiltInSoundEntry(
    val id: String,
    val category: String, // "ADHAN", "FAJR", "IQAMA"
    val assetPath: String,
    val displayName: String,
    val aliases: List<String>
)

/**
 * Centralized Audio File Management System.
 * Connects written audio options and names in the UI directly to project audio files in assets.
 */
object AudioRegistry {

    private const val TAG = "AudioRegistry"

    val EXCLUSIVE_ADHAN_NAMES = listOf(
        "أذان المسجد الأقصى - القدس",
        "أذان المسجد النبوي - المدينة المنورة",
        "عبدالباسط عبدالصمد - أذان مصر",
        "علي بن أحمد ملا - المسجد الحرام",
        "ناصر القطامي - أذان"
    )

    val EXCLUSIVE_FAJR_NAMES = listOf(
        "أذان الفجر - المسجد الحرام",
        "أذان الفجر - الكويت",
        "أذان الفجر - المسجد النبوي"
    )

    val EXCLUSIVE_IQAMA_NAMES = listOf(
        "ياسر الدوسري - إقامة الصلاة"
    )

    // Comprehensive built-in catalog of the audio assets sent by the user
    val BUILT_IN_SOUNDS = listOf(
        // 1. General Adhan (5 files from user's zip)
        BuiltInSoundEntry(
            id = "adhan_aqsa",
            category = "ADHAN",
            assetPath = "Adhan/أذان المسجد الأقصى - القدس.mp3",
            displayName = "أذان المسجد الأقصى - القدس",
            aliases = listOf(
                "أذان المسجد الأقصى - القدس", "أذان المسجد الاقصى - القدس", "اذان المسجد الأقصى - القدس",
                "أذان المسجد الأقصى", "المسجد الأقصى", "القدس", "أقصى", "اقصى", "adhan_aqsa", "aqsa"
            )
        ),
        BuiltInSoundEntry(
            id = "adhan_nabawi",
            category = "ADHAN",
            assetPath = "Adhan/أذان المسجد النبوي - المدينة المنورة.mp3",
            displayName = "أذان المسجد النبوي - المدينة المنورة",
            aliases = listOf(
                "أذان المسجد النبوي - المدينة المنورة", "اذان المسجد النبوي - المدينة المنورة",
                "أذان المسجد النبوي", "المسجد النبوي", "المدينة المنورة", "النبوي", "adhan_nabawi", "nabawi", "madinah"
            )
        ),
        BuiltInSoundEntry(
            id = "adhan_abdulbasit",
            category = "ADHAN",
            assetPath = "Adhan/عبدالباسط عبدالصمد - أذان مصر.mp3",
            displayName = "عبدالباسط عبدالصمد - أذان مصر",
            aliases = listOf(
                "عبدالباسط عبدالصمد - أذان مصر", "عبدالباسط عبدالصمد - اذان مصر", "عبد الباسط عبد الصمد - أذان مصر",
                "عبدالباسط عبدالصمد", "أذان مصر", "اذان مصر", "مصر", "adhan_abdulbasit", "abdulbasit"
            )
        ),
        BuiltInSoundEntry(
            id = "adhan_mulla",
            category = "ADHAN",
            assetPath = "Adhan/علي بن أحمد ملا - المسجد الحرام.mp3",
            displayName = "علي بن أحمد ملا - المسجد الحرام",
            aliases = listOf(
                "علي بن أحمد ملا - المسجد الحرام", "علي بن احمد ملا - المسجد الحرام", "علي بن أحمد ملا", "علي ملا",
                "علي بن احمد ملا", "المسجد الحرام", "أذان الحرم المكي", "الحرم المكي", "adhan_mulla", "ali_mulla", "makkah"
            )
        ),
        BuiltInSoundEntry(
            id = "adhan_qatami",
            category = "ADHAN",
            assetPath = "Adhan/ناصر القطامي - أذان.mp3",
            displayName = "ناصر القطامي - أذان",
            aliases = listOf(
                "ناصر القطامي - أذان", "ناصر القطامي - اذان", "أذان ناصر القطامي", "ناصر القطامي", "القطامي",
                "adhan_qatami", "qatami"
            )
        ),

        // 2. Fajr First Adhan (Exclusively the 3 files put by the user in AdhanFajr)
        BuiltInSoundEntry(
            id = DEFAULT_FAJR_FIRST_ID,
            category = "FAJR",
            assetPath = "AdhanFajr/أذان الفجر - المسجد الحرام.mp3",
            displayName = "أذان الفجر - المسجد الحرام",
            aliases = listOf(
                "أذان الفجر - المسجد الحرام", "أذان الفجر المسجد الحرام", "أذان الفجر الحرم المكي",
                "المسجد الحرام فجر", "المسجد الحرام", "fajr_haram", "fajr_assaf", "Yaseen Al Aassaf - Fajr Iraq",
                "Yaseen Al Aassaf", "أذان الفجر ياسين العساف", "أذان الفجر علي ملا"
            )
        ),
        BuiltInSoundEntry(
            id = "fajr_kuwait",
            category = "FAJR",
            assetPath = "AdhanFajr/أذان الفجر - الكويت.mp3",
            displayName = "أذان الفجر - الكويت",
            aliases = listOf(
                "أذان الفجر - الكويت", "أذان الفجر الكويت", "الكويت فجر", "الكويت", "fajr_kuwait",
                "أذان الفجر عبدالباسط عبدالصمد"
            )
        ),
        BuiltInSoundEntry(
            id = "fajr_nabawi",
            category = "FAJR",
            assetPath = "AdhanFajr/أذان الفجر - المسجد النبوي.mp3",
            displayName = "أذان الفجر - المسجد النبوي",
            aliases = listOf(
                "أذان الفجر - المسجد النبوي", "أذان الفجر المسجد النبوي", "المسجد النبوي فجر", "المسجد النبوي",
                "المدينة المنورة", "fajr_nabawi", "أذان الفجر ياسر الدوسري"
            )
        ),

        // 3. Iqama (Exclusively the audio file sent by the user)
        BuiltInSoundEntry(
            id = "iqama_dossari",
            category = "IQAMA",
            assetPath = "Iqama/ياسر الدوسري - إقامة الصلاة.mp3",
            displayName = "ياسر الدوسري - إقامة الصلاة",
            aliases = listOf(
                "ياسر الدوسري - إقامة الصلاة", "ياسر الدوسري - اقامة الصلاة", "ياسر الدوسري - إقامة",
                "إقامة ياسر الدوسري", "اقامة ياسر الدوسري", "ياسر الدوسري", "الدوسري", "iqama_dossari", "dossari"
            )
        )
    )

    // Primary central maps
    private val audioFiles = mutableMapOf<String, DiscoveredAudio>()
    private val allAudios = mutableListOf<DiscoveredAudio>()
    private val aliasMap = mutableMapOf<String, DiscoveredAudio>()
    private var isInitialized = false

    init {
        // Pre-register all built-in audio entries statically so matching works immediately
        registerBuiltInCatalogue()
    }

    private fun registerBuiltInCatalogue() {
        for (entry in BUILT_IN_SOUNDS) {
            val fileName = entry.assetPath.substringAfterLast('/')
            val baseName = entry.displayName
            val normalizedKey = AudioNameNormalizer.normalizeSpaces(baseName)
            val ext = "mp3"
            val discovered = DiscoveredAudio(
                baseName = baseName,
                normalizedKey = normalizedKey,
                fullFileName = fileName,
                isAsset = true,
                assetPath = entry.assetPath,
                file = null,
                extension = ext,
                priority = 1
            )
            allAudios.add(discovered)
            audioFiles[normalizedKey] = discovered
            audioFiles[baseName] = discovered
            audioFiles[fileName] = discovered
            audioFiles[entry.id] = discovered
            audioFiles["asset:///${entry.assetPath}"] = discovered
            audioFiles[entry.assetPath] = discovered

            // Register all aliases
            for (alias in entry.aliases) {
                aliasMap[AudioNameNormalizer.normalizeSpaces(alias)] = discovered
                aliasMap[AudioNameNormalizer.normalizeArabic(alias)] = discovered
                aliasMap[alias.trim().lowercase()] = discovered
            }
        }
    }

    @Synchronized
    fun initialize(context: Context) {
        if (isInitialized) return
        rescan(context)
        isInitialized = true
    }

    @Synchronized
    fun rescan(context: Context) {
        audioFiles.clear()
        allAudios.clear()
        aliasMap.clear()

        // 1. Re-register built-in entries
        registerBuiltInCatalogue()

        // 2. Dynamic Asset Scanning
        scanAssets(context)

        // 3. Internal App Files Scanning
        scanInternalStorage(context)

        // 4. External App Files Scanning
        scanExternalStorage(context)

        Log.i(TAG, "AudioRegistry scan complete: ${allAudios.size} files, ${audioFiles.size} keys, ${aliasMap.size} aliases.")
    }

    private fun scanAssets(context: Context) {
        try {
            val rootDirs = listOf("", "Adhan", "AdhanFajr", "Iqama", "audio", "adhan", "iqama", "fajr")
            val visited = mutableSetOf<String>()

            for (dir in rootDirs) {
                scanAssetDirRecursively(context, dir, visited)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error scanning assets", e)
        }

        // Fallback to local asset directories for JVM unit tests / dev environments
        try {
            val devDirs = listOf(
                File("src/main/assets"),
                File("app/src/main/assets"),
                File("../app/src/main/assets"),
                File("/app/applet/app/src/main/assets")
            )
            for (devDir in devDirs) {
                if (devDir.exists() && devDir.isDirectory) {
                    scanFileDirRecursively(devDir)
                }
            }
        } catch (_: Exception) {}
    }

    private fun scanAssetDirRecursively(context: Context, dir: String, visited: MutableSet<String>) {
        try {
            val list = context.assets.list(dir) ?: return
            for (item in list) {
                val fullPath = if (dir.isEmpty()) item else "$dir/$item"
                if (!visited.add(fullPath)) continue

                val ext = AudioNameNormalizer.getExtension(item)
                if (ext in listOf("mp3", "wav", "m4a", "ogg", "aac", "flac", "opus")) {
                    registerFile(
                        fileName = item,
                        isAsset = true,
                        assetPath = fullPath,
                        file = null,
                        extension = ext
                    )
                } else if (!item.contains(".")) {
                    scanAssetDirRecursively(context, fullPath, visited)
                }
            }
        } catch (_: Exception) {}
    }

    private fun scanInternalStorage(context: Context) {
        try {
            val dirs = listOf(
                context.filesDir,
                File(context.filesDir, "audio"),
                File(context.filesDir, "adhan"),
                File(context.filesDir, "iqama"),
                File(context.filesDir, "fajr")
            )
            for (d in dirs) {
                if (d.exists() && d.isDirectory) {
                    scanFileDirRecursively(d)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error scanning internal storage", e)
        }
    }

    private fun scanExternalStorage(context: Context) {
        try {
            val extDirs = listOf(
                context.getExternalFilesDir(null),
                context.getExternalFilesDir("audio"),
                context.getExternalFilesDir("adhan"),
                context.getExternalFilesDir("iqama"),
                context.getExternalFilesDir("fajr")
            )
            for (d in extDirs) {
                if (d != null && d.exists() && d.isDirectory) {
                    scanFileDirRecursively(d)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error scanning external storage", e)
        }
    }

    private fun scanFileDirRecursively(dir: File, baseDir: File = dir) {
        val files = dir.listFiles() ?: return
        for (f in files) {
            if (f.isDirectory) {
                scanFileDirRecursively(f, baseDir)
            } else {
                val ext = AudioNameNormalizer.getExtension(f.name)
                if (ext in listOf("mp3", "wav", "m4a", "ogg", "aac", "flac", "opus")) {
                    val isAssetDir = baseDir.path.contains("assets")
                    val relPath = if (isAssetDir) f.relativeTo(baseDir).path.replace('\\', '/') else null
                    registerFile(
                        fileName = f.name,
                        isAsset = isAssetDir,
                        assetPath = relPath,
                        file = f,
                        extension = ext
                    )
                }
            }
        }
    }

    private fun registerFile(
        fileName: String,
        isAsset: Boolean,
        assetPath: String?,
        file: File?,
        extension: String
    ) {
        val simpleFileName = fileName.substringAfterLast('/').substringAfterLast('\\')
        val baseName = AudioNameNormalizer.stripExtension(simpleFileName)
        val normalizedKey = AudioNameNormalizer.normalizeSpaces(baseName)
        val priority = AudioNameNormalizer.calculatePriority(extension)

        val cleanAssetPath = assetPath?.trimStart('/') ?: fileName.trimStart('/')

        val discovered = DiscoveredAudio(
            baseName = baseName,
            normalizedKey = normalizedKey,
            fullFileName = simpleFileName,
            isAsset = isAsset,
            assetPath = cleanAssetPath,
            file = file,
            extension = extension,
            priority = priority
        )

        allAudios.add(discovered)

        val existing = audioFiles[normalizedKey]
        if (existing == null || priority < existing.priority) {
            audioFiles[normalizedKey] = discovered
            audioFiles[baseName] = discovered
            audioFiles[simpleFileName] = discovered
            audioFiles[cleanAssetPath] = discovered
            audioFiles["asset:///$cleanAssetPath"] = discovered
        }
    }

    /**
     * Resolves matching audio for any option name, preset ID, or URI.
     */
    fun findMatchedAudio(soundOptionNameOrUri: String?): DiscoveredAudio? {
        if (soundOptionNameOrUri.isNullOrBlank()) return null
        val query = soundOptionNameOrUri.trim()
        if (query == "لم يتم اختيار صوت") return null

        // 1. Direct filesystem check
        if (query.startsWith("/") || query.startsWith("file://")) {
            val f = File(query.removePrefix("file://"))
            if (f.exists() && f.isFile) {
                val ext = AudioNameNormalizer.getExtension(f.name)
                val base = AudioNameNormalizer.stripExtension(f.name)
                return DiscoveredAudio(
                    baseName = base,
                    normalizedKey = AudioNameNormalizer.normalizeSpaces(base),
                    fullFileName = f.name,
                    isAsset = false,
                    assetPath = null,
                    file = f,
                    extension = ext,
                    priority = AudioNameNormalizer.calculatePriority(ext)
                )
            }
        }

        // 2. Direct asset URI check
        if (query.startsWith("asset:///")) {
            val aPath = query.removePrefix("asset:///").trimStart('/')
            val found = allAudios.firstOrNull { it.assetPath?.trimStart('/') == aPath }
            if (found != null) return found
        }

        // 3. Exact preset ID match from built-in entries
        val entryById = BUILT_IN_SOUNDS.firstOrNull { it.id.equals(query, ignoreCase = true) }
        if (entryById != null) {
            val found = allAudios.firstOrNull { it.assetPath == entryById.assetPath }
            if (found != null) return found
        }

        // 4. Exact dictionary lookup
        audioFiles[query]?.let { return it }

        val rawBase = AudioNameNormalizer.stripExtension(query.substringAfterLast("/"))
        val normQuery = AudioNameNormalizer.normalizeSpaces(rawBase)
        audioFiles[normQuery]?.let { return it }

        // 5. Look up in aliasMap
        aliasMap[normQuery]?.let { return it }
        aliasMap[AudioNameNormalizer.normalizeArabic(normQuery)]?.let { return it }
        aliasMap[normQuery.lowercase()]?.let { return it }

        // 6. Case-insensitive exact match
        audioFiles.entries.firstOrNull {
            it.key.equals(normQuery, ignoreCase = true)
        }?.value?.let { return it }

        // 7. Arabic letter normalization match
        val arabicNormQuery = AudioNameNormalizer.normalizeArabic(rawBase)
        val arabicMatch = audioFiles.entries.firstOrNull { (k, _) ->
            AudioNameNormalizer.normalizeArabic(k) == arabicNormQuery
        }?.value
        if (arabicMatch != null) return arabicMatch

        // 8. Prefix-tolerant matching
        val prefixes = listOf(
            "أذان الفجر الأول ",
            "أذان الفجر ",
            "اذان الفجر ",
            "أذان ",
            "اذان ",
            "إقامة ",
            "اقامة ",
            "صوت أذان ",
            "صوت إقامة ",
            "صوت "
        )

        for (p in prefixes) {
            if (normQuery.startsWith(p)) {
                val trimmedQuery = AudioNameNormalizer.normalizeSpaces(normQuery.removePrefix(p))
                audioFiles[trimmedQuery]?.let { return it }
                val trimmedArabic = AudioNameNormalizer.normalizeArabic(trimmedQuery)
                audioFiles.entries.firstOrNull {
                    AudioNameNormalizer.normalizeArabic(it.key) == trimmedArabic
                }?.value?.let { return it }
            }
        }

        for ((key, audio) in audioFiles) {
            for (p in prefixes) {
                if (key.startsWith(p)) {
                    val keyWithoutPrefix = AudioNameNormalizer.normalizeSpaces(key.removePrefix(p))
                    if (keyWithoutPrefix == normQuery ||
                        AudioNameNormalizer.normalizeArabic(keyWithoutPrefix) == arabicNormQuery
                    ) {
                        return audio
                    }
                }
            }
        }

        // 9. Built-in sound entries fallback check
        for (entry in BUILT_IN_SOUNDS) {
            if (entry.displayName == rawBase || entry.assetPath.endsWith(query) ||
                AudioNameNormalizer.normalizeArabic(entry.displayName) == arabicNormQuery
            ) {
                return allAudios.firstOrNull { it.assetPath == entry.assetPath }
            }
            if (entry.aliases.any { alias ->
                AudioNameNormalizer.normalizeArabic(alias) == arabicNormQuery ||
                normQuery.contains(alias, ignoreCase = true)
            }) {
                return allAudios.firstOrNull { it.assetPath == entry.assetPath }
            }
        }

        return null
    }

    /**
     * Checks whether an audio file is matched for this sound option name or URI.
     */
    fun isAudioMatched(soundOptionNameOrUri: String?): Boolean {
        return findMatchedAudio(soundOptionNameOrUri) != null
    }

    /**
     * Returns a playable local File for the given DiscoveredAudio.
     * Guaranteed to work across runtime emulator, physical devices, and local JVM tests.
     */
    fun getPlayableFile(context: Context, audio: DiscoveredAudio): File? {
        if (!audio.isAsset && audio.file != null && audio.file.exists() && audio.file.length() > 0) {
            return audio.file
        }

        val cleanPath = (audio.assetPath ?: audio.fullFileName).trimStart('/')

        // 1. Check if the file is directly accessible on the host filesystem (Robolectric / dev)
        val devDirs = listOf(
            File("src/main/assets"),
            File("app/src/main/assets"),
            File("../app/src/main/assets"),
            File("/app/src/main/assets"),
            File("/app/applet/app/src/main/assets")
        )
        for (dir in devDirs) {
            val f = File(dir, cleanPath)
            if (f.exists() && f.length() > 0) {
                return f
            }
        }

        // 2. Extract from assets to cache directory
        return try {
            val cacheDir = File(context.cacheDir, "audio_cache").apply { mkdirs() }
            val safeName = audio.fullFileName.replace(Regex("[^a-zA-Z0-9._\\-\\u0600-\\u06FF]"), "_")
            val targetFile = File(cacheDir, safeName)

            if (!targetFile.exists() || targetFile.length() == 0L) {
                val inputStream = try {
                    context.assets.open(cleanPath)
                } catch (e: Exception) {
                    val parent = if (cleanPath.contains('/')) cleanPath.substringBeforeLast('/') else ""
                    val fileName = cleanPath.substringAfterLast('/')
                    val normTarget = AudioNameNormalizer.normalizeArabic(AudioNameNormalizer.stripExtension(fileName))
                    val list = context.assets.list(parent) ?: emptyArray()
                    val matchInDir = list.firstOrNull { nameInDir ->
                        nameInDir == fileName ||
                        AudioNameNormalizer.normalizeArabic(AudioNameNormalizer.stripExtension(nameInDir)) == normTarget
                    } ?: list.firstOrNull { it.endsWith(".mp3") }

                    if (matchInDir != null) {
                        val resolvedPath = if (parent.isEmpty()) matchInDir else "$parent/$matchInDir"
                        context.assets.open(resolvedPath)
                    } else {
                        throw e
                    }
                }

                inputStream.use { input ->
                    targetFile.outputStream().use { output ->
                        input.copyTo(output)
                    }
                }
            }
            if (targetFile.exists() && targetFile.length() > 0) targetFile else null
        } catch (e: Exception) {
            Log.e(TAG, "Failed to prepare playable file from asset: $cleanPath", e)
            null
        }
    }

    /**
     * Returns all discovered audios as selectable AudioFileItem objects.
     */
    fun getAllDiscoveredItems(): List<AudioFileItem> {
        return audioFiles.values.distinctBy { it.normalizedKey }.map { audio ->
            AudioFileItem(
                id = "discovered_${audio.normalizedKey.hashCode()}",
                name = audio.baseName,
                uri = audio.uriString
            )
        }.sortedBy { it.name }
    }

    /**
     * Filters discovered audios for General Adhan.
     * Contains EXCLUSIVELY the designated 5 Adhans + any custom user audios.
     */
    fun getDiscoveredAdhanItems(): List<AudioFileItem> {
        val normalizedExclusive = EXCLUSIVE_ADHAN_NAMES.map { AudioNameNormalizer.normalizeSpaces(it) }.toSet()

        val builtInItems = EXCLUSIVE_ADHAN_NAMES.mapNotNull { name ->
            val match = findMatchedAudio(name) ?: return@mapNotNull null
            AudioFileItem(
                id = "adhan_${match.normalizedKey.hashCode()}",
                name = match.baseName,
                uri = match.uriString,
                isBuiltIn = true
            )
        }

        val customItems = allAudios.filter { audio ->
            !audio.isAsset &&
            !audio.baseName.contains("فجر") &&
            !audio.baseName.contains("إقامة") &&
            !audio.baseName.contains("اقامة")
        }.map { audio ->
            AudioFileItem(
                id = "adhan_custom_${audio.normalizedKey.hashCode()}",
                name = audio.baseName,
                uri = audio.uriString,
                isBuiltIn = false
            )
        }

        return (builtInItems + customItems).distinctBy { it.name }
    }

    /**
     * Filters discovered audios for Iqama (6 built-in files + custom user iqamas).
     */
    fun getDiscoveredIqamaItems(): List<AudioFileItem> {
        val builtInItems = EXCLUSIVE_IQAMA_NAMES.mapNotNull { name ->
            val match = findMatchedAudio(name) ?: return@mapNotNull null
            AudioFileItem(
                id = "iqama_${match.normalizedKey.hashCode()}",
                name = match.baseName,
                uri = match.uriString,
                isBuiltIn = true,
                isDefault = match.baseName.contains("ياسر الدوسري")
            )
        }

        val customItems = allAudios.filter { audio ->
            !audio.isAsset &&
            (audio.baseName.contains("إقامة") || audio.baseName.contains("اقامة"))
        }.map { audio ->
            AudioFileItem(
                id = "iqama_custom_${audio.normalizedKey.hashCode()}",
                name = audio.baseName,
                uri = audio.uriString,
                isBuiltIn = false,
                isDefault = false
            )
        }

        return (builtInItems + customItems).distinctBy { it.name }
            .sortedWith(compareByDescending<AudioFileItem> { it.isDefault }.thenBy { it.name })
    }

    /**
     * Returns discovered audio items for Fajr First (Exclusively the 3 built-in files + custom user fajr files).
     */
    fun getDiscoveredFajrItems(): List<AudioFileItem> {
        val builtInItems = EXCLUSIVE_FAJR_NAMES.mapNotNull { name ->
            val match = findMatchedAudio(name) ?: return@mapNotNull null
            val isHaram = match.baseName.contains("المسجد الحرام")
            AudioFileItem(
                id = if (isHaram) DEFAULT_FAJR_FIRST_ID else "fajr_${match.normalizedKey.hashCode()}",
                name = match.baseName,
                uri = match.uriString,
                isBuiltIn = true,
                isDefault = isHaram
            )
        }

        val customItems = allAudios.filter { audio ->
            !audio.isAsset &&
            (audio.baseName.contains("فجر") || audio.baseName.contains("fajr", ignoreCase = true))
        }.map { audio ->
            AudioFileItem(
                id = "fajr_custom_${audio.normalizedKey.hashCode()}",
                name = audio.baseName,
                uri = audio.uriString,
                isBuiltIn = false,
                isDefault = false
            )
        }

        return (builtInItems + customItems).distinctBy { it.name }
            .sortedWith(compareByDescending<AudioFileItem> { it.isDefault }.thenBy { it.name })
    }
}
