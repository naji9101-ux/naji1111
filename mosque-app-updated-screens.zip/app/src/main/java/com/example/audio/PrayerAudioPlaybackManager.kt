package com.example.audio

import android.content.Context
import android.util.Log
import java.time.LocalDate

/**
 * Unified Audio Playback Manager for Adhan and Iqama.
 * Serves as the single source of truth for scheduled audio playback,
 * preventing duplicate playback, overlapping audio, or playback of late/expired Iqama times.
 */
object PrayerAudioPlaybackManager {

    private const val TAG = "PrayerAudioPlayback"
    private const val PREFS_NAME = "prayer_audio_playback_prefs"
    private const val KEY_PREFIX_IQAMA = "iqama_played_"

    @Volatile
    private var currentPlayer: AdhanPlayer? = null

    @Volatile
    private var isPlaying = false

    @Volatile
    private var currentPlayingType: String? = null // "ADHAN", "IQAMA", or null

    @Volatile
    private var currentPrayerId: String? = null

    /**
     * Checks if this prayer's Iqama has already been played today.
     */
    fun hasIqamaPlayedToday(context: Context, prayerId: String, dateStr: String = LocalDate.now().toString()): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean("${KEY_PREFIX_IQAMA}${dateStr}_${prayerId}", false)
    }

    /**
     * Marks this prayer's Iqama as already played today.
     */
    fun markIqamaPlayedToday(context: Context, prayerId: String, dateStr: String = LocalDate.now().toString()) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putBoolean("${KEY_PREFIX_IQAMA}${dateStr}_${prayerId}", true)
            .putLong("timestamp_${dateStr}_${prayerId}", System.currentTimeMillis())
            .apply()
    }

    /**
     * Whether any prayer audio is currently playing.
     */
    fun isAnyAudioPlaying(): Boolean = isPlaying

    /**
     * Whether an Iqama audio is currently active.
     */
    fun isIqamaCurrentlyPlaying(): Boolean = isPlaying && currentPlayingType == "IQAMA"

    /**
     * Plays Iqama audio strictly once per prayer per day.
     * Rejects playback if already played today, if another Iqama is currently playing,
     * or if scheduled time has passed by more than [maxLateSeconds].
     */
    @Synchronized
    fun playIqamaOnce(
        context: Context,
        prayerId: String,
        soundUri: String?,
        scheduledEpochMs: Long? = null,
        maxLateSeconds: Long = 30L,
        onCompletion: (() -> Unit)? = null
    ): Boolean {
        val todayStr = LocalDate.now().toString()

        // 1. Verify if already played today
        if (hasIqamaPlayedToday(context, prayerId, todayStr)) {
            Log.d(TAG, "Iqama for $prayerId has already been played today ($todayStr). Suppressing playback.")
            return false
        }

        // 2. Verify if the scheduled time has expired/passed too long ago
        if (scheduledEpochMs != null) {
            val nowMs = System.currentTimeMillis()
            val diffMs = nowMs - scheduledEpochMs
            if (diffMs > maxLateSeconds * 1000L || diffMs < -60_000L) {
                Log.d(TAG, "Iqama scheduled time out of playback window (diff: ${diffMs}ms). Suppressing late playback.")
                return false
            }
        }

        // 3. If Iqama for this exact prayer is currently playing, don't start duplicate
        if (isPlaying && currentPlayingType == "IQAMA" && currentPrayerId == prayerId) {
            Log.d(TAG, "Iqama for $prayerId is currently playing. Suppressing duplicate playback.")
            return false
        }

        // 4. Mark as played BEFORE starting so no concurrent triggers can sneak in
        markIqamaPlayedToday(context, prayerId, todayStr)

        if (soundUri.isNullOrBlank() || soundUri == "لم يتم اختيار صوت") {
            Log.d(TAG, "No sound selected for Iqama $prayerId. Marked as played without sound.")
            return false
        }

        // 5. Stop any existing audio before starting the new sound
        stopAll()

        val player = AdhanPlayer(context)
        currentPlayer = player
        isPlaying = true
        currentPlayingType = "IQAMA"
        currentPrayerId = prayerId

        val started = player.playAdhan(soundUri) {
            synchronized(this) {
                if (currentPlayer === player) {
                    isPlaying = false
                    currentPlayingType = null
                    currentPrayerId = null
                    currentPlayer = null
                }
            }
            onCompletion?.invoke()
        }

        if (!started) {
            synchronized(this) {
                if (currentPlayer === player) {
                    isPlaying = false
                    currentPlayingType = null
                    currentPrayerId = null
                    currentPlayer = null
                }
            }
        }

        return started
    }

    /**
     * Plays Adhan audio, stopping previous audio first.
     */
    @Synchronized
    fun playAdhan(
        context: Context,
        prayerId: String,
        soundUri: String?,
        onCompletion: (() -> Unit)? = null
    ): Boolean {
        if (soundUri.isNullOrBlank() || soundUri == "لم يتم اختيار صوت") {
            return false
        }

        // Stop any previous audio
        stopAll()

        val player = AdhanPlayer(context)
        currentPlayer = player
        isPlaying = true
        currentPlayingType = "ADHAN"
        currentPrayerId = prayerId

        val started = player.playAdhan(soundUri) {
            synchronized(this) {
                if (currentPlayer === player) {
                    isPlaying = false
                    currentPlayingType = null
                    currentPrayerId = null
                    currentPlayer = null
                }
            }
            onCompletion?.invoke()
        }

        if (!started) {
            synchronized(this) {
                if (currentPlayer === player) {
                    isPlaying = false
                    currentPlayingType = null
                    currentPrayerId = null
                    currentPlayer = null
                }
            }
        }

        return started
    }

    /**
     * Stops any currently playing Adhan or Iqama audio.
     */
    @Synchronized
    fun stopAll() {
        try {
            currentPlayer?.stop()
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping current player", e)
        }
        currentPlayer = null
        isPlaying = false
        currentPlayingType = null
        currentPrayerId = null
    }
}
