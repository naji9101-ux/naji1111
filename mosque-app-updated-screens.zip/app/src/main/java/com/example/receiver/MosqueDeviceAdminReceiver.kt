package com.example.receiver

import android.app.admin.DeviceAdminReceiver

/**
 * مستقبِل مسؤول الجهاز. وجوده شرط لتعيين التطبيق كـ Device Owner، وهو الطريقة الوحيدة
 * في Android للحصول على قفل كامل حقيقي (Lock Task Mode) بدون تأكيد من المستخدم.
 */
class MosqueDeviceAdminReceiver : DeviceAdminReceiver()
