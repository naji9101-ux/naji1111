package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.example.alarm.PrayerAlarmScheduler
import com.example.util.AutoLaunchManager

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == "android.intent.action.LOCKED_BOOT_COMPLETED" ||
            action == "android.intent.action.QUICKBOOT_POWERON" ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED
        ) {
            Log.d("BootReceiver", "Device booted or app replaced, rescheduling prayer alarms")
            com.example.util.IqamaSilentModeManager.restorePreviousAudioState(context)
            PrayerAlarmScheduler.scheduleAllPrayers(context)

            // التشغيل التلقائي: بعد فتح تخزين المستخدم فقط (BOOT_COMPLETED) حتى تُقرأ الإعدادات الصحيحة.
            if (action == "android.intent.action.LOCKED_BOOT_COMPLETED") return

            try {
                if (AutoLaunchManager.isAutoStartEnabled(context)) {
                    // مهلة قصيرة ليكتمل إقلاع الواجهة (خصوصاً على صناديق Android TV)
                    val pending = goAsync()
                    Handler(Looper.getMainLooper()).postDelayed({
                        try {
                            AutoLaunchManager.launchIfEnabled(context.applicationContext)
                        } catch (e: Exception) {
                            Log.e("BootReceiver", "Error during boot auto-start", e)
                        } finally {
                            pending.finish()
                        }
                    }, 2500L)
                }
            } catch (e: Exception) {
                Log.e("BootReceiver", "Error during boot auto-start check", e)
            }
        }
    }
}
