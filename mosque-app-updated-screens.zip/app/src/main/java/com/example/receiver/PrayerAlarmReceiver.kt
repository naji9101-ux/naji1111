package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.alarm.PrayerAlarmScheduler
import com.example.service.AdhanForegroundService

class PrayerAlarmReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_RESTORE_IQAMA_SILENT = "com.example.ACTION_RESTORE_IQAMA_SILENT"
        const val EXTRA_PRAYER_ID = "extra_prayer_id"
        const val EXTRA_PRAYER_NAME = "extra_prayer_name"
        const val EXTRA_PRAYER_TIME = "extra_prayer_time"
        const val EXTRA_MOSQUE_NAME = "extra_mosque_name"
        const val EXTRA_IS_IQAMA = "extra_is_iqama"
        const val EXTRA_SOUND_URI = "extra_sound_uri"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ACTION_RESTORE_IQAMA_SILENT) {
            com.example.util.IqamaSilentModeManager.restorePreviousAudioState(context)
            return
        }

        val prayerId = intent.getStringExtra(EXTRA_PRAYER_ID) ?: ""
        val prayerName = intent.getStringExtra(EXTRA_PRAYER_NAME) ?: "الصلاة"
        val prayerTime = intent.getStringExtra(EXTRA_PRAYER_TIME) ?: ""
        val mosqueName = intent.getStringExtra(EXTRA_MOSQUE_NAME) ?: "المسجد"
        val isIqama = intent.getBooleanExtra(EXTRA_IS_IQAMA, false)
        val soundUri = intent.getStringExtra(EXTRA_SOUND_URI)

        if (isIqama) {
            com.example.util.IqamaSilentModeManager.enableSilentMode(context)
        }

        val serviceIntent = Intent(context, AdhanForegroundService::class.java).apply {
            action = AdhanForegroundService.ACTION_START_ADHAN
            putExtra(AdhanForegroundService.EXTRA_PRAYER_ID, prayerId)
            putExtra(AdhanForegroundService.EXTRA_PRAYER_NAME, prayerName)
            putExtra(AdhanForegroundService.EXTRA_PRAYER_TIME, prayerTime)
            putExtra(AdhanForegroundService.EXTRA_MOSQUE_NAME, mosqueName)
            putExtra(AdhanForegroundService.EXTRA_IS_IQAMA, isIqama)
            putExtra(AdhanForegroundService.EXTRA_SOUND, soundUri)
        }

        try {
            ContextCompat.startForegroundService(context, serviceIntent)
        } catch (e: Exception) {
            Log.e("PrayerAlarmReceiver", "Failed to start foreground service for adhan", e)
        }

        // Ensure next prayer alarms are up to date
        PrayerAlarmScheduler.scheduleAllPrayers(context)
    }
}
