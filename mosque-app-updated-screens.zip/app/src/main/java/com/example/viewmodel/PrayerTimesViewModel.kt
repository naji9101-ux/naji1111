package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.alarm.PrayerAlarmScheduler
import com.example.audio.AdhanPlayer
import com.example.data.HijriCalendarHelper
import com.example.data.PrayerCalculator
import com.example.data.PrayerRepository
import com.example.model.*
import com.example.util.IqamaSilentModeManager
import com.example.util.LocationHelper
import com.example.util.LocationResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

class PrayerTimesViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = PrayerRepository(application)
    val adhanPlayer = AdhanPlayer(application)

    private val _schedule = MutableStateFlow(repository.loadSchedule())
    val schedule: StateFlow<MosqueSchedule> = _schedule.asStateFlow()

    private val _settings = MutableStateFlow(repository.loadSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private val _currentTimeFormatted = MutableStateFlow("00:00:00")
    val currentTimeFormatted: StateFlow<String> = _currentTimeFormatted.asStateFlow()

    private val _dayOfWeekArabic = MutableStateFlow("")
    val dayOfWeekArabic: StateFlow<String> = _dayOfWeekArabic.asStateFlow()

    private val _hijriDate = MutableStateFlow("")
    val hijriDate: StateFlow<String> = _hijriDate.asStateFlow()

    private val _gregorianDate = MutableStateFlow("")
    val gregorianDate: StateFlow<String> = _gregorianDate.asStateFlow()

    private val _prayerRows = MutableStateFlow<List<PrayerRowItem>>(emptyList())
    val prayerRows: StateFlow<List<PrayerRowItem>> = _prayerRows.asStateFlow()

    private val _adhanCountdown = MutableStateFlow<ActiveCountdown?>(null)
    val adhanCountdown: StateFlow<ActiveCountdown?> = _adhanCountdown.asStateFlow()

    private val _nextUpcomingPrayerType = MutableStateFlow<PrayerType>(PrayerType.FAJR_SECOND)
    val nextUpcomingPrayerType: StateFlow<PrayerType> = _nextUpcomingPrayerType.asStateFlow()

    private val _iqamaCountdown = MutableStateFlow<ActiveCountdown?>(null)
    val iqamaCountdown: StateFlow<ActiveCountdown?> = _iqamaCountdown.asStateFlow()

    private val _prayerState = MutableStateFlow(PrayerState.NORMAL)
    val prayerState: StateFlow<PrayerState> = _prayerState.asStateFlow()

    private val _currentActivePrayerName = MutableStateFlow("")
    val currentActivePrayerName: StateFlow<String> = _currentActivePrayerName.asStateFlow()

    private val _isIqamaNow = MutableStateFlow(false)
    val isIqamaNow: StateFlow<Boolean> = _isIqamaNow.asStateFlow()

    private val _currentTickerMessage = MutableStateFlow("")
    val currentTickerMessage: StateFlow<String> = _currentTickerMessage.asStateFlow()

    private val _selectedPrayerForDetail = MutableStateFlow<PrayerRowItem?>(null)
    val selectedPrayerForDetail: StateFlow<PrayerRowItem?> = _selectedPrayerForDetail.asStateFlow()

    private val _isPlayingAdhanSound = MutableStateFlow(false)
    val isPlayingAdhanSound: StateFlow<Boolean> = _isPlayingAdhanSound.asStateFlow()

    private val _isIqamaScreenActive = MutableStateFlow(false)
    val isIqamaScreenActive: StateFlow<Boolean> = _isIqamaScreenActive.asStateFlow()

    private val _activeIqamaPrayerType = MutableStateFlow<PrayerType?>(null)
    val activeIqamaPrayerType: StateFlow<PrayerType?> = _activeIqamaPrayerType.asStateFlow()

    private val _isPreviewingIqamaScreen = MutableStateFlow(false)
    val isPreviewingIqamaScreen: StateFlow<Boolean> = _isPreviewingIqamaScreen.asStateFlow()

    private val _previewIqamaPrayerType = MutableStateFlow<PrayerType?>(null)
    val previewIqamaPrayerType: StateFlow<PrayerType?> = _previewIqamaPrayerType.asStateFlow()

    private val _iqamaScreenSecondsRemaining = MutableStateFlow(0L)
    val iqamaScreenSecondsRemaining: StateFlow<Long> = _iqamaScreenSecondsRemaining.asStateFlow()

    private val _activePrayerScreenUri = MutableStateFlow<String?>(null)
    val activePrayerScreenUri: StateFlow<String?> = _activePrayerScreenUri.asStateFlow()

    private val _activeIqamaScreenUri = MutableStateFlow<String?>(null)
    val activeIqamaScreenUri: StateFlow<String?> = _activeIqamaScreenUri.asStateFlow()

    private val _isPrayerScreenActive = MutableStateFlow(false)
    val isPrayerScreenActive: StateFlow<Boolean> = _isPrayerScreenActive.asStateFlow()

    private val _previewPrayerScreenType = MutableStateFlow<PrayerType?>(null)
    val previewPrayerScreenType: StateFlow<PrayerType?> = _previewPrayerScreenType.asStateFlow()

    private val _isLocatingGps = MutableStateFlow(false)
    val isLocatingGps: StateFlow<Boolean> = _isLocatingGps.asStateFlow()

    private val _activePeriodId = MutableStateFlow("dhuhr")
    val activePeriodId: StateFlow<String> = _activePeriodId.asStateFlow()

    private val _previewPeriodId = MutableStateFlow<String?>(null)
    val previewPeriodId: StateFlow<String?> = _previewPeriodId.asStateFlow()

    private val _isAdhkarScreenActive = MutableStateFlow(false)
    val isAdhkarScreenActive: StateFlow<Boolean> = _isAdhkarScreenActive.asStateFlow()

    private val _adhkarScreenSecondsRemaining = MutableStateFlow(0L)
    val adhkarScreenSecondsRemaining: StateFlow<Long> = _adhkarScreenSecondsRemaining.asStateFlow()

    private val _isPreviewingAdhkarScreen = MutableStateFlow(false)
    val isPreviewingAdhkarScreen: StateFlow<Boolean> = _isPreviewingAdhkarScreen.asStateFlow()

    private val _isIqamaSilentModeActive = MutableStateFlow(false)
    val isIqamaSilentModeActive: StateFlow<Boolean> = _isIqamaSilentModeActive.asStateFlow()

    private var isPrayerScreenDismissed = false
    private var isIqamaScreenDismissed = false
    private var isAdhkarScreenDismissed = false
    private var lastDismissedPrayerId: String? = null
    private var lastAdhkarPrayerId: String? = null
    private var adhkarManualEndTimeMs: Long? = null
    private var lastTriggeredAdhanMinute = -1
    private var lastTriggeredIqamaMinute = -1
    private var tickerIndex = 0

    init {
        PrayerAlarmScheduler.scheduleAllPrayers(application)
        startClockAndEngineLoop()
        observeIqamaScreenForSilentMode()
    }

    private fun observeIqamaScreenForSilentMode() {
        viewModelScope.launch {
            var previousActive = false
            _isIqamaSilentModeActive.collect { isActive ->
                if (isActive && !previousActive) {
                    IqamaSilentModeManager.enableSilentMode(getApplication())
                } else if (!isActive && previousActive) {
                    IqamaSilentModeManager.restorePreviousAudioState(getApplication())
                }
                previousActive = isActive
            }
        }
    }

    private fun startClockAndEngineLoop() {
        viewModelScope.launch {
            var tickerSecondCounter = 0
            while (isActive) {
                val baseNow = LocalDateTime.now()
                val offsetMins = if (_settings.value.isTimeCorrectionEnabled) {
                    (_settings.value.timeOffsetHours.toLong() * 60L) + _settings.value.timeOffsetMinutes.toLong()
                } else 0L
                val now = if (offsetMins != 0L) baseNow.plusMinutes(offsetMins) else baseNow
                val dateOffset = if (_settings.value.isDateCorrectionEnabled) _settings.value.gregorianDayOffset.toLong() else 0L
                val today = if (dateOffset != 0L) now.toLocalDate().plusDays(dateOffset) else now.toLocalDate()
                val time = now.toLocalTime()

                // Format Live Clock
                val hour12 = when (val h = time.hour % 12) {
                    0 -> 12
                    else -> h
                }
                val secStr = if (_settings.value.showSeconds) String.format(Locale.US, ":%02d", time.second) else ""
                val marker = if (time.hour < 12) "ص" else "م"

                _currentTimeFormatted.value = if (_settings.value.is24Hour) {
                    val pattern = if (_settings.value.showSeconds) "HH:mm:ss" else "HH:mm"
                    time.format(DateTimeFormatter.ofPattern(pattern, Locale.US))
                } else {
                    String.format(Locale.US, "%s %02d:%02d%s", marker, hour12, time.minute, secStr)
                }

                // Format Dates
                _dayOfWeekArabic.value = HijriCalendarHelper.getDayOfWeekArabic(today)
                _hijriDate.value = HijriCalendarHelper.getHijriDateString(today, _settings.value.hijriDayOffset)
                _gregorianDate.value = HijriCalendarHelper.getGregorianDateString(today)

                // Update Prayer Rows
                updateDailyPrayers(today, time)

                // Update Ticker Messages
                tickerSecondCounter++
                val rotationInterval = _settings.value.tickerRotationSeconds.coerceAtLeast(4)
                if (tickerSecondCounter % rotationInterval == 0 && _settings.value.tickerMessages.isNotEmpty()) {
                    tickerIndex = (tickerIndex + 1) % _settings.value.tickerMessages.size
                    _currentTickerMessage.value = _settings.value.tickerMessages[tickerIndex]
                } else if (_currentTickerMessage.value.isEmpty() && _settings.value.tickerMessages.isNotEmpty()) {
                    _currentTickerMessage.value = _settings.value.tickerMessages[0]
                }

                _isPlayingAdhanSound.value = adhanPlayer.isPlayingAdhan()

                delay(1000L)
            }
        }
    }

    private fun updateDailyPrayers(today: LocalDate, nowTime: LocalTime) {
        val scheduleObj = _schedule.value
        val monthData = scheduleObj.months.find { it.month == today.monthValue }
            ?: scheduleObj.months.firstOrNull()
            ?: return
        val dayData = monthData.days.find { it.day == today.dayOfMonth }
            ?: monthData.days.firstOrNull()
            ?: return

        val isFriday = today.dayOfWeek == DayOfWeek.FRIDAY
        val currentSettings = _settings.value

        fun parsePrayerTime(timeStr: String, isPm: Boolean = false): LocalTime {
            return try {
                val parts = timeStr.trim().split(":")
                var hour = parts[0].toInt()
                val min = parts[1].toInt()
                if (isPm && hour < 12) hour += 12
                LocalTime.of(hour, min)
            } catch (e: Exception) {
                LocalTime.of(12, 0)
            }
        }

        val fajrSecondTime = parsePrayerTime(dayData.fajrSecond)
        val fajrFirstTime = fajrSecondTime.minusMinutes(currentSettings.fajrIntervalMinutes.toLong())
        val sunriseTime = parsePrayerTime(dayData.sunrise)
        val dhuhrTime = parsePrayerTime(dayData.dhuhr)
        val asrTime = parsePrayerTime(dayData.asr, isPm = true)
        val maghribTime = parsePrayerTime(dayData.maghrib, isPm = true)
        val ishaTime = parsePrayerTime(dayData.isha, isPm = true)

        val fridayFirstAdhanTime = dhuhrTime.minusMinutes(currentSettings.fridayFirstAdhanOffsetMinutes.toLong())
        val fridaySecondAdhanTime = dhuhrTime

        data class PrayerMeta(
            val type: PrayerType,
            val name: String,
            val time: LocalTime,
            val hasIqama: Boolean
        )

        val fajr1Active = currentSettings.firstAdhansMasterEnabled && currentSettings.isFajrFirstEnabled
        val friday1Active = isFriday && currentSettings.firstAdhansMasterEnabled && currentSettings.isFridayFirstEnabled

        val prayerMetas = mutableListOf<PrayerMeta>()
        if (fajr1Active) {
            prayerMetas.add(PrayerMeta(PrayerType.FAJR_FIRST, "الفجر الأول", fajrFirstTime, hasIqama = false))
        }
        prayerMetas.add(PrayerMeta(PrayerType.FAJR_SECOND, "الفجر الثاني", fajrSecondTime, hasIqama = true))
        prayerMetas.add(PrayerMeta(PrayerType.SUNRISE, "الشروق", sunriseTime, hasIqama = false))

        if (isFriday) {
            if (friday1Active) {
                prayerMetas.add(PrayerMeta(PrayerType.FRIDAY_FIRST, "الأذان الأول", fridayFirstAdhanTime, hasIqama = false))
                prayerMetas.add(PrayerMeta(PrayerType.FRIDAY_SECOND, "الأذان الثاني", fridaySecondAdhanTime, hasIqama = true))
            } else {
                prayerMetas.add(PrayerMeta(PrayerType.FRIDAY_SECOND, "الظهر", fridaySecondAdhanTime, hasIqama = true))
            }
        } else {
            prayerMetas.add(PrayerMeta(PrayerType.DHUHR, "الظهر", dhuhrTime, hasIqama = true))
        }

        prayerMetas.add(PrayerMeta(PrayerType.ASR, "العصر", asrTime, hasIqama = true))
        prayerMetas.add(PrayerMeta(PrayerType.MAGHRIB, "المغرب", maghribTime, hasIqama = true))
        prayerMetas.add(PrayerMeta(PrayerType.ISHA, "العشاء", ishaTime, hasIqama = true))

        val sortedPrayerMetas = prayerMetas.sortedBy { it.time }

        var nextMeta: PrayerMeta? = null
        var currentMeta: PrayerMeta? = null

        for (meta in sortedPrayerMetas) {
            if (nowTime.isBefore(meta.time)) {
                if (nextMeta == null) {
                    nextMeta = meta
                }
            } else {
                currentMeta = meta
            }
        }

        val effectiveNextMeta = nextMeta ?: sortedPrayerMetas.first()
        val effectiveCurrentMeta = currentMeta ?: sortedPrayerMetas.last()

        // Adhans apply ONLY to actual prayers, NEVER Sunrise
        val adhanEligibleMetas = sortedPrayerMetas.filter { it.type != PrayerType.SUNRISE }
        val targetAdhanMeta = adhanEligibleMetas.firstOrNull { nowTime.isBefore(it.time) }
            ?: adhanEligibleMetas.first()

        val countdownCandidateMetas = mutableListOf<PrayerMeta>()
        countdownCandidateMetas.add(PrayerMeta(PrayerType.FAJR_SECOND, "الفجر", fajrSecondTime, hasIqama = true))
        if (isFriday) {
            val fridayCountdownName = if (friday1Active) "الأذان الثاني" else "الظهر"
            countdownCandidateMetas.add(PrayerMeta(PrayerType.FRIDAY_SECOND, fridayCountdownName, fridaySecondAdhanTime, hasIqama = true))
        } else {
            countdownCandidateMetas.add(PrayerMeta(PrayerType.DHUHR, "الظهر", dhuhrTime, hasIqama = true))
        }
        countdownCandidateMetas.add(PrayerMeta(PrayerType.ASR, "العصر", asrTime, hasIqama = true))
        countdownCandidateMetas.add(PrayerMeta(PrayerType.MAGHRIB, "المغرب", maghribTime, hasIqama = true))
        countdownCandidateMetas.add(PrayerMeta(PrayerType.ISHA, "العشاء", ishaTime, hasIqama = true))

        var nextCountdownMeta: PrayerMeta? = null
        for (meta in countdownCandidateMetas) {
            if (nowTime.isBefore(meta.time)) {
                if (nextCountdownMeta == null) {
                    nextCountdownMeta = meta
                }
            }
        }
        val targetCountdownMeta = nextCountdownMeta ?: countdownCandidateMetas.first()
        val targetCountdownTime = targetCountdownMeta.time
        _nextUpcomingPrayerType.value = targetCountdownMeta.type

        // Adhan Countdown strictly for the 5 daily prayers (Fajr second, Dhuhr/Friday, Asr, Maghrib, Isha)
        val nowSeconds = nowTime.toSecondOfDay()
        val targetSeconds = targetCountdownTime.toSecondOfDay()
        val diffAdhanSeconds = if (targetSeconds >= nowSeconds) {
            (targetSeconds - nowSeconds).toLong()
        } else {
            (86400 - nowSeconds + targetSeconds).toLong()
        }

        val adhanHours = diffAdhanSeconds / 3600
        val adhanMins = (diffAdhanSeconds % 3600) / 60
        val adhanSecs = diffAdhanSeconds % 60
        val adhanFormatted = String.format(Locale.US, "%02d:%02d:%02d", adhanHours, adhanMins, adhanSecs)

        val adhanTitle = if (isFriday && targetCountdownMeta.type == PrayerType.FRIDAY_SECOND) {
            if (friday1Active) "أذان الجمعة الثاني" else "أذان الظهر"
        } else {
            "أذان ${targetCountdownMeta.name}"
        }

        _adhanCountdown.value = ActiveCountdown(
            title = adhanTitle,
            formattedTime = adhanFormatted,
            secondsLeft = diffAdhanSeconds,
            prayerName = targetCountdownMeta.name
        )

        // Iqama Countdown, Silent Mode & Full-Screen Iqama trigger
        var iqamaCountdownState: ActiveCountdown? = null
        var isIqamaAlertActive = false
        var isIqamaSilentPeriodActive = false
        val currentPrayerConfig = if (currentMeta != null && currentMeta.hasIqama) {
            currentSettings.getPrayerConfig(currentMeta.type)
        } else null
        var calculatedIqamaSecsOfDay: Int? = null

        if (currentMeta != null && currentMeta.hasIqama && currentPrayerConfig != null) {
            val pConfig = currentPrayerConfig
            val isFridaySecond = isFriday && currentMeta.type == PrayerType.FRIDAY_SECOND

            if (isFridaySecond) {
                // Friday Second Adhan -> directly followed by «استمع للخطبة»
                val secondAdhanStartSecs = currentMeta.time.toSecondOfDay()
                val secondsSinceSecondAdhan = (nowSeconds - secondAdhanStartSecs).toLong()
                val adhanDurationSecs = 120L // Standard duration for Friday second adhan (2 mins)
                val khutbahDurationSecs = (pConfig.iqamaScreenDurationMinutes * 60L).coerceAtLeast(1800L) // Khutbah duration

                if (secondsSinceSecondAdhan in 0 until adhanDurationSecs) {
                    // Second Adhan in progress
                    isIqamaAlertActive = false
                    _isIqamaScreenActive.value = false
                    _iqamaScreenSecondsRemaining.value = 0L
                } else if (secondsSinceSecondAdhan in adhanDurationSecs until (adhanDurationSecs + khutbahDurationSecs)) {
                    // Immediately after Friday Second Adhan: Automatic transition to «استمع للخطبة»
                    isIqamaSilentPeriodActive = true
                    val remSecs = (adhanDurationSecs + khutbahDurationSecs) - secondsSinceSecondAdhan
                    _iqamaScreenSecondsRemaining.value = remSecs.coerceAtLeast(0L)
                    _activeIqamaPrayerType.value = currentMeta.type

                    val isDismissed = isIqamaScreenDismissed && lastDismissedPrayerId == currentMeta.type.id
                    _isIqamaScreenActive.value = !isDismissed
                    isIqamaAlertActive = true
                } else {
                    _isIqamaScreenActive.value = false
                    _iqamaScreenSecondsRemaining.value = 0L
                    if (lastDismissedPrayerId == currentMeta.type.id && secondsSinceSecondAdhan >= (adhanDurationSecs + khutbahDurationSecs)) {
                        isIqamaScreenDismissed = false
                        lastDismissedPrayerId = null
                    }
                }
            } else if (pConfig.iqamaEnabled) {
                val iqamaMin = pConfig.iqamaMinutes
                val iqamaTime = if (pConfig.isManualIqama && !pConfig.manualIqamaTime.isNullOrEmpty()) {
                    parsePrayerTime(pConfig.manualIqamaTime)
                } else {
                    currentMeta.time.plusMinutes(iqamaMin.toLong())
                }

                val iqamaSecsOfDay = iqamaTime.toSecondOfDay()
                calculatedIqamaSecsOfDay = iqamaSecsOfDay
                val diffIqamaSeconds = iqamaSecsOfDay - nowSeconds
                val iqamaScreenDurationSecs = (pConfig.iqamaScreenDurationMinutes * 60).toLong()
                val secondsSinceIqama = (nowSeconds - iqamaSecsOfDay).toLong()

                if (diffIqamaSeconds > 0) {
                    val iqH = diffIqamaSeconds / 3600
                    val iqM = (diffIqamaSeconds % 3600) / 60
                    val iqS = diffIqamaSeconds % 60
                    val iqFormatted = String.format(Locale.US, "%02d:%02d:%02d", iqH, iqM, iqS)

                    iqamaCountdownState = ActiveCountdown(
                        title = "إقامة ${currentMeta.name}",
                        formattedTime = iqFormatted,
                        secondsLeft = diffIqamaSeconds.toLong(),
                        prayerName = currentMeta.name,
                        isIqamaCountdown = true
                    )
                } else if (diffIqamaSeconds in -180..0) {
                    isIqamaAlertActive = true
                }

                // Check Full-Screen Iqama auto-appearance and Silent Mode during Iqama duration:
                // Silent mode stays active for the entire iqamaScreenDurationSecs regardless of X button clicks.
                // The X button only hides the UI; it does NOT cancel the timer or stop silent mode.
                if (currentMeta.hasIqama && secondsSinceIqama in 0 until iqamaScreenDurationSecs) {
                    isIqamaSilentPeriodActive = true
                    val remSecs = (iqamaScreenDurationSecs - secondsSinceIqama).coerceAtLeast(0L)
                    _iqamaScreenSecondsRemaining.value = remSecs
                    _activeIqamaPrayerType.value = currentMeta.type

                    val isDismissed = isIqamaScreenDismissed && lastDismissedPrayerId == currentMeta.type.id
                    _isIqamaScreenActive.value = pConfig.iqamaScreenEnabled && !isDismissed
                } else {
                    _isIqamaScreenActive.value = false
                    _iqamaScreenSecondsRemaining.value = 0L
                    if (lastDismissedPrayerId == currentMeta.type.id && secondsSinceIqama >= iqamaScreenDurationSecs) {
                        isIqamaScreenDismissed = false
                        lastDismissedPrayerId = null
                    }
                }
            }
        } else {
            _isIqamaScreenActive.value = false
            _iqamaScreenSecondsRemaining.value = 0L
        }

        // Automatic Post-Prayer Adhkar Screen Display & Countdown Logic
        val adhkarEnabled = currentSettings.postPrayerAdhkarEnabled
        val adhkarDurationSecs = (currentSettings.postPrayerAdhkarDurationMinutes * 60L).coerceAtLeast(60L)

        if (_isPreviewingAdhkarScreen.value) {
            val rem = _adhkarScreenSecondsRemaining.value - 1L
            if (rem <= 0L) {
                _isPreviewingAdhkarScreen.value = false
                _adhkarScreenSecondsRemaining.value = 0L
            } else {
                _adhkarScreenSecondsRemaining.value = rem
            }
        } else if (adhkarEnabled) {
            val manualEndTime = adhkarManualEndTimeMs
            if (manualEndTime != null) {
                val remMs = manualEndTime - System.currentTimeMillis()
                val remSecs = remMs / 1000L
                if (remSecs > 0) {
                    _isAdhkarScreenActive.value = true
                    _adhkarScreenSecondsRemaining.value = remSecs
                } else {
                    _isAdhkarScreenActive.value = false
                    _adhkarScreenSecondsRemaining.value = 0L
                    adhkarManualEndTimeMs = null
                }
            } else if (currentMeta != null && currentMeta.hasIqama && currentPrayerConfig != null && currentPrayerConfig.iqamaEnabled) {
                val effectiveIqamaDuration = if (isFriday && currentMeta.type == PrayerType.FRIDAY_SECOND) {
                    (currentPrayerConfig.iqamaScreenDurationMinutes * 60L).coerceAtLeast(1800L) + 120L
                } else {
                    (currentPrayerConfig.iqamaScreenDurationMinutes * 60).toLong()
                }
                val effectiveSecondsSinceIqama = if (isFriday && currentMeta.type == PrayerType.FRIDAY_SECOND) {
                    val secondAdhanStartSecs = currentMeta.time.toSecondOfDay()
                    (nowSeconds - secondAdhanStartSecs).toLong()
                } else {
                    val baseIqamaSecs = calculatedIqamaSecsOfDay ?: (currentMeta.time.toSecondOfDay() + (currentPrayerConfig.iqamaMinutes * 60))
                    (nowSeconds - baseIqamaSecs).toLong()
                }

                val totalIqamaPlusAdhkarSecs = effectiveIqamaDuration + adhkarDurationSecs
                if (effectiveSecondsSinceIqama in effectiveIqamaDuration until totalIqamaPlusAdhkarSecs) {
                    val isDismissed = isAdhkarScreenDismissed && lastAdhkarPrayerId == currentMeta.type.id
                    if (!isDismissed) {
                        val remSecs = totalIqamaPlusAdhkarSecs - effectiveSecondsSinceIqama
                        if (remSecs > 0L) {
                            _isAdhkarScreenActive.value = true
                            _adhkarScreenSecondsRemaining.value = remSecs
                        } else {
                            _isAdhkarScreenActive.value = false
                            _adhkarScreenSecondsRemaining.value = 0L
                        }
                    } else {
                        _isAdhkarScreenActive.value = false
                        _adhkarScreenSecondsRemaining.value = 0L
                    }
                } else {
                    _isAdhkarScreenActive.value = false
                    _adhkarScreenSecondsRemaining.value = 0L
                    if (lastAdhkarPrayerId == currentMeta.type.id && effectiveSecondsSinceIqama >= totalIqamaPlusAdhkarSecs) {
                        isAdhkarScreenDismissed = false
                        lastAdhkarPrayerId = null
                    }
                }
            } else {
                _isAdhkarScreenActive.value = false
                _adhkarScreenSecondsRemaining.value = 0L
            }
        } else {
            _isAdhkarScreenActive.value = false
            _adhkarScreenSecondsRemaining.value = 0L
        }

        // Handle simulation mode triggers for Iqama / Friday Khutbah
        if (currentSettings.simulationModeEnabled) {
            if (currentSettings.simulatedState == PrayerState.FRIDAY_IQAMA) {
                _isIqamaScreenActive.value = true
                _activeIqamaPrayerType.value = PrayerType.FRIDAY_SECOND
                _iqamaScreenSecondsRemaining.value = 1800L
                isIqamaAlertActive = true
                isIqamaSilentPeriodActive = true
            } else if (currentSettings.simulatedState == PrayerState.IQAMA) {
                _isIqamaScreenActive.value = true
                _activeIqamaPrayerType.value = currentMeta?.type ?: PrayerType.DHUHR
                _iqamaScreenSecondsRemaining.value = 1200L
                isIqamaAlertActive = true
                isIqamaSilentPeriodActive = true
            }
        }

        _isIqamaSilentModeActive.value = isIqamaSilentPeriodActive

        // Active prayer period interface (Strictly based on Fajr Second and actual Sunrise)
        val dhuhrOrFridayTime = if (isFriday) fridaySecondAdhanTime else dhuhrTime
        val currentPeriod = when {
            nowTime >= ishaTime || nowTime < fajrSecondTime -> "isha"
            nowTime >= maghribTime -> "maghrib"
            nowTime >= asrTime -> "asr"
            nowTime >= dhuhrOrFridayTime -> "dhuhr"
            nowTime >= sunriseTime -> "shuruq"
            else -> "fajr_second"
        }
        _activePeriodId.value = currentPeriod

        _iqamaCountdown.value = iqamaCountdownState
        _isIqamaNow.value = isIqamaAlertActive

        // Compute State Machine
        val calculatedState = if (currentSettings.simulationModeEnabled) {
            currentSettings.simulatedState
        } else {
            val preMinutes = currentSettings.defaultPrePrayerMinutes
            when {
                isIqamaAlertActive -> {
                    if (isFriday) PrayerState.FRIDAY_IQAMA else PrayerState.IQAMA
                }
                isFriday && currentMeta?.type == PrayerType.FRIDAY_SECOND && (nowSeconds - currentMeta.time.toSecondOfDay()) in 0..120 -> {
                    PrayerState.FRIDAY_SECOND_ADHAN
                }
                diffAdhanSeconds in 0..60 -> {
                    if (isFriday && targetAdhanMeta.type == PrayerType.FRIDAY_FIRST) PrayerState.FRIDAY_FIRST_ADHAN
                    else if (isFriday && targetAdhanMeta.type == PrayerType.FRIDAY_SECOND) PrayerState.FRIDAY_SECOND_ADHAN
                    else PrayerState.ADHAN
                }
                diffAdhanSeconds in 61..(preMinutes * 60) -> {
                    if (isFriday && targetAdhanMeta.type == PrayerType.FRIDAY_FIRST) PrayerState.FRIDAY_PRE_FIRST
                    else PrayerState.PRE_PRAYER
                }
                isFriday && currentMeta?.type == PrayerType.FRIDAY_FIRST && nextMeta?.type == PrayerType.FRIDAY_SECOND -> {
                    PrayerState.FRIDAY_BETWEEN_ADHANS
                }
                else -> {
                    if (isFriday) PrayerState.FRIDAY_NORMAL else PrayerState.NORMAL
                }
            }
        }
        _prayerState.value = calculatedState
        _currentActivePrayerName.value = if (calculatedState == PrayerState.PRE_PRAYER || calculatedState == PrayerState.ADHAN) {
            targetCountdownMeta.name
        } else {
            currentMeta?.name ?: targetCountdownMeta.name
        }
        _isPrayerScreenActive.value = false

        // Audio trigger if app is open
        if (calculatedState == PrayerState.ADHAN || calculatedState == PrayerState.FRIDAY_FIRST_ADHAN || calculatedState == PrayerState.FRIDAY_SECOND_ADHAN) {
            val minuteOfDay = nowTime.hour * 60 + nowTime.minute
            if (lastTriggeredAdhanMinute != minuteOfDay) {
                lastTriggeredAdhanMinute = minuteOfDay
                val soundToPlay = currentSettings.getResolvedAdhanSound(targetAdhanMeta.type)
                val pConfig = currentSettings.getPrayerConfig(targetAdhanMeta.type)
                if (pConfig.adhanEnabled && !soundToPlay.isNullOrEmpty()) {
                    if (!com.example.audio.PrayerAudioPlaybackManager.isAnyAudioPlaying()) {
                        val serviceIntent = android.content.Intent(getApplication(), com.example.service.AdhanForegroundService::class.java).apply {
                            action = com.example.service.AdhanForegroundService.ACTION_START_ADHAN
                            putExtra(com.example.service.AdhanForegroundService.EXTRA_PRAYER_ID, targetAdhanMeta.type.id)
                            putExtra(com.example.service.AdhanForegroundService.EXTRA_PRAYER_NAME, targetAdhanMeta.name)
                            putExtra(com.example.service.AdhanForegroundService.EXTRA_PRAYER_TIME, targetAdhanMeta.time)
                            putExtra(com.example.service.AdhanForegroundService.EXTRA_MOSQUE_NAME, currentSettings.mosqueName)
                            putExtra(com.example.service.AdhanForegroundService.EXTRA_IS_IQAMA, false)
                            putExtra(com.example.service.AdhanForegroundService.EXTRA_SOUND, soundToPlay)
                        }
                        try {
                            androidx.core.content.ContextCompat.startForegroundService(getApplication(), serviceIntent)
                        } catch (_: Exception) {
                            com.example.audio.PrayerAudioPlaybackManager.playAdhan(getApplication(), targetAdhanMeta.type.id, soundToPlay)
                        }
                    }
                }
            }
        }

        if (calculatedState == PrayerState.IQAMA || calculatedState == PrayerState.FRIDAY_IQAMA) {
            val minuteOfDay = nowTime.hour * 60 + nowTime.minute
            if (lastTriggeredIqamaMinute != minuteOfDay) {
                lastTriggeredIqamaMinute = minuteOfDay
                val activeType = currentMeta?.type ?: targetAdhanMeta.type
                val soundToPlay = currentSettings.getResolvedIqamaSound(activeType)
                val pConfig = currentSettings.getPrayerConfig(activeType)
                if (pConfig.iqamaEnabled && !soundToPlay.isNullOrEmpty()) {
                    val serviceIntent = android.content.Intent(getApplication(), com.example.service.AdhanForegroundService::class.java).apply {
                        action = com.example.service.AdhanForegroundService.ACTION_START_ADHAN
                        putExtra(com.example.service.AdhanForegroundService.EXTRA_PRAYER_ID, activeType.id)
                        putExtra(com.example.service.AdhanForegroundService.EXTRA_PRAYER_NAME, currentMeta?.name ?: "الإقامة")
                        putExtra(com.example.service.AdhanForegroundService.EXTRA_PRAYER_TIME, currentMeta?.time ?: "")
                        putExtra(com.example.service.AdhanForegroundService.EXTRA_MOSQUE_NAME, currentSettings.mosqueName)
                        putExtra(com.example.service.AdhanForegroundService.EXTRA_IS_IQAMA, true)
                        putExtra(com.example.service.AdhanForegroundService.EXTRA_SOUND, soundToPlay)
                    }
                    try {
                        androidx.core.content.ContextCompat.startForegroundService(getApplication(), serviceIntent)
                    } catch (_: Exception) {
                        com.example.audio.PrayerAudioPlaybackManager.playIqamaOnce(
                            context = getApplication(),
                            prayerId = activeType.id,
                            soundUri = soundToPlay
                        )
                    }
                }
            }
        }

        // Build PrayerRowItems for UI
        fun formatPrayerTimeDisplay(localTime: LocalTime): String {
            return if (currentSettings.is24Hour) {
                localTime.format(DateTimeFormatter.ofPattern("HH:mm", Locale.US))
            } else {
                val hour12 = when (val h = localTime.hour % 12) {
                    0 -> 12
                    else -> h
                }
                val marker = if (localTime.hour < 12) "ص" else "م"
                String.format(Locale.US, "%02d:%02d %s", hour12, localTime.minute, marker)
            }
        }

        _prayerRows.value = sortedPrayerMetas.map { meta ->
            val pConfig = currentSettings.getPrayerConfig(meta.type)
            val adjustedAdhanTime = meta.time.plusMinutes(pConfig.adhanOffsetMinutes.toLong())
            val iqamaStr = if (!meta.hasIqama || !pConfig.iqamaEnabled) {
                "-"
            } else if (pConfig.isManualIqama && !pConfig.manualIqamaTime.isNullOrEmpty()) {
                val raw = pConfig.manualIqamaTime.trim()
                if (raw.contains("ص") || raw.contains("م")) {
                    raw
                } else {
                    try {
                        val parsed = parsePrayerTime(raw)
                        formatPrayerTimeDisplay(parsed)
                    } catch (e: Exception) {
                        raw
                    }
                }
            } else {
                val iqamaTime = adjustedAdhanTime.plusMinutes(pConfig.iqamaMinutes.toLong())
                formatPrayerTimeDisplay(iqamaTime)
            }

            val isNextFive = (targetCountdownMeta.type == meta.type) ||
                    (isFriday && targetCountdownMeta.type == PrayerType.FRIDAY_SECOND && meta.type == PrayerType.DHUHR)

            PrayerRowItem(
                type = meta.type,
                name = meta.name,
                adhanTime = formatPrayerTimeDisplay(adjustedAdhanTime),
                iqamaTime = iqamaStr,
                isCurrent = effectiveCurrentMeta.type == meta.type,
                isNext = isNextFive,
                isFriday = isFriday && (meta.type == PrayerType.FRIDAY_FIRST || meta.type == PrayerType.FRIDAY_SECOND),
                customIconUri = pConfig.customIconUri
            )
        }
    }

    fun updateScheduleFromGps(
        context: Context,
        onResult: (success: Boolean, message: String, newSchedule: MosqueSchedule?) -> Unit
    ) {
        viewModelScope.launch {
            _isLocatingGps.value = true
            val locationResult = LocationHelper.getCurrentLocation(context)
            _isLocatingGps.value = false

            when (locationResult) {
                is LocationResult.Error -> {
                    onResult(false, locationResult.message, null)
                }
                is LocationResult.Success -> {
                    val now = LocalDate.now()
                    val zoneId = ZoneId.systemDefault()
                    val curSettings = _settings.value
                    val newSchedule = withContext(Dispatchers.Default) {
                        PrayerCalculator.calculateAnnualSchedule(
                            year = now.year,
                            latitude = locationResult.latitude,
                            longitude = locationResult.longitude,
                            timeZone = zoneId,
                            mosqueName = curSettings.mosqueName,
                            cityName = locationResult.cityName,
                            fajrIntervalMinutes = curSettings.fajrIntervalMinutes,
                            methodKey = curSettings.calculationMethod,
                            asrMethodKey = curSettings.asrMethod
                        )
                    }

                    // Save new schedule
                    repository.saveSchedule(newSchedule)
                    _schedule.value = newSchedule

                    // Save location in settings
                    val locData = GpsLocationData(
                        cityName = locationResult.cityName,
                        latitude = locationResult.latitude,
                        longitude = locationResult.longitude,
                        calculationMethod = curSettings.calculationMethod,
                        timestamp = System.currentTimeMillis()
                    )
                    val updatedSettings = curSettings.copy(savedLocation = locData)
                    updateSettings(updatedSettings)

                    // Reschedule alarms and refresh main display
                    PrayerAlarmScheduler.scheduleAllPrayers(getApplication())
                    val currentNowTime = LocalTime.now()
                    updateDailyPrayers(now, currentNowTime)
                    onResult(true, "تم حساب مواقيت 365 يوماً لمدينة ${locationResult.cityName} بنجاح.", newSchedule)
                }
            }
        }
    }

    fun onPrayerClicked(prayer: PrayerRowItem) {
        _selectedPrayerForDetail.value = prayer
    }

    fun dismissPrayerDetail() {
        _selectedPrayerForDetail.value = null
    }

    fun saveSinglePrayerConfig(config: SinglePrayerConfig) {
        val updated = _settings.value.withPrayerConfig(config)
        updateSettings(updated)
    }

    fun updateSettings(newSettings: AppSettings) {
        _settings.value = newSettings
        repository.saveSettings(newSettings)
        PrayerAlarmScheduler.scheduleAllPrayers(getApplication())
        val baseNow = LocalDateTime.now()
        val offsetMins = if (newSettings.isTimeCorrectionEnabled) {
            (newSettings.timeOffsetHours.toLong() * 60L) + newSettings.timeOffsetMinutes.toLong()
        } else 0L
        val now = if (offsetMins != 0L) baseNow.plusMinutes(offsetMins) else baseNow
        val dateOffset = if (newSettings.isDateCorrectionEnabled) newSettings.gregorianDayOffset.toLong() else 0L
        val today = if (dateOffset != 0L) now.toLocalDate().plusDays(dateOffset) else now.toLocalDate()
        val time = now.toLocalTime()

        val hour12 = when (val h = time.hour % 12) {
            0 -> 12
            else -> h
        }
        val secStr = if (newSettings.showSeconds) String.format(Locale.US, ":%02d", time.second) else ""
        val marker = if (time.hour < 12) "ص" else "م"

        _currentTimeFormatted.value = if (newSettings.is24Hour) {
            val pattern = if (newSettings.showSeconds) "HH:mm:ss" else "HH:mm"
            time.format(DateTimeFormatter.ofPattern(pattern, Locale.US))
        } else {
            String.format(Locale.US, "%s %02d:%02d%s", marker, hour12, time.minute, secStr)
        }
        _dayOfWeekArabic.value = HijriCalendarHelper.getDayOfWeekArabic(today)
        _hijriDate.value = HijriCalendarHelper.getHijriDateString(today, newSettings.hijriDayOffset)
        _gregorianDate.value = HijriCalendarHelper.getGregorianDateString(today)
        updateDailyPrayers(today, time)
    }

    fun restoreDefaultSchedule() {
        val restored = repository.restoreDefaultSchedule()
        _schedule.value = restored
        PrayerAlarmScheduler.scheduleAllPrayers(getApplication())
        val now = LocalDateTime.now()
        updateDailyPrayers(now.toLocalDate(), now.toLocalTime())
    }

    fun restoreDefaultSettings() {
        val defaultSettings = repository.getDefaultSettings()
        updateSettings(defaultSettings)
    }

    fun dismissIqamaScreen() {
        if (_isPreviewingIqamaScreen.value) {
            dismissIqamaPreview()
            return
        }
        val currentMeta = _prayerRows.value.find { it.isCurrent }
        lastDismissedPrayerId = currentMeta?.type?.id
        isIqamaScreenDismissed = true
        _isIqamaScreenActive.value = false
        // زر X يتحكم فقط في إخفاء واجهة الإقامة، ولا يتحكم في الوضع الصامت.
        // إغلاق الواجهة بواسطة X ≠ إنهاء مدة الإقامة.
        // لا تُلغِ مؤقت الإقامة ولا تُوقف الوضع الصامت ولا تُرجع الهاتف إلى وضع الصوت.
        // يبقى الهاتف في الوضع الصامت حتى انتهاء المدة المحددة لواجهة الإقامة.
        // بعد انتهاء المدة المحددة للإقامة، يُوقف الوضع الصامت تلقائيًا ويُعاد الهاتف لوضعه السابق.
    }

    fun dismissAdhkarScreen() {
        if (_isPreviewingAdhkarScreen.value) {
            dismissAdhkarPreview()
            return
        }
        val currentMeta = _prayerRows.value.find { it.isCurrent }
        lastAdhkarPrayerId = currentMeta?.type?.id
        isAdhkarScreenDismissed = true
        _isAdhkarScreenActive.value = false
        _adhkarScreenSecondsRemaining.value = 0L
        _isPreviewingAdhkarScreen.value = false
        adhkarManualEndTimeMs = null
    }

    fun previewAdhkarScreen() {
        val adhkarDurationSecs = (_settings.value.postPrayerAdhkarDurationMinutes * 60L).coerceAtLeast(60L)
        _adhkarScreenSecondsRemaining.value = adhkarDurationSecs
        _isPreviewingAdhkarScreen.value = true
    }

    fun dismissAdhkarPreview() {
        _isPreviewingAdhkarScreen.value = false
        _adhkarScreenSecondsRemaining.value = 0L
    }

    fun previewIqamaScreen(type: PrayerType? = null) {
        _previewIqamaPrayerType.value = type
        _isPreviewingIqamaScreen.value = true
    }

    fun dismissIqamaPreview() {
        _isPreviewingIqamaScreen.value = false
        _previewIqamaPrayerType.value = null
        _iqamaScreenSecondsRemaining.value = 0L
    }

    fun addCustomGeneralAdhan(name: String, uri: Uri): AudioFileItem? {
        val context = getApplication<Application>()
        val filename = "custom_adhan_${System.currentTimeMillis()}.mp3"
        val savedPath = com.example.util.FileStorageHelper.copyUriToInternalFile(context, uri, filename) ?: return null
        val item = AudioFileItem(
            id = "general_adhan_${System.currentTimeMillis()}",
            name = name.ifBlank { "أذان مخصص" },
            uri = savedPath
        )
        val updatedList = _settings.value.savedAdhanSounds + item
        val updatedSettings = _settings.value.copy(
            savedAdhanSounds = updatedList
        )
        updateSettings(updatedSettings)
        return item
    }

    fun addCustomFajrAdhan(name: String, uri: Uri): AudioFileItem? {
        val context = getApplication<Application>()
        val filename = "fajr_adhan_${System.currentTimeMillis()}.mp3"
        val savedPath = com.example.util.FileStorageHelper.copyUriToInternalFile(context, uri, filename) ?: return null
        val item = AudioFileItem(
            id = "fajr_adhan_${System.currentTimeMillis()}",
            name = name.ifBlank { "أذان فجر مخصص" },
            uri = savedPath,
            isBuiltIn = false,
            isDefault = false
        )
        val updatedList = _settings.value.savedFajrAdhanSounds + item
        val updatedSettings = _settings.value.copy(
            savedFajrAdhanSounds = updatedList
        )
        updateSettings(updatedSettings)
        return item
    }

    fun deleteFajrAdhan(item: AudioFileItem) {
        if (item.id == com.example.model.DEFAULT_FAJR_FIRST_ID || item.isDefault || item.uri.contains("Yaseen Al Aassaf", ignoreCase = true)) {
            return
        }
        val updatedList = _settings.value.savedFajrAdhanSounds.filterNot { it.id == item.id }
        val fajrConfig = _settings.value.getPrayerConfig(PrayerType.FAJR_FIRST)
        val updatedFajrConfig = if (fajrConfig.adhanSoundUri == item.uri) {
            fajrConfig.copy(
                adhanSoundUri = null,
                adhanSoundPreset = "",
                adhanSoundName = null
            )
        } else fajrConfig
        val updatedSettings = _settings.value.copy(
            savedFajrAdhanSounds = updatedList
        ).withPrayerConfig(updatedFajrConfig)
        updateSettings(updatedSettings)
    }

    fun deleteGeneralAdhan(item: AudioFileItem) {
        if (item.isBuiltIn) return
        val updatedList = _settings.value.savedAdhanSounds.filterNot { it.id == item.id }
        val newCommon = if (_settings.value.commonAdhanSound == item.uri) "" else _settings.value.commonAdhanSound
        val updatedConfigs = _settings.value.prayerConfigs.mapValues { (_, cfg) ->
            if (cfg.adhanSoundUri == item.uri) {
                cfg.copy(adhanSoundUri = null, adhanSoundPreset = "", adhanSoundName = null)
            } else cfg
        }
        val updated = _settings.value.copy(
            savedAdhanSounds = updatedList,
            commonAdhanSound = newCommon,
            prayerConfigs = updatedConfigs
        )
        updateSettings(updated)
    }

    fun addCustomIqama(name: String, uri: Uri): AudioFileItem? {
        val context = getApplication<Application>()
        val filename = "custom_iqama_${System.currentTimeMillis()}.mp3"
        val savedPath = com.example.util.FileStorageHelper.copyUriToInternalFile(context, uri, filename) ?: return null
        val item = AudioFileItem(
            id = "custom_iqama_${System.currentTimeMillis()}",
            name = name.ifBlank { "إقامة مخصصة" },
            uri = savedPath
        )
        val updatedList = _settings.value.savedIqamaSounds + item
        val updatedSettings = _settings.value.copy(
            savedIqamaSounds = updatedList
        )
        updateSettings(updatedSettings)
        return item
    }

    fun deleteCustomIqama(item: AudioFileItem) {
        if (item.isBuiltIn) return
        val updatedList = _settings.value.savedIqamaSounds.filterNot { it.id == item.id }
        val newDefault = if (_settings.value.defaultIqamaSound == item.uri) "" else _settings.value.defaultIqamaSound
        val updatedConfigs = _settings.value.prayerConfigs.mapValues { (_, cfg) ->
            if (cfg.iqamaSoundUri == item.uri) {
                cfg.copy(iqamaSoundUri = null, iqamaSoundPreset = "", iqamaSoundName = null)
            } else cfg
        }
        val updated = _settings.value.copy(
            savedIqamaSounds = updatedList,
            defaultIqamaSound = newDefault,
            prayerConfigs = updatedConfigs
        )
        updateSettings(updated)
    }

    fun dismissPrayerScreen() {
        isPrayerScreenDismissed = true
        _isPrayerScreenActive.value = false
        _previewPrayerScreenType.value = null
    }

    fun previewPeriodInterface(periodId: String?) {
        _previewPeriodId.value = periodId
    }

    fun importScheduleFromUri(uri: Uri): Result<MosqueSchedule> {
        return try {
            val content = getApplication<Application>().contentResolver.openInputStream(uri)?.use { inputStream ->
                inputStream.bufferedReader().readText()
            } ?: return Result.failure(Exception("تعذر قراءة محتوى الملف."))
            val result = repository.validateAndImportAny(content)
            if (result.isSuccess) {
                _schedule.value = result.getOrThrow()
                PrayerAlarmScheduler.scheduleAllPrayers(getApplication())
                val now = LocalDateTime.now()
                updateDailyPrayers(now.toLocalDate(), now.toLocalTime())
            }
            result
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun saveManualSchedule(editedSchedule: MosqueSchedule) {
        val success = repository.saveSchedule(editedSchedule)
        if (success) {
            _schedule.value = editedSchedule
            PrayerAlarmScheduler.scheduleAllPrayers(getApplication())
            val now = LocalDateTime.now()
            updateDailyPrayers(now.toLocalDate(), now.toLocalTime())
        }
    }

    fun resetDesignOnly() {
        val current = _settings.value
        val defaultSettings = AppSettings()
        val resetSettings = current.copy(
            titleText = defaultSettings.titleText,
            titleSizeSp = defaultSettings.titleSizeSp,
            clockSizeSp = defaultSettings.clockSizeSp,
            clockColorHex = defaultSettings.clockColorHex,
            clockDigitsColorHex = defaultSettings.clockDigitsColorHex,
            clockMarkerColorHex = defaultSettings.clockMarkerColorHex,
            clockBold = defaultSettings.clockBold,
            showSeconds = defaultSettings.showSeconds,
            backgroundOpacity = defaultSettings.backgroundOpacity,
            overlayColorName = defaultSettings.overlayColorName,
            isAnimatedBackground = defaultSettings.isAnimatedBackground
        )
        updateSettings(resetSettings)
    }

    fun testAdhan(uri: String?) {
        com.example.audio.PrayerAudioPlaybackManager.stopAll()
        val success = adhanPlayer.playAdhan(uri) {
            _isPlayingAdhanSound.value = false
        }
        _isPlayingAdhanSound.value = success
        if (!success) {
            try {
                android.widget.Toast.makeText(getApplication(), "تعذر تشغيل ملف الصوت المحدد", android.widget.Toast.LENGTH_SHORT).show()
            } catch (_: Exception) {}
        }
    }

    fun stopAdhan() {
        com.example.audio.PrayerAudioPlaybackManager.stopAll()
        adhanPlayer.stop()
        _isPlayingAdhanSound.value = false
    }

    override fun onCleared() {
        super.onCleared()
        com.example.audio.PrayerAudioPlaybackManager.stopAll()
        adhanPlayer.stop()
        IqamaSilentModeManager.restorePreviousAudioState(getApplication())
    }
}
