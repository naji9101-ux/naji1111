package com.example.util

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.provider.Settings
import android.util.Log

object IqamaSilentModeManager {

    private const val TAG = "IqamaSilentMode"
    private const val PREFS_NAME = "iqama_silent_mode_prefs"
    private const val KEY_IS_MUTED = "is_muted_by_app"
    private const val KEY_SAVED_RINGER_MODE = "saved_ringer_mode"
    private const val KEY_SAVED_INTERRUPTION_FILTER = "saved_interruption_filter"
    private const val KEY_WAS_DND_ACTIVE = "was_dnd_active"
    private const val KEY_DND_PROMPT_SHOWN = "dnd_prompt_shown"

    /**
     * Checks if the app has permission to modify Do Not Disturb / Notification Policy.
     */
    fun hasDndPermission(context: Context): Boolean {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        return notificationManager?.isNotificationPolicyAccessGranted == true
    }

    /**
     * Opens the official Android system settings screen for Notification Policy Access (DND).
     */
    fun openDndSettings(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to open DND settings screen", e)
        }
    }

    /**
     * Activates Do Not Disturb / Silent Mode upon Iqama screen appearance.
     * Records previous state to safely restore it later.
     * Returns true if successfully muted, false otherwise.
     */
    @Synchronized
    fun enableSilentMode(context: Context): Boolean {
        if (!hasDndPermission(context)) {
            Log.w(TAG, "Cannot enable silent mode: DND permission not granted")
            return false
        }

        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        // If already muted by app, preserve the existing saved state
        if (prefs.getBoolean(KEY_IS_MUTED, false)) {
            Log.d(TAG, "Already muted by app, preserving original state")
            return true
        }

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            ?: return false
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            ?: return false

        try {
            val currentFilter = notificationManager.currentInterruptionFilter
            val currentRinger = audioManager.ringerMode
            val wasDndAlreadyActive = currentFilter != NotificationManager.INTERRUPTION_FILTER_ALL

            // Save state prior to muting
            prefs.edit()
                .putBoolean(KEY_IS_MUTED, true)
                .putInt(KEY_SAVED_RINGER_MODE, currentRinger)
                .putInt(KEY_SAVED_INTERRUPTION_FILTER, currentFilter)
                .putBoolean(KEY_WAS_DND_ACTIVE, wasDndAlreadyActive)
                .apply()

            // Put device into Do Not Disturb / Total Silent
            notificationManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
            if (audioManager.ringerMode != AudioManager.RINGER_MODE_SILENT) {
                audioManager.ringerMode = AudioManager.RINGER_MODE_SILENT
            }

            Log.i(TAG, "Successfully enabled silent mode for Iqama. Previous ringer=$currentRinger, filter=$currentFilter, wasDnd=$wasDndAlreadyActive")
            return true
        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException while enabling silent mode", e)
            return false
        } catch (e: Exception) {
            Log.e(TAG, "Unexpected error enabling silent mode", e)
            return false
        }
    }

    /**
     * Restores the exact audio state the device had before Iqama screen appeared.
     * If DND was already active before Iqama, it remains active.
     * If device was normal, it returns to normal.
     * If device was vibrate, it returns to vibrate.
     * If device was silent, it stays silent.
     */
    @Synchronized
    fun restorePreviousAudioState(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val isMuted = prefs.getBoolean(KEY_IS_MUTED, false)
        if (!isMuted) {
            Log.d(TAG, "Device was not muted by app; no state to restore")
            return false
        }

        if (!hasDndPermission(context)) {
            Log.w(TAG, "Cannot restore audio state: DND permission not granted")
            prefs.edit().putBoolean(KEY_IS_MUTED, false).apply()
            return false
        }

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            ?: return false
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            ?: return false

        val savedRinger = prefs.getInt(KEY_SAVED_RINGER_MODE, AudioManager.RINGER_MODE_NORMAL)
        val savedFilter = prefs.getInt(KEY_SAVED_INTERRUPTION_FILTER, NotificationManager.INTERRUPTION_FILTER_ALL)
        val wasDndActive = prefs.getBoolean(KEY_WAS_DND_ACTIVE, false)

        try {
            if (wasDndActive) {
                // If DND was already active prior to Iqama, restore the original DND filter
                notificationManager.setInterruptionFilter(savedFilter)
            } else {
                // Return to normal interruption filter (all notifications allowed)
                notificationManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
                // Restore ringer mode (Normal, Vibrate, or Silent)
                audioManager.ringerMode = savedRinger
            }

            prefs.edit()
                .putBoolean(KEY_IS_MUTED, false)
                .apply()

            Log.i(TAG, "Successfully restored previous audio state. Ringer restored to $savedRinger, filter restored to $savedFilter")
            return true
        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException while restoring audio state", e)
            prefs.edit().putBoolean(KEY_IS_MUTED, false).apply()
            return false
        } catch (e: Exception) {
            Log.e(TAG, "Unexpected error restoring audio state", e)
            prefs.edit().putBoolean(KEY_IS_MUTED, false).apply()
            return false
        }
    }

    fun isCurrentlyMutedByApp(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_IS_MUTED, false)
    }

    fun hasPromptedForDnd(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_DND_PROMPT_SHOWN, false)
    }

    fun setPromptedForDnd(context: Context, prompted: Boolean) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_DND_PROMPT_SHOWN, prompted).apply()
    }
}
