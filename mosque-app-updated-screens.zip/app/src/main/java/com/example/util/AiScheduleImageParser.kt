package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.util.Base64
import com.example.BuildConfig
import com.example.model.DayPrayers
import com.example.model.MonthPrayers
import com.example.model.MosqueSchedule
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.time.LocalTime
import java.util.concurrent.TimeUnit

data class AiExtractionResult(
    val schedule: MosqueSchedule,
    val warnings: List<String>,
    val uncertainCells: Set<String>,
    val processedPagesCount: Int
)

data class ImageQualityCheck(
    val isAcceptable: Boolean,
    val warningMessage: String? = null
)

object AiScheduleImageParser {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    fun checkImageQuality(context: Context, uri: Uri): ImageQualityCheck {
        return try {
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, options)
            }
            val width = options.outWidth
            val height = options.outHeight
            if (width < 350 || height < 350) {
                return ImageQualityCheck(
                    isAcceptable = false,
                    warningMessage = "دقة الصورة منخفضة جداً (${width}x${height}). يرجى التقاط صورة أقرب وأكثر وضوحاً لجدول المواقيت."
                )
            }
            ImageQualityCheck(isAcceptable = true)
        } catch (e: Exception) {
            ImageQualityCheck(isAcceptable = true)
        }
    }

    private fun uriToBase64(context: Context, uri: Uri): String? {
        return try {
            val rotationDegrees = getExifRotationDegrees(context, uri)
            context.contentResolver.openInputStream(uri)?.use { stream ->
                val fullBitmap = BitmapFactory.decodeStream(stream) ?: return null
                val orientedBitmap = if (rotationDegrees != 0f) {
                    val matrix = Matrix().apply { postRotate(rotationDegrees) }
                    Bitmap.createBitmap(fullBitmap, 0, 0, fullBitmap.width, fullBitmap.height, matrix, true)
                } else {
                    fullBitmap
                }

                val maxDim = 2048
                val scaled = if (orientedBitmap.width > maxDim || orientedBitmap.height > maxDim) {
                    val ratio = orientedBitmap.width.toFloat() / orientedBitmap.height.toFloat()
                    val targetW = if (ratio > 1) maxDim else (maxDim * ratio).toInt()
                    val targetH = if (ratio > 1) (maxDim / ratio).toInt() else maxDim
                    Bitmap.createScaledBitmap(orientedBitmap, targetW, targetH, true)
                } else {
                    orientedBitmap
                }

                val outputStream = ByteArrayOutputStream()
                scaled.compress(Bitmap.CompressFormat.JPEG, 85, outputStream)
                val bytes = outputStream.toByteArray()
                Base64.encodeToString(bytes, Base64.NO_WRAP)
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun getExifRotationDegrees(context: Context, uri: Uri): Float {
        return try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                val exif = ExifInterface(stream)
                val orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                when (orientation) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        } catch (e: Exception) {
            0f
        }
    }

    fun normalizeArabicDigits(str: String): String {
        return str
            .replace('٠', '0')
            .replace('١', '1')
            .replace('٢', '2')
            .replace('٣', '3')
            .replace('٤', '4')
            .replace('٥', '5')
            .replace('٦', '6')
            .replace('٧', '7')
            .replace('٨', '8')
            .replace('٩', '9')
            .replace('٫', '.')
    }

    suspend fun parseScheduleImages(
        context: Context,
        imageUris: List<Uri>,
        currentSchedule: MosqueSchedule,
        onProgress: (pageIndex: Int, totalPages: Int, statusMessage: String) -> Unit
    ): Result<AiExtractionResult> = withContext(Dispatchers.IO) {
        val apiKey = try {
            val field = BuildConfig::class.java.getField("GEMINI_API_KEY")
            field.get(null) as? String
        } catch (_: Exception) {
            null
        }

        if (apiKey.isNullOrEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext Result.failure(
                Exception("يرجى إدخال مفتاح GEMINI_API_KEY في لوحة Secrets.")
            )
        }

        val allWarnings = mutableListOf<String>()
        val allUncertainCells = mutableSetOf<String>()
        val parsedMonthsMap = currentSchedule.months.associateBy { it.month }.toMutableMap()

        val prompt = """
            أنت خبير في قراءة وتحليل جداول مواقيت الصلاة الإسلامية المطبوعة والمصورة بدقة 100%.
            استخرج مواقيت الصلاة من هذه الصورة لجميع الأيام الظاهرة لكل شهر.
            يجب أن يكون الناتج حصراً بصيغة JSON نظيفة بدون أي شروحات، بالهيكل التالي:
            {
              "months": [
                {
                  "month": 1,
                  "days": [
                    {
                      "day": 1,
                      "fajr": "05:15",
                      "sunrise": "06:35",
                      "dhuhr": "12:15",
                      "asr": "15:30",
                      "maghrib": "18:00",
                      "isha": "19:30"
                    }
                  ]
                }
              ]
            }
        """.trimIndent()

        var processedCount = 0

        for ((index, uri) in imageUris.withIndex()) {
            val pageNum = index + 1
            onProgress(pageNum, imageUris.size, "جاري تحليل الصفحة $pageNum من ${imageUris.size}...")

            val base64Image = uriToBase64(context, uri)
            if (base64Image == null) {
                allWarnings.add("تعذر فتح الصورة رقم $pageNum")
                continue
            }

            try {
                val requestJson = JSONObject().apply {
                    val contentsArray = JSONArray().apply {
                        val contentObj = JSONObject().apply {
                            val partsArray = JSONArray().apply {
                                put(JSONObject().apply { put("text", prompt) })
                                put(JSONObject().apply {
                                    put("inlineData", JSONObject().apply {
                                        put("mimeType", "image/jpeg")
                                        put("data", base64Image)
                                    })
                                })
                            }
                            put("parts", partsArray)
                        }
                        put(contentObj)
                    }
                    put("contents", contentsArray)
                    put("generationConfig", JSONObject().apply {
                        put("responseMimeType", "application/json")
                        put("temperature", 0.1)
                    })
                }

                val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey"
                val request = Request.Builder()
                    .url(url)
                    .post(requestJson.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                val response = httpClient.newCall(request).execute()
                if (!response.isSuccessful) {
                    allWarnings.add("فشل تحليل الصفحة $pageNum: رمز الخطأ ${response.code}")
                    continue
                }

                val respStr = response.body?.string() ?: ""
                val respJson = JSONObject(respStr)
                val candidates = respJson.optJSONArray("candidates")
                val firstCandidate = candidates?.optJSONObject(0)
                val content = firstCandidate?.optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                val textResponse = parts?.optJSONObject(0)?.optString("text") ?: ""

                if (textResponse.isNotEmpty()) {
                    val cleanJson = cleanJsonString(textResponse)
                    val rawJson = JSONObject(cleanJson)
                    val mArray = rawJson.optJSONArray("months")
                    if (mArray != null) {
                        for (i in 0 until mArray.length()) {
                            val mObj = mArray.getJSONObject(i)
                            val detectedMonth = mObj.optInt("month", pageNum.coerceIn(1, 12))
                            val daysArray = mObj.optJSONArray("days") ?: JSONArray()
                            val dayPrayersList = mutableListOf<DayPrayers>()

                            for (dIdx in 0 until daysArray.length()) {
                                val dObj = daysArray.optJSONObject(dIdx) ?: continue
                                val dayNum = dObj.optInt("day", dIdx + 1)
                                val fajr = formatTime(dObj.optString("fajr", "05:00"))
                                val sunrise = formatTime(dObj.optString("sunrise", "06:30"))
                                val dhuhr = formatTime(dObj.optString("dhuhr", "12:00"))
                                val asr = formatTime(dObj.optString("asr", "15:30"))
                                val maghrib = formatTime(dObj.optString("maghrib", "18:00"))
                                val isha = formatTime(dObj.optString("isha", "19:30"))

                                dayPrayersList.add(
                                    DayPrayers(
                                        day = dayNum,
                                        fajrFirst = calculatePreFajr(fajr),
                                        fajrSecond = fajr,
                                        sunrise = sunrise,
                                        dhuhr = dhuhr,
                                        asr = asr,
                                        maghrib = maghrib,
                                        isha = isha
                                    )
                                )
                            }

                            if (dayPrayersList.isNotEmpty()) {
                                parsedMonthsMap[detectedMonth] = MonthPrayers(
                                    month = detectedMonth,
                                    days = dayPrayersList.sortedBy { it.day }
                                )
                                processedCount++
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                allWarnings.add("خطأ في معالجة الصفحة $pageNum: ${e.message}")
            }
        }

        if (processedCount == 0) {
            val errMsg = if (allWarnings.isNotEmpty()) allWarnings.joinToString("\n") else "تعذر استخراج أي مواقيت من الصور المرفقة."
            return@withContext Result.failure(Exception(errMsg))
        }

        val fullMonths = (1..12).map { m ->
            parsedMonthsMap[m] ?: currentSchedule.months.find { it.month == m } ?: MonthPrayers(m, emptyList())
        }

        val finalSchedule = currentSchedule.copy(
            description = "مستخرج بالذكاء الاصطناعي من الصور",
            months = fullMonths
        )

        Result.success(
            AiExtractionResult(
                schedule = finalSchedule,
                warnings = allWarnings,
                uncertainCells = allUncertainCells,
                processedPagesCount = processedCount
            )
        )
    }

    private fun cleanJsonString(raw: String): String {
        var str = raw.trim()
        if (str.startsWith("```json")) {
            str = str.removePrefix("```json")
        }
        if (str.startsWith("```")) {
            str = str.removePrefix("```")
        }
        if (str.endsWith("```")) {
            str = str.removeSuffix("```")
        }
        return str.trim()
    }

    private fun formatTime(timeStr: String): String {
        val normalized = normalizeArabicDigits(timeStr).trim().replace(" ", "")
        val parts = normalized.split(":", ".")
        if (parts.size >= 2) {
            val h = parts[0].toIntOrNull() ?: 0
            val m = parts[1].toIntOrNull() ?: 0
            return String.format("%02d:%02d", h.coerceIn(0, 23), m.coerceIn(0, 59))
        }
        return normalized.ifEmpty { "00:00" }
    }

    private fun calculatePreFajr(fajrTime: String): String {
        return try {
            val parts = fajrTime.split(":")
            val h = parts[0].toInt()
            val m = parts[1].toInt()
            val time = LocalTime.of(h, m).minusMinutes(15)
            String.format("%02d:%02d", time.hour, time.minute)
        } catch (e: Exception) {
            fajrTime
        }
    }
}
