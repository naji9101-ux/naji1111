package com.example.util

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.example.model.MosqueSchedule
import com.example.ui.settings.getOrPopulateMonthDays
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

object AnnualCalendarExportHelper {

    val ARABIC_MONTH_NAMES_CLEAN = listOf(
        "",
        "كانون الثاني",
        "شباط",
        "آذار",
        "نيسان",
        "أيار",
        "حزيران",
        "تموز",
        "آب",
        "أيلول",
        "تشرين الأول",
        "تشرين الثاني",
        "كانون الأول"
    )

    val ENGLISH_MONTH_NAMES = listOf(
        "",
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December"
    )

    /**
     * Generates a real 12-page vector/text PDF document styled exactly to match the user's reference design.
     * Dark royal navy background (#04162E), double rounded gold frame (#ECC469), top-right mosque name & year,
     * top-left dual-language month card, and continuous gold table grid with pure white numerals.
     * Strictly contains the 7 columns: اليوم، الفجر، الشروق، الظهر، العصر، المغرب، العشاء.
     * Texts and numbers are selectable and copyable.
     */
    fun generateAnnualPdfDocument(
        schedule: MosqueSchedule,
        mosqueName: String,
        year: Int
    ): PdfDocument {
        val pdfDoc = PdfDocument()

        val pageWidth = 595
        val pageHeight = 842
        val marginX = 36f
        val tableWidth = pageWidth - (marginX * 2f) // 523f
        val tableLeft = marginX
        val tableRight = marginX + tableWidth

        // Colors exactly as in reference design
        val bgNavy = Color.parseColor("#04162E")
        val goldPrimary = Color.parseColor("#ECC469")
        val goldGrid = Color.parseColor("#C5A059")
        val textWhite = Color.WHITE
        val textPaleSlate = Color.parseColor("#B0C4DE")
        val textSubtitle = Color.parseColor("#D2C4A4")

        // 7 columns RTL strictly omitting Fajr 1 (Sum = 523f)
        val dayColWidth = 45f
        val prayerColWidth = (tableWidth - dayColWidth) / 6f // ~79.66f each
        val colWidths = floatArrayOf(
            dayColWidth,
            prayerColWidth,
            prayerColWidth,
            prayerColWidth,
            prayerColWidth,
            prayerColWidth,
            prayerColWidth
        )
        val colTitles = arrayOf("اليوم", "الفجر", "الشروق", "الظهر", "العصر", "المغرب", "العشاء")

        val printDateStr = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.US))

        // Paints
        val fillPaint = Paint().apply { isAntiAlias = true }
        val strokePaint = Paint().apply {
            isAntiAlias = true
            style = Paint.Style.STROKE
        }
        val textPaint = Paint().apply {
            isAntiAlias = true
        }

        for (monthIndex in 1..12) {
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, monthIndex).create()
            val page = pdfDoc.startPage(pageInfo)
            val canvas: Canvas = page.canvas

            // 1. Overall Dark Royal Navy Background
            canvas.drawColor(bgNavy)

            // 2. Double Rounded Golden Frame
            strokePaint.color = goldPrimary
            strokePaint.strokeWidth = 1.6f
            canvas.drawRoundRect(RectF(16f, 16f, pageWidth - 16f, pageHeight - 16f), 8f, 8f, strokePaint)

            strokePaint.strokeWidth = 0.8f
            canvas.drawRoundRect(RectF(20f, 20f, pageWidth - 20f, pageHeight - 20f), 6f, 6f, strokePaint)

            // 3. Top Header Section
            // Right Side: Mosque Name & Annual Schedule Subtitle
            textPaint.color = goldPrimary
            textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            textPaint.textSize = 17.5f
            textPaint.textAlign = Paint.Align.RIGHT
            canvas.drawText(mosqueName.ifBlank { "اسم المسجد" }, tableRight - 4f, 48f, textPaint)

            textPaint.color = textSubtitle
            textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            textPaint.textSize = 11f
            textPaint.textAlign = Paint.Align.RIGHT
            canvas.drawText("جدول مواقيت الصلاة للعام $year م", tableRight - 4f, 66f, textPaint)

            // Left Side: Rounded Month Badge Card
            val badgeLeft = tableLeft + 4f
            val badgeTop = 27f
            val badgeRight = badgeLeft + 148f
            val badgeBottom = 72f
            val badgeRect = RectF(badgeLeft, badgeTop, badgeRight, badgeBottom)

            strokePaint.color = goldPrimary
            strokePaint.strokeWidth = 1.2f
            canvas.drawRoundRect(badgeRect, 8f, 8f, strokePaint)

            val monthArabic = ARABIC_MONTH_NAMES_CLEAN.getOrElse(monthIndex) { "" }
            val monthEnglish = ENGLISH_MONTH_NAMES.getOrElse(monthIndex) { "" }
            val badgeCenterX = (badgeLeft + badgeRight) / 2f

            // Badge Line 1: "(كانون الثاني) 1"
            textPaint.color = goldPrimary
            textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            textPaint.textSize = 12.5f
            textPaint.textAlign = Paint.Align.CENTER
            canvas.drawText("($monthArabic) $monthIndex", badgeCenterX, 46f, textPaint)

            // Badge Line 2: "January — Month 1"
            textPaint.color = textPaleSlate
            textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            textPaint.textSize = 9.5f
            textPaint.textAlign = Paint.Align.CENTER
            canvas.drawText("$monthEnglish — Month $monthIndex", badgeCenterX, 63f, textPaint)

            // 4. Prayer Times Table Section
            val tableTopY = 82f
            val headerRowHeight = 24f
            val dataRowHeight = 21f

            val daysInMonth = try {
                YearMonth.of(year, monthIndex).lengthOfMonth()
            } catch (e: Exception) {
                30
            }
            val tableBottomY = tableTopY + headerRowHeight + (daysInMonth * dataRowHeight)

            // Header Row Background
            fillPaint.color = Color.parseColor("#04162E")
            canvas.drawRect(tableLeft, tableTopY, tableRight, tableTopY + headerRowHeight, fillPaint)

            // Days Data Rows
            val monthData = schedule.months.find { it.month == monthIndex }
            val daysList = getOrPopulateMonthDays(monthData, monthIndex, daysInMonth)

            // 1) Draw Alternating Backgrounds and Horizontal Dividers for Odd & Even Rows
            for (dIdx in 0 until daysInMonth) {
                val dayNum = dIdx + 1
                val rowTopY = tableTopY + headerRowHeight + (dIdx * dataRowHeight)

                // Odd rows (1, 3, 5...) vs Even rows (2, 4, 6...) distinct colors
                val isOddRow = (dayNum % 2 != 0)
                fillPaint.color = if (isOddRow) Color.parseColor("#061D3A") else Color.parseColor("#0E3562")
                canvas.drawRect(tableLeft, rowTopY, tableRight, rowTopY + dataRowHeight, fillPaint)

                // Row Bottom Divider Line
                strokePaint.color = goldGrid
                strokePaint.strokeWidth = 0.7f
                canvas.drawLine(tableLeft, rowTopY + dataRowHeight, tableRight, rowTopY + dataRowHeight, strokePaint)
            }

            // Header Bottom Line
            strokePaint.color = goldGrid
            strokePaint.strokeWidth = 1f
            canvas.drawLine(tableLeft, tableTopY + headerRowHeight, tableRight, tableTopY + headerRowHeight, strokePaint)

            // 2) Header Text (RTL) & Vertical Column Dividers across rows
            var currentRight = tableRight
            for (colIdx in 0..6) {
                val cWidth = colWidths[colIdx]
                val cLeft = currentRight - cWidth
                val cCenterX = cLeft + (cWidth / 2f)

                textPaint.color = goldPrimary
                textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                textPaint.textSize = 11.5f
                textPaint.textAlign = Paint.Align.CENTER

                val baselineY = tableTopY + (headerRowHeight / 2f) - ((textPaint.descent() + textPaint.ascent()) / 2f)
                canvas.drawText(colTitles[colIdx], cCenterX, baselineY, textPaint)

                // Vertical column divider across entire table (drawn cleanly over row backgrounds)
                if (colIdx < 6) {
                    strokePaint.color = goldGrid
                    strokePaint.strokeWidth = 0.8f
                    canvas.drawLine(cLeft, tableTopY, cLeft, tableBottomY, strokePaint)
                }

                currentRight = cLeft
            }

            // 3) Draw Data Cells Numbers & Prayer Times (Pure White, Bold, Centered)
            for (dIdx in 0 until daysInMonth) {
                val dayItem = daysList.getOrNull(dIdx)
                val dayNum = dIdx + 1
                val rowTopY = tableTopY + headerRowHeight + (dIdx * dataRowHeight)

                // Cell values RTL (Day, Fajr, Sunrise, Dhuhr, Asr, Maghrib, Isha)
                val cellValues = arrayOf(
                    "$dayNum",
                    dayItem?.fajrSecond ?: "--:--",
                    dayItem?.sunrise ?: "--:--",
                    dayItem?.dhuhr ?: "--:--",
                    dayItem?.asr ?: "--:--",
                    dayItem?.maghrib ?: "--:--",
                    dayItem?.isha ?: "--:--"
                )

                var cRight = tableRight
                for (colIdx in 0..6) {
                    val cWidth = colWidths[colIdx]
                    val cLeft = cRight - cWidth
                    val cCenterX = cLeft + (cWidth / 2f)

                    textPaint.color = textWhite
                    textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                    textPaint.textSize = 11.5f
                    textPaint.textAlign = Paint.Align.CENTER

                    val baselineY = rowTopY + (dataRowHeight / 2f) - ((textPaint.descent() + textPaint.ascent()) / 2f)
                    canvas.drawText(cellValues[colIdx], cCenterX, baselineY, textPaint)

                    cRight = cLeft
                }
            }

            // 4) Outer Table Border (Gold)
            strokePaint.color = goldGrid
            strokePaint.strokeWidth = 1.2f
            canvas.drawRect(tableLeft, tableTopY, tableRight, tableBottomY, strokePaint)

            // 5. Footer Section
            val footerY = 804f

            // Right: Quranic Verse
            textPaint.color = textPaleSlate
            textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            textPaint.textSize = 9.5f
            textPaint.textAlign = Paint.Align.RIGHT
            canvas.drawText("«أقيموا الصلاة وآتوا الزكاة واركعوا مع الراكعين»", tableRight - 4f, footerY, textPaint)

            // Center: Page number "صفحة X من 12"
            textPaint.color = goldPrimary
            textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            textPaint.textSize = 10.5f
            textPaint.textAlign = Paint.Align.CENTER
            canvas.drawText("صفحة $monthIndex من 12", pageWidth / 2f, footerY, textPaint)

            // Left: Print date
            textPaint.color = textPaleSlate
            textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            textPaint.textSize = 9f
            textPaint.textAlign = Paint.Align.LEFT
            canvas.drawText("تاريخ الطباعة: $printDateStr", tableLeft + 4f, footerY, textPaint)

            pdfDoc.finishPage(page)
        }

        return pdfDoc
    }

    /**
     * Print Document:
     * Opens native Android system Print Manager and presents printer selection/PDF save dialog.
     * Does NOT download any file automatically.
     */
    fun printAnnualCalendar(
        context: Context,
        schedule: MosqueSchedule,
        mosqueName: String,
        year: Int
    ) {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
        val printJobName = "جدول مواقيت الصلاة للعام $year - $mosqueName"

        val adapter = object : PrintDocumentAdapter() {
            private var generatedPdf: PdfDocument? = null

            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes?,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback?,
                extras: Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback?.onLayoutCancelled()
                    return
                }

                val info = PrintDocumentInfo.Builder("prayer_calendar_${year}.pdf")
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(12)
                    .build()

                callback?.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out PageRange>?,
                destination: ParcelFileDescriptor?,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback?.onWriteCancelled()
                    return
                }

                try {
                    val pdf = generateAnnualPdfDocument(schedule, mosqueName, year)
                    generatedPdf = pdf
                    destination?.fileDescriptor?.let { fd ->
                        FileOutputStream(fd).use { outputStream ->
                            pdf.writeTo(outputStream)
                        }
                    }
                    callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    callback?.onWriteFailed(e.message)
                } finally {
                    try {
                        generatedPdf?.close()
                    } catch (_: Exception) {}
                    generatedPdf = null
                }
            }
        }

        val attributes = PrintAttributes.Builder()
            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
            .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
            .build()

        printManager.print(printJobName, adapter, attributes)
    }

    /**
     * Download PDF:
     * Generates a real 12-page vector/text PDF file and saves it in public Downloads.
     * Only executes when the user explicitly clicks the Download PDF button.
     */
    fun downloadAnnualCalendarPdf(
        context: Context,
        schedule: MosqueSchedule,
        mosqueName: String,
        year: Int
    ): Result<File> {
        return try {
            val fileName = "prayer_schedule_${year}.pdf"
            val pdfDoc = generateAnnualPdfDocument(schedule, mosqueName, year)

            // 1. Cache file for immediate viewing/sharing via FileProvider
            val cacheFile = File(context.cacheDir, fileName)
            FileOutputStream(cacheFile).use { out ->
                pdfDoc.writeTo(out)
            }
            pdfDoc.close()

            // 2. Save into system Downloads directory
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = context.contentResolver
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { out ->
                        FileInputStream(cacheFile).use { inp ->
                            inp.copyTo(out)
                        }
                    }
                }
            } else {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (downloadsDir.exists() || downloadsDir.mkdirs()) {
                    val publicFile = File(downloadsDir, fileName)
                    FileInputStream(cacheFile).use { inp ->
                        FileOutputStream(publicFile).use { out ->
                            inp.copyTo(out)
                        }
                    }
                }
            }

            // 3. Launch intent to view the PDF file
            try {
                val fileUri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", cacheFile)
                val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(fileUri, "application/pdf")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(Intent.createChooser(viewIntent, "فتح ملف مواقيت الصلاة (PDF)"))
            } catch (e: Exception) {
                // If no viewer app is installed, file is safely in Downloads
            }

            Result.success(cacheFile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Export JSON:
     * Exports the 12 months schedule as a standard, valid JSON file.
     * Contains: year, mosque, 12 months, days with (day, fajr, fajr_second, sunrise, dhuhr, asr, maghrib, isha).
     * Strictly removes fajr_first.
     */
    fun exportAnnualCalendarJson(
        context: Context,
        schedule: MosqueSchedule,
        mosqueName: String,
        year: Int
    ): Result<File> {
        return try {
            val fileName = "prayer_schedule_${year}.json"
            val root = JSONObject()
            root.put("year", year)
            root.put("mosque", mosqueName)
            root.put("version", "2.0")
            root.put("description", "جدول مواقيت الصلاة للعام $year")

            val monthsArray = JSONArray()
            for (m in 1..12) {
                val mObj = JSONObject()
                mObj.put("month", m)
                val monthData = schedule.months.find { it.month == m }
                val daysInMonth = try {
                    YearMonth.of(year, m).lengthOfMonth()
                } catch (e: Exception) {
                    30
                }
                val daysList = getOrPopulateMonthDays(monthData, m, daysInMonth)

                val daysArray = JSONArray()
                for (d in daysList) {
                    val dObj = JSONObject()
                    dObj.put("day", d.day)
                    // Standard prayer times - NO fajr_first
                    dObj.put("fajr", d.fajrSecond)
                    dObj.put("fajr_second", d.fajrSecond)
                    dObj.put("sunrise", d.sunrise)
                    dObj.put("dhuhr", d.dhuhr)
                    dObj.put("asr", d.asr)
                    dObj.put("maghrib", d.maghrib)
                    dObj.put("isha", d.isha)
                    daysArray.put(dObj)
                }
                mObj.put("days", daysArray)
                monthsArray.put(mObj)
            }
            root.put("months", monthsArray)

            val jsonContent = root.toString(2)

            // 1. Cache file
            val cacheFile = File(context.cacheDir, fileName)
            cacheFile.writeText(jsonContent, Charsets.UTF_8)

            // 2. Public Downloads directory
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = context.contentResolver
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/json")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { out ->
                        out.write(jsonContent.toByteArray(Charsets.UTF_8))
                    }
                }
            } else {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (downloadsDir.exists() || downloadsDir.mkdirs()) {
                    val publicFile = File(downloadsDir, fileName)
                    publicFile.writeText(jsonContent, Charsets.UTF_8)
                }
            }

            // 3. Share chooser
            try {
                val fileUri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", cacheFile)
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "application/json"
                    putExtra(Intent.EXTRA_STREAM, fileUri)
                    putExtra(Intent.EXTRA_SUBJECT, "جدول مواقيت الصلاة للعام $year - $mosqueName")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(Intent.createChooser(shareIntent, "مشاركة / تصدير ملف جدول المواقيت (JSON)"))
            } catch (e: Exception) {
                // Shared if chooser available
            }

            Result.success(cacheFile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
