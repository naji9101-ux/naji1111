package com.example.util

import android.app.Activity
import android.app.ActivityManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.os.Build
import android.util.Log
import com.example.receiver.MosqueDeviceAdminReceiver

/**
 * وضع الشاشة الثابتة (Kiosk) باستخدام Android Lock Task Mode الحقيقي.
 *
 * - إن كان التطبيق Device Owner: قفل كامل (لا Home ولا Recents ولا إشعارات) دون أي تأكيد.
 * - وإلا: تثبيت الشاشة (Screen Pinning) — يطلب النظام تأكيد المستخدم، ويمكن الخروج منه
 *   بالضغط المطوّل على زري الرجوع والنظرة العامة. هذا أقصى ما تسمح به Android بدون Device Owner.
 */
object KioskManager {

    private const val TAG = "KioskManager"

    enum class Mode { FULL_LOCK, SCREEN_PINNING, OFF, FAILED }

    private fun dpm(context: Context): DevicePolicyManager =
        context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager

    fun adminComponent(context: Context) = ComponentName(context, MosqueDeviceAdminReceiver::class.java)

    fun isDeviceOwner(context: Context): Boolean =
        try { dpm(context).isDeviceOwnerApp(context.packageName) } catch (_: Exception) { false }

    fun isInLockTask(context: Context): Boolean = try {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        am.lockTaskModeState != ActivityManager.LOCK_TASK_MODE_NONE
    } catch (_: Exception) {
        false
    }

    /** أمر adb لتعيين التطبيق Device Owner (يُنفَّذ مرة واحدة على جهاز بلا حسابات مسجلة). */
    fun deviceOwnerCommand(context: Context): String =
        "adb shell dpm set-device-owner ${context.packageName}/${MosqueDeviceAdminReceiver::class.java.name}"

    /** يطبّق الحالة المطلوبة من داخل Activity (startLockTask/stopLockTask يحتاجان Activity). */
    fun apply(activity: Activity, enabled: Boolean): Mode {
        return try {
            if (enabled) {
                val owner = isDeviceOwner(activity)
                if (owner) {
                    val admin = adminComponent(activity)
                    val d = dpm(activity)
                    d.setLockTaskPackages(admin, arrayOf(activity.packageName))
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        d.setLockTaskFeatures(admin, DevicePolicyManager.LOCK_TASK_FEATURE_NONE)
                    }
                }
                if (!isInLockTask(activity)) {
                    activity.startLockTask()
                }
                if (owner) Mode.FULL_LOCK else Mode.SCREEN_PINNING
            } else {
                if (isInLockTask(activity)) {
                    activity.stopLockTask()
                }
                Mode.OFF
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to apply kiosk mode (enabled=$enabled)", e)
            Mode.FAILED
        }
    }

    /** رسالة واضحة تُعرض للمستخدم عند تفعيل الخيار، تصف الوضع الذي سيعمل فعلياً. */
    fun enableMessage(context: Context): String =
        if (isDeviceOwner(context)) {
            "تم تفعيل القفل الكامل (Lock Task): لا يمكن الخروج من التطبيق إلا بإيقاف هذا الخيار."
        } else {
            "سيعمل تثبيت الشاشة (Screen Pinning): قد يطلب النظام تأكيدك، ويمكن الخروج منه بالضغط المطوّل " +
                "على زري الرجوع والنظرة العامة. للقفل الكامل عيّن التطبيق Device Owner بالأمر: " +
                deviceOwnerCommand(context)
        }
}
