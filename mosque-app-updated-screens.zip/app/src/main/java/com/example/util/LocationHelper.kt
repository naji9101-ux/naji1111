package com.example.util

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Locale
import kotlin.coroutines.resume

sealed class LocationResult {
    data class Success(
        val cityName: String,
        val latitude: Double,
        val longitude: Double
    ) : LocationResult()

    data class Error(val message: String) : LocationResult()
}

object LocationHelper {

    fun hasLocationPermission(context: Context): Boolean {
        val fine = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        return fine || coarse
    }

    fun isLocationServiceEnabled(context: Context): Boolean {
        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            ?: return false
        val gpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
        val networkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
        return gpsEnabled || networkEnabled
    }

    @SuppressLint("MissingPermission")
    suspend fun getCurrentLocation(context: Context): LocationResult = withContext(Dispatchers.IO) {
        if (!hasLocationPermission(context)) {
            return@withContext LocationResult.Error("يرجى منح إذن تحديد الموقع (GPS)")
        }
        if (!isLocationServiceEnabled(context)) {
            return@withContext LocationResult.Error("خدمة الموقع (GPS) غير مفعلة على الجهاز")
        }

        var foundLocation: Location? = null

        // Try FusedLocationProviderClient first
        try {
            val fusedClient = LocationServices.getFusedLocationProviderClient(context)
            val cts = CancellationTokenSource()
            foundLocation = withTimeoutOrNull(6000L) {
                suspendCancellableCoroutine { continuation ->
                    fusedClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, cts.token)
                        .addOnSuccessListener { loc ->
                            continuation.resume(loc)
                        }
                        .addOnFailureListener {
                            continuation.resume(null)
                        }
                }
            }
            if (foundLocation == null) {
                foundLocation = suspendCancellableCoroutine { cont ->
                    fusedClient.lastLocation
                        .addOnSuccessListener { loc -> cont.resume(loc) }
                        .addOnFailureListener { cont.resume(null) }
                }
            }
        } catch (_: Exception) {}

        // Fallback to system LocationManager
        if (foundLocation == null) {
            foundLocation = getLocationFromLocationManager(context)
        }

        if (foundLocation == null) {
            return@withContext LocationResult.Error("تعذر استقبال إشارة GPS، يرجى التأكد من تشغيل الموقع والمحاولة في مكان مكشوف")
        }

        val lat = foundLocation.latitude
        val lng = foundLocation.longitude
        val cityName = resolveCityName(context, lat, lng)

        return@withContext LocationResult.Success(
            cityName = cityName,
            latitude = lat,
            longitude = lng
        )
    }

    @SuppressLint("MissingPermission")
    private suspend fun getLocationFromLocationManager(context: Context): Location? {
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
        val providers = listOf(
            LocationManager.GPS_PROVIDER,
            LocationManager.NETWORK_PROVIDER,
            LocationManager.PASSIVE_PROVIDER
        )
        var bestLastKnown: Location? = null
        for (p in providers) {
            if (lm.isProviderEnabled(p)) {
                val loc = lm.getLastKnownLocation(p)
                if (loc != null) {
                    if (bestLastKnown == null || loc.accuracy < bestLastKnown.accuracy) {
                        bestLastKnown = loc
                    }
                }
            }
        }
        if (bestLastKnown != null && System.currentTimeMillis() - bestLastKnown.time < 300_000L) {
            return bestLastKnown
        }

        return withTimeoutOrNull(8000L) {
            suspendCancellableCoroutine { continuation ->
                val listener = object : LocationListener {
                    override fun onLocationChanged(location: Location) {
                        lm.removeUpdates(this)
                        if (continuation.isActive) continuation.resume(location)
                    }

                    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                    override fun onProviderEnabled(provider: String) {}
                    override fun onProviderDisabled(provider: String) {}
                }
                continuation.invokeOnCancellation {
                    lm.removeUpdates(listener)
                }

                var registered = false
                if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                    try {
                        lm.requestSingleUpdate(LocationManager.GPS_PROVIDER, listener, Looper.getMainLooper())
                        registered = true
                    } catch (_: Exception) {}
                }
                if (!registered && lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                    try {
                        lm.requestSingleUpdate(LocationManager.NETWORK_PROVIDER, listener, Looper.getMainLooper())
                        registered = true
                    } catch (_: Exception) {}
                }
                if (!registered) {
                    continuation.resume(bestLastKnown)
                }
            }
        } ?: bestLastKnown
    }

    private fun resolveCityName(context: Context, latitude: Double, longitude: Double): String {
        return try {
            val geocoder = Geocoder(context, Locale("ar"))
            val addresses = geocoder.getFromLocation(latitude, longitude, 1)
            if (!addresses.isNullOrEmpty()) {
                val addr = addresses[0]
                val locality = addr.locality
                val subAdmin = addr.subAdminArea
                val adminArea = addr.adminArea
                val country = addr.countryName
                when {
                    !locality.isNullOrBlank() -> "$locality${if (!country.isNullOrBlank()) " - $country" else ""}"
                    !subAdmin.isNullOrBlank() -> "$subAdmin${if (!country.isNullOrBlank()) " - $country" else ""}"
                    !adminArea.isNullOrBlank() -> "$adminArea${if (!country.isNullOrBlank()) " - $country" else ""}"
                    !country.isNullOrBlank() -> country
                    else -> String.format(Locale.US, "%.4f, %.4f", latitude, longitude)
                }
            } else {
                String.format(Locale.US, "%.4f, %.4f", latitude, longitude)
            }
        } catch (e: Exception) {
            String.format(Locale.US, "%.4f, %.4f", latitude, longitude)
        }
    }
}
