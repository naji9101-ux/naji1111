package com.example.util

import android.content.Context
import android.net.Uri
import android.util.Log
import java.io.File
import java.io.FileOutputStream

object FileStorageHelper {

    fun copyUriToInternalFile(context: Context, sourceUri: Uri, destinationFileName: String): String? {
        return try {
            val destFile = File(context.filesDir, destinationFileName)
            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output)
                }
            }
            Uri.fromFile(destFile).toString()
        } catch (e: Exception) {
            Log.e("FileStorageHelper", "Failed to save file internally", e)
            sourceUri.toString()
        }
    }

    fun readTextFromUri(context: Context, uri: Uri): String? {
        return try {
            context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
        } catch (e: Exception) {
            Log.e("FileStorageHelper", "Failed to read text from uri", e)
            null
        }
    }
}
