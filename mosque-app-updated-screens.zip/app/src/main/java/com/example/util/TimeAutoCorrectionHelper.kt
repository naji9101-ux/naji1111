package com.example.util

import java.util.Locale

sealed class TimeParseResult {
    data class Success(val formattedTime: String) : TimeParseResult()
    data class Error(val reason: String) : TimeParseResult()
}

object TimeAutoCorrectionHelper {

    /**
     * Converts Eastern Arabic digits (٠-٩) and Persian digits (۰-۹) to standard Western digits (0-9).
     */
    fun normalizeDigits(input: String): String {
        val sb = StringBuilder()
        for (ch in input) {
            when (ch) {
                in '٠'..'٩' -> sb.append((ch - '٠' + '0'.code).toChar())
                in '۰'..'۹' -> sb.append((ch - '۰' + '0'.code).toChar())
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    /**
     * Parses and auto-corrects time input into standard "HH:mm" format (e.g., "04:34").
     *
     * Rules:
     * - "4:34"  -> "04:34"
     * - "434"   -> "04:34"
     * - "415"   -> "04:15"
     * - "530"   -> "05:30"
     * - "945"   -> "09:45"
     * - "0415"  -> "04:15"
     * - "1205"  -> "12:05"
     *
     * Validations:
     * - Minutes must be between 00 and 59 (e.g. "475" is rejected because 75 > 59).
     * - Hours must be between 00 and 23.
     */
    fun parseAndCorrect(rawInput: String): TimeParseResult {
        val clean = normalizeDigits(rawInput.trim()).replace(" ", "")

        if (clean.isEmpty()) {
            return TimeParseResult.Error("الوقت فارغ")
        }

        // Case 1: Contains colon separator, e.g. "4:34", "04:15", "12:5"
        if (clean.contains(":")) {
            val parts = clean.split(":")
            if (parts.size != 2) {
                return TimeParseResult.Error("صيغة الوقت غير صحيحة")
            }
            val hourStr = parts[0]
            val minStr = parts[1]

            val h = hourStr.toIntOrNull()
            val m = minStr.toIntOrNull()

            if (h == null || m == null) {
                return TimeParseResult.Error("يجب أن يحتوي الوقت على أرقام فقط")
            }

            return validateAndFormat(h, m)
        }

        // Only digits
        val digitsOnly = clean.filter { it.isDigit() }
        if (digitsOnly.length != clean.length) {
            return TimeParseResult.Error("المدخلات يجب أن تكون أرقاماً فقط")
        }

        return when (digitsOnly.length) {
            3 -> {
                // E.g. "434" -> 4:34 -> "04:34", "415" -> "04:15", "530" -> "05:30", "945" -> "09:45"
                val h = digitsOnly.substring(0, 1).toInt()
                val m = digitsOnly.substring(1).toInt()
                validateAndFormat(h, m)
            }
            4 -> {
                // E.g. "0415" -> "04:15", "1205" -> "12:05"
                val h = digitsOnly.substring(0, 2).toInt()
                val m = digitsOnly.substring(2).toInt()
                validateAndFormat(h, m)
            }
            1, 2 -> {
                // 1 or 2 digits without colon e.g. "4" or "12" -> Treat as hour with 00 minutes
                val h = digitsOnly.toInt()
                validateAndFormat(h, 0)
            }
            else -> {
                TimeParseResult.Error("طول وقت الصلاة غير صالح (أدخل 3 أو 4 أرقام مثل 415 أو 04:15)")
            }
        }
    }

    private fun validateAndFormat(h: Int, m: Int): TimeParseResult {
        if (m !in 0..59) {
            return TimeParseResult.Error("الدقائق غير صالحة ($m): يجب أن تكون بين 00 و 59")
        }
        if (h !in 0..23) {
            return TimeParseResult.Error("الساعة غير صالحة ($h): يجب أن تكون بين 00 و 23")
        }
        val formatted = String.format(Locale.US, "%02d:%02d", h, m)
        return TimeParseResult.Success(formatted)
    }

    /**
     * Determines whether typing has completed 4 digits without colon (e.g. "0415" or "1205")
     * so it can be formatted inline without blocking the user.
     */
    fun shouldAutoFormatLive(input: String): Boolean {
        val clean = normalizeDigits(input.trim())
        if (!clean.contains(":") && clean.length == 4 && clean.all { it.isDigit() }) {
            val h = clean.substring(0, 2).toIntOrNull() ?: return false
            val m = clean.substring(2).toIntOrNull() ?: return false
            return h in 0..23 && m in 0..59
        }
        return false
    }
}
