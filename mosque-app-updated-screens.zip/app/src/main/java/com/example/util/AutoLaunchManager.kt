package com.example.util

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.Log
import android.widget.Toast
import com.example.MainActivity

/**
 * وضع الشاشة الرئيسية (تشغيل تلقائي بعد الإقلاع).
 *
 * الطريقة الأكثر موثوقية: تعيين التطبيق كشاشة رئيسية افتراضية (Home) فيشغّله النظام نفسه عند الإقلاع.
 * الطريقة المساندة: BOOT_COMPLETED + إطلاق النشاط، وهي على Android 10+ مقيّدة من النظام وتتطلب
 * إذن «العرض فوق التطبيقات الأخرى» (أو أن يكون التطبيق Home افتراضياً / Device Owner).
 */
object AutoLaunchManager {

    private const val TAG = "AutoLaunchManager"
    private const val PREFS = "mosque_prayer_prefs"
    private const val KEY_PENDING_HOME_PICKER = "pending_home_picker"
    const val KEY_AUTO_START = "isAutoStartHomeEnabled"

    fun isDefaultHome(context: Context): Boolean = try {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val ri = context.packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
        ri?.activityInfo?.packageName == context.packageName
    } catch (_: Exception) {
        false
    }

    fun canDrawOverlays(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(context)

    /** هل يستطيع التطبيق فتح واجهته من الخلفية عند الإقلاع على هذا الجهاز؟ */
    fun canLaunchFromBackground(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.Q ||
            canDrawOverlays(context) ||
            KioskManager.isDeviceOwner(context) ||
            isDefaultHome(context)

    fun launchMainActivity(context: Context) {
        try {
            val intent = Intent(context, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to launch MainActivity from background", e)
        }
    }

    /** يقرأ حالة التفعيل من التخزين الدائم (SharedPreferences) ثم من ملف الإعدادات كاحتياط. */
    fun isAutoStartEnabled(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.contains(KEY_AUTO_START)) return prefs.getBoolean(KEY_AUTO_START, false)
        return try {
            com.example.data.PrayerRepository(context).loadSettings().isAutoStartHomeEnabled
        } catch (_: Exception) {
            false
        }
    }

    fun launchIfEnabled(context: Context) {
        if (!isAutoStartEnabled(context)) return
        if (!canLaunchFromBackground(context)) {
            Log.w(TAG, "Auto-start enabled but system blocks background launch; app must be default Home or have overlay permission")
        }
        launchMainActivity(context)
    }

    fun openHomeSettings(context: Context) {
        val flags = Intent.FLAG_ACTIVITY_NEW_TASK
        try {
            context.startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(flags))
        } catch (_: Exception) {
            try {
                context.startActivity(
                    Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(flags)
                )
            } catch (e: Exception) {
                Log.e(TAG, "Unable to open Home settings", e)
                Toast.makeText(
                    context,
                    "تعذّر فتح إعدادات الشاشة الرئيسية. من إعدادات النظام: التطبيقات الافتراضية ← تطبيق الشاشة الرئيسية، ثم اختر هذا التطبيق.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    /** يُستدعى عند تفعيل الخيار: يشرح للمستخدم الخطوات المطلوبة ويفتح شاشة النظام المناسبة. */
    fun requestSetup(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        when {
            isDefaultHome(context) -> {
                Toast.makeText(
                    context,
                    "التطبيق هو الشاشة الرئيسية الافتراضية: سيفتح تلقائياً بعد إعادة تشغيل الجهاز.",
                    Toast.LENGTH_LONG
                ).show()
            }
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && !canDrawOverlays(context) -> {
                prefs.edit().putBoolean(KEY_PENDING_HOME_PICKER, true).commit()
                Toast.makeText(
                    context,
                    "الخطوة 1: فعّل «العرض فوق التطبيقات الأخرى» ليتمكن التطبيق من الفتح بعد الإقلاع، ثم ارجع وسنفتح لك اختيار الشاشة الرئيسية.",
                    Toast.LENGTH_LONG
                ).show()
                try {
                    context.startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (e: Exception) {
                    Log.e(TAG, "Unable to open overlay permission screen", e)
                    prefs.edit().remove(KEY_PENDING_HOME_PICKER).commit()
                    openHomeSettings(context)
                }
            }
            else -> {
                Toast.makeText(
                    context,
                    "اختر هذا التطبيق كتطبيق افتراضي للشاشة الرئيسية ليفتح تلقائياً بعد إعادة تشغيل الجهاز.",
                    Toast.LENGTH_LONG
                ).show()
                openHomeSettings(context)
            }
        }
    }

    /** يُستدعى من onResume: يُكمل خطوة اختيار الشاشة الرئيسية بعد العودة من شاشة إذن العرض. */
    fun onActivityResumed(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(KEY_PENDING_HOME_PICKER, false)) return
        prefs.edit().remove(KEY_PENDING_HOME_PICKER).commit()
        if (!isAutoStartEnabled(context)) return
        if (!canDrawOverlays(context)) {
            Toast.makeText(
                context,
                "لم يُمنح إذن العرض فوق التطبيقات: لن يفتح التطبيق من الخلفية إلا إن عُيّن شاشة رئيسية افتراضية.",
                Toast.LENGTH_LONG
            ).show()
        }
        if (!isDefaultHome(context)) {
            Toast.makeText(
                context,
                "الخطوة 2: اختر هذا التطبيق كتطبيق افتراضي للشاشة الرئيسية.",
                Toast.LENGTH_LONG
            ).show()
            openHomeSettings(context)
        }
    }

    fun cancelPending(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_PENDING_HOME_PICKER).commit()
    }
}
