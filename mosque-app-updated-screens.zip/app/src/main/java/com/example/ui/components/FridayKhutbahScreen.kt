package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ArefRuqaaFamily
import com.example.ui.theme.CairoFamily
import com.example.ui.theme.CinzelFamily
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import java.util.Locale

/** شاشة الخطبة بالتصميم المرفق، مع إبقاء العدّاد والإعدادات الأصلية. */
@Composable
fun FridayKhutbahScreen(
    secondsRemaining: Long = 2700L,
    currentDurationMinutes: Int = 45,
    isAutoKhutbahEnabled: Boolean = true,
    onSaveSettings: ((newDuration: Int, isEnabled: Boolean) -> Unit)? = null,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val initialSeconds = remember(secondsRemaining) {
        if (secondsRemaining > 0L) secondsRemaining else (currentDurationMinutes * 60L).coerceAtLeast(60L)
    }
    var currentSecondsLeft by remember(initialSeconds) { mutableLongStateOf(initialSeconds) }
    var showSettingsModal by remember { mutableStateOf(false) }

    LaunchedEffect(initialSeconds) {
        currentSecondsLeft = initialSeconds
        while (isActive && currentSecondsLeft > 0L) {
            delay(1000L)
            currentSecondsLeft -= 1L
            if (currentSecondsLeft <= 0L) {
                onDismiss()
                break
            }
        }
    }

    val formattedCountdown = remember(currentSecondsLeft) {
        val safe = currentSecondsLeft.coerceAtLeast(0L)
        String.format(Locale.US, "%02d:%02d", safe / 60, safe % 60)
    }

    HtmlDesignScreen(
        assetName = "khutbah.html",
        state = org.json.JSONObject()
            .put("countdown", formattedCountdown)
            .put("prayerName", "خطبة الجمعة"),
        onAction = { action ->
            when (action) {
                "settings" -> showSettingsModal = true
                "dismiss" -> onDismiss()
            }
        },
        modifier = modifier,
        screenTag = "friday_khutbah_screen"
    )

    if (showSettingsModal) {
        ExactKhutbahSettingsModalDialog(
            initialDuration = currentDurationMinutes,
            initialEnabled = isAutoKhutbahEnabled,
            onSave = { dur, enabled ->
                onSaveSettings?.invoke(dur, enabled)
                showSettingsModal = false
            },
            onDismiss = { showSettingsModal = false }
        )
    }
}

private fun svgPath(d: String): Path = PathParser().parsePathString(d).toPath()

/** السماعة الصوتية وموجاتها — viewBox 220×220 كما في الـSVG الأصلي */
@Composable
private fun OriginalVectorSpeakerWaves(modifier: Modifier = Modifier) {
    val arc1 = remember { svgPath("M136 78 C150 90 150 130 136 142") }
    val arc2 = remember { svgPath("M152 64 C172 80 172 140 152 156") }
    val arc3 = remember { svgPath("M168 52 C194 72 194 148 168 168") }

    Canvas(modifier = modifier) {
        val s = size.minDimension / 220f
        withTransform({ scale(s, s, Offset.Zero) }) {
            val c = Offset(110f, 110f)
            val aura = Brush.radialGradient(
                colorStops = arrayOf(
                    0f to Color(0xFF0B3464).copy(alpha = 0.9f),
                    0.7f to Color(0xFF05274F).copy(alpha = 0.95f),
                    1f to Color(0xFF031835)
                ),
                center = c,
                radius = 98f
            )
            drawCircle(aura, radius = 98f, center = c)
            drawCircle(OvGold.copy(alpha = 0.95f), radius = 98f, center = c, style = Stroke(2.5f))
            drawCircle(
                OvGold.copy(alpha = 0.55f), radius = 92f, center = c,
                style = Stroke(1.2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 3f)))
            )

            drawPath(arc1, OvGoldLight.copy(alpha = 0.9f), style = Stroke(5f, cap = StrokeCap.Round))
            drawPath(arc2, OvGold.copy(alpha = 0.8f), style = Stroke(5.5f, cap = StrokeCap.Round))
            drawPath(arc3, OvGoldLight.copy(alpha = 0.6f), style = Stroke(4.5f, cap = StrokeCap.Round))

            withTransform({ translate(48f, 62f) }) {
                val dark = Color(0xFF082346)
                drawRoundRect(dark, Offset(8f, 32f), Size(22f, 32f), CornerRadius(5f, 5f))
                drawRoundRect(OvGold, Offset(8f, 32f), Size(22f, 32f), CornerRadius(5f, 5f), style = Stroke(3f))

                val horn = Path().apply {
                    moveTo(30f, 32f); lineTo(70f, 8f); lineTo(70f, 88f); lineTo(30f, 64f); close()
                }
                val hornBrush = Brush.linearGradient(
                    colorStops = arrayOf(
                        0f to Color(0xFF0C3463),
                        0.5f to Color(0xFF072346),
                        1f to Color(0xFF04162C)
                    ),
                    start = Offset(30f, 8f),
                    end = Offset(70f, 88f)
                )
                drawPath(horn, hornBrush)
                drawPath(horn, OvGold, style = Stroke(3.5f, join = StrokeJoin.Round))

                drawOval(dark, Offset(64f, 8f), Size(12f, 80f))
                drawOval(OvGoldLight, Offset(64f, 8f), Size(12f, 80f), style = Stroke(3.5f))
                drawOval(OvGoldAccent, Offset(67.5f, 30f), Size(5f, 36f))
                drawLine(OvGold.copy(alpha = 0.6f), Offset(18f, 38f), Offset(18f, 58f), strokeWidth = 2.5f, cap = StrokeCap.Round)
            }
        }
    }
}

@Composable
private fun ExactKhutbahSettingsModalDialog(
    initialDuration: Int,
    initialEnabled: Boolean,
    onSave: (duration: Int, isEnabled: Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    var draftDuration by remember { mutableIntStateOf(initialDuration.coerceIn(1, 180)) }
    var isEnabled by remember { mutableStateOf(initialEnabled) }

    OvModalShell(
        title = "إعدادات شاشة خطبة الجمعة",
        subtitle = "تعديل مدة استمرار شاشة «استمع للخطبة»",
        saveTag = "khutbah_save_modal_button",
        onSave = { onSave(draftDuration, isEnabled) },
        onDismiss = onDismiss
    ) {
        OvMinuteRowCard(
            title = "مدة شاشة الخطبة",
            subtitle = "بالدقائق",
            value = draftDuration,
            min = 1,
            max = 180,
            onChange = { draftDuration = it }
        )

        OvToggleRow(
            title = "تفعيل شاشة خطبة الجمعة التلقائية",
            subtitle = "تحل محل إقامة الظهر يوم الجمعة فقط",
            checked = isEnabled,
            onToggle = { isEnabled = !isEnabled }
        )
    }
}
