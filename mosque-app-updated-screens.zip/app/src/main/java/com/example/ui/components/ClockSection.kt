package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ActiveCountdown
import com.example.model.AppSettings
import com.example.ui.theme.*

@Composable
fun ClockSection(
    currentTimeFormatted: String,
    dayOfWeek: String,
    hijriDate: String,
    gregorianDate: String,
    adhanCountdown: ActiveCountdown?,
    iqamaCountdown: ActiveCountdown?,
    isIqamaNow: Boolean,
    settings: AppSettings,
    isPeriodInterfaceActive: Boolean = false,
    modifier: Modifier = Modifier
) {
    val cardAlpha = if (isPeriodInterfaceActive) 0.0f else 0.95f
    val borderAlpha = 1.0f

    Column(
        modifier = modifier
            .fillMaxHeight()
            .padding(horizontal = 6.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top: Giant Live Clock Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1.15f)
                .then(
                    if (!isPeriodInterfaceActive) Modifier.shadow(4.dp, RoundedCornerShape(16.dp))
                    else Modifier
                )
                .clip(RoundedCornerShape(16.dp))
                .then(
                    if (isPeriodInterfaceActive) Modifier.background(Color.Transparent)
                    else Modifier.background(
                        Brush.verticalGradient(
                            listOf(
                                MosqueVeryDarkGreen.copy(alpha = cardAlpha),
                                MosqueDarkGreen.copy(alpha = cardAlpha)
                            )
                        )
                    )
                )
                .border(1.2.dp, MosqueGold.copy(alpha = borderAlpha), RoundedCornerShape(16.dp))
                .padding(vertical = 8.dp, horizontal = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                val clockColor = try {
                    Color(android.graphics.Color.parseColor(settings.clockColorHex))
                } catch (e: Exception) {
                    MosqueLightGold
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    AutoSizedClockText(
                        text = currentTimeFormatted.trim(),
                        targetFontSizeSp = settings.clockSizeSp.toFloat(),
                        color = clockColor,
                        fontWeight = if (settings.clockBold) FontWeight.Black else FontWeight.Bold,
                        letterSpacing = 1.5.sp,
                        fontFamily = FontFamily.SansSerif,
                        horizontalSafetyPadding = 16.dp,
                        verticalSafetyPadding = 6.dp,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                if (settings.showDate) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .height(1.dp)
                            .background(MosqueGold.copy(alpha = 0.4f))
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = dayOfWeek,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MosqueWhite
                        )
                        Text(
                            text = "•",
                            fontSize = 12.sp,
                            color = MosqueGold
                        )
                        Text(
                            text = hijriDate,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MosqueLightGold
                        )
                        Text(
                            text = "•",
                            fontSize = 12.sp,
                            color = MosqueGold
                        )
                        Text(
                            text = gregorianDate,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Normal,
                            color = MosqueIvory
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Middle/Bottom: Countdown Cards
        if (settings.showCountdowns) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.85f),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Next Adhan Countdown Card
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .then(
                            if (!isPeriodInterfaceActive) Modifier.shadow(3.dp, RoundedCornerShape(14.dp))
                            else Modifier
                        )
                        .clip(RoundedCornerShape(14.dp))
                        .then(
                            if (isPeriodInterfaceActive) Modifier.background(Color.Transparent)
                            else Modifier.background(
                                Brush.verticalGradient(
                                    listOf(
                                        MosqueDarkGreen.copy(alpha = cardAlpha),
                                        MosqueVeryDarkGreen.copy(alpha = cardAlpha)
                                    )
                                )
                            )
                        )
                        .border(1.dp, MosqueGold.copy(alpha = borderAlpha), RoundedCornerShape(14.dp))
                        .padding(vertical = 6.dp, horizontal = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccessTime,
                                contentDescription = null,
                                tint = MosqueLightGold,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = adhanCountdown?.title ?: "الأذان القادم",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MosqueLightGold
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = adhanCountdown?.formattedTime ?: "00:00:00",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MosqueWhite,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.sp
                        )
                        if (adhanCountdown != null && adhanCountdown.prayerName.isNotEmpty()) {
                            Text(
                                text = adhanCountdown.prayerName,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = MosqueGold
                            )
                        }
                    }
                }

                // Iqama Countdown Card
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .then(
                            if (!isPeriodInterfaceActive) Modifier.shadow(3.dp, RoundedCornerShape(14.dp))
                            else Modifier
                        )
                        .clip(RoundedCornerShape(14.dp))
                        .then(
                            if (isPeriodInterfaceActive && !isIqamaNow) Modifier.background(Color.Transparent)
                            else if (isIqamaNow) Modifier.background(Brush.verticalGradient(listOf(Color(0xFF2E7D32), Color(0xFF1B5E20))))
                            else Modifier.background(Brush.verticalGradient(listOf(MosqueDarkGreen.copy(alpha = 0.90f), MosqueVeryDarkGreen.copy(alpha = 0.95f))))
                        )
                        .border(
                            1.dp,
                            if (isIqamaNow) MosqueLightGold else MosqueGold.copy(alpha = 0.7f),
                            RoundedCornerShape(14.dp)
                        )
                        .padding(vertical = 6.dp, horizontal = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Alarm,
                                contentDescription = null,
                                tint = if (isIqamaNow) MosqueWhite else MosqueLightGold,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isIqamaNow) "حان موعد الصلاة" else (iqamaCountdown?.title ?: "الإقامة"),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isIqamaNow) MosqueWhite else MosqueLightGold
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        if (isIqamaNow) {
                            val isFridayNow = dayOfWeek.contains("جمعة") || dayOfWeek.contains("الجمعة")
                            if (isFridayNow) {
                                Text(
                                    text = "استمع للخطبة",
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Black,
                                    color = MosqueLightGold,
                                    textAlign = TextAlign.Center
                                )
                            } else {
                                Text(
                                    text = "الصلاة قائمة",
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Black,
                                    color = MosqueLightGold,
                                    textAlign = TextAlign.Center
                                )
                                Text(
                                    text = "أثابكم الله",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MosqueWhite
                                )
                            }
                        } else {
                            Text(
                                text = iqamaCountdown?.formattedTime ?: "--:--:--",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = MosqueWhite,
                                fontFamily = FontFamily.Monospace,
                                letterSpacing = 1.sp
                            )
                            if (iqamaCountdown != null && iqamaCountdown.prayerName.isNotEmpty()) {
                                Text(
                                    text = iqamaCountdown.prayerName,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = MosqueGold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
