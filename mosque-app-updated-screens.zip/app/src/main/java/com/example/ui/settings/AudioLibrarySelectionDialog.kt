package com.example.ui.settings

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.AudioFileItem
import com.example.ui.theme.*

@Composable
fun AudioLibrarySelectionDialog(
    title: String,
    subtitle: String,
    initialSelectedUri: String?,
    librarySounds: List<AudioFileItem>,
    isPlayingTest: Boolean,
    playingSoundKey: String?,
    onTestSound: (String) -> Unit,
    onStopSound: () -> Unit,
    onImportFileFromPhone: (String, Uri) -> AudioFileItem?,
    onDeleteSound: ((AudioFileItem) -> Unit)? = null,
    onConfirmSelection: (selectedItem: AudioFileItem) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var selectedUri by remember { mutableStateOf(initialSelectedUri ?: "") }

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val fileName = uri.lastPathSegment?.substringAfterLast("/") ?: "صوت مخصص"
            val item = onImportFileFromPhone(fileName, uri)
            if (item != null) {
                selectedUri = item.uri
                onConfirmSelection(item)
                Toast.makeText(context, "تمت إضافة واختيار الصوت بنجاح", Toast.LENGTH_SHORT).show()
                onDismiss()
            }
        }
    }

    Dialog(
        onDismissRequest = {
            onStopSound()
            onDismiss()
        },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
            shape = RoundedCornerShape(20.dp),
            color = MosqueVeryDarkGreen,
            border = BorderStroke(1.5.dp, MosqueGold),
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .heightIn(min = 320.dp, max = 580.dp)
                .padding(6.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            onStopSound()
                            onDismiss()
                        }
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = MosqueLightGold)
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.LibraryMusic,
                                contentDescription = null,
                                tint = MosqueGold,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = title,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = MosqueWhite
                            )
                        }
                        Text(
                            text = subtitle,
                            fontSize = 11.5.sp,
                            color = MosqueLightGold.copy(alpha = 0.8f)
                        )
                    }

                    Spacer(modifier = Modifier.width(48.dp))
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Button to import from phone
                Button(
                    onClick = { filePickerLauncher.launch("audio/*") },
                    colors = ButtonDefaults.buttonColors(containerColor = MosqueDeepGreen),
                    border = BorderStroke(1.2.dp, MosqueGold),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth(),
                    contentPadding = PaddingValues(vertical = 10.dp)
                ) {
                    Icon(
                        Icons.Default.UploadFile,
                        contentDescription = null,
                        tint = MosqueGold,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "اختيار ملف صوتي من الهاتف (MP3, WAV, M4A)",
                        color = MosqueGold,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = MosqueGold.copy(alpha = 0.25f))
                Spacer(modifier = Modifier.height(10.dp))

                // Scrollable Sounds List
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    if (librarySounds.isEmpty()) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                Icons.Default.MusicOff,
                                contentDescription = null,
                                tint = MosqueGold.copy(alpha = 0.5f),
                                modifier = Modifier.size(42.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "المكتبة فارغة حالياً",
                                color = MosqueLightGold,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "اضغط على الزر أعلاه لإضافة أصوات من هاتفك",
                                color = MosqueIvory.copy(alpha = 0.7f),
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "الأصوات المتوفرة (${librarySounds.size}):",
                                color = MosqueLightGold,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )

                            librarySounds.forEach { item ->
                                val isDefaultItem = item.isDefault || item.id == com.example.model.DEFAULT_FAJR_FIRST_ID || item.uri.contains("Yaseen Al Aassaf", ignoreCase = true)
                                val isBuiltInItem = item.isBuiltIn || isDefaultItem
                                val canDeleteThisItem = !isDefaultItem && !isBuiltInItem

                                val isSelected = selectedUri == item.uri || selectedUri == item.name
                                val isThisPlaying = isPlayingTest && (playingSoundKey == item.uri || playingSoundKey == item.name)
                                val isMatched = item.isBuiltIn || isDefaultItem || com.example.audio.AudioRegistry.isAudioMatched(item.name) || com.example.audio.AudioRegistry.isAudioMatched(item.uri) || com.example.audio.AudioRegistry.isAudioMatched(item.id)

                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isSelected) MosqueDeepGreen else MosqueDarkGreen.copy(alpha = 0.7f)
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(
                                        width = if (isSelected) 1.5.dp else 1.dp,
                                        color = if (isSelected) MosqueGold else MosqueGold.copy(alpha = 0.3f)
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { selectedUri = item.uri }
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 10.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            RadioButton(
                                                selected = isSelected,
                                                onClick = { selectedUri = item.uri },
                                                colors = RadioButtonDefaults.colors(
                                                    selectedColor = MosqueGold,
                                                    unselectedColor = MosqueLightGold.copy(alpha = 0.6f)
                                                )
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Column {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text(
                                                        text = item.name,
                                                        fontSize = 13.5.sp,
                                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                        color = if (isSelected) MosqueWhite else MosqueIvory
                                                    )
                                                    if (isDefaultItem) {
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Surface(
                                                            color = MosqueGold.copy(alpha = 0.22f),
                                                            shape = RoundedCornerShape(4.dp),
                                                            border = BorderStroke(1.dp, MosqueGold)
                                                        ) {
                                                            Text(
                                                                text = "أساسي",
                                                                fontSize = 9.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                color = MosqueGold,
                                                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.5.dp)
                                                            )
                                                        }
                                                    } else if (isBuiltInItem) {
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Surface(
                                                            color = MosqueGold.copy(alpha = 0.22f),
                                                            shape = RoundedCornerShape(4.dp),
                                                            border = BorderStroke(1.dp, MosqueGold)
                                                        ) {
                                                            Text(
                                                                text = "أساسي",
                                                                fontSize = 9.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                color = MosqueGold,
                                                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.5.dp)
                                                            )
                                                        }
                                                    } else {
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Surface(
                                                            color = Color(0xFF1565C0).copy(alpha = 0.25f),
                                                            shape = RoundedCornerShape(4.dp),
                                                            border = BorderStroke(0.8.dp, Color(0xFF90CAF9))
                                                        ) {
                                                            Text(
                                                                text = "صوت مستخدم",
                                                                fontSize = 8.5.sp,
                                                                color = Color(0xFFBBDEFB),
                                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                            )
                                                        }
                                                    }
                                                }
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    if (isDefaultItem) {
                                                        val defaultLabel = when {
                                                            title.contains("فجر") || title.contains("الفجر") -> "🕌 أذان الفجر الأول الأساسي • "
                                                            title.contains("إقامة") || title.contains("الإقامة") -> "🕌 صوت الإقامة الأساسي • "
                                                            else -> "🕌 الصوت الأساسي • "
                                                        }
                                                        Text(
                                                            text = defaultLabel,
                                                            fontSize = 10.sp,
                                                            color = MosqueGold,
                                                            fontWeight = FontWeight.Medium
                                                        )
                                                    } else if (isSelected) {
                                                        Text(
                                                            text = "محدد حالياً • ",
                                                            fontSize = 10.sp,
                                                            color = MosqueGold
                                                        )
                                                    }
                                                    if (isMatched) {
                                                        Text(
                                                            text = "✓ مرتبط بملف الصوت",
                                                            fontSize = 10.sp,
                                                            color = MosqueLightGold
                                                        )
                                                    } else {
                                                        Text(
                                                            text = "✗ ملف الصوت غير موجود",
                                                            fontSize = 10.sp,
                                                            color = Color(0xFFEF9A9A)
                                                        )
                                                    }
                                                }
                                            }
                                        }

                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            IconButton(
                                                onClick = {
                                                    if (isThisPlaying) {
                                                        onStopSound()
                                                    } else if (isMatched) {
                                                        onStopSound()
                                                        onTestSound(item.uri.ifBlank { item.name })
                                                    } else {
                                                        Toast.makeText(context, "ملف الصوت غير موجود", Toast.LENGTH_SHORT).show()
                                                    }
                                                },
                                                enabled = isMatched || isThisPlaying,
                                                modifier = Modifier.size(36.dp)
                                            ) {
                                                Icon(
                                                    imageVector = if (isThisPlaying) Icons.Default.Stop else Icons.Default.PlayArrow,
                                                    contentDescription = if (isThisPlaying) "إيقاف" else "معاينة",
                                                    tint = if (isThisPlaying) Color(0xFFFF5252) else if (isMatched) MosqueGold else MosqueGold.copy(alpha = 0.3f)
                                                )
                                            }

                                            if (canDeleteThisItem && onDeleteSound != null) {
                                                IconButton(
                                                    onClick = {
                                                        onDeleteSound(item)
                                                        if (selectedUri == item.uri) {
                                                            selectedUri = ""
                                                        }
                                                        Toast.makeText(context, "تم حذف الصوت من المكتبة", Toast.LENGTH_SHORT).show()
                                                    },
                                                    modifier = Modifier.size(36.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Delete,
                                                        contentDescription = "حذف",
                                                        tint = Color(0xFFEF5350).copy(alpha = 0.85f),
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = MosqueGold.copy(alpha = 0.25f))
                Spacer(modifier = Modifier.height(10.dp))

                // Footer Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            onStopSound()
                            onDismiss()
                        },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MosqueLightGold),
                        border = BorderStroke(1.dp, MosqueGold.copy(alpha = 0.6f)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("إلغاء", fontSize = 13.sp)
                    }

                    Button(
                        onClick = {
                            onStopSound()
                            val selectedItem = librarySounds.find { it.uri == selectedUri }
                            if (selectedItem != null) {
                                onConfirmSelection(selectedItem)
                                onDismiss()
                            } else {
                                Toast.makeText(context, "يرجى تحديد صوت أولاً", Toast.LENGTH_SHORT).show()
                            }
                        },
                        enabled = selectedUri.isNotEmpty() && librarySounds.any { it.uri == selectedUri },
                        colors = ButtonDefaults.buttonColors(containerColor = MosqueGold),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1.3f)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = MosqueVeryDarkGreen, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "تأكيد الاختيار",
                            color = MosqueVeryDarkGreen,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.5.sp
                        )
                    }
                }
            }
        }
        }
    }
}
