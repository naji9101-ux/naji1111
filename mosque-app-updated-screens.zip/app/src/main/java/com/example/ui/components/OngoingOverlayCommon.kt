package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.CairoFamily
import com.example.ui.theme.CinzelFamily

// ألوان التصميم المنقولة حرفياً من OngoingPrayerScreen.tsx / FridayKhutbahScreen.tsx
internal val OvBgDarkBlue = Color(0xFF03152B)
internal val OvGradStart = Color(0xFF0B2B54)
internal val OvGradMid = Color(0xFF05274F)
internal val OvGradEnd = Color(0xFF031935)
internal val OvInnerBg = Color(0xFF041F40)
internal val OvGold = Color(0xFFE2C265)
internal val OvGoldLight = Color(0xFFFBE48A)
internal val OvGoldAccent = Color(0xFFE8C75A)
internal val OvModalHeaderBg = Color(0xFF092345)
internal val OvDarkBtnText = Color(0xFF041935)
internal val OvInputBg = Color(0xFF07203E)

/** نقاط التوقف المطابقة لـ Tailwind: sm=640 / md=768 / lg=1024 */
internal class OvLayout(val width: Dp, val bodyHeight: Dp) {
    val isSm = width >= 640.dp
    val isMd = width >= 768.dp
    val isLg = width >= 1024.dp

    fun pick(base: Float, sm: Float, md: Float, lg: Float = md): Float = when {
        isLg -> lg
        isMd -> md
        isSm -> sm
        else -> base
    }
}

private val ArchPath by lazy {
    PathParser().parsePathString("M400 80 C260 200 240 380 240 540 H560 C560 380 540 200 400 80 Z").toPath()
}

/**
 * الهيكل المشترك للشاشتين: إطار ذهبي مزدوج، علامة مائية، شريط علوي (الشارة + ⚙ + ✕)،
 * منطقة المحتوى الوسطى، والشريط السفلي.
 */
@Composable
internal fun OngoingOverlayScaffold(
    badgeText: String,
    countdown: String,
    bottomText: String,
    rootTag: String,
    settingsTag: String,
    closeTag: String,
    onOpenSettings: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    body: @Composable (OvLayout) -> Unit
) {
    val fade = remember { Animatable(0f) }
    LaunchedEffect(Unit) { fade.animateTo(1f, tween(400)) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        BoxWithConstraints(
            modifier = modifier
                .fillMaxSize()
                .testTag(rootTag)
                .graphicsLayer { alpha = fade.value }
                .background(OvBgDarkBlue)
                .windowInsetsPadding(WindowInsets.safeDrawing)
        ) {
            val rootWidth = maxWidth
            val probe = OvLayout(rootWidth, maxHeight)
            val rootPad = probe.pick(8f, 16f, 24f).dp
            val innerPad = probe.pick(12f, 24f, 32f).dp
            val outerShape = RoundedCornerShape(22.dp)
            val innerShape = RoundedCornerShape(17.dp)

            // الإطار الخارجي (border 2px + p 4px + تدرج)
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(rootPad)
                    .clip(outerShape)
                    .background(Brush.verticalGradient(listOf(OvGradStart, OvGradMid, OvGradEnd)))
                    .border(2.dp, OvGold, outerShape)
                    .padding(4.dp)
            ) {
                // الإطار الداخلي (border 1.4px + خلفية #041F40 بشفافية 85%)
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(innerShape)
                        .background(OvInnerBg.copy(alpha = 0.85f))
                        .border(1.4.dp, OvGold.copy(alpha = 0.8f), innerShape)
                ) {
                    // علامة المحراب المائية (opacity 0.06، عرض 120vw)
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val side = size.width * 1.2f
                        val s = side / 800f
                        val c = OvGoldAccent.copy(alpha = 0.06f)
                        withTransform({
                            translate((size.width - side) / 2f, (size.height - side) / 2f)
                            scale(s, s, Offset.Zero)
                        }) {
                            drawCircle(c, radius = 360f, center = Offset(400f, 400f), style = Stroke(8f))
                            drawPath(ArchPath, c)
                        }
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPad),
                        verticalArrangement = Arrangement.SpaceBetween,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // ---------- الشريط العلوي ----------
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            OvTopBadge(
                                name = badgeText,
                                countdown = countdown,
                                textSize = probe.pick(13f, 15f, 15f),
                                hPad = probe.pick(12f, 16f, 16f),
                                vPad = probe.pick(6f, 8f, 8f)
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                val btn = probe.pick(36f, 40f, 40f).dp
                                val ico = probe.pick(16f, 20f, 20f).dp
                                OvCircleButton(
                                    icon = Icons.Default.Settings,
                                    tint = OvGoldAccent,
                                    size = btn,
                                    iconSize = ico,
                                    tag = settingsTag,
                                    onClick = onOpenSettings
                                )
                                OvCircleButton(
                                    icon = Icons.Default.Close,
                                    tint = OvGoldLight,
                                    size = btn,
                                    iconSize = ico,
                                    tag = closeTag,
                                    onClick = onDismiss
                                )
                            }
                        }

                        // ---------- المحتوى الأوسط (يتصغّر تلقائياً ليظهر كاملاً على أي هاتف) ----------
                        OvFitBox(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                        ) {
                            body(OvLayout(rootWidth, maxHeight))
                        }

                        // ---------- الشريط السفلي ----------
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(1.dp)
                                    .background(OvGold.copy(alpha = 0.30f))
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = bottomText,
                                color = Color.White.copy(alpha = if (rootTag.contains("khutbah")) 0.75f else 0.70f),
                                fontFamily = CairoFamily,
                                fontSize = probe.pick(12f, 14f, 16f).sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun OvTopBadge(
    name: String,
    countdown: String,
    textSize: Float,
    hPad: Float,
    vPad: Float
) {
    val pulse = rememberInfiniteTransition(label = "ov_pulse")
    val pulseAlpha by pulse.animateFloat(
        initialValue = 1f,
        targetValue = 0.5f,
        animationSpec = infiniteRepeatable(tween(1000), RepeatMode.Reverse),
        label = "ov_pulse_alpha"
    )
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(percent = 50))
            .background(OvGradMid.copy(alpha = 0.95f))
            .border(1.dp, OvGold, RoundedCornerShape(percent = 50))
            .padding(horizontal = hPad.dp, vertical = vPad.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(modifier = Modifier.size(10.dp), contentAlignment = Alignment.Center) {
            Canvas(modifier = Modifier.size(22.dp).graphicsLayer { alpha = pulseAlpha }) {
                drawCircle(OvGoldAccent.copy(alpha = 0.35f), radius = 8.dp.toPx())
                drawCircle(OvGoldAccent, radius = 5.dp.toPx())
            }
        }
        Text(
            text = name,
            color = OvGoldLight,
            fontFamily = CairoFamily,
            fontWeight = FontWeight.Bold,
            fontSize = textSize.sp
        )
        Text(text = "•", color = Color.White.copy(alpha = 0.4f), fontSize = 12.sp)
        Text(
            text = countdown,
            color = Color.White,
            fontFamily = CinzelFamily,
            fontWeight = FontWeight.Bold,
            fontSize = textSize.sp,
            letterSpacing = 0.05.em
        )
    }
}

@Composable
private fun OvCircleButton(
    icon: ImageVector,
    tint: Color,
    size: Dp,
    iconSize: Dp,
    tag: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(size)
            .testTag(tag)
            .clip(CircleShape)
            .background(OvGradMid)
            .border(1.dp, OvGold.copy(alpha = 0.8f), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(iconSize))
    }
}

/** خط ذهبي متلاشي تحت العنوان الكبير */
@Composable
internal fun OvGoldUnderline(width: Dp) {
    Box(
        modifier = Modifier
            .padding(top = 4.dp)
            .size(width = width, height = 2.dp)
            .background(Brush.horizontalGradient(listOf(Color.Transparent, OvGold, Color.Transparent)))
    )
}

// =====================================================================
//                       مكونات نافذة الإعدادات
// =====================================================================

@Composable
internal fun OvModalShell(
    title: String,
    subtitle: String,
    saveTag: String? = null,
    onSave: () -> Unit,
    onDismiss: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.85f))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = onDismiss
                    )
                    .padding(12.dp),
                contentAlignment = Alignment.Center
            ) {
                val cardShape = RoundedCornerShape(18.dp)
                Column(
                    modifier = Modifier
                        .widthIn(max = 448.dp)
                        .fillMaxWidth()
                        .clip(cardShape)
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(0xFF0B2B54), Color(0xFF072444), Color(0xFF041935))
                            )
                        )
                        .border(1.8.dp, OvGold, cardShape)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = {}
                        )
                        .verticalScroll(rememberScrollState())
                ) {
                    // الرأس
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(OvModalHeaderBg)
                            .padding(horizontal = 20.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(OvGradMid)
                                    .border(1.dp, OvGold, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AccessTime,
                                    contentDescription = null,
                                    tint = OvGoldAccent,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = title,
                                    color = OvGoldLight,
                                    fontFamily = CairoFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                                Text(
                                    text = subtitle,
                                    color = Color.White.copy(alpha = 0.65f),
                                    fontFamily = CairoFamily,
                                    fontSize = 11.sp
                                )
                            }
                        }
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(OvGradMid)
                                .border(1.dp, OvGold.copy(alpha = 0.6f), CircleShape)
                                .clickable(onClick = onDismiss),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = null,
                                tint = OvGoldLight,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    // الجسم
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        content = content
                    )

                    // التذييل
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(OvGold.copy(alpha = 0.4f))
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(OvModalHeaderBg)
                            .padding(horizontal = 20.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier
                                .then(if (saveTag != null) Modifier.testTag(saveTag) else Modifier)
                                .clip(RoundedCornerShape(10.dp))
                                .background(OvGoldAccent)
                                .clickable(onClick = onSave)
                                .padding(horizontal = 20.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = OvDarkBtnText,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "حفظ وتطبيق التعديل",
                                color = OvDarkBtnText,
                                fontFamily = CairoFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.5.sp
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .border(1.dp, OvGold.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
                                .clickable(onClick = onDismiss)
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = "إلغاء",
                                color = Color.White,
                                fontFamily = CairoFamily,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * بطاقة إعداد بالدقائق: الاسم على اليمين ومربع (− رقم +) على اليسار.
 */
@Composable
internal fun OvMinuteRowCard(
    title: String,
    subtitle: String? = null,
    value: Int,
    min: Int,
    max: Int,
    signed: Boolean = false,
    onChange: (Int) -> Unit
) {
    val shape = RoundedCornerShape(12.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(OvGradMid)
            .border(1.dp, OvGold.copy(alpha = 0.4f), shape)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 10.dp)) {
            Text(
                text = title,
                color = Color.White,
                fontFamily = CairoFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            if (subtitle != null) {
                Text(
                    text = subtitle,
                    color = Color.White.copy(alpha = 0.6f),
                    fontFamily = CairoFamily,
                    fontSize = 11.sp
                )
            }
        }
        GoldMinuteControl(value = value, onValueChange = onChange, min = min, max = max, signed = signed)
    }
}

@Composable
internal fun OvToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onToggle: () -> Unit
) {
    val shape = RoundedCornerShape(12.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(OvGradMid)
            .border(1.dp, OvGold.copy(alpha = 0.4f), shape)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = Color.White,
                fontFamily = CairoFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 13.5.sp
            )
            Text(
                text = subtitle,
                color = Color.White.copy(alpha = 0.6f),
                fontFamily = CairoFamily,
                fontSize = 11.sp
            )
        }
        val trackShape = RoundedCornerShape(percent = 50)
        Box(
            modifier = Modifier
                .size(width = 48.dp, height = 24.dp)
                .clip(trackShape)
                .background(if (checked) OvGoldAccent else OvDarkBtnText)
                .border(1.dp, if (checked) OvGoldLight else Color.White.copy(alpha = 0.3f), trackShape)
                .clickable(onClick = onToggle)
                .padding(4.dp),
            contentAlignment = if (checked) Alignment.CenterEnd else Alignment.CenterStart
        ) {
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .clip(CircleShape)
                    .background(if (checked) OvGradMid else Color.White.copy(alpha = 0.7f))
            )
        }
    }
}

/** يقيس المحتوى بحجمه الطبيعي ثم يصغّره (إن لزم) ليظهر كاملاً داخل المساحة المتاحة. */
@Composable
internal fun OvFitBox(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Layout(content = content, modifier = modifier) { measurables, constraints ->
        val placeable = measurables.first().measure(
            constraints.copy(minWidth = 0, minHeight = 0, maxHeight = Constraints.Infinity)
        )
        val w = constraints.maxWidth
        val h = constraints.maxHeight
        val scale = if (placeable.height > h && placeable.height > 0) h.toFloat() / placeable.height else 1f
        layout(w, h) {
            placeable.placeWithLayer((w - placeable.width) / 2, (h - placeable.height) / 2) {
                scaleX = scale
                scaleY = scale
            }
        }
    }
}
