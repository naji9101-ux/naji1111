package com.example.ui.settings

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppSettings
import com.example.model.AudioFileItem
import com.example.model.IqamaScreenCustomConfig
import com.example.model.PrayerType
import com.example.model.SinglePrayerConfig
import com.example.ui.components.MinuteAdjuster
import com.example.ui.components.PrayerIconBox
import com.example.ui.components.SelectedAudioBox
import com.example.ui.components.AudioSourceSelectionRow
import com.example.ui.theme.*
import com.example.util.IqamaSilentModeManager

@Composable
fun IqamaSettingsTab(
    settings: AppSettings,
    isPlayingTest: Boolean,
    onTestIqama: (String?) -> Unit,
    onStopIqama: () -> Unit,
    onAddCustomIqama: (String, Uri) -> AudioFileItem?,
    onDeleteCustomIqama: (AudioFileItem) -> Unit,
    onSelectCommonIqama: (AudioFileItem) -> Unit,
    onClearCommonIqama: () -> Unit,
    onSelectPrayerIqamaSound: (PrayerType, AudioFileItem) -> Unit,
    onClearPrayerIqamaSound: (PrayerType) -> Unit,
    onSelectPrayerIqamaDuration: (PrayerType, Int) -> Unit,
    onSelectPrayerIqamaConfig: (PrayerType, IqamaScreenCustomConfig) -> Unit,
    onPreviewPrayerIqamaScreen: (PrayerType) -> Unit,
    onUpdatePrayerConfig: (SinglePrayerConfig) -> Unit,
    onUpdate: (AppSettings) -> Unit
) {
    val context = LocalContext.current
    var currentlyPlayingSound by remember { mutableStateOf<String?>(null) }
    var prayerForLibraryDialog by remember { mutableStateOf<PrayerType?>(null) }
    var prayerForPhoneFilePicker by remember { mutableStateOf<PrayerType?>(null) }
    var showCommonLibraryDialog by remember { mutableStateOf(false) }

    // Launcher for unified Iqama sound from phone
    val unifiedPhonePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val fileName = uri.lastPathSegment?.substringAfterLast("/") ?: "إقامة موحدة"
            val item = onAddCustomIqama(fileName, uri)
            if (item != null) {
                onSelectCommonIqama(item)
                Toast.makeText(context, "تمت إضافة صوت الإقامة الموحد واختياره بنجاح", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Launcher for picking iqama directly from phone for a specific prayer
    val prayerPhonePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        val targetPrayer = prayerForPhoneFilePicker
        if (uri != null && targetPrayer != null) {
            val fileName = uri.lastPathSegment?.substringAfterLast("/") ?: "إقامة ${targetPrayer.defaultName}"
            val item = onAddCustomIqama(fileName, uri)
            if (item != null) {
                onSelectPrayerIqamaSound(targetPrayer, item)
                Toast.makeText(context, "تم اختيار وتفعيل صوت الإقامة لـ ${targetPrayer.defaultName}", Toast.LENGTH_SHORT).show()
            }
        }
        prayerForPhoneFilePicker = null
    }

    // Prayers that have Iqama
    val isFridayFirstActive = settings.firstAdhansMasterEnabled && settings.isFridayFirstEnabled
    val iqamaPrayersList = listOf(
        PrayerType.FAJR_SECOND to "الفجر الثاني",
        PrayerType.DHUHR to "الظهر",
        PrayerType.ASR to "العصر",
        PrayerType.MAGHRIB to "المغرب",
        PrayerType.ISHA to "العشاء",
        PrayerType.FRIDAY_SECOND to if (isFridayFirstActive) "الأذان الثاني" else "الظهر"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // =========================================================================
        // 0. وضع عدم الإزعاج / الصامت التلقائي أثناء ظهور واجهة الإقامة
        // =========================================================================
        val isDndGranted = IqamaSilentModeManager.hasDndPermission(context)
        Card(
            colors = CardDefaults.cardColors(containerColor = if (isDndGranted) MosqueDeepGreen else Color(0xFF2C2215)),
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.2.dp, if (isDndGranted) MosqueGold else Color(0xFFFFB74D)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (isDndGranted) Icons.Default.CheckCircle else Icons.Default.DoNotDisturbOn,
                        contentDescription = null,
                        tint = if (isDndGranted) MosqueGold else Color(0xFFFFB74D)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "وضع الصامت التلقائي أثناء ظهور واجهة الإقامة",
                        color = MosqueLightGold,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = if (isDndGranted) {
                        "الميزة نشطة: عند بدء وقت الإقامة وظهور واجهتها، يتحول الهاتف تلقائياً لوضع الصامت/عدم الإزعاج طوال مدة المؤقت، ويعود لحالته السابقة تماماً فور انتهاء الإقامة أو إغلاقها."
                    } else {
                        "لتفعيل كتم الهاتف تلقائياً أثناء الإقامة، يرجى منح إذن «الوصول إلى سياسة عدم الإزعاج» للتطبيق من إعدادات الهاتف."
                    },
                    color = MosqueIvory,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )

                if (!isDndGranted) {
                    Button(
                        onClick = { IqamaSilentModeManager.openDndSettings(context) },
                        colors = ButtonDefaults.buttonColors(containerColor = MosqueGold),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.padding(top = 2.dp)
                    ) {
                        Text(
                            text = "منح إذن عدم الإزعاج من إعدادات الهاتف",
                            color = MosqueVeryDarkGreen,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // =========================================================================
        // 1. تفعيل / تطبيق صوت الإقامة المختار على جميع الإقامات (OFF افتراضياً)
        // =========================================================================
        Card(
            colors = CardDefaults.cardColors(containerColor = MosqueDeepGreen),
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.2.dp, MosqueGold),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        horizontalAlignment = Alignment.Start,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = "تطبيق صوت الإقامة المختار على جميع الصلوات",
                            color = MosqueGold,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (settings.applyIqamaSoundToAll) "مفعل (يعمم على جميع صلوات الإقامة)" else "معطل (كل صلاة بصوتها المستقل)",
                            color = if (settings.applyIqamaSoundToAll) MosqueWhite else MosqueLightGold.copy(alpha = 0.7f),
                            fontSize = 11.5.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Switch(
                        checked = settings.applyIqamaSoundToAll,
                        onCheckedChange = { isChecked ->
                            onUpdate(settings.copy(applyIqamaSoundToAll = isChecked))
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = MosqueVeryDarkGreen,
                            checkedTrackColor = MosqueGold
                        )
                    )
                }

                if (settings.applyIqamaSoundToAll) {
                    HorizontalDivider(color = MosqueGold.copy(alpha = 0.25f))
                    Text(
                        text = "صوت الإقامة الموحد لجميع الصلوات:",
                        color = MosqueLightGold,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    val unifiedSoundUri = settings.defaultIqamaSound
                    val unifiedTitle = if (unifiedSoundUri.isNotBlank()) {
                        settings.defaultIqamaName.ifBlank {
                            settings.savedIqamaSounds.find { it.uri == unifiedSoundUri }?.name
                                ?: unifiedSoundUri.substringAfterLast("/")
                        }
                    } else {
                        "لم يتم اختيار صوت"
                    }

                    // Selected Sound Box (Card above the action buttons)
                    SelectedAudioBox(
                        soundTitle = unifiedTitle,
                        isPlaying = isPlayingTest && currentlyPlayingSound == "unified_iqama",
                        soundUriOrKey = unifiedSoundUri.ifBlank { unifiedTitle },
                        enabled = settings.applyIqamaSoundToAll,
                        onPlayPause = {
                            if (!settings.applyIqamaSoundToAll) return@SelectedAudioBox
                            if (isPlayingTest && currentlyPlayingSound == "unified_iqama") {
                                onStopIqama()
                                currentlyPlayingSound = null
                            } else {
                                onStopIqama()
                                currentlyPlayingSound = "unified_iqama"
                                onTestIqama(unifiedSoundUri.ifBlank { unifiedTitle })
                            }
                        },
                        onClear = if (settings.applyIqamaSoundToAll && unifiedSoundUri.isNotEmpty()) {
                            { onClearCommonIqama() }
                        } else null
                    )

                    // Action buttons
                    AudioSourceSelectionRow(
                        enabled = settings.applyIqamaSoundToAll,
                        libraryButtonText = "اختيار من المكتبة",
                        phoneButtonText = "ملف من الهاتف",
                        onOpenLibrary = { if (settings.applyIqamaSoundToAll) showCommonLibraryDialog = true },
                        onPickFromPhone = { if (settings.applyIqamaSoundToAll) unifiedPhonePicker.launch("audio/*") }
                    )
                }
            }
        }

        // =========================================================================
        // 2. إعدادات كل صلاة بشكل مستقل
        // =========================================================================
        Text(
            text = "إعدادات الإقامة لكل صلاة:",
            color = MosqueLightGold,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
        )

        iqamaPrayersList.forEach { (prayerType, prayerDisplayName) ->
            val pConfig = settings.getPrayerConfig(prayerType)
            val pIqamaConfig = pConfig.iqamaScreenCustomConfig
            val isOverriddenByUnified = settings.applyIqamaSoundToAll

            val activeSoundUri = if (isOverriddenByUnified) {
                settings.defaultIqamaSound
            } else {
                pConfig.iqamaSoundUri?.takeIf { it.isNotEmpty() } ?: pConfig.iqamaSoundPreset
            }

            val soundTitle = if (activeSoundUri.isNotBlank()) {
                if (isOverriddenByUnified) {
                    settings.defaultIqamaName.ifBlank {
                        settings.savedIqamaSounds.find { it.uri == activeSoundUri }?.name
                            ?: activeSoundUri.substringAfterLast("/")
                    }
                } else if (pConfig.iqamaSoundName?.isNotBlank() == true) {
                    pConfig.iqamaSoundName
                } else {
                    settings.savedIqamaSounds.find { it.uri == activeSoundUri }?.name
                        ?: activeSoundUri.substringAfterLast("/")
                }
            } else {
                "لم يتم اختيار صوت"
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = MosqueDarkGreen),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.2.dp, MosqueGold.copy(alpha = 0.5f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("iqama_card_${prayerType.id}")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Title Bar with Icon, Preview Button & Activation Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            PrayerIconBox(prayerType = prayerType, boxSize = 38.dp)
                            Column {
                                Text(
                                    text = "إقامة $prayerDisplayName",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MosqueWhite
                                )
                                Text(
                                    text = if (pConfig.iqamaEnabled) "الإقامة مفعلة" else "الإقامة معطلة",
                                    fontSize = 11.5.sp,
                                    color = if (pConfig.iqamaEnabled) MosqueGold else Color(0xFFFF8A80)
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { onPreviewPrayerIqamaScreen(prayerType) },
                                colors = ButtonDefaults.buttonColors(containerColor = MosqueGold),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Icon(Icons.Default.Visibility, contentDescription = null, tint = MosqueVeryDarkGreen, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("معاينة الشاشة", color = MosqueVeryDarkGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            // Independent ON/OFF switch per prayer - stays ON/OFF immediately!
                            Switch(
                                checked = pConfig.iqamaEnabled,
                                onCheckedChange = { isChecked ->
                                    val updatedCfg = pConfig.copy(iqamaEnabled = isChecked)
                                    onUpdatePrayerConfig(updatedCfg)
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = MosqueVeryDarkGreen,
                                    checkedTrackColor = MosqueGold
                                )
                            )
                        }
                    }

                    HorizontalDivider(color = MosqueGold.copy(alpha = 0.2f))

                    // 1. [ مستطيل جميل للصوت المختار ]
                    // ▶ اسم الصوت المختار
                    // تشغيل / معاينة
                    SelectedAudioBox(
                        soundTitle = soundTitle,
                        isPlaying = isPlayingTest && currentlyPlayingSound == "${prayerType.id}_iqama",
                        label = if (isOverriddenByUnified) "الصوت الموحد المطبق:" else "صوت الإقامة المختار:",
                        soundUriOrKey = activeSoundUri.ifBlank { soundTitle },
                        enabled = pConfig.iqamaEnabled,
                        onPlayPause = {
                            if (!pConfig.iqamaEnabled) return@SelectedAudioBox
                            if (isPlayingTest && currentlyPlayingSound == "${prayerType.id}_iqama") {
                                onStopIqama()
                                currentlyPlayingSound = null
                            } else {
                                onStopIqama()
                                currentlyPlayingSound = "${prayerType.id}_iqama"
                                onTestIqama(activeSoundUri.ifBlank { soundTitle })
                            }
                        },
                        onClear = if (pConfig.iqamaEnabled && !isOverriddenByUnified && activeSoundUri.isNotBlank()) {
                            { onClearPrayerIqamaSound(prayerType) }
                        } else null
                    )

                    // 2. [ اختيار من مكتبة الإقامة ] & [ اختيار ملف إقامة من الهاتف ]
                    // Positioned below the selected audio rectangle matching reference screenshot
                    if (!isOverriddenByUnified) {
                        AudioSourceSelectionRow(
                            enabled = pConfig.iqamaEnabled,
                            libraryButtonText = "اختيار من المكتبة",
                            phoneButtonText = "ملف من الهاتف",
                            onOpenLibrary = { if (pConfig.iqamaEnabled) prayerForLibraryDialog = prayerType },
                            onPickFromPhone = {
                                if (pConfig.iqamaEnabled) {
                                    prayerForPhoneFilePicker = prayerType
                                    prayerPhonePicker.launch("audio/*")
                                }
                            }
                        )
                    } else {
                        Text(
                            text = "ملاحظة: هذه الصلاة تتبع صوت الإقامة الموحد لأن خيار التعميم مفعل.",
                            color = MosqueLightGold.copy(alpha = 0.7f),
                            fontSize = 11.sp
                        )
                    }

                    // 5. مدة الانتظار بعد الأذان (تحدد وقت بداية الإقامة: وقت الإقامة = وقت الأذان + مدة الانتظار بعد الأذان)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "مدة الانتظار بعد الأذان:",
                                color = if (pConfig.iqamaEnabled) MosqueWhite else MosqueWhite.copy(alpha = 0.4f),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "(بالدقائق حتى بدء الإقامة)",
                                color = if (pConfig.iqamaEnabled) MosqueLightGold else MosqueLightGold.copy(alpha = 0.4f),
                                fontSize = 11.sp
                            )
                        }
                        MinuteAdjuster(
                            value = pConfig.iqamaMinutes,
                            onValueChange = { newMinutes ->
                                val updatedCfg = pConfig.copy(iqamaMinutes = newMinutes)
                                onUpdatePrayerConfig(updatedCfg)
                            },
                            minValue = 1,
                            maxValue = 120,
                            title = "مدة الانتظار بعد أذان $prayerDisplayName (دقيقة)",
                            enabled = pConfig.iqamaEnabled
                        )
                    }

                    // 6. مدة شاشة الإقامة (تبقى كما هي ولا تستخدم لحساب وقت بداية الإقامة)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "مدة شاشة الإقامة:",
                                color = if (pConfig.iqamaEnabled) MosqueWhite else MosqueWhite.copy(alpha = 0.4f),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "(بالدقائق بعد حلول الإقامة)",
                                color = if (pConfig.iqamaEnabled) MosqueLightGold else MosqueLightGold.copy(alpha = 0.4f),
                                fontSize = 11.sp
                            )
                        }
                        MinuteAdjuster(
                            value = pConfig.iqamaScreenDurationMinutes,
                            onValueChange = { newDuration ->
                                onSelectPrayerIqamaDuration(prayerType, newDuration)
                            },
                            minValue = 1,
                            maxValue = 60,
                            title = "مدة شاشة إقامة $prayerDisplayName (دقيقة)",
                            enabled = pConfig.iqamaEnabled
                        )
                    }

                    // 4. Customization details expander
                    var showDesignDetails by remember { mutableStateOf(false) }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MosqueDeepGreen)
                            .clickable { showDesignDetails = !showDesignDetails }
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "تخصيص ألوان وتصميم شاشة الإقامة",
                            color = MosqueGold,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Icon(
                            imageVector = if (showDesignDetails) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = null,
                            tint = MosqueGold
                        )
                    }

                    if (showDesignDetails) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MosqueVeryDarkGreen.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .border(1.dp, MosqueGold.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                .padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Frame color
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("لون الإطار الذهبي:", color = MosqueLightGold, fontSize = 12.sp)
                                val frameColors = listOf(
                                    "#C9A646" to "ذهبي معتمد",
                                    "#D4AF37" to "ذهبي لامع",
                                    "#E8D28A" to "ذهبي فاتح",
                                    "#A68026" to "برونزي"
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    frameColors.forEach { (hex, _) ->
                                        val isSel = pIqamaConfig.frameColorHex.equals(hex, ignoreCase = true)
                                        Box(
                                            modifier = Modifier
                                                .size(width = 36.dp, height = 24.dp)
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(Color(android.graphics.Color.parseColor(hex)))
                                                .border(
                                                    width = if (isSel) 2.dp else 0.8.dp,
                                                    color = if (isSel) MosqueWhite else Color.Transparent,
                                                    shape = RoundedCornerShape(4.dp)
                                                )
                                                .clickable {
                                                    onSelectPrayerIqamaConfig(prayerType, pIqamaConfig.copy(frameColorHex = hex))
                                                },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (isSel) Text("✓", color = MosqueVeryDarkGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }

                            // Frame Thickness
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("سماكة الإطار (dp):", color = MosqueWhite, fontSize = 12.sp)
                                MinuteAdjuster(
                                    value = pIqamaConfig.frameOuterThicknessDp,
                                    onValueChange = {
                                        onSelectPrayerIqamaConfig(prayerType, pIqamaConfig.copy(frameOuterThicknessDp = it))
                                    },
                                    minValue = 1,
                                    maxValue = 12,
                                    title = "سماكة الإطار (dp)"
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }

    // Modal dialog for selecting unified iqama sound
    if (showCommonLibraryDialog) {
        AudioLibrarySelectionDialog(
            title = "مكتبة أصوات الإقامة الموحدة",
            subtitle = "اختر صوتاً لتعميمه على جميع الإقامات",
            initialSelectedUri = settings.defaultIqamaSound,
            librarySounds = settings.savedIqamaSounds,
            isPlayingTest = isPlayingTest,
            playingSoundKey = currentlyPlayingSound,
            onTestSound = { sound ->
                currentlyPlayingSound = sound
                onTestIqama(sound)
            },
            onStopSound = {
                onStopIqama()
                currentlyPlayingSound = null
            },
            onImportFileFromPhone = { name, uri ->
                onAddCustomIqama(name, uri)
            },
            onDeleteSound = { item ->
                onDeleteCustomIqama(item)
            },
            onConfirmSelection = { item ->
                onSelectCommonIqama(item)
                showCommonLibraryDialog = false
            },
            onDismiss = {
                showCommonLibraryDialog = false
            }
        )
    }

    // Modal dialog for selecting iqama sound for a specific prayer
    if (prayerForLibraryDialog != null) {
        val targetPrayer = prayerForLibraryDialog!!
        val targetConfig = settings.getPrayerConfig(targetPrayer)
        val initialUri = targetConfig.iqamaSoundUri ?: targetConfig.iqamaSoundPreset

        AudioLibrarySelectionDialog(
            title = "مكتبة الإقامة لـ ${targetPrayer.defaultName}",
            subtitle = "اختر صوت إقامة مناسب لهذه الصلاة",
            initialSelectedUri = initialUri,
            librarySounds = settings.savedIqamaSounds,
            isPlayingTest = isPlayingTest,
            playingSoundKey = currentlyPlayingSound,
            onTestSound = { sound ->
                currentlyPlayingSound = sound
                onTestIqama(sound)
            },
            onStopSound = {
                onStopIqama()
                currentlyPlayingSound = null
            },
            onImportFileFromPhone = { name, uri ->
                onAddCustomIqama(name, uri)
            },
            onDeleteSound = { item ->
                onDeleteCustomIqama(item)
            },
            onConfirmSelection = { item ->
                onSelectPrayerIqamaSound(targetPrayer, item)
                Toast.makeText(context, "تم اختيار ${item.name} لـ ${targetPrayer.defaultName}", Toast.LENGTH_SHORT).show()
                prayerForLibraryDialog = null
            },
            onDismiss = {
                prayerForLibraryDialog = null
            }
        )
    }
}
