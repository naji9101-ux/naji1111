package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CairoFamily

// ===== ألوان المربع (من ألوان البرنامج: الأزرق الداكن + الذهبي) =====
private val CapsuleBg = Color(0xFF02101F)
private val GoldEdge = Brush.verticalGradient(listOf(Color(0xFFFBE48A), Color(0xFFE2B13C), Color(0xFFC98F24)))
private val GoldHair = Color(0xFFE2C265).copy(alpha = 0.45f)
private val SideBoxBrush = Brush.verticalGradient(listOf(Color(0xFF0E3668), Color(0xFF05234A)))
private val CenterBoxBrush = Brush.verticalGradient(listOf(Color(0xFF09305D), Color(0xFF031630)))

/** الكبسولة الذهبية الخارجية (حدّ ذهبي + خط رفيع داخلي) التي تحمل الصناديق */
@Composable
private fun GoldCapsuleFrame(
    height: Dp,
    enabled: Boolean,
    modifier: Modifier = Modifier,
    content: @Composable RowScope.() -> Unit
) {
    val capsule = RoundedCornerShape(percent = 50)
    Row(
        modifier = modifier
            .alpha(if (enabled) 1f else 0.4f)
            .height(height)
            .clip(capsule)
            .background(CapsuleBg)
            .border(1.5.dp, GoldEdge, capsule)
            .padding(1.dp)
            .border(0.5.dp, GoldHair, capsule)
            .padding(height * 0.06f),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(height * 0.065f),
        content = content
    )
}

/** صندوق مربع بزوايا مدورة وحدّ ذهبي رفيع */
@Composable
private fun GoldBox(
    modifier: Modifier,
    brush: Brush,
    focused: Boolean = false,
    onClick: (() -> Unit)? = null,
    enabled: Boolean = true,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(percent = 24)
    Box(
        modifier = modifier
            .fillMaxHeight()
            .clip(shape)
            .background(brush)
            .border(1.dp, if (focused) SolidColor(Color(0xFFFBE48A)) else GoldEdge, shape)
            .then(if (onClick != null) Modifier.clickable(enabled = enabled, onClick = onClick) else Modifier),
        contentAlignment = Alignment.Center,
        content = content
    )
}

/** علامة + أو − مرسومة برمجياً بتدرج ذهبي */
@Composable
private fun GoldSign(plus: Boolean, boxHeight: Dp) {
    Canvas(Modifier.size(boxHeight * 0.5f)) {
        val s = size.minDimension
        val t = s * 0.32f
        val r = CornerRadius(s * 0.05f, s * 0.05f)
        val brush = Brush.verticalGradient(
            listOf(Color(0xFFFFE08A), Color(0xFFE3A92F)),
            startY = 0f,
            endY = s
        )
        drawRoundRect(brush, Offset(0f, (s - t) / 2f), Size(s, t), r)
        if (plus) drawRoundRect(brush, Offset((s - t) / 2f, 0f), Size(t, s), r)
    }
}

/**
 * مربع الدقائق بنفس شكل التصميم المطلوب: كبسولة ذهبية فيها ثلاثة صناديق  [ + ] [ رقم ] [ − ]
 * - الرقم قابل للمسح والكتابة من لوحة المفاتيح.
 * - الترتيب ثابت (+ يسار، − يمين) حتى داخل الواجهات العربية.
 */
@Composable
internal fun GoldMinuteControl(
    value: Int,
    onValueChange: (Int) -> Unit,
    min: Int,
    max: Int,
    modifier: Modifier = Modifier,
    signed: Boolean = false,
    enabled: Boolean = true,
    height: Dp = 44.dp
) {
    fun fmt(v: Int) = if (signed && v > 0) "+$v" else v.toString()

    var text by remember { mutableStateOf(fmt(value)) }
    var focused by remember { mutableStateOf(false) }
    val focusManager = LocalFocusManager.current

    LaunchedEffect(value, focused) { if (!focused) text = fmt(value) }

    fun commit(v: Int) {
        val c = v.coerceIn(min, max)
        onValueChange(c)
        text = fmt(c)
    }

    val boxH = height - 6.dp - height * 0.12f

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        GoldCapsuleFrame(height = height, enabled = enabled, modifier = modifier) {
            // [ + ]
            GoldBox(
                modifier = Modifier.width(height * 0.909f),
                brush = SideBoxBrush,
                onClick = { commit(value + 1) },
                enabled = enabled
            ) { GoldSign(plus = true, boxHeight = boxH) }

            // [ الرقم ]
            GoldBox(
                modifier = Modifier.width(height * 1.73f),
                brush = CenterBoxBrush,
                focused = focused
            ) {
                BasicTextField(
                    value = text,
                    onValueChange = { raw ->
                        val sb = StringBuilder()
                        raw.forEach { ch ->
                            if (ch.isDigit()) sb.append(ch)
                            else if (ch == '-' && signed && sb.isEmpty()) sb.append(ch)
                        }
                        val s = sb.toString().take(4)
                        text = s
                        s.toIntOrNull()?.let { if (it in min..max) onValueChange(it) }
                    },
                    enabled = enabled,
                    singleLine = true,
                    cursorBrush = SolidColor(Color(0xFFFBE48A)),
                    textStyle = TextStyle(
                        color = Color.White,
                        fontFamily = CairoFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = (boxH.value * 0.62f).sp,
                        textAlign = TextAlign.Center,
                        textDirection = TextDirection.Ltr
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = if (signed) KeyboardType.Phone else KeyboardType.Number,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
                    modifier = Modifier
                        .fillMaxHeight()
                        .padding(horizontal = 4.dp)
                        .onFocusChanged { st ->
                            if (focused && !st.isFocused) {
                                val p = text.toIntOrNull()
                                if (p == null) text = fmt(value) else commit(p)
                            }
                            focused = st.isFocused
                        },
                    decorationBox = { inner ->
                        Box(Modifier.fillMaxHeight(), contentAlignment = Alignment.Center) { inner() }
                    }
                )
            }

            // [ − ]
            GoldBox(
                modifier = Modifier.width(height * 0.909f),
                brush = SideBoxBrush,
                onClick = { commit(value - 1) },
                enabled = enabled
            ) { GoldSign(plus = false, boxHeight = boxH) }
        }
    }
}

/** حقل نص (مثل التوقيت الثابت 12:45) بنفس الكبسولة الذهبية وصندوق وسطي واحد */
@Composable
internal fun GoldTimeField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    height: Dp = 44.dp,
    boxWidth: Dp = 110.dp
) {
    var focused by remember { mutableStateOf(false) }
    val boxH = height - 6.dp - height * 0.12f
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        GoldCapsuleFrame(height = height, enabled = enabled, modifier = modifier) {
            GoldBox(modifier = Modifier.width(boxWidth), brush = CenterBoxBrush, focused = focused) {
                BasicTextField(
                    value = value,
                    onValueChange = onValueChange,
                    enabled = enabled,
                    singleLine = true,
                    cursorBrush = SolidColor(Color(0xFFFBE48A)),
                    textStyle = TextStyle(
                        color = Color.White,
                        fontFamily = CairoFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = (boxH.value * 0.62f).sp,
                        textAlign = TextAlign.Center,
                        textDirection = TextDirection.Ltr
                    ),
                    modifier = Modifier
                        .fillMaxHeight()
                        .padding(horizontal = 6.dp)
                        .onFocusChanged { focused = it.isFocused },
                    decorationBox = { inner ->
                        Box(Modifier.fillMaxHeight(), contentAlignment = Alignment.Center) { inner() }
                    }
                )
            }
        }
    }
}
