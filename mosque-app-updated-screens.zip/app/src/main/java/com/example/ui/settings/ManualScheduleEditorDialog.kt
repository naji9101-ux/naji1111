package com.example.ui.settings

import android.widget.Toast
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.DayPrayers
import com.example.model.MonthPrayers
import com.example.model.MosqueSchedule
import com.example.ui.theme.*
import com.example.util.TimeAutoCorrectionHelper
import com.example.util.TimeParseResult
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ManualScheduleEditorDialog(
    initialSchedule: MosqueSchedule,
    onSaveSchedule: (MosqueSchedule) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val keyboardController = LocalSoftwareKeyboardController.current
    val lazyListState = rememberLazyListState()

    val density = LocalDensity.current
    val imeInsets = WindowInsets.ime
    val imeHeightPx = imeInsets.getBottom(density)
    val imeHeightDp = with(density) { imeHeightPx.toDp() }

    var workingSchedule by remember { mutableStateOf(initialSchedule) }
    var currentMonthIndex by remember { mutableIntStateOf(1) } // 1 to 12

    // In-cell editing state
    var activeCellKey by remember { mutableStateOf<String?>(null) }
    var activeCellText by remember { mutableStateOf(TextFieldValue("")) }
    var activeCellOriginalValue by remember { mutableStateOf("") }
    var activeCellTarget by remember { mutableStateOf<ManualCellEditTarget?>(null) }
    var validationAlert by remember { mutableStateOf<String?>(null) }

    val isEditing = activeCellKey != null

    var savedFirstVisibleIndex by remember { mutableIntStateOf(0) }
    var savedScrollOffset by remember { mutableIntStateOf(0) }
    var wasEditing by remember { mutableStateOf(false) }

    val monthNames = listOf(
        "", "1 - كانون الثاني (يناير)", "2 - شباط (فبراير)", "3 - آذار (مارس)",
        "4 - نيسان (أبريل)", "5 - أيار (مايو)", "6 - حزيران (يونيو)",
        "7 - تموز (يوليو)", "8 - آب (أغسطس)", "9 - أيلول (سبتمبر)",
        "10 - تشرين الأول (أكتوبر)", "11 - تشرين الثاني (نوفمبر)", "12 - كانون الأول (ديسمبر)"
    )

    fun commitCurrentEditingCell() {
        val target = activeCellTarget ?: return
        val currentText = activeCellText.text.trim()

        if (currentText.isEmpty() || currentText == activeCellOriginalValue.trim()) {
            activeCellKey = null
            activeCellTarget = null
            return
        }

        when (val result = TimeAutoCorrectionHelper.parseAndCorrect(currentText)) {
            is TimeParseResult.Success -> {
                target.onTimeChanged(result.formattedTime)
                activeCellKey = null
                activeCellTarget = null
                validationAlert = null
            }
            is TimeParseResult.Error -> {
                val errorMsg = "تنبيه: الوقت المدخل ($currentText) غير صالح (${result.reason}). تم الإبقاء على الوقت الأصلي ($activeCellOriginalValue)."
                validationAlert = errorMsg
                Toast.makeText(context, errorMsg, Toast.LENGTH_LONG).show()
                activeCellKey = null
                activeCellTarget = null
            }
        }
    }

    fun startEditingCell(key: String, dayNum: Int, prayerName: String, originalTime: String, onTimeChanged: (String) -> Unit) {
        if (activeCellKey == null) {
            savedFirstVisibleIndex = lazyListState.firstVisibleItemIndex
            savedScrollOffset = lazyListState.firstVisibleItemScrollOffset
        } else {
            commitCurrentEditingCell()
        }
        activeCellKey = key
        activeCellOriginalValue = originalTime
        activeCellTarget = ManualCellEditTarget(dayNum, prayerName, originalTime, onTimeChanged)
        activeCellText = TextFieldValue(originalTime, TextRange(0, originalTime.length))
    }

    LaunchedEffect(activeCellKey) {
        val key = activeCellKey
        if (key != null) {
            wasEditing = true
            val parts = key.split("_")
            val dayNum = parts.getOrNull(1)?.toIntOrNull()
            if (dayNum != null) {
                val targetIndex = (dayNum - 1).coerceAtLeast(0)
                lazyListState.scrollToItem(index = targetIndex, scrollOffset = 0)
                delay(120)
                lazyListState.animateScrollToItem(index = targetIndex, scrollOffset = 0)
                delay(180)
                lazyListState.animateScrollToItem(index = targetIndex, scrollOffset = 0)
            }
        } else if (wasEditing) {
            wasEditing = false
            delay(60)
            try {
                lazyListState.animateScrollToItem(savedFirstVisibleIndex, savedScrollOffset)
            } catch (e: Exception) {
                // Ignore
            }
        }
    }

    val targetBottomPadding = if (isEditing) {
        maxOf(imeHeightDp + 260.dp, 450.dp)
    } else {
        16.dp
    }
    val animatedBottomPadding by animateDpAsState(
        targetValue = targetBottomPadding,
        animationSpec = tween(durationMillis = if (isEditing) 100 else 280),
        label = "manualBottomPadding"
    )

    Dialog(
        onDismissRequest = {
            commitCurrentEditingCell()
            onDismiss()
        },
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = false,
            decorFitsSystemWindows = false
        )
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                color = MosqueVeryDarkGreen,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(if (isEditing) 4.dp else 12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(if (isEditing) 4.dp else 12.dp)
                ) {
                    // Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = {
                            commitCurrentEditingCell()
                            onDismiss()
                        }) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = MosqueLightGold)
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "محرر الجدول السنوي الكامل (365 يوماً)",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = MosqueGold
                            )
                            Text(
                                text = "تعديل أوقات الصلوات مباشرة داخل الخلايا",
                                fontSize = 12.sp,
                                color = MosqueIvory
                            )
                        }

                        Button(
                            onClick = {
                                commitCurrentEditingCell()
                                onSaveSchedule(workingSchedule)
                                onDismiss()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MosqueGold),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = MosqueVeryDarkGreen, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("حفظ الكل", color = MosqueVeryDarkGreen, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Alert Banner
                    validationAlert?.let { alertText ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF4A180E)),
                            border = BorderStroke(1.2.dp, Color(0xFFFF5252)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 6.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFFF5252), modifier = Modifier.size(18.dp))
                                Text(
                                    text = alertText,
                                    color = Color(0xFFFFCDD2),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = { validationAlert = null },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = Color(0xFFFFCDD2), modifier = Modifier.size(14.dp))
                                }
                            }
                        }
                    }

                    // Month Navigator
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MosqueDarkGreen),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = {
                                    commitCurrentEditingCell()
                                    if (currentMonthIndex > 1) currentMonthIndex--
                                },
                                enabled = currentMonthIndex > 1
                            ) {
                                Icon(
                                    Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "الشهر السابق",
                                    tint = if (currentMonthIndex > 1) MosqueGold else MosqueGold.copy(alpha = 0.3f)
                                )
                            }

                            Text(
                                text = monthNames.getOrElse(currentMonthIndex) { "شهر $currentMonthIndex" },
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = MosqueWhite
                            )

                            IconButton(
                                onClick = {
                                    commitCurrentEditingCell()
                                    if (currentMonthIndex < 12) currentMonthIndex++
                                },
                                enabled = currentMonthIndex < 12
                            ) {
                                Icon(
                                    Icons.AutoMirrored.Filled.ArrowForward,
                                    contentDescription = "الشهر التالي",
                                    tint = if (currentMonthIndex < 12) MosqueGold else MosqueGold.copy(alpha = 0.3f)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    val currentMonthData = workingSchedule.months.find { it.month == currentMonthIndex }
                        ?: MonthPrayers(currentMonthIndex, emptyList())
                    val daysList = currentMonthData.days.sortedBy { it.day }

                    // Table Header
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MosqueDeepGreen,
                        border = BorderStroke(1.dp, MosqueGold.copy(alpha = 0.7f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 10.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("اليوم", modifier = Modifier.weight(0.9f), textAlign = TextAlign.Center, color = MosqueGold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("الفجر", modifier = Modifier.weight(1.2f), textAlign = TextAlign.Center, color = MosqueGold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("الشروق", modifier = Modifier.weight(1.2f), textAlign = TextAlign.Center, color = MosqueGold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("الظهر", modifier = Modifier.weight(1.2f), textAlign = TextAlign.Center, color = MosqueGold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("العصر", modifier = Modifier.weight(1.2f), textAlign = TextAlign.Center, color = MosqueGold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("المغرب", modifier = Modifier.weight(1.2f), textAlign = TextAlign.Center, color = MosqueGold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("العشاء", modifier = Modifier.weight(1.2f), textAlign = TextAlign.Center, color = MosqueGold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    LazyColumn(
                        state = lazyListState,
                        contentPadding = PaddingValues(bottom = animatedBottomPadding),
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .imePadding(),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        itemsIndexed(daysList, key = { _, item -> item.day }) { index, dayItem ->
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = MosqueDarkGreen,
                                border = BorderStroke(0.6.dp, MosqueGold.copy(alpha = 0.35f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp, horizontal = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${dayItem.day}",
                                        modifier = Modifier.weight(0.9f),
                                        textAlign = TextAlign.Center,
                                        color = MosqueWhite,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )

                                    // Fajr
                                    val fajrKey = "${currentMonthIndex}_${dayItem.day}_fajr"
                                    EditableCell(
                                        time = dayItem.fajrSecond,
                                        isEditing = (activeCellKey == fajrKey),
                                        activeText = activeCellText,
                                        onTextChange = { newVal ->
                                            val clean = TimeAutoCorrectionHelper.normalizeDigits(newVal.text).filter { it.isDigit() || it == ':' }
                                            if (clean.length <= 5) {
                                                if (TimeAutoCorrectionHelper.shouldAutoFormatLive(clean)) {
                                                    val h = clean.substring(0, 2)
                                                    val m = clean.substring(2)
                                                    val formatted = "$h:$m"
                                                    activeCellText = TextFieldValue(formatted, TextRange(formatted.length))
                                                } else {
                                                    activeCellText = newVal.copy(text = clean)
                                                }
                                            }
                                        },
                                        onClick = {
                                            commitCurrentEditingCell()
                                            activeCellKey = fajrKey
                                            activeCellOriginalValue = dayItem.fajrSecond
                                            activeCellTarget = ManualCellEditTarget(dayItem.day, "الفجر", dayItem.fajrSecond) { newTime ->
                                                updateDayPrayer(workingSchedule, currentMonthIndex, dayItem.day) {
                                                    it.copy(fajrSecond = newTime)
                                                }.also { workingSchedule = it }
                                            }
                                            activeCellText = TextFieldValue(dayItem.fajrSecond, TextRange(0, dayItem.fajrSecond.length))
                                            coroutineScope.launch { lazyListState.animateScrollToItem(index) }
                                        },
                                        onDone = {
                                            commitCurrentEditingCell()
                                            keyboardController?.hide()
                                        },
                                        modifier = Modifier.weight(1.2f)
                                    )

                                    // Sunrise
                                    val sunriseKey = "${currentMonthIndex}_${dayItem.day}_sunrise"
                                    EditableCell(
                                        time = dayItem.sunrise,
                                        isEditing = (activeCellKey == sunriseKey),
                                        activeText = activeCellText,
                                        onTextChange = { newVal ->
                                            val clean = TimeAutoCorrectionHelper.normalizeDigits(newVal.text).filter { it.isDigit() || it == ':' }
                                            if (clean.length <= 5) {
                                                if (TimeAutoCorrectionHelper.shouldAutoFormatLive(clean)) {
                                                    val h = clean.substring(0, 2)
                                                    val m = clean.substring(2)
                                                    val formatted = "$h:$m"
                                                    activeCellText = TextFieldValue(formatted, TextRange(formatted.length))
                                                } else {
                                                    activeCellText = newVal.copy(text = clean)
                                                }
                                            }
                                        },
                                        onClick = {
                                            commitCurrentEditingCell()
                                            activeCellKey = sunriseKey
                                            activeCellOriginalValue = dayItem.sunrise
                                            activeCellTarget = ManualCellEditTarget(dayItem.day, "الشروق", dayItem.sunrise) { newTime ->
                                                updateDayPrayer(workingSchedule, currentMonthIndex, dayItem.day) {
                                                    it.copy(sunrise = newTime)
                                                }.also { workingSchedule = it }
                                            }
                                            activeCellText = TextFieldValue(dayItem.sunrise, TextRange(0, dayItem.sunrise.length))
                                            coroutineScope.launch { lazyListState.animateScrollToItem(index) }
                                        },
                                        onDone = {
                                            commitCurrentEditingCell()
                                            keyboardController?.hide()
                                        },
                                        modifier = Modifier.weight(1.2f)
                                    )

                                    // Dhuhr
                                    val dhuhrKey = "${currentMonthIndex}_${dayItem.day}_dhuhr"
                                    EditableCell(
                                        time = dayItem.dhuhr,
                                        isEditing = (activeCellKey == dhuhrKey),
                                        activeText = activeCellText,
                                        onTextChange = { newVal ->
                                            val clean = TimeAutoCorrectionHelper.normalizeDigits(newVal.text).filter { it.isDigit() || it == ':' }
                                            if (clean.length <= 5) {
                                                if (TimeAutoCorrectionHelper.shouldAutoFormatLive(clean)) {
                                                    val h = clean.substring(0, 2)
                                                    val m = clean.substring(2)
                                                    val formatted = "$h:$m"
                                                    activeCellText = TextFieldValue(formatted, TextRange(formatted.length))
                                                } else {
                                                    activeCellText = newVal.copy(text = clean)
                                                }
                                            }
                                        },
                                        onClick = {
                                            commitCurrentEditingCell()
                                            activeCellKey = dhuhrKey
                                            activeCellOriginalValue = dayItem.dhuhr
                                            activeCellTarget = ManualCellEditTarget(dayItem.day, "الظهر", dayItem.dhuhr) { newTime ->
                                                updateDayPrayer(workingSchedule, currentMonthIndex, dayItem.day) {
                                                    it.copy(dhuhr = newTime)
                                                }.also { workingSchedule = it }
                                            }
                                            activeCellText = TextFieldValue(dayItem.dhuhr, TextRange(0, dayItem.dhuhr.length))
                                            coroutineScope.launch { lazyListState.animateScrollToItem(index) }
                                        },
                                        onDone = {
                                            commitCurrentEditingCell()
                                            keyboardController?.hide()
                                        },
                                        modifier = Modifier.weight(1.2f)
                                    )

                                    // Asr
                                    val asrKey = "${currentMonthIndex}_${dayItem.day}_asr"
                                    EditableCell(
                                        time = dayItem.asr,
                                        isEditing = (activeCellKey == asrKey),
                                        activeText = activeCellText,
                                        onTextChange = { newVal ->
                                            val clean = TimeAutoCorrectionHelper.normalizeDigits(newVal.text).filter { it.isDigit() || it == ':' }
                                            if (clean.length <= 5) {
                                                if (TimeAutoCorrectionHelper.shouldAutoFormatLive(clean)) {
                                                    val h = clean.substring(0, 2)
                                                    val m = clean.substring(2)
                                                    val formatted = "$h:$m"
                                                    activeCellText = TextFieldValue(formatted, TextRange(formatted.length))
                                                } else {
                                                    activeCellText = newVal.copy(text = clean)
                                                }
                                            }
                                        },
                                        onClick = {
                                            commitCurrentEditingCell()
                                            activeCellKey = asrKey
                                            activeCellOriginalValue = dayItem.asr
                                            activeCellTarget = ManualCellEditTarget(dayItem.day, "العصر", dayItem.asr) { newTime ->
                                                updateDayPrayer(workingSchedule, currentMonthIndex, dayItem.day) {
                                                    it.copy(asr = newTime)
                                                }.also { workingSchedule = it }
                                            }
                                            activeCellText = TextFieldValue(dayItem.asr, TextRange(0, dayItem.asr.length))
                                            coroutineScope.launch { lazyListState.animateScrollToItem(index) }
                                        },
                                        onDone = {
                                            commitCurrentEditingCell()
                                            keyboardController?.hide()
                                        },
                                        modifier = Modifier.weight(1.2f)
                                    )

                                    // Maghrib
                                    val maghribKey = "${currentMonthIndex}_${dayItem.day}_maghrib"
                                    EditableCell(
                                        time = dayItem.maghrib,
                                        isEditing = (activeCellKey == maghribKey),
                                        activeText = activeCellText,
                                        onTextChange = { newVal ->
                                            val clean = TimeAutoCorrectionHelper.normalizeDigits(newVal.text).filter { it.isDigit() || it == ':' }
                                            if (clean.length <= 5) {
                                                if (TimeAutoCorrectionHelper.shouldAutoFormatLive(clean)) {
                                                    val h = clean.substring(0, 2)
                                                    val m = clean.substring(2)
                                                    val formatted = "$h:$m"
                                                    activeCellText = TextFieldValue(formatted, TextRange(formatted.length))
                                                } else {
                                                    activeCellText = newVal.copy(text = clean)
                                                }
                                            }
                                        },
                                        onClick = {
                                            commitCurrentEditingCell()
                                            activeCellKey = maghribKey
                                            activeCellOriginalValue = dayItem.maghrib
                                            activeCellTarget = ManualCellEditTarget(dayItem.day, "المغرب", dayItem.maghrib) { newTime ->
                                                updateDayPrayer(workingSchedule, currentMonthIndex, dayItem.day) {
                                                    it.copy(maghrib = newTime)
                                                }.also { workingSchedule = it }
                                            }
                                            activeCellText = TextFieldValue(dayItem.maghrib, TextRange(0, dayItem.maghrib.length))
                                            coroutineScope.launch { lazyListState.animateScrollToItem(index) }
                                        },
                                        onDone = {
                                            commitCurrentEditingCell()
                                            keyboardController?.hide()
                                        },
                                        modifier = Modifier.weight(1.2f)
                                    )

                                    // Isha
                                    val ishaKey = "${currentMonthIndex}_${dayItem.day}_isha"
                                    EditableCell(
                                        time = dayItem.isha,
                                        isEditing = (activeCellKey == ishaKey),
                                        activeText = activeCellText,
                                        onTextChange = { newVal ->
                                            val clean = TimeAutoCorrectionHelper.normalizeDigits(newVal.text).filter { it.isDigit() || it == ':' }
                                            if (clean.length <= 5) {
                                                if (TimeAutoCorrectionHelper.shouldAutoFormatLive(clean)) {
                                                    val h = clean.substring(0, 2)
                                                    val m = clean.substring(2)
                                                    val formatted = "$h:$m"
                                                    activeCellText = TextFieldValue(formatted, TextRange(formatted.length))
                                                } else {
                                                    activeCellText = newVal.copy(text = clean)
                                                }
                                            }
                                        },
                                        onClick = {
                                            commitCurrentEditingCell()
                                            activeCellKey = ishaKey
                                            activeCellOriginalValue = dayItem.isha
                                            activeCellTarget = ManualCellEditTarget(dayItem.day, "العشاء", dayItem.isha) { newTime ->
                                                updateDayPrayer(workingSchedule, currentMonthIndex, dayItem.day) {
                                                    it.copy(isha = newTime)
                                                }.also { workingSchedule = it }
                                            }
                                            activeCellText = TextFieldValue(dayItem.isha, TextRange(0, dayItem.isha.length))
                                            coroutineScope.launch { lazyListState.animateScrollToItem(index) }
                                        },
                                        onDone = {
                                            commitCurrentEditingCell()
                                            keyboardController?.hide()
                                        },
                                        modifier = Modifier.weight(1.2f)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = {
                                commitCurrentEditingCell()
                                onDismiss()
                            },
                            modifier = Modifier.weight(1f),
                            border = BorderStroke(1.dp, MosqueGold.copy(alpha = 0.7f)),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MosqueLightGold)
                        ) {
                            Text("إلغاء", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                commitCurrentEditingCell()
                                if (currentMonthIndex < 12) {
                                    currentMonthIndex++
                                } else {
                                    currentMonthIndex = 1
                                }
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = MosqueDeepGreen),
                            border = BorderStroke(1.dp, MosqueGold),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = if (currentMonthIndex < 12) "الشهر التالي (${currentMonthIndex + 1})" else "الشهر الأول (1)",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = MosqueGold
                            )
                        }

                        Button(
                            onClick = {
                                commitCurrentEditingCell()
                                onSaveSchedule(workingSchedule)
                                Toast.makeText(context, "تم حفظ واعتماد جدول المواقيت بنجاح", Toast.LENGTH_SHORT).show()
                                onDismiss()
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = MosqueGold),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("اعتماد وحفظ", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MosqueVeryDarkGreen)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EditableCell(
    time: String,
    isEditing: Boolean,
    activeText: TextFieldValue,
    onTextChange: (TextFieldValue) -> Unit,
    onClick: () -> Unit,
    onDone: () -> Unit,
    modifier: Modifier = Modifier
) {
    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(isEditing) {
        if (isEditing) {
            focusRequester.requestFocus()
        }
    }

    Box(
        modifier = modifier
            .padding(horizontal = 2.dp, vertical = 2.dp)
            .height(34.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(if (isEditing) MosqueDeepGreen else MosqueVeryDarkGreen)
            .border(
                width = if (isEditing) 1.8.dp else 0.8.dp,
                color = if (isEditing) MosqueGold else MosqueGold.copy(alpha = 0.5f),
                shape = RoundedCornerShape(4.dp)
            )
            .clickable(enabled = !isEditing, onClick = onClick)
            .padding(vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        if (isEditing) {
            BasicTextField(
                value = activeText,
                onValueChange = onTextChange,
                singleLine = true,
                cursorBrush = SolidColor(MosqueGold),
                textStyle = TextStyle(
                    color = MosqueWhite,
                    fontSize = 12.5.sp,
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                ),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Number,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(
                    onDone = { onDone() }
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 2.dp)
                    .focusRequester(focusRequester)
            )
        } else {
            Text(
                text = time,
                fontSize = 12.sp,
                color = MosqueLightGold,
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
        }
    }
}

private data class ManualCellEditTarget(
    val day: Int,
    val prayerName: String,
    val currentTime: String,
    val onTimeChanged: (String) -> Unit
)

private fun updateDayPrayer(
    schedule: MosqueSchedule,
    monthNum: Int,
    dayNum: Int,
    updater: (DayPrayers) -> DayPrayers
): MosqueSchedule {
    val newMonths = schedule.months.map { month ->
        if (month.month == monthNum) {
            val newDays = month.days.map { day ->
                if (day.day == dayNum) {
                    updater(day)
                } else {
                    day
                }
            }
            month.copy(days = newDays)
        } else {
            month
        }
    }
    return schedule.copy(months = newMonths)
}
