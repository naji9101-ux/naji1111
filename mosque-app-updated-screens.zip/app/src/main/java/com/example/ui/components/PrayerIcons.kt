package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.model.PrayerType
import com.example.ui.theme.MosqueDarkGreen
import com.example.ui.theme.MosqueGold
import com.example.ui.theme.MosqueLightGold
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun PrayerIconBox(
    prayerType: PrayerType,
    modifier: Modifier = Modifier,
    customIconUri: String? = null,
    boxSize: Dp = 48.dp,
    iconColor: Color = MosqueLightGold,
    backgroundColor: Color = MosqueDarkGreen,
    borderColor: Color = MosqueGold.copy(alpha = 0.5f),
    cornerRadius: Dp = 10.dp
) {
    val shape = RoundedCornerShape(cornerRadius)
    Box(
        modifier = modifier
            .size(boxSize)
            .clip(shape)
            .background(backgroundColor, shape)
            .then(
                if (borderColor != Color.Transparent) Modifier.border(1.dp, borderColor, shape)
                else Modifier
            ),
        contentAlignment = Alignment.Center
    ) {
        if (!customIconUri.isNullOrEmpty()) {
            when (customIconUri) {
                "preset:kaaba" -> {
                    Image(
                        painter = painterResource(id = R.drawable.ic_kaaba),
                        contentDescription = prayerType.defaultName,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize(0.8f)
                    )
                }
                "preset:crescent" -> {
                    Image(
                        painter = painterResource(id = R.drawable.ic_crescent),
                        contentDescription = prayerType.defaultName,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize(0.8f)
                    )
                }
                "preset:mosque" -> {
                    Image(
                        painter = painterResource(id = R.drawable.ic_mosque_logo),
                        contentDescription = prayerType.defaultName,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize(0.8f)
                    )
                }
                else -> {
                    AsyncImage(
                        model = customIconUri,
                        contentDescription = prayerType.defaultName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        } else {
            Canvas(modifier = Modifier.size(boxSize * 0.65f)) {
                when (prayerType) {
                    PrayerType.FAJR_FIRST -> drawFajrFirstIcon(iconColor)
                    PrayerType.FAJR_SECOND -> drawFajrSecondIcon(iconColor)
                    PrayerType.SUNRISE -> drawSunriseIcon(iconColor)
                    PrayerType.DHUHR -> drawDhuhrIcon(iconColor)
                    PrayerType.FRIDAY_FIRST, PrayerType.FRIDAY_SECOND -> drawFridayIcon(iconColor)
                    PrayerType.ASR -> drawAsrIcon(iconColor)
                    PrayerType.MAGHRIB -> drawMaghribIcon(iconColor)
                    PrayerType.ISHA -> drawIshaIcon(iconColor)
                }
            }
        }
    }
}

private fun DrawScope.drawFajrFirstIcon(color: Color) {
    val w = size.width
    val h = size.height
    val moonPath = Path().apply {
        moveTo(w * 0.45f, h * 0.15f)
        arcTo(
            rect = Rect(w * 0.1f, h * 0.15f, w * 0.8f, h * 0.85f),
            startAngleDegrees = -90f,
            sweepAngleDegrees = 180f,
            forceMoveTo = false
        )
        arcTo(
            rect = Rect(w * 0.28f, h * 0.22f, w * 0.82f, h * 0.78f),
            startAngleDegrees = 90f,
            sweepAngleDegrees = -180f,
            forceMoveTo = false
        )
        close()
    }
    drawPath(moonPath, color, style = Fill)
    drawLine(
        color = color.copy(alpha = 0.8f),
        start = Offset(w * 0.15f, h * 0.88f),
        end = Offset(w * 0.85f, h * 0.88f),
        strokeWidth = 2.dp.toPx(),
        cap = StrokeCap.Round
    )
    drawCircle(color, radius = 2.dp.toPx(), center = Offset(w * 0.68f, h * 0.35f))
}

private fun DrawScope.drawFajrSecondIcon(color: Color) {
    val w = size.width
    val h = size.height
    val horizonY = h * 0.68f
    drawLine(
        color = color,
        start = Offset(w * 0.1f, horizonY),
        end = Offset(w * 0.9f, horizonY),
        strokeWidth = 2.5.dp.toPx(),
        cap = StrokeCap.Round
    )
    drawArc(
        color = color,
        startAngle = 180f,
        sweepAngle = 180f,
        useCenter = true,
        topLeft = Offset(w * 0.28f, horizonY - w * 0.22f),
        size = Size(w * 0.44f, w * 0.44f)
    )
    val rayLen = w * 0.18f
    val angles = listOf(-140.0, -115.0, -90.0, -65.0, -40.0)
    for (ang in angles) {
        val rad = Math.toRadians(ang)
        val startX = (w * 0.5f + (w * 0.26f) * cos(rad)).toFloat()
        val startY = (horizonY + (w * 0.26f) * sin(rad)).toFloat()
        val endX = (w * 0.5f + (w * 0.26f + rayLen) * cos(rad)).toFloat()
        val endY = (horizonY + (w * 0.26f + rayLen) * sin(rad)).toFloat()
        drawLine(color, Offset(startX, startY), Offset(endX, endY), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
    }
}

private fun DrawScope.drawSunriseIcon(color: Color) {
    val w = size.width
    val h = size.height
    val horizonY = h * 0.65f
    drawLine(
        color = color,
        start = Offset(w * 0.08f, horizonY),
        end = Offset(w * 0.92f, horizonY),
        strokeWidth = 2.5.dp.toPx(),
        cap = StrokeCap.Round
    )
    drawLine(
        color = color.copy(alpha = 0.6f),
        start = Offset(w * 0.22f, horizonY + 5.dp.toPx()),
        end = Offset(w * 0.78f, horizonY + 5.dp.toPx()),
        strokeWidth = 1.8.dp.toPx(),
        cap = StrokeCap.Round
    )
    drawArc(
        color = color,
        startAngle = 180f,
        sweepAngle = 180f,
        useCenter = true,
        topLeft = Offset(w * 0.25f, horizonY - w * 0.25f),
        size = Size(w * 0.5f, w * 0.5f)
    )
    val arrowPath = Path().apply {
        moveTo(w * 0.5f, h * 0.12f)
        lineTo(w * 0.42f, h * 0.24f)
        lineTo(w * 0.58f, h * 0.24f)
        close()
    }
    drawPath(arrowPath, color)
}

private fun DrawScope.drawDhuhrIcon(color: Color) {
    val w = size.width
    val h = size.height
    val center = Offset(w * 0.5f, h * 0.5f)
    val r = w * 0.24f
    drawCircle(color, radius = r, center = center)
    val rayInner = r + 3.dp.toPx()
    val rayOuter = r + 9.dp.toPx()
    for (i in 0 until 8) {
        val rad = Math.toRadians(i * 45.0)
        val sX = (center.x + rayInner * cos(rad)).toFloat()
        val sY = (center.y + rayInner * sin(rad)).toFloat()
        val eX = (center.x + rayOuter * cos(rad)).toFloat()
        val eY = (center.y + rayOuter * sin(rad)).toFloat()
        drawLine(color, Offset(sX, sY), Offset(eX, eY), strokeWidth = 2.5.dp.toPx(), cap = StrokeCap.Round)
    }
}

private fun DrawScope.drawAsrIcon(color: Color) {
    val w = size.width
    val h = size.height
    val sunCenter = Offset(w * 0.42f, h * 0.42f)
    drawCircle(color, radius = w * 0.20f, center = sunCenter)
    drawLine(
        color = color.copy(alpha = 0.5f),
        start = Offset(w * 0.15f, h * 0.85f),
        end = Offset(w * 0.88f, h * 0.85f),
        strokeWidth = 2.dp.toPx(),
        cap = StrokeCap.Round
    )
    val rayAngles = listOf(25.0, 45.0, 65.0, 85.0, -15.0)
    for (ang in rayAngles) {
        val rad = Math.toRadians(ang)
        val sX = (sunCenter.x + (w * 0.24f) * cos(rad)).toFloat()
        val sY = (sunCenter.y + (w * 0.24f) * sin(rad)).toFloat()
        val eX = (sunCenter.x + (w * 0.38f) * cos(rad)).toFloat()
        val eY = (sunCenter.y + (w * 0.38f) * sin(rad)).toFloat()
        drawLine(color, Offset(sX, sY), Offset(eX, eY), strokeWidth = 2.2.dp.toPx(), cap = StrokeCap.Round)
    }
}

private fun DrawScope.drawMaghribIcon(color: Color) {
    val w = size.width
    val h = size.height
    val horizonY = h * 0.58f
    drawArc(
        color = color,
        startAngle = 180f,
        sweepAngle = 180f,
        useCenter = true,
        topLeft = Offset(w * 0.26f, horizonY - w * 0.22f),
        size = Size(w * 0.48f, w * 0.48f)
    )
    drawLine(
        color = color,
        start = Offset(w * 0.08f, horizonY),
        end = Offset(w * 0.92f, horizonY),
        strokeWidth = 2.5.dp.toPx(),
        cap = StrokeCap.Round
    )
    val arrowPath = Path().apply {
        moveTo(w * 0.5f, h * 0.88f)
        lineTo(w * 0.42f, h * 0.74f)
        lineTo(w * 0.58f, h * 0.74f)
        close()
    }
    drawPath(arrowPath, color)
}

private fun DrawScope.drawIshaIcon(color: Color) {
    val w = size.width
    val h = size.height
    val moonPath = Path().apply {
        moveTo(w * 0.38f, h * 0.16f)
        arcTo(
            rect = Rect(w * 0.12f, h * 0.16f, w * 0.78f, h * 0.82f),
            startAngleDegrees = -90f,
            sweepAngleDegrees = 200f,
            forceMoveTo = false
        )
        arcTo(
            rect = Rect(w * 0.28f, h * 0.22f, w * 0.82f, h * 0.76f),
            startAngleDegrees = 110f,
            sweepAngleDegrees = -190f,
            forceMoveTo = false
        )
        close()
    }
    drawPath(moonPath, color, style = Fill)
    drawCircle(color, radius = 3.dp.toPx(), center = Offset(w * 0.72f, h * 0.28f))
    drawCircle(color.copy(alpha = 0.85f), radius = 2.dp.toPx(), center = Offset(w * 0.78f, h * 0.55f))
}

private fun DrawScope.drawFridayIcon(color: Color) {
    val w = size.width
    val h = size.height
    val archPath = Path().apply {
        moveTo(w * 0.25f, h * 0.85f)
        lineTo(w * 0.25f, h * 0.48f)
        cubicTo(w * 0.25f, h * 0.28f, w * 0.42f, h * 0.16f, w * 0.5f, h * 0.12f)
        cubicTo(w * 0.58f, h * 0.16f, w * 0.75f, h * 0.28f, w * 0.75f, h * 0.48f)
        lineTo(w * 0.75f, h * 0.85f)
        close()
    }
    drawPath(archPath, color, style = Stroke(width = 2.dp.toPx()))
    drawCircle(color, radius = 3.dp.toPx(), center = Offset(w * 0.5f, h * 0.45f))
    drawLine(
        color = color.copy(alpha = 0.8f),
        start = Offset(w * 0.18f, h * 0.85f),
        end = Offset(w * 0.82f, h * 0.85f),
        strokeWidth = 2.dp.toPx(),
        cap = StrokeCap.Round
    )
}
