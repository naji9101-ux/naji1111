package com.example.ui.settings

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.R
import com.example.model.AppSettings
import com.example.model.AudioFileItem
import com.example.model.PrayerRowItem
import com.example.model.PrayerType
import com.example.model.SinglePrayerConfig
import com.example.ui.components.GoldMinuteControl
import com.example.ui.components.GoldTimeField
import com.example.ui.components.PrayerIconBox
import com.example.ui.theme.ArefRuqaaFamily
import com.example.ui.theme.CinzelFamily
import java.util.Locale

// ===== ألوان وخطوط التصميم (من PrayerSpec.kt / Ui.kt في مشروع PrayerTimesAndroid) =====
private object Pd {
    val Gold = Color(0xFFE8C75A); val GoldLight = Color(0xFFFBE48A); val GoldBorder = Color(0xFFE2C265)
    val CardBlue = Color(0xFF0B2B54); val Navy = Color(0xFF05274F)
    val DlgTop = Color(0xFF0B2B54); val DlgMid = Color(0xFF072444); val DlgBot = Color(0xFF041935)
    val DlgBar = Color(0xFF092345); val InnerCard = Color(0xFF07203E); val LibBtn = Color(0xFF0E3A6E)
    val PhoneBtn = Color(0xFF082C54); val Red = Color(0xFFFF8A80)
}

private val PdCairo = FontFamily(
    Font(R.font.cairo_design, FontWeight.Normal),
    Font(R.font.cairo_design_bold, FontWeight.Bold)
)

@Composable
private fun T(s: String, c: Color, sz: TextUnit, bold: Boolean = false, f: FontFamily = PdCairo, m: Modifier = Modifier) =
    Text(s, m, color = c, fontSize = sz, fontFamily = f, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)

private fun parseDisplayMinutes(s: String): Int? {
    val m = Regex("(\\d{1,2}):(\\d{2})").find(s) ?: return null
    var h = m.groupValues[1].toInt()
    val mi = m.groupValues[2].toInt()
    val pm = s.contains("م")
    val am = s.contains("ص")
    if (pm || am) { h %= 12; if (pm) h += 12 }
    return h * 60 + mi
}

private fun formatDisplayMinutes(total: Int, is24: Boolean): String {
    val t = ((total % 1440) + 1440) % 1440
    val h = t / 60
    val mi = t % 60
    return if (is24) String.format(Locale.US, "%02d:%02d", h, mi)
    else String.format(Locale.US, "%02d:%02d %s", if (h % 12 == 0) 12 else h % 12, mi, if (h < 12) "ص" else "م")
}

@Composable
private fun PdCard(bg: Color = Pd.InnerCard, r: Dp = 14.dp, a: Float = .6f, content: @Composable ColumnScope.() -> Unit) =
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(r)).background(bg)
            .border(1.dp, Pd.GoldBorder.copy(alpha = a), RoundedCornerShape(r)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp), content = content
    )

@Composable
private fun PdRound(label: String, enabled: Boolean = true, onClick: () -> Unit) =
    Box(
        Modifier.size(32.dp).clip(CircleShape).background(Pd.CardBlue).border(1.dp, Pd.GoldBorder, CircleShape)
            .clickable(enabled = enabled, onClick = onClick),
        Alignment.Center
    ) { T(label, Pd.Gold, 18.sp, true) }

@Composable
private fun PdValueBox(text: String, minW: Dp = 70.dp) =
    Box(
        Modifier.widthIn(min = minW).clip(RoundedCornerShape(6.dp)).background(Pd.Navy)
            .border(1.dp, Pd.GoldBorder.copy(alpha = .5f), RoundedCornerShape(6.dp)).padding(horizontal = 8.dp, vertical = 4.dp),
        Alignment.Center
    ) { T(text, Color.White, 15.sp, true) }

@Composable
private fun PdPill(label: String, sel: Boolean, enabled: Boolean = true, onClick: () -> Unit) =
    Box(
        Modifier.clip(RoundedCornerShape(6.dp)).background(if (sel) Pd.Gold else Pd.CardBlue)
            .border(1.dp, if (sel) Pd.GoldLight else Pd.GoldBorder.copy(alpha = .4f), RoundedCornerShape(6.dp))
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 10.dp, vertical = 4.dp)
    ) { T(label, if (sel) Pd.Navy else Color.White.copy(alpha = .85f), 11.5.sp, sel) }

@Composable
private fun PdTimeBadge(label: String, value: String) =
    Row(
        Modifier.clip(RoundedCornerShape(8.dp)).background(Pd.CardBlue).border(1.dp, Pd.GoldBorder, RoundedCornerShape(8.dp))
            .padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically
    ) { T(label, Color.White.copy(alpha = .8f), 11.sp); T(value, Pd.GoldLight, 15.sp, true, CinzelFamily) }

@Composable
private fun PdHead(title: String, sub: String, modifier: Modifier = Modifier) =
    Column(modifier) { T(title, Pd.GoldLight, 15.sp, true); T(sub, Color.White.copy(alpha = .7f), 11.5.sp) }

@Composable
private fun PdToggle(on: Boolean, onClick: () -> Unit) =
    Box(
        Modifier.size(48.dp, 24.dp).clip(CircleShape).background(if (on) Pd.Gold else Pd.Navy)
            .border(1.dp, if (on) Pd.GoldLight else Color.White.copy(alpha = .3f), CircleShape).clickable(onClick = onClick).padding(4.dp),
        contentAlignment = if (on) Alignment.CenterEnd else Alignment.CenterStart
    ) { Box(Modifier.size(16.dp).clip(CircleShape).background(if (on) Pd.Navy else Color.White.copy(alpha = .7f))) }

/** صف إعداد بالدقائق: الاسم على اليمين ومربع (− رقم +) على اليسار */
@Composable
private fun PdMinuteRow(
    title: String, sub: String?, value: Int, min: Int, max: Int,
    signed: Boolean = false, enabled: Boolean = true, onChange: (Int) -> Unit
) = Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
    Column(Modifier.weight(1f).padding(end = 10.dp)) {
        T(title, Color.White, 14.sp, true)
        if (sub != null) T(sub, Pd.GoldLight.copy(alpha = .85f), 11.5.sp)
    }
    GoldMinuteControl(value = value, onValueChange = onChange, min = min, max = max, signed = signed, enabled = enabled)
}

/** بطاقة الصوت (أذان/إقامة) بنفس تصميم AudioCard في النسخة الجديدة */
@Composable
private fun PdAudioCard(
    title: String, kind: String, icon: String,
    on: Boolean, onToggle: () -> Unit,
    label: String, name: String, sub: String,
    isPlaying: Boolean, onPlayPause: () -> Unit, onClear: (() -> Unit)?,
    libraryText: String, onLibrary: () -> Unit, onPhone: () -> Unit
) {
    PdCard(Pd.DlgMid, 16.dp, .5f) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(32.dp).clip(CircleShape).background(Pd.Navy).border(1.dp, Pd.GoldBorder.copy(alpha = .7f), CircleShape), Alignment.Center) { T(icon, Pd.Gold, 14.sp) }
                Column { T(title, Pd.GoldLight, 16.sp, true); T(kind, Color.White.copy(alpha = .6f), 11.sp) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                T(if (on) "مفعّل" else "معطّل", if (on) Pd.Gold else Color.White.copy(alpha = .45f), 12.sp, true)
                PdToggle(on, onToggle)
            }
        }
        HorizontalDivider(color = Pd.GoldBorder.copy(alpha = .25f))
        T(label, Color.White.copy(alpha = .85f), 13.sp, true)
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Pd.Navy)
                .border(1.dp, Pd.GoldBorder.copy(alpha = .4f), RoundedCornerShape(12.dp)).padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(name, color = Pd.GoldLight, fontFamily = PdCairo, fontWeight = FontWeight.Bold, fontSize = 13.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                T(sub, Color.White.copy(alpha = .6f), 11.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                if (onClear != null) {
                    Box(Modifier.size(28.dp).clip(CircleShape).border(1.dp, Pd.Red.copy(alpha = .7f), CircleShape).clickable(onClick = onClear), Alignment.Center) { T("✕", Pd.Red, 12.sp, true) }
                }
                Box(
                    Modifier.clip(RoundedCornerShape(8.dp)).background(Pd.CardBlue).border(1.dp, Pd.GoldBorder, RoundedCornerShape(8.dp))
                        .clickable(enabled = on, onClick = onPlayPause).padding(horizontal = 12.dp, vertical = 6.dp)
                ) { T(if (isPlaying) "■ إيقاف" else "▶ استماع", Pd.Gold, 12.sp, true) }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(Pd.LibBtn).border(1.dp, Pd.Gold.copy(alpha = .7f), RoundedCornerShape(10.dp)).clickable(enabled = on, onClick = onLibrary).padding(10.dp), Alignment.Center) { T(libraryText, Pd.GoldLight, 13.sp, true) }
            Box(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(Pd.PhoneBtn).border(1.dp, Pd.GoldBorder.copy(alpha = .5f), RoundedCornerShape(10.dp)).clickable(enabled = on, onClick = onPhone).padding(10.dp), Alignment.Center) { T("ملف من الهاتف", Color.White, 13.sp, true) }
        }
    }
}

@Composable
fun PrayerDetailDialog(
    prayer: PrayerRowItem,
    currentConfig: SinglePrayerConfig,
    settings: AppSettings? = null,
    savedAdhanSounds: List<AudioFileItem> = emptyList(),
    savedFajrAdhanSounds: List<AudioFileItem> = emptyList(),
    savedIqamaSounds: List<AudioFileItem> = emptyList(),
    onSaveConfig: (SinglePrayerConfig) -> Unit,
    onTestAudio: (String?) -> Unit,
    onStopAudio: () -> Unit,
    onAddAdhanToLibrary: ((String, Uri) -> AudioFileItem?)? = null,
    onAddFajrAdhanToLibrary: ((String, Uri) -> AudioFileItem?)? = null,
    onAddIqamaToLibrary: ((String, Uri) -> AudioFileItem?)? = null,
    onDeleteAdhanFromLibrary: ((AudioFileItem) -> Unit)? = null,
    onDeleteFajrAdhanFromLibrary: ((AudioFileItem) -> Unit)? = null,
    onDeleteIqamaFromLibrary: ((AudioFileItem) -> Unit)? = null,
    isPlayingTest: Boolean,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val isFajrFirst = prayer.type == PrayerType.FAJR_FIRST
    val isFridayFirst = prayer.type == PrayerType.FRIDAY_FIRST
    val isSunrise = prayer.type == PrayerType.SUNRISE
    val hasAdhan = prayer.type.hasAdhan && !isSunrise
    val hasIqama = prayer.type.hasIqama && !isFajrFirst && !isFridayFirst && !isSunrise

    val initialAdhanSoundUri = currentConfig.adhanSoundUri?.takeIf { it.isNotBlank() }
        ?: currentConfig.adhanSoundPreset.takeIf { it.isNotBlank() }
    val initialAdhanSoundName = currentConfig.adhanSoundName?.takeIf { it.isNotBlank() }
        ?: (if (isFajrFirst) {
            savedFajrAdhanSounds.find { it.uri == initialAdhanSoundUri }?.name
        } else {
            savedAdhanSounds.find { it.uri == initialAdhanSoundUri }?.name
        })

    val initialIqamaSoundUri = currentConfig.iqamaSoundUri?.takeIf { it.isNotBlank() }
        ?: currentConfig.iqamaSoundPreset.takeIf { it.isNotBlank() }
    val initialIqamaSoundName = currentConfig.iqamaSoundName?.takeIf { it.isNotBlank() }
        ?: savedIqamaSounds.find { it.uri == initialIqamaSoundUri }?.name

    var selectedFilter by remember { mutableIntStateOf(0) }

    // 1. Adhan States
    var adhanEnabled by remember(currentConfig.prayerId) { mutableStateOf(currentConfig.adhanEnabled) }
    var adhanOffsetMinutes by remember(currentConfig.prayerId) { mutableIntStateOf(currentConfig.adhanOffsetMinutes) }
    var adhanSoundUri by remember(currentConfig.prayerId) { mutableStateOf(initialAdhanSoundUri) }
    var adhanSoundName by remember(currentConfig.prayerId) { mutableStateOf(initialAdhanSoundName) }

    // 2. Iqama States
    var iqamaEnabled by remember(currentConfig.prayerId) { mutableStateOf(currentConfig.iqamaEnabled) }
    var iqamaMinutes by remember(currentConfig.prayerId) { mutableIntStateOf(currentConfig.iqamaMinutes) }
    var isManualIqama by remember(currentConfig.prayerId) { mutableStateOf(false) }
    var manualIqamaTime by remember(currentConfig.prayerId) { mutableStateOf(currentConfig.manualIqamaTime ?: prayer.iqamaTime) }
    var iqamaSoundUri by remember(currentConfig.prayerId) { mutableStateOf(initialIqamaSoundUri) }
    var iqamaSoundName by remember(currentConfig.prayerId) { mutableStateOf(initialIqamaSoundName) }
    var iqamaScreenDurationMinutes by remember(currentConfig.prayerId) { mutableIntStateOf(currentConfig.iqamaScreenDurationMinutes) }

    // 3. Pre-Prayer & Alerts
    var prePrayerEnabled by remember(currentConfig.prayerId) { mutableStateOf(currentConfig.prePrayerEnabled) }
    var prePrayerMinutes by remember(currentConfig.prayerId) { mutableIntStateOf(currentConfig.prePrayerMinutes) }

    // 4. Custom Icon
    var customIconUri by remember(currentConfig.prayerId) { mutableStateOf(currentConfig.customIconUri) }

    // Dialog state for audio libraries
    var showAdhanLibraryDialog by remember { mutableStateOf(false) }
    var showIqamaLibraryDialog by remember { mutableStateOf(false) }
    var currentlyTestingType by remember { mutableStateOf<String?>(null) }
    var currentPreviewSoundKey by remember { mutableStateOf<String?>(null) }

    fun emitConfigUpdate(
        newAdhanEnabled: Boolean = adhanEnabled,
        newAdhanOffset: Int = adhanOffsetMinutes,
        newAdhanUri: String? = adhanSoundUri,
        newAdhanName: String? = adhanSoundName,
        newIqamaEnabled: Boolean = iqamaEnabled,
        newIqamaMinutes: Int = iqamaMinutes,
        newIsManualIqama: Boolean = isManualIqama,
        newManualIqamaTime: String? = manualIqamaTime,
        newIqamaUri: String? = iqamaSoundUri,
        newIqamaName: String? = iqamaSoundName,
        newIqamaDuration: Int = iqamaScreenDurationMinutes,
        newPrePrayerEnabled: Boolean = prePrayerEnabled,
        newPrePrayerMinutes: Int = prePrayerMinutes,
        newCustomIconUri: String? = customIconUri
    ) {
        val updated = currentConfig.copy(
            prayerId = prayer.type.id,
            adhanEnabled = newAdhanEnabled,
            adhanOffsetMinutes = newAdhanOffset,
            adhanSoundUri = newAdhanUri,
            adhanSoundName = newAdhanName,
            adhanSoundPreset = if (newAdhanUri == null) "" else currentConfig.adhanSoundPreset,
            iqamaEnabled = if (isFajrFirst || isFridayFirst) false else newIqamaEnabled,
            iqamaMinutes = newIqamaMinutes,
            isManualIqama = newIsManualIqama,
            manualIqamaTime = newManualIqamaTime?.trim(),
            iqamaSoundUri = newIqamaUri,
            iqamaSoundName = newIqamaName,
            iqamaSoundPreset = if (newIqamaUri == null) "" else currentConfig.iqamaSoundPreset,
            iqamaScreenDurationMinutes = newIqamaDuration,
            prePrayerEnabled = newPrePrayerEnabled,
            prePrayerMinutes = newPrePrayerMinutes,
            customIconUri = newCustomIconUri
        )
        onSaveConfig(updated)
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val saved = com.example.util.FileStorageHelper.copyUriToInternalFile(
                context, uri, "prayer_icon_${prayer.type.id}.png"
            ) ?: uri.toString()
            customIconUri = saved
            emitConfigUpdate(newCustomIconUri = saved)
        }
    }

    val adhanPhonePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val fileName = uri.lastPathSegment?.substringAfterLast("/") ?: "أذان ${prayer.name}"
            val item = if (isFajrFirst) {
                onAddFajrAdhanToLibrary?.invoke(fileName, uri)
            } else {
                onAddAdhanToLibrary?.invoke(fileName, uri)
            }
            if (item != null) {
                adhanSoundUri = item.uri
                adhanSoundName = item.name
                emitConfigUpdate(newAdhanUri = item.uri, newAdhanName = item.name)
                Toast.makeText(context, "تم اختيار وتفعيل صوت الأذان", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val iqamaPhonePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val fileName = uri.lastPathSegment?.substringAfterLast("/") ?: "إقامة ${prayer.name}"
            val item = onAddIqamaToLibrary?.invoke(fileName, uri)
            if (item != null) {
                iqamaSoundUri = item.uri
                iqamaSoundName = item.name
                emitConfigUpdate(newIqamaUri = item.uri, newIqamaName = item.name)
                Toast.makeText(context, "تم اختيار وتفعيل صوت الإقامة", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ===== الأوقات المعروضة في الشارات (الوقت المعتمد / وقت الإقامة) =====
    val is24 = settings?.is24Hour ?: !(prayer.adhanTime.contains("ص") || prayer.adhanTime.contains("م"))
    val baseAdhanMin = parseDisplayMinutes(prayer.adhanTime)
    val adhanDelta = adhanOffsetMinutes - currentConfig.adhanOffsetMinutes
    val adhanDisplay = baseAdhanMin?.let { formatDisplayMinutes(it + adhanDelta, is24) } ?: prayer.adhanTime
    val iqamaDisplay = when {
        baseAdhanMin != null -> formatDisplayMinutes(baseAdhanMin + adhanDelta + iqamaMinutes, is24)
        else -> prayer.iqamaTime
    }
    val closeAll = {
        onStopAudio()
        onDismiss()
    }
    val dialogShape = RoundedCornerShape(18.dp)

    Dialog(
        onDismissRequest = closeAll,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Column(
                Modifier.widthIn(max = 672.dp).fillMaxWidth(.96f).fillMaxHeight(.92f).clip(dialogShape)
                    .background(Brush.verticalGradient(listOf(Pd.DlgTop, Pd.DlgMid, Pd.DlgBot)))
                    .border(1.8.dp, Pd.GoldBorder, dialogShape)
            ) {
                // ---------- الترويسة ----------
                Row(
                    Modifier.fillMaxWidth().background(Pd.DlgBar).padding(horizontal = 20.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(40.dp).clip(CircleShape).background(Pd.Navy).border(1.dp, Pd.GoldBorder, CircleShape), Alignment.Center) { T("🕒", Pd.Gold, 18.sp) }
                        Column {
                            T("إعدادات ${prayer.name}", Pd.GoldLight, 22.sp, true, ArefRuqaaFamily)
                            T("تخصيص الوقت، أصوات الأذان والإقامة المستقلة من المكتبة أو الهاتف", Color.White.copy(alpha = .75f), 12.sp)
                        }
                    }
                    Box(
                        Modifier.size(36.dp).clip(CircleShape).background(Pd.Navy).border(1.dp, Pd.GoldBorder.copy(alpha = .6f), CircleShape).clickable(onClick = closeAll),
                        Alignment.Center
                    ) { T("✕", Pd.GoldLight, 16.sp) }
                }

                // ---------- المحتوى ----------
                Column(
                    Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // 2) مدة انتظار الإقامة (بالدقائق فقط)
                    if (hasIqama) PdCard {
                        PdMinuteRow(
                            title = "إقامة ${prayer.name}",
                            sub = "وقت الإقامة: $iqamaDisplay",
                            value = iqamaMinutes, min = 1, max = 90, enabled = iqamaEnabled
                        ) {
                            iqamaMinutes = it
                            emitConfigUpdate(newIqamaMinutes = it)
                        }
                    }

                    // 3) بطاقة صوت الأذان
                    if (hasAdhan) {
                        val isUnifiedAdhanActive = settings?.useCommonAdhan == true && !isFajrFirst
                        val adhanTitle = when {
                            !adhanSoundUri.isNullOrBlank() -> {
                                adhanSoundName?.takeIf { it.isNotBlank() }
                                    ?: (if (isFajrFirst) savedFajrAdhanSounds.find { it.uri == adhanSoundUri }?.name
                                        else savedAdhanSounds.find { it.uri == adhanSoundUri }?.name)
                                    ?: adhanSoundUri!!.substringAfterLast("/")
                            }
                            settings != null -> settings.getResolvedAdhanTitle(prayer.type)
                            else -> "لم يتم اختيار صوت"
                        }
                        val soundUriToUse = adhanSoundUri?.takeIf { it.isNotBlank() }
                            ?: settings?.getResolvedAdhanSound(prayer.type)
                            ?: adhanTitle
                        PdAudioCard(
                            title = if (isFajrFirst) "أذان الفجر الأول" else "أذان ${prayer.name}",
                            kind = "التنبيه الصوتي بالأذان",
                            icon = "🔊",
                            on = adhanEnabled,
                            onToggle = {
                                adhanEnabled = !adhanEnabled
                                emitConfigUpdate(newAdhanEnabled = adhanEnabled)
                            },
                            label = if (isUnifiedAdhanActive && adhanSoundUri.isNullOrBlank()) "الصوت الموحد المطبق:" else "الصوت المختار:",
                            name = adhanTitle,
                            sub = "تسجيل الأذان المعتمد",
                            isPlaying = isPlayingTest && currentlyTestingType == "adhan",
                            onPlayPause = {
                                if (!adhanEnabled) return@PdAudioCard
                                if (isPlayingTest && currentlyTestingType == "adhan") {
                                    onStopAudio()
                                    currentlyTestingType = null
                                } else {
                                    onStopAudio()
                                    currentlyTestingType = "adhan"
                                    onTestAudio(soundUriToUse)
                                }
                            },
                            onClear = if (adhanEnabled && !adhanSoundUri.isNullOrBlank()) {
                                {
                                    adhanSoundUri = null
                                    adhanSoundName = null
                                    emitConfigUpdate(newAdhanUri = null, newAdhanName = null)
                                }
                            } else null,
                            libraryText = if (isFajrFirst) "مكتبة أذان الفجر" else "اختيار من المكتبة",
                            onLibrary = { if (adhanEnabled) showAdhanLibraryDialog = true },
                            onPhone = { if (adhanEnabled) adhanPhonePickerLauncher.launch("audio/*") }
                        )
                    }

                    // 4) بطاقة صوت الإقامة
                    if (hasIqama) {
                        val isUnifiedIqamaActive = settings?.applyIqamaSoundToAll == true
                        val iqamaTitle = when {
                            !iqamaSoundUri.isNullOrBlank() -> {
                                iqamaSoundName?.takeIf { it.isNotBlank() }
                                    ?: savedIqamaSounds.find { it.uri == iqamaSoundUri }?.name
                                    ?: iqamaSoundUri!!.substringAfterLast("/")
                            }
                            settings != null -> settings.getResolvedIqamaTitle(prayer.type)
                            else -> "لم يتم اختيار صوت"
                        }
                        val iqamaSoundUriToUse = iqamaSoundUri?.takeIf { it.isNotBlank() }
                            ?: settings?.getResolvedIqamaSound(prayer.type)
                            ?: iqamaTitle
                        PdAudioCard(
                            title = "إقامة ${prayer.name}",
                            kind = "التنبيه الصوتي بإقامة الصلاة",
                            icon = "🔔",
                            on = iqamaEnabled,
                            onToggle = {
                                iqamaEnabled = !iqamaEnabled
                                emitConfigUpdate(newIqamaEnabled = iqamaEnabled)
                            },
                            label = if (isUnifiedIqamaActive && iqamaSoundUri.isNullOrBlank()) "الصوت الموحد المطبق:" else "الصوت المختار:",
                            name = iqamaTitle,
                            sub = "الله أكبر الله أكبر.. قد قامت الصلاة قد قامت الصلاة",
                            isPlaying = isPlayingTest && currentlyTestingType == "iqama",
                            onPlayPause = {
                                if (!iqamaEnabled) return@PdAudioCard
                                if (isPlayingTest && currentlyTestingType == "iqama") {
                                    onStopAudio()
                                    currentlyTestingType = null
                                } else {
                                    onStopAudio()
                                    currentlyTestingType = "iqama"
                                    onTestAudio(iqamaSoundUriToUse)
                                }
                            },
                            onClear = if (iqamaEnabled && !iqamaSoundUri.isNullOrBlank()) {
                                {
                                    iqamaSoundUri = null
                                    iqamaSoundName = null
                                    emitConfigUpdate(newIqamaUri = null, newIqamaName = null)
                                }
                            } else null,
                            libraryText = "اختيار من المكتبة",
                            onLibrary = { if (iqamaEnabled) showIqamaLibraryDialog = true },
                            onPhone = { if (iqamaEnabled) iqamaPhonePickerLauncher.launch("audio/*") }
                        )
                    }

                    // 5) مدة شاشة «الصلاة قائمة»
                    if (hasIqama) PdCard {
                        PdMinuteRow(
                            title = "مدة شاشة الصلاة قائمة",
                            sub = "بالدقائق بعد الإقامة",
                            value = iqamaScreenDurationMinutes, min = 1, max = 60, enabled = iqamaEnabled
                        ) {
                            iqamaScreenDurationMinutes = it
                            emitConfigUpdate(newIqamaDuration = it)
                        }
                    }

                    // 7) تنبيه اقتراب الأذان (ميزة موجودة سابقاً — بنفس التصميم)
                    PdCard {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            PdHead("تنبيه اقتراب الأذان", "شريط تنبيه قبل الصلاة", Modifier.weight(1f))
                            PdToggle(prePrayerEnabled) { prePrayerEnabled = !prePrayerEnabled }
                        }
                        if (prePrayerEnabled) {
                            PdMinuteRow("دقائق التنبيه قبل الأذان", null, prePrayerMinutes, 1, 30) { prePrayerMinutes = it }
                        }
                    }
                }

                // ---------- التذييل ----------
                Row(
                    Modifier.fillMaxWidth().background(Pd.DlgBar).padding(horizontal = 20.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.clip(RoundedCornerShape(10.dp)).background(Pd.Gold).clickable {
                            onStopAudio()
                            onSaveConfig(
                                currentConfig.copy(
                                    prayerId = prayer.type.id,
                                    adhanEnabled = adhanEnabled,
                                    adhanOffsetMinutes = adhanOffsetMinutes,
                                    adhanSoundUri = adhanSoundUri,
                                    adhanSoundName = adhanSoundName,
                                    adhanSoundPreset = if (adhanSoundUri == null) "" else currentConfig.adhanSoundPreset,
                                    iqamaEnabled = if (isFajrFirst || isFridayFirst) false else iqamaEnabled,
                                    iqamaMinutes = iqamaMinutes,
                                    isManualIqama = false,
                                    manualIqamaTime = manualIqamaTime.trim(),
                                    iqamaSoundUri = iqamaSoundUri,
                                    iqamaSoundName = iqamaSoundName,
                                    iqamaSoundPreset = if (iqamaSoundUri == null) "" else currentConfig.iqamaSoundPreset,
                                    iqamaScreenDurationMinutes = iqamaScreenDurationMinutes,
                                    prePrayerEnabled = prePrayerEnabled,
                                    prePrayerMinutes = prePrayerMinutes,
                                    customIconUri = customIconUri
                                )
                            )
                            Toast.makeText(context, "تم حفظ إعدادات ${prayer.name} بنجاح", Toast.LENGTH_SHORT).show()
                            onDismiss()
                        }.padding(horizontal = 20.dp, vertical = 8.dp)
                    ) { T("✓ حفظ الإعدادات والتطبيق", Color(0xFF041935), 14.sp, true) }
                    Box(
                        Modifier.clip(RoundedCornerShape(10.dp)).border(1.dp, Pd.GoldBorder.copy(alpha = .6f), RoundedCornerShape(10.dp))
                            .clickable(onClick = closeAll).padding(horizontal = 16.dp, vertical = 8.dp)
                    ) { T("إلغاء", Color.White, 13.5.sp) }
                }
            }
        }
    }

    // Modal dialog for selecting adhan
    if (showAdhanLibraryDialog) {
        val libraryToUse = if (isFajrFirst) savedFajrAdhanSounds else savedAdhanSounds
        AudioLibrarySelectionDialog(
            title = if (isFajrFirst) "مكتبة أذان الفجر الأول (الملفات المضغوطة)" else "مكتبة الأذان لـ ${prayer.name}",
            subtitle = if (isFajrFirst) "أصوات أذان الفجر الأول المستخرجة من الملف المضغوط" else "اختر صوت الأذان المناسب لهذه الصلاة",
            initialSelectedUri = adhanSoundUri,
            librarySounds = libraryToUse,
            isPlayingTest = isPlayingTest && currentlyTestingType == "adhan",
            playingSoundKey = if (isPlayingTest && currentlyTestingType == "adhan") (currentPreviewSoundKey ?: adhanSoundUri) else null,
            onTestSound = { sound ->
                currentPreviewSoundKey = sound
                currentlyTestingType = "adhan"
                onTestAudio(sound)
            },
            onStopSound = {
                onStopAudio()
                currentlyTestingType = null
                currentPreviewSoundKey = null
            },
            onImportFileFromPhone = { name, uri ->
                if (isFajrFirst) onAddFajrAdhanToLibrary?.invoke(name, uri)
                else onAddAdhanToLibrary?.invoke(name, uri)
            },
            onDeleteSound = { item ->
                if (isFajrFirst) onDeleteFajrAdhanFromLibrary?.invoke(item)
                else onDeleteAdhanFromLibrary?.invoke(item)
            },
            onConfirmSelection = { item ->
                onStopAudio()
                currentlyTestingType = null
                currentPreviewSoundKey = null
                adhanSoundUri = item.uri
                adhanSoundName = item.name
                emitConfigUpdate(newAdhanUri = item.uri, newAdhanName = item.name)
                showAdhanLibraryDialog = false
            },
            onDismiss = {
                onStopAudio()
                currentlyTestingType = null
                currentPreviewSoundKey = null
                showAdhanLibraryDialog = false
            }
        )
    }

    // Modal dialog for selecting iqama
    if (showIqamaLibraryDialog) {
        AudioLibrarySelectionDialog(
            title = "مكتبة أصوات الإقامة (للإقامة فقط)",
            subtitle = "أصوات الإقامة المستقلة المخصصة للإقامة دون خلطها بالأذان",
            initialSelectedUri = iqamaSoundUri,
            librarySounds = savedIqamaSounds,
            isPlayingTest = isPlayingTest && currentlyTestingType == "iqama",
            playingSoundKey = if (isPlayingTest && currentlyTestingType == "iqama") (currentPreviewSoundKey ?: iqamaSoundUri) else null,
            onTestSound = { sound ->
                currentPreviewSoundKey = sound
                currentlyTestingType = "iqama"
                onTestAudio(sound)
            },
            onStopSound = {
                onStopAudio()
                currentlyTestingType = null
                currentPreviewSoundKey = null
            },
            onImportFileFromPhone = { name, uri ->
                onAddIqamaToLibrary?.invoke(name, uri)
            },
            onDeleteSound = { item ->
                onDeleteIqamaFromLibrary?.invoke(item)
            },
            onConfirmSelection = { item ->
                onStopAudio()
                currentlyTestingType = null
                currentPreviewSoundKey = null
                iqamaSoundUri = item.uri
                iqamaSoundName = item.name
                emitConfigUpdate(newIqamaUri = item.uri, newIqamaName = item.name)
                showIqamaLibraryDialog = false
            },
            onDismiss = {
                onStopAudio()
                currentlyTestingType = null
                currentPreviewSoundKey = null
                showIqamaLibraryDialog = false
            }
        )
    }
}
