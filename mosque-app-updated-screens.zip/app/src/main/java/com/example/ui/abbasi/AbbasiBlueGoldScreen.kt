package com.example.ui.abbasi

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ActiveCountdown
import com.example.model.AppSettings
import com.example.model.PrayerRowItem
import com.example.model.PrayerType
import com.example.ui.components.PrayerIconBox
import com.example.ui.theme.NotoNaskhArabicFamily
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Main Mosque Prayer Interface — Royal Navy & Gold Digital Board:
 *
 * RTL / Horizontal Orientation:
 * - Far Right (9% width): Bright cyan vertical banner («مسجد عرصه الكبير» / اسم المسجد).
 * - Main Navy Board (Double gold frame, subtle Islamic silhouette arches):
 *   - Top Row:
 *     - Right (In RTL, ~42% width): Two stacked cards:
 *       1. «الوقت المتبقي للأذان القادم» (HH:MM:SS)
 *       2. «الوقت المتبقي للإقامة» (HH:MM:SS / MM:SS)
 *     - Left (In RTL, ~58% width): Prominent Digital Clock with double gold frame,
 *       extra-large bold digits, golden AM/PM indicator, and enlarged date bar:
 *       («الجمعة 11 جمادى الأولى 1448 هـ  |  2026/10/24»).
 *   - Middle Row: 7 Prayer Columns (from Right to Left in Arabic:
 *     الفجر 1، الفجر 2، الشروق، الظهر، العصر، المغرب، العشاء)
 *     separated by gradient blue vertical dividers.
 *     The NEXT upcoming prayer among the 5 obligatory prayers (الفجر الثاني، الظهر، العصر، المغرب، العشاء)
 *     is highlighted with an illuminated cyan glow border and glowing time box.
 *     الفجر الأول and الشروق are strictly NEVER highlighted.
 *   - Bottom Row:
 *     - Right: «بيانات المواقيت» button with calendar icon.
 *     - Center: «اللهم ارحم موتانا وموتى المسلمين».
 *     - Left: «الإعدادات» button with gear icon.
 */
@Composable
fun AbbasiBlueGoldScreen(
    currentTimeFormatted: String,
    dayOfWeek: String,
    hijriDate: String,
    gregorianDate: String,
    prayerRows: List<PrayerRowItem>,
    iqamaCountdown: ActiveCountdown?,
    adhanCountdown: ActiveCountdown?,
    settings: AppSettings,
    nextUpcomingPrayerType: PrayerType? = null,
    onPrayerClick: (PrayerRowItem) -> Unit,
    onSettingsClick: () -> Unit,
    onScheduleClick: () -> Unit = onSettingsClick,
    modifier: Modifier = Modifier
) {
    val displayMosqueName = if (settings.mosqueName.isBlank() || settings.mosqueName == "مسجد الشهداء" || settings.mosqueName == "مسجد عرصه الكبير") {
        "اسم المسجد"
    } else {
        settings.mosqueName
    }

    // Parse clean time digits and AM/PM marker (e.g. "11:50:30" and "م")
    val (timeOnly, amPmMarker) = remember(currentTimeFormatted) {
        val trimmed = currentTimeFormatted.trim()
        val isPm = trimmed.contains("م") || trimmed.contains("PM", ignoreCase = true)
        val isAm = trimmed.contains("ص") || trimmed.contains("AM", ignoreCase = true)
        val marker = if (isPm) "م" else if (isAm) "ص" else ""
        val cleanTime = trimmed
            .replace(" ص", "")
            .replace(" م", "")
            .replace("ص ", "")
            .replace("م ", "")
            .replace("ص", "")
            .replace("م", "")
            .replace("AM", "", ignoreCase = true)
            .replace("PM", "", ignoreCase = true)
            .trim()
        Pair(cleanTime, marker)
    }

    // Gregorian numeric date (e.g. 2026/10/24)
    val gregorianNumeric = remember {
        try {
            LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy/MM/dd", Locale.US))
        } catch (_: Exception) {
            gregorianDate
        }
    }

    // Hijri date with day of week (e.g. الجمعة 11 جمادى الأولى 1448 هـ)
    val hijriWithDay = remember(dayOfWeek, hijriDate) {
        val cleanHijri = hijriDate.replace("هـ", "").trim()
        if (cleanHijri.isNotBlank()) {
            "$dayOfWeek $cleanHijri هـ"
        } else {
            dayOfWeek
        }
    }

    val adhanTimeDisplay = adhanCountdown?.formattedTime ?: "00:00:00"
    val iqamaTimeDisplay = iqamaCountdown?.formattedTime ?: "00:00"

    // 7 prayers in chronological Arabic order (starts at Fajr on the right, ends at Isha on the left)
    val orderedPrayers = remember(prayerRows) {
        val targetOrder = listOf(
            PrayerType.FAJR_FIRST,
            PrayerType.FAJR_SECOND,
            PrayerType.SUNRISE,
            PrayerType.DHUHR,
            PrayerType.FRIDAY_SECOND,
            PrayerType.FRIDAY_FIRST,
            PrayerType.ASR,
            PrayerType.MAGHRIB,
            PrayerType.ISHA
        )

        val result = mutableListOf<PrayerRowItem>()
        for (type in targetOrder) {
            val item = prayerRows.find { it.type == type }
            if (item != null && !result.any { it.type == item.type }) {
                result.add(item)
            }
        }
        if (result.isEmpty()) prayerRows else result.take(7)
    }

    // Determine the single next upcoming prayer strictly among the 5 obligatory prayers:
    // (الفجر الثاني، الظهر، العصر، المغرب، العشاء).
    // Strictly NEVER FAJR_FIRST or SUNRISE.
    val targetNextType = remember(nextUpcomingPrayerType, prayerRows) {
        if (nextUpcomingPrayerType != null &&
            nextUpcomingPrayerType != PrayerType.FAJR_FIRST &&
            nextUpcomingPrayerType != PrayerType.SUNRISE &&
            nextUpcomingPrayerType != PrayerType.FRIDAY_FIRST
        ) {
            nextUpcomingPrayerType
        } else {
            val candidate = prayerRows.find { it.isNext }?.type
            if (candidate != null &&
                candidate != PrayerType.FAJR_FIRST &&
                candidate != PrayerType.SUNRISE &&
                candidate != PrayerType.FRIDAY_FIRST
            ) {
                candidate
            } else {
                PrayerType.FAJR_SECOND
            }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        BoxWithConstraints(
            modifier = modifier
                .fillMaxSize()
                .background(AbbasiThemeColors.BackgroundNavy),
            contentAlignment = Alignment.Center
        ) {
            val boardW = maxWidth
            val boardH = maxHeight

            // Width of vertical cyan strip is ~9% of board width
            val stripWidth = (boardW * 0.092f).coerceIn(40.dp, 68.dp)
            val outerCornerRadius = 0.dp

            // Enlarged typography and element sizing proportional to board dimensions
            val clockTimeSize = (boardH.value * 0.175f).coerceIn(44f, 86f).sp
            val clockAmPmSize = (boardH.value * 0.105f).coerceIn(24f, 50f).sp
            val dateFontSize = (boardH.value * 0.058f).coerceIn(17f, 30f).sp
            val countdownTitleSize = (boardH.value * 0.046f).coerceIn(13.5f, 22f).sp
            val countdownTimeSize = (boardH.value * 0.110f).coerceIn(28f, 54f).sp
            val prayerNameSize = (boardH.value * 0.076f).coerceIn(20f, 36f).sp
            val prayerTimeSize = (boardH.value * 0.076f).coerceIn(22f, 37f).sp
            val iconBadgeSize = (boardH.value * 0.108f).coerceIn(30f, 50f).dp
            val timeBoxHeight = (boardH.value * 0.125f).coerceIn(34f, 56f).dp
            val footerTextSize = (boardH.value * 0.040f).coerceIn(13f, 20f).sp
            val footerDuaSize = (boardH.value * 0.046f).coerceIn(14f, 23f).sp

            // Outer Mosque Board: Fills 100% of the screen edge-to-edge
            Row(
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.Start,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // =========================================================================
                // 1. FAR RIGHT (First Child in RTL): Bright Sky-Blue Vertical Strip («مسجد عرصه الكبير»)
                // =========================================================================
                Row(
                    modifier = Modifier
                        .width(stripWidth)
                        .fillMaxHeight(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            // In RTL, topStart and bottomStart are the outer right corners
                            .clip(RoundedCornerShape(topStart = outerCornerRadius, bottomStart = outerCornerRadius))
                            .background(AbbasiThemeColors.CyanStripGradient),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = displayMosqueName,
                            color = AbbasiThemeColors.WhiteExact,
                            fontSize = (stripWidth.value * 0.52f).coerceIn(18f, 30f).sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = NotoNaskhArabicFamily,
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            softWrap = false,
                            style = TextStyle(
                                shadow = Shadow(
                                    color = Color(0x80002244),
                                    offset = Offset(1f, 2f),
                                    blurRadius = 3f
                                )
                            ),
                            modifier = Modifier
                                .wrapContentSize(unbounded = true)
                                .graphicsLayer(rotationZ = -90f)
                        )
                    }

                    // Crisp metallic gold divider bead between cyan strip and navy board
                    Box(
                        modifier = Modifier
                            .width(1.2.dp)
                            .fillMaxHeight()
                            .background(AbbasiThemeColors.MetallicGoldGradient)
                    )
                }

                // =========================================================================
                // 2. MAIN NAVY BOARD (Left of the Blue Strip, with Double Gold Borders)
                // =========================================================================
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        // In RTL, topEnd and bottomEnd are the outer left corners
                        .border(
                            width = 1.6.dp,
                            brush = AbbasiThemeColors.MetallicGoldGradient,
                            shape = RoundedCornerShape(topEnd = outerCornerRadius, bottomEnd = outerCornerRadius)
                        )
                        .padding(2.5.dp)
                        .border(
                            width = 1.0.dp,
                            brush = AbbasiThemeColors.SubtleGoldBorder,
                            shape = RoundedCornerShape(topEnd = 11.dp, bottomEnd = 11.dp)
                        )
                        .background(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    AbbasiThemeColors.InnerNavy,
                                    AbbasiThemeColors.BackgroundNavy
                                )
                            ),
                            shape = RoundedCornerShape(topEnd = 11.dp, bottomEnd = 11.dp)
                        )
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    // Architectural background silhouette
                    AbbasiMosqueSilhouette(modifier = Modifier.fillMaxSize())

                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        // -----------------------------------------------------------------
                        // TOP SECTION: Countdowns (Right in RTL) + Big Clock (Left in RTL)
                        // -----------------------------------------------------------------
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1.05f),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // RIGHT (In RTL, Child 0): Two Stacked Countdown Cards (~42% width)
                            Column(
                                modifier = Modifier
                                    .weight(0.88f)
                                    .fillMaxHeight(),
                                verticalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                // Top Countdown: «الوقت المتبقي للأذان القادم»
                                CountdownBox(
                                    title = "الوقت المتبقي للأذان القادم",
                                    timeText = adhanTimeDisplay,
                                    titleSize = countdownTitleSize,
                                    timeSize = countdownTimeSize,
                                    modifier = Modifier.weight(1f)
                                )

                                // Bottom Countdown: «الوقت المتبقي للإقامة»
                                CountdownBox(
                                    title = "الوقت المتبقي للإقامة",
                                    timeText = iqamaTimeDisplay,
                                    titleSize = countdownTitleSize,
                                    timeSize = countdownTimeSize,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            // LEFT (In RTL, Child 1): Enlarged Digital Clock & Date Card (~58% width)
                            Box(
                                modifier = Modifier
                                    .weight(1.24f)
                                    .fillMaxHeight()
                                    .border(1.6.dp, AbbasiThemeColors.MetallicGoldGradient, RoundedCornerShape(10.dp))
                                    .padding(2.dp)
                                    .border(1.0.dp, AbbasiThemeColors.SubtleGoldBorder, RoundedCornerShape(8.dp))
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(AbbasiThemeColors.DigitalBoxGradient)
                                    .padding(horizontal = 10.dp, vertical = 4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxSize(),
                                    verticalArrangement = Arrangement.SpaceBetween,
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    // Upper Time Row: e.g. [م] [11:50:30]
                                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                        Row(
                                            modifier = Modifier.weight(1f),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.Center
                                        ) {
                                            if (amPmMarker.isNotBlank()) {
                                                Text(
                                                    text = amPmMarker,
                                                    color = AbbasiThemeColors.LightGoldExact,
                                                    fontSize = clockAmPmSize,
                                                    fontWeight = FontWeight.Black,
                                                    fontFamily = NotoNaskhArabicFamily,
                                                    style = TextStyle(
                                                        shadow = Shadow(
                                                            color = Color(0xB3000000),
                                                            offset = Offset(1f, 1f),
                                                            blurRadius = 3f
                                                        )
                                                    )
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                            }
                                            Text(
                                                text = timeOnly,
                                                color = AbbasiThemeColors.WhiteExact,
                                                fontSize = clockTimeSize,
                                                fontWeight = FontWeight.Black,
                                                letterSpacing = 1.sp,
                                                maxLines = 1,
                                                softWrap = false,
                                                style = TextStyle(
                                                    fontFeatureSettings = "tnum",
                                                    shadow = Shadow(
                                                        color = Color(0x99000000),
                                                        offset = Offset(0f, 2.5f),
                                                        blurRadius = 4f
                                                    )
                                                )
                                            )
                                        }
                                    }

                                    // Bottom Date Bar: الجمعة 11 جمادى الأولى 1448 هـ  |  2026/10/24
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(7.dp))
                                            .background(Color(0x44000000))
                                            .border(1.0.dp, AbbasiThemeColors.SubtleGoldBorder, RoundedCornerShape(7.dp))
                                            .padding(horizontal = 8.dp, vertical = 4.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Row(
                                            horizontalArrangement = Arrangement.Center,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = hijriWithDay,
                                                color = AbbasiThemeColors.LightGoldExact,
                                                fontSize = dateFontSize,
                                                fontWeight = FontWeight.Black,
                                                fontFamily = NotoNaskhArabicFamily,
                                                maxLines = 1,
                                                softWrap = false,
                                                style = TextStyle(
                                                    shadow = Shadow(
                                                        color = Color.Black,
                                                        offset = Offset(1.5f, 1.5f),
                                                        blurRadius = 3f
                                                    )
                                                )
                                            )
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Text(
                                                text = "|",
                                                color = AbbasiThemeColors.LightGoldExact.copy(alpha = 0.85f),
                                                fontSize = dateFontSize,
                                                fontWeight = FontWeight.Black
                                            )
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Text(
                                                text = gregorianNumeric,
                                                color = AbbasiThemeColors.LightGoldExact,
                                                fontSize = dateFontSize,
                                                fontWeight = FontWeight.Black,
                                                style = TextStyle(
                                                    fontFeatureSettings = "tnum",
                                                    shadow = Shadow(
                                                        color = Color.Black,
                                                        offset = Offset(1.5f, 1.5f),
                                                        blurRadius = 3f
                                                    )
                                                ),
                                                maxLines = 1,
                                                softWrap = false
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(3.dp))

                        // -----------------------------------------------------------------
                        // MIDDLE SECTION: 7 Prayer Columns (RTL: Fajr on Right -> Isha on Left)
                        // -----------------------------------------------------------------
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1.05f),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            orderedPrayers.forEachIndexed { index, prayer ->
                                val isHighlighted = (prayer.type == targetNextType ||
                                        (prayer.type == PrayerType.DHUHR && targetNextType == PrayerType.FRIDAY_SECOND) ||
                                        (prayer.type == PrayerType.FRIDAY_SECOND && targetNextType == PrayerType.DHUHR))
                                        && prayer.type != PrayerType.FAJR_FIRST
                                        && prayer.type != PrayerType.SUNRISE
                                        && prayer.type != PrayerType.FRIDAY_FIRST

                                PrayerColumnItem(
                                    prayer = prayer,
                                    isHighlighted = isHighlighted,
                                    nameFontSize = prayerNameSize,
                                    timeFontSize = prayerTimeSize,
                                    iconBadgeSize = iconBadgeSize,
                                    timeBoxHeight = timeBoxHeight,
                                    onClick = { onPrayerClick(prayer) },
                                    modifier = Modifier.weight(1f)
                                )

                                // Refined gradient light-blue divider between columns
                                if (index < orderedPrayers.size - 1) {
                                    Box(
                                        modifier = Modifier
                                            .width(1.2.dp)
                                            .fillMaxHeight(0.88f)
                                            .background(AbbasiThemeColors.DividerBlueGradient)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(3.dp))

                        // -----------------------------------------------------------------
                        // BOTTOM SECTION: Action Buttons & Spiritual Phrase
                        // (RTL: Schedule on Right, Dua Center, Settings on Left)
                        // -----------------------------------------------------------------
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height((boardH * 0.10f).coerceIn(28.dp, 40.dp)),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Right Button (In RTL, Child 0): «بيانات المواقيت»
                            Surface(
                                onClick = onScheduleClick,
                                shape = RoundedCornerShape(9.dp),
                                color = Color.Transparent,
                                border = BorderStroke(1.2.dp, AbbasiThemeColors.SubtleGoldBorder)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .background(AbbasiThemeColors.DigitalBoxGradient)
                                        .padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.DateRange,
                                            contentDescription = "بيانات المواقيت",
                                            tint = AbbasiThemeColors.LightGoldExact,
                                            modifier = Modifier.size((boardH * 0.052f).coerceIn(14.dp, 19.dp))
                                        )
                                        Text(
                                            text = "بيانات المواقيت",
                                            color = AbbasiThemeColors.LightGoldExact,
                                            fontSize = footerTextSize,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = NotoNaskhArabicFamily
                                        )
                                    }
                                }
                            }

                            // Center Spiritual Phrase
                            Text(
                                text = "اللهم ارحم موتانا وموتى المسلمين",
                                color = AbbasiThemeColors.LightGoldExact,
                                fontSize = footerDuaSize,
                                fontWeight = FontWeight.Bold,
                                fontFamily = NotoNaskhArabicFamily,
                                textAlign = TextAlign.Center,
                                style = TextStyle(
                                    shadow = Shadow(
                                        color = Color.Black.copy(alpha = 0.85f),
                                        offset = Offset(1f, 1f),
                                        blurRadius = 3f
                                    )
                                )
                            )

                            // Left Button (In RTL, Child 2): «الإعدادات»
                            Surface(
                                onClick = onSettingsClick,
                                shape = RoundedCornerShape(9.dp),
                                color = Color.Transparent,
                                border = BorderStroke(1.2.dp, AbbasiThemeColors.SubtleGoldBorder)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .background(AbbasiThemeColors.DigitalBoxGradient)
                                        .padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Settings,
                                            contentDescription = "الإعدادات",
                                            tint = AbbasiThemeColors.LightGoldExact,
                                            modifier = Modifier.size((boardH * 0.052f).coerceIn(14.dp, 19.dp))
                                        )
                                        Text(
                                            text = "الإعدادات",
                                            color = AbbasiThemeColors.LightGoldExact,
                                            fontSize = footerTextSize,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = NotoNaskhArabicFamily
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Reusable Countdown Box (for Adhan and Iqama Countdown).
 */
@Composable
private fun CountdownBox(
    title: String,
    timeText: String,
    titleSize: TextUnit,
    timeSize: TextUnit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(9.dp))
            .border(1.2.dp, AbbasiThemeColors.SubtleGoldBorder, RoundedCornerShape(9.dp))
            .background(AbbasiThemeColors.DigitalBoxGradient)
            .padding(horizontal = 6.dp, vertical = 2.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = title,
                color = AbbasiThemeColors.WhiteExact,
                fontSize = titleSize,
                fontWeight = FontWeight.Bold,
                fontFamily = NotoNaskhArabicFamily,
                textAlign = TextAlign.Center,
                maxLines = 1,
                softWrap = false,
                style = TextStyle(
                    shadow = Shadow(
                        color = Color(0x99000000),
                        offset = Offset(0f, 1f),
                        blurRadius = 2f
                    )
                )
            )
            Spacer(modifier = Modifier.height(1.dp))
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Text(
                    text = timeText,
                    color = AbbasiThemeColors.WhiteExact,
                    fontSize = timeSize,
                    fontWeight = FontWeight.Black,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    softWrap = false,
                    style = TextStyle(
                        fontFeatureSettings = "tnum",
                        shadow = Shadow(
                            color = Color(0x99000000),
                            offset = Offset(0f, 1.5f),
                            blurRadius = 3f
                        )
                    )
                )
            }
        }
    }
}

/**
 * Individual Prayer Column in the Middle Row:
 * [Top: اسم الصلاة بالذهبي الفاتح والخط الثقيل]
 * [Middle: أيقونة الصلاة في دائرة ذهبية بارزة]
 * [Bottom: مستطيل الوقت بأرقام بيضاء كبيرة وواضحة]
 *
 * When highlighted (تمييز الصلاة القادمة):
 * Distinctive glowing cyan border (#079FDC) and illuminated time box.
 * Strictly applied only to: الفجر الثاني، الظهر، العصر، المغرب، العشاء.
 * NEVER applied to الفجر الأول or الشروق.
 */
@Composable
private fun PrayerColumnItem(
    prayer: PrayerRowItem,
    isHighlighted: Boolean,
    nameFontSize: TextUnit,
    timeFontSize: TextUnit,
    iconBadgeSize: Dp,
    timeBoxHeight: Dp,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val displayName = remember(prayer.type, prayer.name) {
        when (prayer.type) {
            PrayerType.FAJR_FIRST -> if (prayer.name.contains("الأذان")) prayer.name else "الفجر 1"
            PrayerType.FAJR_SECOND -> if (prayer.name.contains("الأذان")) prayer.name else "الفجر 2"
            else -> prayer.name
        }
    }

    // Time digits without AM/PM text
    val timeDisplay = remember(prayer.adhanTime) {
        prayer.adhanTime
            .replace(" ص", "")
            .replace(" م", "")
            .replace("ص", "")
            .replace("م", "")
            .trim()
    }

    Column(
        modifier = modifier
            .fillMaxHeight()
            .clip(RoundedCornerShape(9.dp))
            .clickable(onClick = onClick)
            .then(
                if (isHighlighted) {
                    Modifier
                        .border(2.2.dp, AbbasiThemeColors.ActiveBorderCyan, RoundedCornerShape(9.dp))
                        .background(AbbasiThemeColors.BrightCyan.copy(alpha = 0.20f))
                } else Modifier
            )
            .padding(horizontal = 3.dp, vertical = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // 1. Prayer Name (Top) — Extra-Large, Deep Bold Gold filling the top space
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 1.dp, vertical = 1.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = displayName,
                color = AbbasiThemeColors.LightGoldExact,
                fontSize = nameFontSize,
                fontWeight = FontWeight.Black,
                fontFamily = NotoNaskhArabicFamily,
                textAlign = TextAlign.Center,
                maxLines = 1,
                softWrap = false,
                style = TextStyle(
                    shadow = Shadow(
                        color = Color.Black,
                        offset = Offset(1.5f, 1.5f),
                        blurRadius = 3.5f
                    )
                )
            )
        }

        // 2. Circular Icon Badge (Middle)
        Box(
            modifier = Modifier
                .size(iconBadgeSize)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF0F3E75),
                            Color(0xFF061E3B)
                        )
                    )
                )
                .border(
                    width = if (isHighlighted) 1.8.dp else 1.2.dp,
                    color = if (isHighlighted) AbbasiThemeColors.ActiveBorderCyan else AbbasiThemeColors.PrimaryGoldExact,
                    shape = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            PrayerIconBox(
                prayerType = prayer.type,
                customIconUri = prayer.customIconUri,
                boxSize = (iconBadgeSize.value * 0.74f).dp,
                iconColor = if (isHighlighted) AbbasiThemeColors.LightGoldExact else AbbasiThemeColors.PrimaryGoldExact,
                backgroundColor = Color.Transparent,
                borderColor = Color.Transparent
            )
        }

        // 3. Time Box (Bottom) — Fills the rectangle with enlarged, bold numbers
        Box(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .height(timeBoxHeight)
                .clip(RoundedCornerShape(6.dp))
                .background(
                    if (isHighlighted) AbbasiThemeColors.ActivePrayerGlowGradient
                    else AbbasiThemeColors.DigitalBoxGradient
                )
                .border(
                    width = if (isHighlighted) 2.0.dp else 1.1.dp,
                    color = if (isHighlighted) AbbasiThemeColors.ActiveBoxBorderCyan else AbbasiThemeColors.PrimaryGoldExact,
                    shape = RoundedCornerShape(6.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Text(
                    text = timeDisplay,
                    color = AbbasiThemeColors.WhiteExact,
                    fontSize = timeFontSize,
                    fontWeight = FontWeight.Black,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    softWrap = false,
                    style = TextStyle(
                        fontFeatureSettings = "tnum",
                        shadow = Shadow(
                            color = Color(0x99000000),
                            offset = Offset(0f, 1f),
                            blurRadius = 2.5f
                        )
                    )
                )
            }
        }
    }
}
