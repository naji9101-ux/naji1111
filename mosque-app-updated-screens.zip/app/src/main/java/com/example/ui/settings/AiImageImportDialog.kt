package com.example.ui.settings

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.example.model.MosqueSchedule
import com.example.ui.theme.*
import com.example.util.AiExtractionResult
import com.example.util.AiScheduleImageParser
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun AiImageImportDialog(
    currentSchedule: MosqueSchedule,
    onDismiss: () -> Unit,
    onSuccess: (AiExtractionResult) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val selectedUris = remember { mutableStateListOf<Uri>() }
    var isProcessing by remember { mutableStateOf(false) }
    var progressStatus by remember { mutableStateOf("") }
    var tempCameraUri by remember { mutableStateOf<Uri?>(null) }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        if (success) {
            val uri = tempCameraUri
            if (uri != null) {
                val check = AiScheduleImageParser.checkImageQuality(context, uri)
                if (!check.isAcceptable) {
                    Toast.makeText(context, check.warningMessage ?: "جودة الصورة منخفضة", Toast.LENGTH_LONG).show()
                }
                selectedUris.add(uri)
            }
        }
        tempCameraUri = null
    }

    fun startCameraCapture() {
        try {
            val cacheFile = File(context.cacheDir, "camera_schedule_${System.currentTimeMillis()}.jpg")
            val authority = "${context.packageName}.fileprovider"
            val uri = FileProvider.getUriForFile(context, authority, cacheFile)
            tempCameraUri = uri
            cameraLauncher.launch(uri)
        } catch (e: Exception) {
            Toast.makeText(context, "خطأ الكاميرا: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            startCameraCapture()
        } else {
            Toast.makeText(context, "تم رفض إذن الكاميرا", Toast.LENGTH_SHORT).show()
        }
    }

    fun onCaptureClicked() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCameraCapture()
        } else {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris ->
        if (uris.isNotEmpty()) {
            var hadQualityIssue = false
            for (u in uris) {
                val check = AiScheduleImageParser.checkImageQuality(context, u)
                if (!check.isAcceptable) {
                    hadQualityIssue = true
                }
                selectedUris.add(u)
            }
            if (hadQualityIssue) {
                Toast.makeText(context, "بعض الصور منخفضة الدقة، يفضل استخدام صور عالية الوضوح.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Dialog(
        onDismissRequest = { if (!isProcessing) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MosqueVeryDarkGreen,
            border = BorderStroke(1.5.dp, MosqueGold),
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .wrapContentHeight()
                .padding(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onDismiss,
                        enabled = !isProcessing,
                        modifier = Modifier.testTag("close_ai_import_button")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = MosqueLightGold)
                    }

                    Text(
                        text = "استيراد الجدول بالذكاء الاصطناعي",
                        color = MosqueGold,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = MosqueGold,
                        modifier = Modifier.size(24.dp)
                    )
                }

                HorizontalDivider(color = MosqueGold.copy(alpha = 0.3f))

                Text(
                    text = "التقط صوراً لجدول المواقيت المطبوع (أو اختر صوراً من المعرض) لتحويلها بدقة إلى جدول سنوي رقمي.",
                    color = MosqueIvory,
                    fontSize = 12.5.sp,
                    lineHeight = 18.sp,
                    textAlign = TextAlign.Center
                )

                if (isProcessing) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CircularProgressIndicator(color = MosqueGold)
                        Text(
                            text = progressStatus,
                            color = MosqueGold,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "يرجى الانتظار، جاري معالجة الصور واستخراج المواقيت بدقة...",
                            color = MosqueLightGold.copy(alpha = 0.8f),
                            fontSize = 11.5.sp
                        )
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { onCaptureClicked() },
                            colors = ButtonDefaults.buttonColors(containerColor = MosqueDeepGreen),
                            border = BorderStroke(1.2.dp, MosqueGold),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("camera_capture_button"),
                            contentPadding = PaddingValues(vertical = 12.dp)
                        ) {
                            Icon(Icons.Default.CameraAlt, contentDescription = null, tint = MosqueGold, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تصوير بالكاميرا", color = MosqueLightGold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }

                        Button(
                            onClick = {
                                galleryLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MosqueDeepGreen),
                            border = BorderStroke(1.2.dp, MosqueGold),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("gallery_pick_button"),
                            contentPadding = PaddingValues(vertical = 12.dp)
                        ) {
                            Icon(Icons.Default.PhotoLibrary, contentDescription = null, tint = MosqueGold, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("اختيار من المعرض", color = MosqueLightGold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }

                    if (selectedUris.isNotEmpty()) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MosqueDarkGreen, RoundedCornerShape(10.dp))
                                .padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "الصور المختارة (${selectedUris.size}):",
                                    color = MosqueGold,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                TextButton(
                                    onClick = { selectedUris.clear() }
                                ) {
                                    Text("مسح الكل", color = Color(0xFFFF8A80), fontSize = 11.sp)
                                }
                            }

                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                itemsIndexed(selectedUris) { index, uri ->
                                    Box(
                                        modifier = Modifier
                                            .size(72.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .border(1.dp, MosqueGold, RoundedCornerShape(8.dp))
                                    ) {
                                        AsyncImage(
                                            model = uri,
                                            contentDescription = "صورة $index",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                        IconButton(
                                            onClick = { selectedUris.removeAt(index) },
                                            modifier = Modifier
                                                .align(Alignment.TopEnd)
                                                .size(22.dp)
                                                .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                                        ) {
                                            Icon(Icons.Default.Close, contentDescription = "حذف", tint = Color.White, modifier = Modifier.size(14.dp))
                                        }
                                        Text(
                                            text = "${index + 1}",
                                            color = MosqueWhite,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier
                                                .align(Alignment.BottomStart)
                                                .background(MosqueVeryDarkGreen.copy(alpha = 0.8f))
                                                .padding(horizontal = 4.dp)
                                        )
                                    }
                                }
                            }
                        }

                        Button(
                            onClick = {
                                isProcessing = true
                                progressStatus = "بدء التحليل..."
                                coroutineScope.launch {
                                    val result = AiScheduleImageParser.parseScheduleImages(
                                        context = context,
                                        imageUris = selectedUris.toList(),
                                        currentSchedule = currentSchedule,
                                        onProgress = { _, _, msg ->
                                            progressStatus = msg
                                        }
                                    )
                                    isProcessing = false
                                    if (result.isSuccess) {
                                        val extraction = result.getOrThrow()
                                        onSuccess(extraction)
                                    } else {
                                        val err = result.exceptionOrNull()?.message ?: "حدث خطأ أثناء معالجة الصور."
                                        Toast.makeText(context, err, Toast.LENGTH_LONG).show()
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MosqueGold),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("start_ai_analysis_button"),
                            contentPadding = PaddingValues(vertical = 12.dp)
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MosqueVeryDarkGreen)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "بدء التحليل بالذكاء الاصطناعي (${selectedUris.size} صور)",
                                color = MosqueVeryDarkGreen,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
