package com.example.ui.abbasi

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill

/**
 * Procedural vector rendering of Islamic architectural silhouettes (grand domes,
 * towering minarets, crescent spires, and arch colonnades).
 * Drawn in translucent sky blue to give atmospheric depth to the background.
 */
@Composable
fun AbbasiMosqueSilhouette(
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val color = AbbasiThemeColors.SilhouetteBlue.copy(alpha = AbbasiThemeColors.SilhouetteAlpha)

        // 1. Central Grand Dome (around w * 0.45 to w * 0.65)
        val domeCenterX = w * 0.52f
        val domeBaseY = h * 0.90f
        val domeRadiusX = w * 0.16f
        val domeHeight = h * 0.42f

        val domePath = Path().apply {
            moveTo(domeCenterX - domeRadiusX, domeBaseY)
            // Left curve of the pointed Islamic dome
            cubicTo(
                domeCenterX - domeRadiusX, domeBaseY - domeHeight * 0.55f,
                domeCenterX - domeRadiusX * 0.35f, domeBaseY - domeHeight * 0.90f,
                domeCenterX, domeBaseY - domeHeight
            )
            // Right curve of the pointed Islamic dome
            cubicTo(
                domeCenterX + domeRadiusX * 0.35f, domeBaseY - domeHeight * 0.90f,
                domeCenterX + domeRadiusX, domeBaseY - domeHeight * 0.55f,
                domeCenterX + domeRadiusX, domeBaseY
            )
            close()
        }
        drawPath(domePath, color)

        // Spire on central dome
        drawLine(
            color = color,
            start = Offset(domeCenterX, domeBaseY - domeHeight),
            end = Offset(domeCenterX, domeBaseY - domeHeight - h * 0.06f),
            strokeWidth = 2.5f
        )
        // Small crescent on spire
        drawCircle(
            color = color,
            radius = h * 0.012f,
            center = Offset(domeCenterX, domeBaseY - domeHeight - h * 0.06f)
        )

        // 2. Secondary Dome (to the right, w * 0.68)
        val dome2X = w * 0.68f
        val dome2Radius = w * 0.09f
        val dome2Height = h * 0.28f
        val dome2Path = Path().apply {
            moveTo(dome2X - dome2Radius, domeBaseY)
            cubicTo(
                dome2X - dome2Radius, domeBaseY - dome2Height * 0.50f,
                dome2X - dome2Radius * 0.30f, domeBaseY - dome2Height * 0.88f,
                dome2X, domeBaseY - dome2Height
            )
            cubicTo(
                dome2X + dome2Radius * 0.30f, domeBaseY - dome2Height * 0.88f,
                dome2X + dome2Radius, domeBaseY - dome2Height * 0.50f,
                dome2X + dome2Radius, domeBaseY
            )
            close()
        }
        drawPath(dome2Path, color.copy(alpha = color.alpha * 0.85f))

        // 3. Left Minaret (around w * 0.18)
        val minaretLeftX = w * 0.19f
        val minaretWidth = w * 0.024f
        val minaretTopY = h * 0.24f

        val minaretLeftPath = Path().apply {
            moveTo(minaretLeftX - minaretWidth / 2f, domeBaseY)
            lineTo(minaretLeftX - minaretWidth / 2f, minaretTopY + h * 0.10f)
            // Balcony 1
            lineTo(minaretLeftX - minaretWidth * 0.85f, minaretTopY + h * 0.10f)
            lineTo(minaretLeftX - minaretWidth * 0.85f, minaretTopY + h * 0.08f)
            lineTo(minaretLeftX - minaretWidth / 2f, minaretTopY + h * 0.08f)
            lineTo(minaretLeftX - minaretWidth / 2f, minaretTopY + h * 0.03f)
            // Balcony 2
            lineTo(minaretLeftX - minaretWidth * 0.75f, minaretTopY + h * 0.03f)
            lineTo(minaretLeftX - minaretWidth * 0.75f, minaretTopY + h * 0.015f)
            lineTo(minaretLeftX - minaretWidth / 2f, minaretTopY + h * 0.015f)
            // Conical Cap
            lineTo(minaretLeftX, minaretTopY - h * 0.04f)
            lineTo(minaretLeftX + minaretWidth / 2f, minaretTopY + h * 0.015f)
            // Right side of balconies
            lineTo(minaretLeftX + minaretWidth * 0.75f, minaretTopY + h * 0.015f)
            lineTo(minaretLeftX + minaretWidth * 0.75f, minaretTopY + h * 0.03f)
            lineTo(minaretLeftX + minaretWidth / 2f, minaretTopY + h * 0.03f)
            lineTo(minaretLeftX + minaretWidth / 2f, minaretTopY + h * 0.08f)
            lineTo(minaretLeftX + minaretWidth * 0.85f, minaretTopY + h * 0.08f)
            lineTo(minaretLeftX + minaretWidth * 0.85f, minaretTopY + h * 0.10f)
            lineTo(minaretLeftX + minaretWidth / 2f, minaretTopY + h * 0.10f)
            lineTo(minaretLeftX + minaretWidth / 2f, domeBaseY)
            close()
        }
        drawPath(minaretLeftPath, color)

        // Left Minaret Crescent Spire
        drawLine(
            color = color,
            start = Offset(minaretLeftX, minaretTopY - h * 0.04f),
            end = Offset(minaretLeftX, minaretTopY - h * 0.09f),
            strokeWidth = 2f
        )
        drawCircle(
            color = color,
            radius = h * 0.010f,
            center = Offset(minaretLeftX, minaretTopY - h * 0.09f)
        )

        // 4. Far Left Tall Minaret (around w * 0.35)
        val minaret2X = w * 0.36f
        val minaret2Width = w * 0.020f
        val minaret2TopY = h * 0.30f

        val minaret2Path = Path().apply {
            moveTo(minaret2X - minaret2Width / 2f, domeBaseY)
            lineTo(minaret2X - minaret2Width / 2f, minaret2TopY)
            lineTo(minaret2X, minaret2TopY - h * 0.035f)
            lineTo(minaret2X + minaret2Width / 2f, minaret2TopY)
            lineTo(minaret2X + minaret2Width / 2f, domeBaseY)
            close()
        }
        drawPath(minaret2Path, color.copy(alpha = color.alpha * 0.75f))

        // 5. Right Minaret (around w * 0.86)
        val minaretRightX = w * 0.85f
        val minaretRightWidth = w * 0.022f
        val minaretRightTopY = h * 0.28f

        val minaretRightPath = Path().apply {
            moveTo(minaretRightX - minaretRightWidth / 2f, domeBaseY)
            lineTo(minaretRightX - minaretRightWidth / 2f, minaretRightTopY + h * 0.08f)
            // Balcony
            lineTo(minaretRightX - minaretRightWidth * 0.8f, minaretRightTopY + h * 0.08f)
            lineTo(minaretRightX - minaretRightWidth * 0.8f, minaretRightTopY + h * 0.065f)
            lineTo(minaretRightX - minaretRightWidth / 2f, minaretRightTopY + h * 0.065f)
            lineTo(minaretRightX - minaretRightWidth / 2f, minaretRightTopY)
            // Cap
            lineTo(minaretRightX, minaretRightTopY - h * 0.04f)
            lineTo(minaretRightX + minaretRightWidth / 2f, minaretRightTopY)
            lineTo(minaretRightX + minaretRightWidth / 2f, minaretRightTopY + h * 0.065f)
            lineTo(minaretRightX + minaretRightWidth * 0.8f, minaretRightTopY + h * 0.065f)
            lineTo(minaretRightX + minaretRightWidth * 0.8f, minaretRightTopY + h * 0.08f)
            lineTo(minaretRightX + minaretRightWidth / 2f, minaretRightTopY + h * 0.08f)
            lineTo(minaretRightX + minaretRightWidth / 2f, domeBaseY)
            close()
        }
        drawPath(minaretRightPath, color)
    }
}
