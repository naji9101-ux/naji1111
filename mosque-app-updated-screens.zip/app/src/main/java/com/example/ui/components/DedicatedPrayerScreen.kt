package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.model.PrayerState
import com.example.ui.theme.*

@Composable
fun DedicatedPrayerScreen(
    prayerName: String,
    imageUri: String?,
    mosqueName: String,
    currentTime: String,
    iqamaCountdown: String,
    prayerState: PrayerState,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MosqueVeryDarkGreen)
    ) {
        if (!imageUri.isNullOrEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = imageUri,
                    contentDescription = "شاشة صلاة $prayerName",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Black.copy(alpha = 0.65f),
                                Color.Black.copy(alpha = 0.45f),
                                Color.Black.copy(alpha = 0.80f)
                            )
                        )
                    )
            )
        } else {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.bg_mosque_pattern),
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxSize()
                        .alpha(0.35f)
                )
            }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                MosqueDarkGreen.copy(alpha = 0.75f),
                                MosqueVeryDarkGreen.copy(alpha = 0.95f)
                            )
                        )
                    )
            )
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = Color.Black.copy(alpha = 0.6f)),
                border = androidx.compose.foundation.BorderStroke(1.dp, MosqueGold.copy(alpha = 0.6f)),
                shape = RoundedCornerShape(20.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = MosqueGold, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("إغلاق الشاشة", color = MosqueLightGold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }

            Surface(
                color = Color.Black.copy(alpha = 0.5f),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MosqueGold.copy(alpha = 0.4f)),
                modifier = Modifier.padding(end = 8.dp)
            ) {
                Text(
                    text = mosqueName,
                    color = MosqueGold,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                )
            }
        }

        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val isLandscape = maxWidth > maxHeight

            if (isLandscape) {
                // Landscape Layout: Two-column / balanced horizontal distribution
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 24.dp, vertical = 60.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Left Column (Mosque logo + Prayer Name)
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_mosque_logo),
                            contentDescription = null,
                            modifier = Modifier
                                .size(70.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color.Black.copy(alpha = 0.4f))
                                .border(1.5.dp, MosqueGold, RoundedCornerShape(16.dp))
                                .padding(10.dp)
                        )

                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MosqueDarkGreen.copy(alpha = 0.85f),
                            border = androidx.compose.foundation.BorderStroke(1.5.dp, MosqueGold),
                            modifier = Modifier.padding(horizontal = 8.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 24.dp, vertical = 10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "الصلاة الحالية",
                                    color = MosqueLightGold,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = prayerName,
                                    color = MosqueGold,
                                    fontSize = 32.sp,
                                    fontWeight = FontWeight.Black,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }

                    // Right Column (Time Clock + Iqama Banner/Countdown)
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = Color.Black.copy(alpha = 0.65f),
                            border = androidx.compose.foundation.BorderStroke(1.2.dp, MosqueGold.copy(alpha = 0.5f)),
                            modifier = Modifier
                                .padding(horizontal = 8.dp)
                                .widthIn(min = 200.dp, max = 340.dp)
                                .height(60.dp)
                        ) {
                            AutoSizedClockText(
                                text = currentTime.trim(),
                                targetFontSizeSp = 40f,
                                color = MosqueWhite,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.SansSerif,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 16.dp, vertical = 4.dp)
                            )
                        }

                        if (prayerState == PrayerState.IQAMA || prayerState == PrayerState.FRIDAY_IQAMA) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color(0xFFC62828).copy(alpha = 0.9f),
                                border = androidx.compose.foundation.BorderStroke(1.5.dp, MosqueGold)
                            ) {
                                Text(
                                    text = "حان موعد الإقامة .. استووا",
                                    color = MosqueWhite,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp)
                                )
                            }
                        } else if (iqamaCountdown.isNotEmpty() && iqamaCountdown != "--:--") {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MosqueDeepGreen.copy(alpha = 0.85f),
                                border = androidx.compose.foundation.BorderStroke(1.dp, MosqueGold.copy(alpha = 0.5f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = "باقي على الإقامة:",
                                        color = MosqueLightGold,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = iqamaCountdown,
                                        color = MosqueGold,
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.SansSerif
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                // Portrait Layout: Centered vertical distribution
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 20.dp, vertical = 70.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_mosque_logo),
                        contentDescription = null,
                        modifier = Modifier
                            .size(90.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(Color.Black.copy(alpha = 0.4f))
                            .border(1.5.dp, MosqueGold, RoundedCornerShape(18.dp))
                            .padding(12.dp)
                    )
                    Spacer(modifier = Modifier.height(18.dp))

                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MosqueDarkGreen.copy(alpha = 0.85f),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, MosqueGold),
                        modifier = Modifier.padding(horizontal = 16.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 28.dp, vertical = 14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "الصلاة الحالية",
                                color = MosqueLightGold,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = prayerName,
                                color = MosqueGold,
                                fontSize = 36.sp,
                                fontWeight = FontWeight.Black,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color.Black.copy(alpha = 0.65f),
                        border = androidx.compose.foundation.BorderStroke(1.2.dp, MosqueGold.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .padding(horizontal = 16.dp)
                            .widthIn(min = 180.dp, max = 360.dp)
                            .height(64.dp)
                    ) {
                        AutoSizedClockText(
                            text = currentTime.trim(),
                            targetFontSizeSp = 42f,
                            color = MosqueWhite,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.SansSerif,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 16.dp, vertical = 6.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    if (prayerState == PrayerState.IQAMA || prayerState == PrayerState.FRIDAY_IQAMA) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFFC62828).copy(alpha = 0.9f),
                            border = androidx.compose.foundation.BorderStroke(1.5.dp, MosqueGold)
                        ) {
                            Text(
                                text = "حان موعد الإقامة .. استووا",
                                color = MosqueWhite,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)
                            )
                        }
                    } else if (iqamaCountdown.isNotEmpty() && iqamaCountdown != "--:--") {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MosqueDeepGreen.copy(alpha = 0.85f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MosqueGold.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "باقي على الإقامة:",
                                    color = MosqueLightGold,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = iqamaCountdown,
                                    color = MosqueGold,
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.SansSerif
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
