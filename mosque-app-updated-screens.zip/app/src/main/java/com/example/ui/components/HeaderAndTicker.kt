package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.model.AppSettings
import com.example.ui.theme.*

@Composable
fun MosqueHeader(
    settings: AppSettings,
    onSettingsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(44.dp)
            .padding(horizontal = 12.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Mosque Logo & Mosque Name
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .clickable { onSettingsClick() }
                .padding(horizontal = 4.dp, vertical = 2.dp)
        ) {
            if (settings.showLogo) {
                Box(
                    modifier = Modifier
                        .size((34 * settings.logoScale).dp)
                        .clip(CircleShape)
                        .border(1.2.dp, MosqueGold, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    if (!settings.customLogoUri.isNullOrEmpty()) {
                        AsyncImage(
                            model = settings.customLogoUri,
                            contentDescription = "Mosque Logo",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Image(
                            painter = painterResource(id = R.drawable.ic_mosque_logo),
                            contentDescription = "Mosque Emblem",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize(0.85f)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(8.dp))
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = settings.mosqueName,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MosqueLightGold
                )
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = "تعديل",
                    tint = MosqueGold.copy(alpha = 0.7f),
                    modifier = Modifier.size(13.dp)
                )
            }
        }

        // Center: App Title
        if (settings.showTitle) {
            Text(
                text = settings.titleText,
                fontSize = (settings.titleSizeSp - 2).coerceAtLeast(16).sp,
                fontWeight = FontWeight.ExtraBold,
                color = MosqueWhite,
                textAlign = TextAlign.Center
            )
        }

        // Settings Button
        IconButton(
            onClick = onSettingsClick,
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(MosqueDarkGreen.copy(alpha = 0.8f))
                .border(1.dp, MosqueGold.copy(alpha = 0.6f), CircleShape)
        ) {
            Icon(
                imageVector = Icons.Default.Settings,
                contentDescription = "الإعدادات",
                tint = MosqueLightGold,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
fun MosqueTickerBar(
    currentMessage: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(30.dp)
            .background(
                Brush.horizontalGradient(
                    listOf(
                        MosqueDeepGreen,
                        MosqueDarkGreen,
                        MosqueDeepGreen
                    )
                )
            )
            .border(width = 1.dp, color = MosqueGold.copy(alpha = 0.45f))
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        AnimatedContent(
            targetState = currentMessage,
            transitionSpec = {
                fadeIn() togetherWith fadeOut()
            },
            label = "tickerTransition"
        ) { message ->
            Text(
                text = message,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = MosqueLightGold,
                textAlign = TextAlign.Center,
                maxLines = 1
            )
        }
    }
}
