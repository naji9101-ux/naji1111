package com.example.ui.components

import android.annotation.SuppressLint
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.annotation.Keep
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.viewinterop.AndroidView
import org.json.JSONObject

/** Displays a bundled design. All data, timers and actions remain owned by Compose. */
@SuppressLint("SetJavaScriptEnabled")
@Composable
internal fun HtmlDesignScreen(
    assetName: String,
    state: JSONObject,
    onAction: (String) -> Unit,
    modifier: Modifier = Modifier,
    screenTag: String
) {
    val stateJson = state.toString()
    AndroidView(
        modifier = modifier.fillMaxSize().testTag(screenTag),
        factory = { context ->
            MosqueDesignWebView(context).apply {
                setBackgroundColor(android.graphics.Color.rgb(3, 21, 43))
                isHorizontalScrollBarEnabled = false
                isVerticalScrollBarEnabled = false
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = false
                    allowFileAccess = false
                    allowContentAccess = false
                    blockNetworkLoads = true
                    javaScriptCanOpenWindowsAutomatically = false
                    setSupportMultipleWindows(false)
                    setSupportZoom(false)
                    textZoom = 100
                }
                actionHandler = onAction
                renderState = stateJson
                addJavascriptInterface(MosqueDesignActions(this), "MosqueActions")
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = true

                    @Suppress("DEPRECATION")
                    override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean = true

                    override fun onPageFinished(view: WebView, url: String) {
                        pageReady = true
                        render()
                    }
                }
                loadUrl("file:///android_asset/screens/$assetName")
            }
        },
        update = { view ->
            // Update the existing page, without restarting layout, animations or countdowns.
            view.actionHandler = onAction
            if (view.renderState != stateJson) {
                view.renderState = stateJson
                view.render()
            }
        },
        onRelease = { view ->
            view.actionHandler = {}
            view.stopLoading()
            view.removeJavascriptInterface("MosqueActions")
            view.destroy()
        }
    )
}

private class MosqueDesignWebView(context: android.content.Context) : WebView(context) {
    var actionHandler: (String) -> Unit = {}
    var renderState: String = "{}"
    var pageReady: Boolean = false

    fun render() {
        if (pageReady) {
            evaluateJavascript("window.renderMosqueState(JSON.parse(${JSONObject.quote(renderState)}));", null)
        }
    }
}

@Keep
private class MosqueDesignActions(private val view: MosqueDesignWebView) {
    @JavascriptInterface
    fun perform(action: String) {
        // JavascriptInterface calls arrive on a WebView worker thread.
        view.post { view.actionHandler(action) }
    }
}
