package com.example.ui.settings

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DayPrayers
import com.example.model.MonthPrayers
import com.example.model.MosqueSchedule
import com.example.ui.theme.*
import com.example.util.TimeAutoCorrectionHelper
import com.example.util.TimeParseResult
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.YearMonth

val ARABIC_MONTH_NAMES = listOf(
    "",
    "1 - كانون الثاني (يناير)",
    "2 - شباط (فبراير)",
    "3 - آذار (مارس)",
    "4 - نيسان (أبريل)",
    "5 - أيار (مايو)",
    "6 - حزيران (يونيو)",
    "7 - تموز (يوليو)",
    "8 - آب (أغسطس)",
    "9 - أيلول (سبتمبر)",
    "10 - تشرين الأول (أكتوبر)",
    "11 - تشرين الثاني (نوفمبر)",
    "12 - كانون الأول (ديسمبر)"
)

@Composable
fun AnnualScheduleTableSection(
    workingSchedule: MosqueSchedule,
    onScheduleChange: (MosqueSchedule) -> Unit,
    monthIndex: Int,
    onMonthIndexChange: (Int) -> Unit,
    onCancel: () -> Unit,
    onNext: () -> Unit,
    onDone: () -> Unit,
    modifier: Modifier = Modifier,
    reviewTitle: String? = null,
    uncertainCells: Set<String> = emptySet(),
    onClearUncertainCell: ((String) -> Unit)? = null,
    onEditingChanged: ((Boolean) -> Unit)? = null
) {
    val context = LocalContext.current
    val today = remember { LocalDate.now() }
    val keyboardController = LocalSoftwareKeyboardController.current
    val lazyListState = rememberLazyListState()

    // Calculate actual keyboard height and density
    val density = LocalDensity.current
    val imeInsets = WindowInsets.ime
    val imeHeightPx = imeInsets.getBottom(density)
    val imeHeightDp = with(density) { imeHeightPx.toDp() }

    // Active in-cell editing states
    var activeCellKey by remember { mutableStateOf<String?>(null) }
    var activeCellText by remember { mutableStateOf(TextFieldValue("")) }
    var activeCellOriginalValue by remember { mutableStateOf("") }
    var activeCellTarget by remember { mutableStateOf<AnnualCellEditTarget?>(null) }
    var validationAlert by remember { mutableStateOf<String?>(null) }

    val isEditing = activeCellKey != null

    // Scroll state memory to smoothly return the table to its previous natural position
    var savedFirstVisibleIndex by remember { mutableIntStateOf(0) }
    var savedScrollOffset by remember { mutableIntStateOf(0) }
    var wasEditing by remember { mutableStateOf(false) }

    var showMonthInputDialog by remember { mutableStateOf(false) }

    val daysInCurrentMonth = remember(monthIndex, today.year) {
        try {
            YearMonth.of(today.year, monthIndex).lengthOfMonth()
        } catch (e: Exception) {
            30
        }
    }

    val currentMonthData = workingSchedule.months.find { it.month == monthIndex }
    val daysList = remember(workingSchedule, monthIndex, daysInCurrentMonth) {
        getOrPopulateMonthDays(currentMonthData, monthIndex, daysInCurrentMonth)
    }

    // Function to commit and validate current active cell edit
    fun commitCurrentEditingCell() {
        val target = activeCellTarget ?: return
        val currentText = activeCellText.text.trim()

        if (currentText.isEmpty() || currentText == activeCellOriginalValue.trim()) {
            activeCellKey = null
            activeCellTarget = null
            return
        }

        when (val result = TimeAutoCorrectionHelper.parseAndCorrect(currentText)) {
            is TimeParseResult.Success -> {
                val updatedSchedule = updateSchedulePrayerTime(
                    currentSchedule = workingSchedule,
                    monthNum = monthIndex,
                    dayNum = target.day,
                    prayerField = target.prayerField,
                    newTime = result.formattedTime
                )
                onScheduleChange(updatedSchedule)
                onClearUncertainCell?.invoke("${monthIndex}_${target.day}_${target.prayerField}")
                activeCellKey = null
                activeCellTarget = null
                validationAlert = null
            }
            is TimeParseResult.Error -> {
                val errorMsg = "تنبيه: الوقت المدخل ($currentText) غير صالح (${result.reason}). تم الإبقاء على الوقت الأصلي ($activeCellOriginalValue)."
                validationAlert = errorMsg
                Toast.makeText(context, errorMsg, Toast.LENGTH_LONG).show()
                // Revert to original value without losing it
                activeCellKey = null
                activeCellTarget = null
            }
        }
    }

    // Function to initiate cell editing and record position
    fun startEditingCell(key: String, dayNum: Int, prayerNameAr: String, prayerField: String, time: String) {
        if (activeCellKey == null) {
            savedFirstVisibleIndex = lazyListState.firstVisibleItemIndex
            savedScrollOffset = lazyListState.firstVisibleItemScrollOffset
        } else {
            commitCurrentEditingCell()
        }
        activeCellKey = key
        activeCellOriginalValue = time
        activeCellTarget = AnnualCellEditTarget(dayNum, prayerNameAr, prayerField, time)
        activeCellText = TextFieldValue(time, TextRange(0, time.length))
    }

    // Automatically elevate and scroll the selected row to the top when cell is activated
    // Stage 1: Immediate scrollToItem so layout anchors on the row
    // Stage 2 & 3: Follow-up animateScrollToItem as keyboard expands and finishes opening
    LaunchedEffect(activeCellKey) {
        val key = activeCellKey
        if (key != null) {
            wasEditing = true
            onEditingChanged?.invoke(true)
            val parts = key.split("_")
            val dayNum = parts.getOrNull(1)?.toIntOrNull()
            if (dayNum != null) {
                val targetIndex = daysList.indexOfFirst { it.day == dayNum }
                if (targetIndex >= 0) {
                    lazyListState.scrollToItem(index = targetIndex, scrollOffset = 0)
                    delay(120)
                    lazyListState.animateScrollToItem(index = targetIndex, scrollOffset = 0)
                    delay(180)
                    lazyListState.animateScrollToItem(index = targetIndex, scrollOffset = 0)
                }
            }
        } else {
            onEditingChanged?.invoke(false)
            if (wasEditing) {
                wasEditing = false
                delay(60)
                try {
                    lazyListState.animateScrollToItem(
                        index = savedFirstVisibleIndex.coerceIn(0, maxOf(0, daysList.size - 1)),
                        scrollOffset = savedScrollOffset
                    )
                } catch (e: Exception) {
                    // Ignore cancellation
                }
            }
        }
    }

    // Keep active row pinned at top when keyboard height updates
    LaunchedEffect(imeHeightPx > 0) {
        if (imeHeightPx > 0 && isEditing) {
            val key = activeCellKey ?: return@LaunchedEffect
            val parts = key.split("_")
            val dayNum = parts.getOrNull(1)?.toIntOrNull() ?: return@LaunchedEffect
            val targetIndex = daysList.indexOfFirst { it.day == dayNum }
            if (targetIndex >= 0) {
                lazyListState.animateScrollToItem(index = targetIndex, scrollOffset = 0)
            }
        }
    }

    // Generous bottom padding during editing so that even Day 31 has ample scroll space
    val targetBottomPadding = if (isEditing) {
        maxOf(imeHeightDp + 260.dp, 450.dp)
    } else {
        16.dp
    }
    val animatedBottomPadding by animateDpAsState(
        targetValue = targetBottomPadding,
        animationSpec = tween(durationMillis = if (isEditing) 100 else 280),
        label = "tableBottomPadding"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 4.dp, vertical = 2.dp)
    ) {
        // Review Header (hidden during cell editing to maximize visible space)
        if (reviewTitle != null && !isEditing) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MosqueDeepGreen),
                border = BorderStroke(1.2.dp, MosqueGold),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp)
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MosqueGold, modifier = Modifier.size(22.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = reviewTitle,
                            color = MosqueGold,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.5.sp
                        )
                        Text(
                            text = "يمكنك تعديل أي وقت صلاة مباشرة داخل الخلية نفسها وكتابة التوقيت الجديد.",
                            color = MosqueIvory,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        }

        // Validation Warning Banner if user entered an invalid time
        validationAlert?.let { alertText ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF4A180E)),
                border = BorderStroke(1.2.dp, Color(0xFFFF5252)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFFF5252), modifier = Modifier.size(18.dp))
                    Text(
                        text = alertText,
                        color = Color(0xFFFFCDD2),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = { validationAlert = null },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = Color(0xFFFFCDD2), modifier = Modifier.size(14.dp))
                    }
                }
            }
        }

        // Month Header: Full selector when not editing, compact status bar when editing
        if (!isEditing) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MosqueDarkGreen),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, MosqueGold.copy(alpha = 0.7f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            FilledIconButton(
                                onClick = {
                                    commitCurrentEditingCell()
                                    if (monthIndex > 1) {
                                        onMonthIndexChange(monthIndex - 1)
                                    }
                                },
                                enabled = monthIndex > 1,
                                colors = IconButtonDefaults.filledIconButtonColors(
                                    containerColor = MosqueDeepGreen,
                                    contentColor = MosqueGold,
                                    disabledContainerColor = MosqueVeryDarkGreen.copy(alpha = 0.5f),
                                    disabledContentColor = MosqueGold.copy(alpha = 0.3f)
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .size(44.dp)
                                    .border(1.dp, MosqueGold.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                            ) {
                                Icon(Icons.Default.Remove, contentDescription = "الشهر السابق")
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MosqueVeryDarkGreen,
                                border = BorderStroke(1.2.dp, MosqueGold),
                                modifier = Modifier
                                    .height(44.dp)
                                    .widthIn(min = 54.dp)
                                    .clickable {
                                        commitCurrentEditingCell()
                                        showMonthInputDialog = true
                                    }
                            ) {
                                Box(
                                    modifier = Modifier
                                        .padding(horizontal = 12.dp, vertical = 4.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "$monthIndex",
                                        color = MosqueGold,
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.SansSerif
                                    )
                                }
                            }

                            FilledIconButton(
                                onClick = {
                                    commitCurrentEditingCell()
                                    if (monthIndex < 12) {
                                        onMonthIndexChange(monthIndex + 1)
                                    }
                                },
                                enabled = monthIndex < 12,
                                colors = IconButtonDefaults.filledIconButtonColors(
                                    containerColor = MosqueDeepGreen,
                                    contentColor = MosqueGold,
                                    disabledContainerColor = MosqueVeryDarkGreen.copy(alpha = 0.5f),
                                    disabledContentColor = MosqueGold.copy(alpha = 0.3f)
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .size(44.dp)
                                    .border(1.dp, MosqueGold.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                            ) {
                                Icon(Icons.Default.Add, contentDescription = "الشهر التالي")
                            }
                        }

                        Column(
                            horizontalAlignment = Alignment.End,
                            modifier = Modifier.clickable {
                                commitCurrentEditingCell()
                                showMonthInputDialog = true
                            }
                        ) {
                            Text(
                                text = ARABIC_MONTH_NAMES.getOrElse(monthIndex) { "شهر $monthIndex" },
                                color = MosqueWhite,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "انقر لتغيير الشهر (1-12)",
                                color = MosqueLightGold.copy(alpha = 0.85f),
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        } else {
            // Compact Month Header during editing: saves vertical space, displays active day & prayer name, and has a direct Done button
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MosqueDarkGreen,
                border = BorderStroke(1.dp, MosqueGold.copy(alpha = 0.7f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(32.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val target = activeCellTarget
                    val cellInfo = if (target != null) {
                        "تعديل وقت ${target.prayerName} - اليوم ${target.day} (شهر $monthIndex)"
                    } else {
                        "شهر $monthIndex - ${ARABIC_MONTH_NAMES.getOrElse(monthIndex) { "" }}"
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = null,
                            tint = MosqueGold,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = cellInfo,
                            color = MosqueGold,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MosqueGold,
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .clickable {
                                commitCurrentEditingCell()
                                keyboardController?.hide()
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "تم",
                                tint = MosqueVeryDarkGreen,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "تم ✓",
                                color = MosqueVeryDarkGreen,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.5.sp
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Pinned Table Headers: Always visible above the rows so user clearly sees prayer names
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = MosqueDeepGreen,
            border = BorderStroke(1.dp, MosqueGold.copy(alpha = 0.8f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 7.dp, horizontal = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("اليوم", modifier = Modifier.weight(0.85f), textAlign = TextAlign.Center, color = MosqueGold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text("الفجر", modifier = Modifier.weight(1.15f), textAlign = TextAlign.Center, color = MosqueGold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text("الشروق", modifier = Modifier.weight(1.15f), textAlign = TextAlign.Center, color = MosqueGold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text("الظهر", modifier = Modifier.weight(1.15f), textAlign = TextAlign.Center, color = MosqueGold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text("العصر", modifier = Modifier.weight(1.15f), textAlign = TextAlign.Center, color = MosqueGold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text("المغرب", modifier = Modifier.weight(1.15f), textAlign = TextAlign.Center, color = MosqueGold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text("العشاء", modifier = Modifier.weight(1.15f), textAlign = TextAlign.Center, color = MosqueGold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(3.dp))

        // Table Rows with Direct In-Cell Editing, High Elevation and Generous Padding
        LazyColumn(
            state = lazyListState,
            contentPadding = PaddingValues(bottom = animatedBottomPadding),
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .imePadding(),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            itemsIndexed(daysList, key = { _, item -> item.day }) { _, dayItem ->
                val isToday = (today.monthValue == monthIndex && today.dayOfMonth == dayItem.day)
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (isToday) MosqueDeepGreen.copy(alpha = 0.9f) else MosqueDarkGreen,
                    border = BorderStroke(
                        if (isToday) 1.2.dp else 0.5.dp,
                        if (isToday) MosqueGold else MosqueGold.copy(alpha = 0.35f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp, horizontal = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier.weight(0.85f),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${dayItem.day}",
                                textAlign = TextAlign.Center,
                                color = if (isToday) MosqueGold else MosqueWhite,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                fontFamily = FontFamily.SansSerif
                            )
                        }

                        // Fajr Cell
                        val fajrKey = "${monthIndex}_${dayItem.day}_fajr"
                        InlineEditableTimeCell(
                            time = dayItem.fajrSecond,
                            isEditing = (activeCellKey == fajrKey),
                            hasWarning = uncertainCells.contains(fajrKey),
                            activeText = activeCellText,
                            onTextChange = { newVal ->
                                val clean = TimeAutoCorrectionHelper.normalizeDigits(newVal.text).filter { it.isDigit() || it == ':' }
                                if (clean.length <= 5) {
                                    if (TimeAutoCorrectionHelper.shouldAutoFormatLive(clean)) {
                                        val h = clean.substring(0, 2)
                                        val m = clean.substring(2)
                                        val formatted = "$h:$m"
                                        activeCellText = TextFieldValue(formatted, TextRange(formatted.length))
                                    } else {
                                        activeCellText = newVal.copy(text = clean)
                                    }
                                }
                            },
                            onCellClick = {
                                startEditingCell(fajrKey, dayItem.day, "الفجر", "fajr", dayItem.fajrSecond)
                            },
                            onDone = {
                                commitCurrentEditingCell()
                                keyboardController?.hide()
                            },
                            modifier = Modifier.weight(1.15f)
                        )

                        // Sunrise Cell
                        val sunriseKey = "${monthIndex}_${dayItem.day}_sunrise"
                        InlineEditableTimeCell(
                            time = dayItem.sunrise,
                            isEditing = (activeCellKey == sunriseKey),
                            hasWarning = uncertainCells.contains(sunriseKey),
                            activeText = activeCellText,
                            onTextChange = { newVal ->
                                val clean = TimeAutoCorrectionHelper.normalizeDigits(newVal.text).filter { it.isDigit() || it == ':' }
                                if (clean.length <= 5) {
                                    if (TimeAutoCorrectionHelper.shouldAutoFormatLive(clean)) {
                                        val h = clean.substring(0, 2)
                                        val m = clean.substring(2)
                                        val formatted = "$h:$m"
                                        activeCellText = TextFieldValue(formatted, TextRange(formatted.length))
                                    } else {
                                        activeCellText = newVal.copy(text = clean)
                                    }
                                }
                            },
                            onCellClick = {
                                startEditingCell(sunriseKey, dayItem.day, "الشروق", "sunrise", dayItem.sunrise)
                            },
                            onDone = {
                                commitCurrentEditingCell()
                                keyboardController?.hide()
                            },
                            modifier = Modifier.weight(1.15f)
                        )

                        // Dhuhr Cell
                        val dhuhrKey = "${monthIndex}_${dayItem.day}_dhuhr"
                        InlineEditableTimeCell(
                            time = dayItem.dhuhr,
                            isEditing = (activeCellKey == dhuhrKey),
                            hasWarning = uncertainCells.contains(dhuhrKey),
                            activeText = activeCellText,
                            onTextChange = { newVal ->
                                val clean = TimeAutoCorrectionHelper.normalizeDigits(newVal.text).filter { it.isDigit() || it == ':' }
                                if (clean.length <= 5) {
                                    if (TimeAutoCorrectionHelper.shouldAutoFormatLive(clean)) {
                                        val h = clean.substring(0, 2)
                                        val m = clean.substring(2)
                                        val formatted = "$h:$m"
                                        activeCellText = TextFieldValue(formatted, TextRange(formatted.length))
                                    } else {
                                        activeCellText = newVal.copy(text = clean)
                                    }
                                }
                            },
                            onCellClick = {
                                startEditingCell(dhuhrKey, dayItem.day, "الظهر", "dhuhr", dayItem.dhuhr)
                            },
                            onDone = {
                                commitCurrentEditingCell()
                                keyboardController?.hide()
                            },
                            modifier = Modifier.weight(1.15f)
                        )

                        // Asr Cell
                        val asrKey = "${monthIndex}_${dayItem.day}_asr"
                        InlineEditableTimeCell(
                            time = dayItem.asr,
                            isEditing = (activeCellKey == asrKey),
                            hasWarning = uncertainCells.contains(asrKey),
                            activeText = activeCellText,
                            onTextChange = { newVal ->
                                val clean = TimeAutoCorrectionHelper.normalizeDigits(newVal.text).filter { it.isDigit() || it == ':' }
                                if (clean.length <= 5) {
                                    if (TimeAutoCorrectionHelper.shouldAutoFormatLive(clean)) {
                                        val h = clean.substring(0, 2)
                                        val m = clean.substring(2)
                                        val formatted = "$h:$m"
                                        activeCellText = TextFieldValue(formatted, TextRange(formatted.length))
                                    } else {
                                        activeCellText = newVal.copy(text = clean)
                                    }
                                }
                            },
                            onCellClick = {
                                startEditingCell(asrKey, dayItem.day, "العصر", "asr", dayItem.asr)
                            },
                            onDone = {
                                commitCurrentEditingCell()
                                keyboardController?.hide()
                            },
                            modifier = Modifier.weight(1.15f)
                        )

                        // Maghrib Cell
                        val maghribKey = "${monthIndex}_${dayItem.day}_maghrib"
                        InlineEditableTimeCell(
                            time = dayItem.maghrib,
                            isEditing = (activeCellKey == maghribKey),
                            hasWarning = uncertainCells.contains(maghribKey),
                            activeText = activeCellText,
                            onTextChange = { newVal ->
                                val clean = TimeAutoCorrectionHelper.normalizeDigits(newVal.text).filter { it.isDigit() || it == ':' }
                                if (clean.length <= 5) {
                                    if (TimeAutoCorrectionHelper.shouldAutoFormatLive(clean)) {
                                        val h = clean.substring(0, 2)
                                        val m = clean.substring(2)
                                        val formatted = "$h:$m"
                                        activeCellText = TextFieldValue(formatted, TextRange(formatted.length))
                                    } else {
                                        activeCellText = newVal.copy(text = clean)
                                    }
                                }
                            },
                            onCellClick = {
                                startEditingCell(maghribKey, dayItem.day, "المغرب", "maghrib", dayItem.maghrib)
                            },
                            onDone = {
                                commitCurrentEditingCell()
                                keyboardController?.hide()
                            },
                            modifier = Modifier.weight(1.15f)
                        )

                        // Isha Cell
                        val ishaKey = "${monthIndex}_${dayItem.day}_isha"
                        InlineEditableTimeCell(
                            time = dayItem.isha,
                            isEditing = (activeCellKey == ishaKey),
                            hasWarning = uncertainCells.contains(ishaKey),
                            activeText = activeCellText,
                            onTextChange = { newVal ->
                                val clean = TimeAutoCorrectionHelper.normalizeDigits(newVal.text).filter { it.isDigit() || it == ':' }
                                if (clean.length <= 5) {
                                    if (TimeAutoCorrectionHelper.shouldAutoFormatLive(clean)) {
                                        val h = clean.substring(0, 2)
                                        val m = clean.substring(2)
                                        val formatted = "$h:$m"
                                        activeCellText = TextFieldValue(formatted, TextRange(formatted.length))
                                    } else {
                                        activeCellText = newVal.copy(text = clean)
                                    }
                                }
                            },
                            onCellClick = {
                                startEditingCell(ishaKey, dayItem.day, "العشاء", "isha", dayItem.isha)
                            },
                            onDone = {
                                commitCurrentEditingCell()
                                keyboardController?.hide()
                            },
                            modifier = Modifier.weight(1.15f)
                        )
                    }
                }
            }
        }

        // Action Buttons: Visible when not editing, so they don't crowd the screen when keyboard is open
        AnimatedVisibility(
            visible = !isEditing,
            enter = fadeIn(animationSpec = tween(200)),
            exit = fadeOut(animationSpec = tween(150))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = {
                        commitCurrentEditingCell()
                        onCancel()
                    },
                    border = BorderStroke(1.dp, MosqueGold.copy(alpha = 0.7f)),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MosqueLightGold),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Close, contentDescription = null, tint = MosqueLightGold, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("إلغاء", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        commitCurrentEditingCell()
                        onNext()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MosqueDeepGreen),
                    border = BorderStroke(1.dp, MosqueGold),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = MosqueGold, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (monthIndex < 12) "الشهر التالي" else "الشهر الأول",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MosqueGold
                    )
                }

                Button(
                    onClick = {
                        commitCurrentEditingCell()
                        onDone()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MosqueGold),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    modifier = Modifier.weight(1.3f)
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = MosqueVeryDarkGreen, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("حفظ واعتماد", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MosqueVeryDarkGreen)
                }
            }
        }
    }

    if (showMonthInputDialog) {
        DirectMonthPickerDialog(
            currentMonth = monthIndex,
            onMonthSelected = { newMonth ->
                commitCurrentEditingCell()
                onMonthIndexChange(newMonth)
                showMonthInputDialog = false
            },
            onDismiss = { showMonthInputDialog = false }
        )
    }
}

/**
 * Direct In-Cell Editable Time Cell:
 * When clicked, renders an inline BasicTextField directly inside the cell.
 * Features:
 * - Number keyboard with ImeAction.Done (✓)
 * - Immediate auto-formatting for complete 4 digits
 * - Text selection on click for easy replacement/erasing
 * - Highlighted golden border while editing
 */
@Composable
private fun InlineEditableTimeCell(
    time: String,
    isEditing: Boolean,
    hasWarning: Boolean,
    activeText: TextFieldValue,
    onTextChange: (TextFieldValue) -> Unit,
    onCellClick: () -> Unit,
    onDone: () -> Unit,
    modifier: Modifier = Modifier
) {
    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(isEditing) {
        if (isEditing) {
            focusRequester.requestFocus()
        }
    }

    Box(
        modifier = modifier
            .padding(horizontal = 1.dp, vertical = 1.dp)
            .height(34.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(
                when {
                    isEditing -> MosqueDeepGreen
                    hasWarning -> Color(0xFF4E260A)
                    else -> MosqueVeryDarkGreen
                }
            )
            .border(
                width = if (isEditing) 1.8.dp else if (hasWarning) 1.2.dp else 0.6.dp,
                color = when {
                    isEditing -> MosqueGold
                    hasWarning -> Color(0xFFFFB74D)
                    else -> MosqueGold.copy(alpha = 0.5f)
                },
                shape = RoundedCornerShape(4.dp)
            )
            .clickable(enabled = !isEditing, onClick = onCellClick),
        contentAlignment = Alignment.Center
    ) {
        if (isEditing) {
            BasicTextField(
                value = activeText,
                onValueChange = onTextChange,
                singleLine = true,
                cursorBrush = SolidColor(MosqueGold),
                textStyle = TextStyle(
                    color = MosqueWhite,
                    fontSize = 12.5.sp,
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                ),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Number,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(
                    onDone = { onDone() }
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 2.dp)
                    .focusRequester(focusRequester)
            )
        } else {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                if (hasWarning) {
                    Text(
                        text = "!",
                        fontSize = 9.sp,
                        color = Color(0xFFFFB74D)
                    )
                    Spacer(modifier = Modifier.width(1.5.dp))
                }
                Text(
                    text = time,
                    fontSize = 11.5.sp,
                    color = if (hasWarning) Color(0xFFFFE082) else MosqueLightGold,
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun DirectMonthPickerDialog(
    currentMonth: Int,
    onMonthSelected: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    var monthText by remember { mutableStateOf(currentMonth.toString()) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MosqueVeryDarkGreen,
        shape = RoundedCornerShape(14.dp),
        title = {
            Text(
                text = "الانتقال إلى شهر محدد",
                color = MosqueGold,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "أدخل رقم الشهر من 1 إلى 12:",
                    color = MosqueIvory,
                    fontSize = 13.sp
                )

                OutlinedTextField(
                    value = monthText,
                    onValueChange = { input ->
                        val filtered = input.filter { it.isDigit() }
                        if (filtered.length <= 2) {
                            monthText = filtered
                            val num = filtered.toIntOrNull()
                            errorMessage = if (num != null && (num < 1 || num > 12)) {
                                "يجب أن يكون الشهر بين 1 و 12"
                            } else {
                                null
                            }
                        }
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Number,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            val num = monthText.toIntOrNull()
                            if (num in 1..12) {
                                onMonthSelected(num!!)
                            } else {
                                errorMessage = "يجب أن يكون الشهر بين 1 و 12"
                            }
                        }
                    ),
                    textStyle = LocalTextStyle.current.copy(
                        textAlign = TextAlign.Center,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = MosqueWhite,
                        fontFamily = FontFamily.SansSerif
                    ),
                    trailingIcon = {
                        if (monthText.isNotEmpty()) {
                            IconButton(onClick = { monthText = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "مسح", tint = MosqueGold)
                            }
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = MosqueWhite,
                        unfocusedTextColor = MosqueWhite,
                        focusedBorderColor = MosqueGold,
                        unfocusedBorderColor = MosqueGold.copy(alpha = 0.5f),
                        focusedContainerColor = MosqueDarkGreen,
                        unfocusedContainerColor = MosqueDarkGreen
                    ),
                    modifier = Modifier.width(130.dp)
                )

                val previewNum = monthText.toIntOrNull()
                if (previewNum in 1..12) {
                    Text(
                        text = ARABIC_MONTH_NAMES.getOrElse(previewNum!!) { "" },
                        color = MosqueGold,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }

                if (errorMessage != null) {
                    Text(
                        text = errorMessage ?: "",
                        color = Color(0xFFFF5252),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Text("أو اختر مباشرة:", color = MosqueLightGold, fontSize = 11.sp)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        (1..6).forEach { m ->
                            SuggestionChip(
                                onClick = { onMonthSelected(m) },
                                label = { Text("$m", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                colors = SuggestionChipDefaults.suggestionChipColors(
                                    containerColor = if (previewNum == m) MosqueGold else MosqueDeepGreen,
                                    labelColor = if (previewNum == m) MosqueVeryDarkGreen else MosqueGold
                                )
                            )
                        }
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        (7..12).forEach { m ->
                            SuggestionChip(
                                onClick = { onMonthSelected(m) },
                                label = { Text("$m", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                colors = SuggestionChipDefaults.suggestionChipColors(
                                    containerColor = if (previewNum == m) MosqueGold else MosqueDeepGreen,
                                    labelColor = if (previewNum == m) MosqueVeryDarkGreen else MosqueGold
                                )
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val num = monthText.toIntOrNull()
                    if (num in 1..12) {
                        onMonthSelected(num!!)
                    } else {
                        errorMessage = "يجب أن يكون الشهر بين 1 و 12"
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = MosqueGold),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("انتقال", color = MosqueVeryDarkGreen, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء", color = MosqueLightGold)
            }
        }
    )
}

private data class AnnualCellEditTarget(
    val day: Int,
    val prayerName: String,
    val prayerField: String,
    val currentTime: String
)

fun getOrPopulateMonthDays(
    monthData: MonthPrayers?,
    monthNum: Int,
    daysInMonth: Int
): List<DayPrayers> {
    val existingDays = monthData?.days?.associateBy { it.day } ?: emptyMap()
    val result = mutableListOf<DayPrayers>()
    var lastKnown = existingDays.values.firstOrNull() ?: DayPrayers(
        day = 1,
        fajrFirst = "05:00",
        fajrSecond = "05:15",
        sunrise = "06:30",
        dhuhr = "12:15",
        asr = "03:30",
        maghrib = "06:00",
        isha = "07:30"
    )

    for (d in 1..daysInMonth) {
        val existing = existingDays[d]
        if (existing != null) {
            result.add(existing)
            lastKnown = existing
        } else {
            result.add(lastKnown.copy(day = d))
        }
    }
    return result
}

fun updateSchedulePrayerTime(
    currentSchedule: MosqueSchedule,
    monthNum: Int,
    dayNum: Int,
    prayerField: String,
    newTime: String
): MosqueSchedule {
    val existingMonths = currentSchedule.months.toMutableList()
    val mIndex = existingMonths.indexOfFirst { it.month == monthNum }
    val monthPrayers = if (mIndex >= 0) existingMonths[mIndex] else MonthPrayers(monthNum, emptyList())
    val daysList = monthPrayers.days.toMutableList()
    val dIndex = daysList.indexOfFirst { it.day == dayNum }
    val targetDay = if (dIndex >= 0) {
        daysList[dIndex]
    } else {
        DayPrayers(
            day = dayNum,
            fajrFirst = "05:00",
            fajrSecond = "05:15",
            sunrise = "06:30",
            dhuhr = "12:15",
            asr = "03:30",
            maghrib = "06:00",
            isha = "07:30"
        )
    }

    val updatedDay = when (prayerField) {
        "fajr" -> targetDay.copy(fajrSecond = newTime)
        "sunrise" -> targetDay.copy(sunrise = newTime)
        "dhuhr" -> targetDay.copy(dhuhr = newTime)
        "asr" -> targetDay.copy(asr = newTime)
        "maghrib" -> targetDay.copy(maghrib = newTime)
        "isha" -> targetDay.copy(isha = newTime)
        else -> targetDay
    }

    if (dIndex >= 0) {
        daysList[dIndex] = updatedDay
    } else {
        daysList.add(updatedDay)
        daysList.sortBy { it.day }
    }

    val updatedMonth = monthPrayers.copy(days = daysList)
    if (mIndex >= 0) {
        existingMonths[mIndex] = updatedMonth
    } else {
        existingMonths.add(updatedMonth)
        existingMonths.sortBy { it.month }
    }

    return currentSchedule.copy(months = existingMonths)
}
