package com.example.ui.abbasi

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Traditional Islamic Hanging Lantern (فانوس إسلامي ذهبي) with golden chain,
 * brass filigree cap, glowing glass panels, and ornamental base.
 */
@Composable
fun AbbasiHangingLantern(
    modifier: Modifier = Modifier,
    width: Dp = 38.dp,
    height: Dp = 75.dp
) {
    Box(modifier = modifier.size(width, height)) {
        Canvas(modifier = Modifier.size(width, height)) {
            val w = size.width
            val h = size.height
            val centerX = w / 2f
            val gold = AbbasiThemeColors.PrimaryGold
            val brightGold = AbbasiThemeColors.BrightGold
            val darkGold = AbbasiThemeColors.DeepGold
            val glassGlow = AbbasiThemeColors.LanternGlow

            // 1. Hanging Chain / Cord
            val chainEndY = h * 0.28f
            drawLine(
                color = gold,
                start = Offset(centerX, 0f),
                end = Offset(centerX, chainEndY),
                strokeWidth = 1.6.dp.toPx(),
                cap = StrokeCap.Round
            )

            // Hanging Ring
            drawCircle(
                color = gold,
                radius = 3.dp.toPx(),
                center = Offset(centerX, chainEndY + 3.dp.toPx()),
                style = Stroke(width = 1.2.dp.toPx())
            )

            // 2. Lantern Cap (Islamic Pointed Dome)
            val capTopY = chainEndY + 6.dp.toPx()
            val capBaseY = h * 0.46f
            val capWidth = w * 0.70f

            val capPath = Path().apply {
                moveTo(centerX, capTopY)
                quadraticTo(centerX + capWidth * 0.25f, capTopY + (capBaseY - capTopY) * 0.4f, centerX + capWidth / 2f, capBaseY)
                lineTo(centerX - capWidth / 2f, capBaseY)
                quadraticTo(centerX - capWidth * 0.25f, capTopY + (capBaseY - capTopY) * 0.4f, centerX, capTopY)
                close()
            }
            drawPath(capPath, gold)
            drawPath(capPath, brightGold, style = Stroke(width = 1.dp.toPx()))

            // 3. Lantern Glass Body with Warm Amber Glow
            val bodyTopY = capBaseY
            val bodyBottomY = h * 0.78f
            val bodyTopWidth = capWidth * 0.90f
            val bodyBottomWidth = w * 0.45f

            val bodyPath = Path().apply {
                moveTo(centerX - bodyTopWidth / 2f, bodyTopY)
                lineTo(centerX + bodyTopWidth / 2f, bodyTopY)
                lineTo(centerX + bodyBottomWidth / 2f, bodyBottomY)
                lineTo(centerX - bodyBottomWidth / 2f, bodyBottomY)
                close()
            }

            // Glow inside glass
            drawPath(
                path = bodyPath,
                brush = Brush.radialGradient(
                    colors = listOf(
                        glassGlow,
                        Color(0xFFFFB74D),
                        Color(0xFFE65100).copy(alpha = 0.85f)
                    ),
                    center = Offset(centerX, (bodyTopY + bodyBottomY) / 2f),
                    radius = (bodyBottomY - bodyTopY) * 0.65f
                )
            )

            // Brass Ribs of the Lantern
            drawPath(bodyPath, darkGold, style = Stroke(width = 1.2.dp.toPx()))

            // Center vertical strut
            drawLine(
                color = darkGold,
                start = Offset(centerX, bodyTopY),
                end = Offset(centerX, bodyBottomY),
                strokeWidth = 1.2.dp.toPx()
            )

            // 4. Lantern Base
            val baseTopY = bodyBottomY
            val baseBottomY = h * 0.86f
            val baseWidth = bodyBottomWidth * 1.15f

            val basePath = Path().apply {
                moveTo(centerX - bodyBottomWidth / 2f, baseTopY)
                lineTo(centerX + bodyBottomWidth / 2f, baseTopY)
                lineTo(centerX + baseWidth / 2f, baseBottomY)
                lineTo(centerX - baseWidth / 2f, baseBottomY)
                close()
            }
            drawPath(basePath, gold)

            // Bottom Drop Finial / Tassel
            val finialPath = Path().apply {
                moveTo(centerX, baseBottomY)
                lineTo(centerX + 3.dp.toPx(), baseBottomY + 5.dp.toPx())
                lineTo(centerX, baseBottomY + 10.dp.toPx())
                lineTo(centerX - 3.dp.toPx(), baseBottomY + 5.dp.toPx())
                close()
            }
            drawPath(finialPath, brightGold)
        }
    }
}
