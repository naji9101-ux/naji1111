package com.example.ui.settings

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.AppSettings
import com.example.model.MosqueSchedule
import com.example.ui.theme.*
import com.example.util.AnnualCalendarExportHelper
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth

val CALENDAR_MONTH_NAMES = listOf(
    "",
    "كانون الثاني (1)",
    "شباط (2)",
    "آذار (3)",
    "نيسان (4)",
    "أيار (5)",
    "حزيران (6)",
    "تموز (7)",
    "آب (8)",
    "أيلول (9)",
    "تشرين الأول (10)",
    "تشرين الثاني (11)",
    "كانون الأول (12)"
)

/**
 * Annual Prayer Times Calendar View:
 * Full wide layout, 7 prayer columns (Day, Fajr, Sunrise, Dhuhr, Asr, Maghrib, Isha),
 * completely omitting First Fajr.
 * Includes interactive 12-month selector, Jump to Today, and independent Print/Download/Export options.
 */
@Composable
fun AnnualCalendarView(
    currentSettings: AppSettings,
    workingSchedule: MosqueSchedule,
    onBackToMenu: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val today = remember { LocalDate.now() }
    val displayYear = today.year

    var selectedMonth by remember { mutableIntStateOf(today.monthValue) }
    var showPrintDialog by remember { mutableStateOf(false) }

    val daysInCurrentMonth = remember(selectedMonth, displayYear) {
        try {
            YearMonth.of(displayYear, selectedMonth).lengthOfMonth()
        } catch (e: Exception) {
            30
        }
    }

    val currentMonthData = workingSchedule.months.find { it.month == selectedMonth }
    val daysList = remember(workingSchedule, selectedMonth, daysInCurrentMonth) {
        getOrPopulateMonthDays(currentMonthData, selectedMonth, daysInCurrentMonth)
    }

    val listState = rememberLazyListState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF082D59))
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        // ================= 1. Top Bar =================
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Right: Back to Home/Menu Button
            OutlinedButton(
                onClick = onBackToMenu,
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = Color(0xFF051D3A),
                    contentColor = MosqueGold
                ),
                border = BorderStroke(1.2.dp, MosqueGold),
                shape = RoundedCornerShape(20.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = null,
                    tint = MosqueGold,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "الرجوع للرئيسية",
                    color = MosqueGold,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.5.sp
                )
            }

            // Center: Clear title strictly "جدول مواقيت الصلاة للعام [السنة]" & Mosque Name
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    text = "جدول مواقيت الصلاة للعام $displayYear",
                    color = MosqueGold,
                    fontSize = 18.5.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = NotoNaskhArabicFamily
                )
                Surface(
                    color = Color(0xFF0B3B70),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(0.8.dp, MosqueGold.copy(alpha = 0.5f))
                ) {
                    Text(
                        text = "مسجد: ${currentSettings.mosqueName.ifBlank { "اسم المسجد" }}",
                        color = MosqueWhite,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 2.dp)
                    )
                }
            }

            // Left Action Buttons: "اليوم الحالي" & "طباعة"
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // "اليوم الحالي" button
                FilledTonalButton(
                    onClick = {
                        selectedMonth = today.monthValue
                        coroutineScope.launch {
                            val targetIndex = (today.dayOfMonth - 1).coerceAtLeast(0)
                            listState.animateScrollToItem(targetIndex)
                        }
                    },
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = Color(0xFF0B3B70),
                        contentColor = MosqueWhite
                    ),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, MosqueGold.copy(alpha = 0.6f)),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Today,
                        contentDescription = null,
                        tint = MosqueGold,
                        modifier = Modifier.size(17.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "اليوم الحالي",
                        color = MosqueWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.5.sp
                    )
                }

                // "طباعة" button
                Button(
                    onClick = { showPrintDialog = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MosqueGold,
                        contentColor = Color(0xFF082D59)
                    ),
                    shape = RoundedCornerShape(20.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Print,
                        contentDescription = null,
                        tint = Color(0xFF082D59),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "طباعة وتصدير",
                        color = Color(0xFF082D59),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.5.sp
                    )
                }
            }
        }

        // ================= 2. 12-Month Selector Bar =================
        Surface(
            color = Color(0xFF051D3A),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, MosqueGold.copy(alpha = 0.5f)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Next Month Arrow (Navigates to month + 1)
                IconButton(
                    onClick = {
                        if (selectedMonth < 12) selectedMonth++ else selectedMonth = 1
                    },
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF0B3B70))
                        .border(1.dp, MosqueGold.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "الشهر التالي",
                        tint = MosqueGold,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // 12 Months Horizontal Scrollable Chips
                val monthScrollState = rememberScrollState()
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 8.dp)
                        .horizontalScroll(monthScrollState),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    for (m in 1..12) {
                        val isSelected = (selectedMonth == m)
                        val isCurrentSystemMonth = (today.monthValue == m)
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) MosqueGold else Color(0xFF0B3B70),
                            border = BorderStroke(
                                if (isSelected) 1.5.dp else if (isCurrentSystemMonth) 1.2.dp else 0.8.dp,
                                if (isSelected) Color(0xFFECC469) else if (isCurrentSystemMonth) MosqueGold.copy(alpha = 0.7f) else Color(0xFF1E3A5F)
                            ),
                            onClick = { selectedMonth = m }
                        ) {
                            Text(
                                text = CALENDAR_MONTH_NAMES.getOrElse(m) { "شهر $m" },
                                color = if (isSelected) Color(0xFF082D59) else MosqueWhite,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                            )
                        }
                    }
                }

                // Previous Month Arrow (Navigates to month - 1)
                IconButton(
                    onClick = {
                        if (selectedMonth > 1) selectedMonth-- else selectedMonth = 12
                    },
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF0B3B70))
                        .border(1.dp, MosqueGold.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "الشهر السابق",
                        tint = MosqueGold,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // ================= 3. Table Column Headers (Strictly 7 Columns, RTL) =================
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color(0xFF051D3A),
            border = BorderStroke(1.2.dp, MosqueGold.copy(alpha = 0.85f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 9.dp, horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 1. اليوم (Rightmost)
                Text(
                    text = "اليوم",
                    modifier = Modifier.weight(0.85f),
                    textAlign = TextAlign.Center,
                    color = MosqueGold,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.5.sp
                )
                // 2. الفجر
                Text(
                    text = "الفجر",
                    modifier = Modifier.weight(1.15f),
                    textAlign = TextAlign.Center,
                    color = MosqueGold,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.5.sp
                )
                // 3. الشروق
                Text(
                    text = "الشروق",
                    modifier = Modifier.weight(1.15f),
                    textAlign = TextAlign.Center,
                    color = MosqueGold,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.5.sp
                )
                // 4. الظهر
                Text(
                    text = "الظهر",
                    modifier = Modifier.weight(1.15f),
                    textAlign = TextAlign.Center,
                    color = MosqueGold,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.5.sp
                )
                // 5. العصر
                Text(
                    text = "العصر",
                    modifier = Modifier.weight(1.15f),
                    textAlign = TextAlign.Center,
                    color = MosqueGold,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.5.sp
                )
                // 6. المغرب
                Text(
                    text = "المغرب",
                    modifier = Modifier.weight(1.15f),
                    textAlign = TextAlign.Center,
                    color = MosqueGold,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.5.sp
                )
                // 7. العشاء (Leftmost)
                Text(
                    text = "العشاء",
                    modifier = Modifier.weight(1.15f),
                    textAlign = TextAlign.Center,
                    color = MosqueGold,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.5.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // ================= 4. Table Rows =================
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            items(daysList, key = { it.day }) { dayItem ->
                val isToday = (today.year == displayYear && today.monthValue == selectedMonth && today.dayOfMonth == dayItem.day)

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isToday) Color(0xFF0D47A1).copy(alpha = 0.85f) else Color(0xFF0B3B70).copy(alpha = 0.55f),
                    border = BorderStroke(
                        if (isToday) 1.6.dp else 0.6.dp,
                        if (isToday) MosqueGold else Color(0xFFECC469).copy(alpha = 0.25f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 5.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // 1. اليوم
                        Box(
                            modifier = Modifier.weight(0.85f),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isToday) {
                                Surface(
                                    color = MosqueGold,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = "${dayItem.day}",
                                        textAlign = TextAlign.Center,
                                        color = Color(0xFF082D59),
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 13.sp,
                                        fontFamily = FontFamily.SansSerif,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }
                            } else {
                                Text(
                                    text = "${dayItem.day}",
                                    textAlign = TextAlign.Center,
                                    color = MosqueWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.5.sp,
                                    fontFamily = FontFamily.SansSerif
                                )
                            }
                        }

                        // 2. الفجر (Standard Fajr = fajrSecond)
                        CalendarTimeCell(time = dayItem.fajrSecond, isToday = isToday, modifier = Modifier.weight(1.15f))

                        // 3. الشروق
                        CalendarTimeCell(time = dayItem.sunrise, isToday = isToday, modifier = Modifier.weight(1.15f))

                        // 4. الظهر
                        CalendarTimeCell(time = dayItem.dhuhr, isToday = isToday, modifier = Modifier.weight(1.15f))

                        // 5. العصر
                        CalendarTimeCell(time = dayItem.asr, isToday = isToday, modifier = Modifier.weight(1.15f))

                        // 6. المغرب
                        CalendarTimeCell(time = dayItem.maghrib, isToday = isToday, modifier = Modifier.weight(1.15f))

                        // 7. العشاء
                        CalendarTimeCell(time = dayItem.isha, isToday = isToday, modifier = Modifier.weight(1.15f))
                    }
                }
            }
        }
    }

    // ================= Print & Export Options Dialog =================
    if (showPrintDialog) {
        AnnualPrintOptionsDialog(
            mosqueName = currentSettings.mosqueName.ifBlank { "اسم المسجد" },
            year = displayYear,
            onPrintDocument = {
                AnnualCalendarExportHelper.printAnnualCalendar(
                    context = context,
                    schedule = workingSchedule,
                    mosqueName = currentSettings.mosqueName.ifBlank { "اسم المسجد" },
                    year = displayYear
                )
            },
            onDownloadPdf = {
                val result = AnnualCalendarExportHelper.downloadAnnualCalendarPdf(
                    context = context,
                    schedule = workingSchedule,
                    mosqueName = currentSettings.mosqueName.ifBlank { "اسم المسجد" },
                    year = displayYear
                )
                if (result.isSuccess) {
                    Toast.makeText(context, "تم حفظ ملف PDF في التنزيلات بنجاح (12 صفحة)", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(context, "فشل إنشاء ملف PDF: ${result.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                }
            },
            onExportJson = {
                val result = AnnualCalendarExportHelper.exportAnnualCalendarJson(
                    context = context,
                    schedule = workingSchedule,
                    mosqueName = currentSettings.mosqueName.ifBlank { "اسم المسجد" },
                    year = displayYear
                )
                if (result.isSuccess) {
                    Toast.makeText(context, "تم تصدير ملف JSON بنجاح إلى التنزيلات", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(context, "فشل تصدير ملف JSON: ${result.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                }
            },
            onDismiss = { showPrintDialog = false }
        )
    }
}

@Composable
private fun CalendarTimeCell(
    time: String,
    isToday: Boolean,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.padding(horizontal = 2.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = time.ifBlank { "--:--" },
            textAlign = TextAlign.Center,
            color = if (isToday) MosqueGold else MosqueWhite,
            fontWeight = FontWeight.Bold,
            fontSize = 13.5.sp,
            fontFamily = FontFamily.SansSerif
        )
    }
}

/**
 * Independent Print & Export Dialog:
 * Separates Document Printing, PDF Download (12 pages), and JSON Export into 3 distinct options.
 */
@Composable
fun AnnualPrintOptionsDialog(
    mosqueName: String,
    year: Int,
    onPrintDocument: () -> Unit,
    onDownloadPdf: () -> Unit,
    onExportJson: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .widthIn(max = 560.dp)
                .fillMaxWidth(0.92f)
                .padding(16.dp),
            shape = RoundedCornerShape(20.dp),
            color = Color(0xFF082D59), // Royal Navy Blue
            border = BorderStroke(1.5.dp, MosqueGold)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = MosqueGold)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "خيارات الطباعة والتصدير",
                            color = MosqueGold,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = NotoNaskhArabicFamily
                        )
                        Text(
                            text = "جدول مواقيت الصلاة للعام $year - $mosqueName",
                            color = MosqueIvory,
                            fontSize = 12.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(36.dp))
                }

                HorizontalDivider(color = MosqueGold.copy(alpha = 0.35f), thickness = 1.dp)

                // Option 1: طباعة المستند
                PrintOptionCard(
                    icon = Icons.Default.Print,
                    title = "1. طباعة المستند (A4)",
                    description = "فتح نافذة الطباعة الأصلية للنظام واختيار الطابعة أو الحفظ كـ PDF مباشرة بدون تنزيل تلقائي.",
                    buttonText = "طباعة المستند",
                    buttonColor = MosqueGold,
                    contentColor = Color(0xFF082D59),
                    onClick = {
                        onDismiss()
                        onPrintDocument()
                    }
                )

                // Option 2: تنزيل ملف PDF
                PrintOptionCard(
                    icon = Icons.Default.PictureAsPdf,
                    title = "2. تنزيل ملف PDF (12 صفحة كاملة)",
                    description = "إنشاء ملف PDF حقيقي يحتوي على أشهر السنة الاثني عشر (صفحة لكل شهر)، ونصوص وأرقام قابلة للتحديد والنسخ.",
                    buttonText = "تنزيل الملف (PDF)",
                    buttonColor = Color(0xFF0B3B70),
                    contentColor = MosqueWhite,
                    borderColor = MosqueGold,
                    onClick = {
                        onDismiss()
                        onDownloadPdf()
                    }
                )

                // Option 3: تصدير ملف JSON
                PrintOptionCard(
                    icon = Icons.Default.DataObject,
                    title = "3. تصدير ملف الجدول (JSON)",
                    description = "تصدير جميع بيانات السنة بصيغة JSON قابلة للاستيراد ومطابقة للنظام وبدون بيانات الفجر الأول.",
                    buttonText = "تصدير (JSON)",
                    buttonColor = Color(0xFF051D3A),
                    contentColor = MosqueGold,
                    borderColor = MosqueGold.copy(alpha = 0.7f),
                    onClick = {
                        onDismiss()
                        onExportJson()
                    }
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Close Button
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "إلغاء وإغلاق",
                        color = MosqueLightGold,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun PrintOptionCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String,
    buttonText: String,
    buttonColor: Color,
    contentColor: Color,
    borderColor: Color? = null,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF051D3A)),
        border = BorderStroke(1.dp, borderColor ?: MosqueGold.copy(alpha = 0.4f)),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF0B3B70))
                    .border(1.dp, MosqueGold.copy(alpha = 0.5f), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = MosqueGold, modifier = Modifier.size(24.dp))
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = MosqueGold,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.5.sp
                )
                Text(
                    text = description,
                    color = MosqueIvory,
                    fontSize = 11.sp,
                    lineHeight = 15.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Button(
                onClick = onClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = buttonColor,
                    contentColor = contentColor
                ),
                shape = RoundedCornerShape(10.dp),
                border = if (borderColor != null) BorderStroke(1.dp, borderColor) else null,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = buttonText,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
        }
    }
}
