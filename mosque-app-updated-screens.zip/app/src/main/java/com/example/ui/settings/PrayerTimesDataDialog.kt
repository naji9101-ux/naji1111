package com.example.ui.settings

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.AppSettings
import com.example.model.MosqueSchedule
import com.example.ui.abbasi.AbbasiThemeColors
import com.example.ui.theme.*

/**
 * Screen mode within PrayerTimesDataDialog:
 * - MENU: The 4-card management menu matching the screenshot
 * - VIEW_CALENDAR: 365-day annual schedule viewer
 * - EDIT_CALENDAR: 365-day annual schedule editor
 */
enum class DataScreenMode {
    MENU,
    VIEW_CALENDAR,
    EDIT_CALENDAR
}

/**
 * Dedicated Dialog for «إدارة بيانات ومواقيت الصلاة».
 * Implements the exact layout requested by the user:
 * - Top Header: [الرجوع للرئيسية], Title/Subtitle, [اسم المسجد]
 * - 1. عرض التقويم السنوي (Replaces GPS)
 * - 2. استيراد ملف المواقيت السنوي (JSON و CSV)
 * - 3. تعديل الجدول يدوياً
 * - 4. لصق جدول المواقيت بتنسيق JSON
 */
@Composable
fun PrayerTimesDataDialog(
    currentSettings: AppSettings,
    currentSchedule: MosqueSchedule,
    isLocatingGps: Boolean = false,
    onSaveSchedule: (MosqueSchedule) -> Unit,
    onSaveSettings: (AppSettings) -> Unit,
    onRestoreDefaultSchedule: () -> Unit,
    onImportAnnualScheduleUri: (Uri) -> Result<MosqueSchedule>,
    onRequestGpsLocation: ((onResult: (Boolean, String, MosqueSchedule?) -> Unit) -> Unit)? = null,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val repository = remember { com.example.data.PrayerRepository(context) }
    val clipboardManager = LocalClipboardManager.current

    var workingSchedule by remember(currentSchedule) { mutableStateOf(currentSchedule) }
    var scheduleMonthIndex by remember { mutableIntStateOf(java.time.LocalDate.now().monthValue) }
    var currentMode by remember { mutableStateOf(DataScreenMode.MENU) }

    var showConfirmReplaceDialog by remember { mutableStateOf(false) }
    var pendingImportUri by remember { mutableStateOf<Uri?>(null) }
    var showJsonPasteDialog by remember { mutableStateOf(false) }
    var showRestoreConfirmDialog by remember { mutableStateOf(false) }
    var isTableEditing by remember { mutableStateOf(false) }

    // Launcher for JSON or CSV schedule file
    val annualFilePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            if (repository.hasCustomSchedule()) {
                pendingImportUri = uri
                showConfirmReplaceDialog = true
            } else {
                val result = onImportAnnualScheduleUri(uri)
                if (result.isSuccess) {
                    val newSched = result.getOrThrow()
                    workingSchedule = newSched
                    onSaveSchedule(newSched)
                    Toast.makeText(context, "تم استيراد جدول المواقيت السنوي بنجاح", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(context, "خطأ في الاستيراد: ${result.exceptionOrNull()?.message ?: ""}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = false,
            decorFitsSystemWindows = false
        )
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(if (isTableEditing) 4.dp else 8.dp),
                shape = RoundedCornerShape(18.dp),
                color = Color(0xFF082D59), // Unified Royal Navy Blue
                border = BorderStroke(1.6.dp, AbbasiThemeColors.MetallicGoldGradient)
            ) {
                when (currentMode) {
                    DataScreenMode.VIEW_CALENDAR -> {
                        AnnualCalendarView(
                            currentSettings = currentSettings,
                            workingSchedule = workingSchedule,
                            onBackToMenu = { currentMode = DataScreenMode.MENU },
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    DataScreenMode.EDIT_CALENDAR -> {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(if (isTableEditing) 4.dp else 12.dp)
                        ) {
                            // Header with Back to Menu button - collapses when editing cell to give maximum screen space
                            AnimatedVisibility(
                                visible = !isTableEditing,
                                enter = fadeIn(tween(150)),
                                exit = fadeOut(tween(150))
                            ) {
                                Column {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(bottom = 6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        OutlinedButton(
                                            onClick = { currentMode = DataScreenMode.MENU },
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MosqueGold),
                                            border = BorderStroke(1.2.dp, MosqueGold),
                                            shape = RoundedCornerShape(20.dp),
                                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                                contentDescription = null,
                                                tint = MosqueGold,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "الرجوع لقائمة البيانات",
                                                color = MosqueGold,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp
                                            )
                                        }

                                        Text(
                                            text = "تعديل جدول المواقيت يدوياً",
                                            color = MosqueWhite,
                                            fontSize = 17.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = NotoNaskhArabicFamily
                                        )

                                        Spacer(modifier = Modifier.width(60.dp))
                                    }

                                    HorizontalDivider(color = MosqueGold.copy(alpha = 0.35f), thickness = 1.dp)
                                    Spacer(modifier = Modifier.height(4.dp))
                                }
                            }

                            AnnualScheduleTableSection(
                                workingSchedule = workingSchedule,
                                onScheduleChange = {
                                    workingSchedule = it
                                },
                                monthIndex = scheduleMonthIndex,
                                onMonthIndexChange = { scheduleMonthIndex = it },
                                onCancel = {
                                    workingSchedule = currentSchedule
                                    currentMode = DataScreenMode.MENU
                                },
                                onNext = {
                                    if (scheduleMonthIndex < 12) {
                                        scheduleMonthIndex++
                                    } else {
                                        scheduleMonthIndex = 1
                                    }
                                },
                                onDone = {
                                    onSaveSchedule(workingSchedule)
                                    Toast.makeText(context, "تم حفظ واعتماد جدول المواقيت بنجاح", Toast.LENGTH_SHORT).show()
                                    currentMode = DataScreenMode.MENU
                                },
                                onEditingChanged = { isTableEditing = it },
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }

                    DataScreenMode.MENU -> {
                        // Main Menu Screen matching the user's reference screenshot
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .padding(horizontal = 18.dp, vertical = 14.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Top Bar: [الرجوع للرئيسية], [Title & Subtitle], [Mosque Name]
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Right Side (in RTL): Outlined Pill Button "الرجوع للرئيسية"
                                OutlinedButton(
                                    onClick = onDismiss,
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = Color.Transparent,
                                        contentColor = MosqueGold
                                    ),
                                    border = BorderStroke(1.2.dp, MosqueGold),
                                    shape = RoundedCornerShape(20.dp),
                                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                        contentDescription = null,
                                        tint = MosqueGold,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "الرجوع للرئيسية",
                                        color = MosqueGold,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.5.sp
                                    )
                                }

                                // Center: Title and Data Source
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "إدارة بيانات ومواقيت الصلاة",
                                        color = MosqueWhite,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = NotoNaskhArabicFamily
                                    )
                                    Text(
                                        text = if (repository.hasCustomSchedule()) "مصدر البيانات: جدول مواقيت مخصص محفوظ" else "مصدر البيانات: جدول المواقيت المصحح الأصلي",
                                        color = MosqueLightGold.copy(alpha = 0.85f),
                                        fontSize = 12.sp,
                                        fontFamily = NotoNaskhArabicFamily
                                    )
                                }

                                // Left Side (in RTL): Mosque Name Badge
                                Surface(
                                    shape = RoundedCornerShape(20.dp),
                                    color = MosqueDarkGreen,
                                    border = BorderStroke(1.dp, MosqueGold.copy(alpha = 0.7f)),
                                    contentColor = MosqueLightGold
                                ) {
                                    Text(
                                        text = currentSettings.mosqueName.ifEmpty { "اسم المسجد" },
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MosqueLightGold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(2.dp))

                            // =========================================================
                            // CARD 1: 1. عرض التقويم السنوي (Replaces GPS)
                            // =========================================================
                            DataMenuCard(
                                numberPrefix = "1.",
                                title = "عرض التقويم السنوي",
                                subtitle = "استعراض كامل مواقيت الصلوات لكافة أشهر وأيام السنة بالتصميم الأزرق والذهبي مع إمكانية التنقل",
                                icon = Icons.Default.CalendarMonth,
                                onClick = { currentMode = DataScreenMode.VIEW_CALENDAR }
                            )

                            // =========================================================
                            // CARD 2: 2. استيراد ملف المواقيت السنوي (JSON و CSV)
                            // =========================================================
                            DataMenuCard(
                                numberPrefix = "2.",
                                title = "استيراد ملف المواقيت السنوي (JSON و CSV)",
                                subtitle = "استيراد جدول مواقيت الصلوات من ملف خارجي بصيغة JSON أو CSV وحفظه وتطبيقه في التطبيق",
                                icon = Icons.Default.Description,
                                onClick = { annualFilePickerLauncher.launch("*/*") }
                            )

                            // =========================================================
                            // CARD 3: 3. تعديل الجدول يدوياً
                            // =========================================================
                            DataMenuCard(
                                numberPrefix = "3.",
                                title = "تعديل الجدول يدوياً",
                                subtitle = "عرض وتعديل مواقيت الصلوات الفعلية المستوردة لأي يوم من أيام السنة الـ 365 بدقة",
                                icon = Icons.Default.EditCalendar,
                                onClick = { currentMode = DataScreenMode.EDIT_CALENDAR }
                            )

                            // =========================================================
                            // CARD 4: 4. لصق جدول المواقيت بتنسيق JSON
                            // =========================================================
                            DataMenuCard(
                                numberPrefix = "4.",
                                title = "لصق جدول المواقيت بتنسيق JSON",
                                subtitle = "إدخال ولصق بيانات المواقيت بصيغة JSON مباشرة وحفظها فوراً داخل التطبيق",
                                icon = Icons.Default.Code,
                                onClick = { showJsonPasteDialog = true }
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            // Subtle restore default option at the bottom
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center
                            ) {
                                TextButton(onClick = { showRestoreConfirmDialog = true }) {
                                    Icon(
                                        imageVector = Icons.Default.Restore,
                                        contentDescription = null,
                                        tint = MosqueLightGold.copy(alpha = 0.7f),
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "استعادة جدول المواقيت المعتمد الأصلي",
                                        color = MosqueLightGold.copy(alpha = 0.7f),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Dialog for pasting JSON directly (Card 4)
    if (showJsonPasteDialog) {
        var jsonInputText by remember { mutableStateOf("") }
        var jsonErrorMessage by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showJsonPasteDialog = false },
            containerColor = MosqueVeryDarkGreen,
            shape = RoundedCornerShape(16.dp),
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Code,
                        contentDescription = null,
                        tint = MosqueGold,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = "لصق جدول المواقيت بتنسيق JSON",
                        color = MosqueGold,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "الصق بيانات جدول المواقيت بصيغة JSON لحفظها وتطبيقها مباشرة:",
                        color = MosqueIvory,
                        fontSize = 13.sp
                    )

                    OutlinedTextField(
                        value = jsonInputText,
                        onValueChange = {
                            jsonInputText = it
                            jsonErrorMessage = null
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        placeholder = {
                            Text(
                                text = "{\"months\": [{\"month\": 1, \"days\": [...]}]}",
                                color = MosqueLightGold.copy(alpha = 0.45f),
                                fontSize = 12.sp
                            )
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = MosqueWhite,
                            unfocusedTextColor = MosqueWhite,
                            focusedBorderColor = MosqueGold,
                            unfocusedBorderColor = MosqueGold.copy(alpha = 0.5f),
                            focusedContainerColor = MosqueDeepGreen,
                            unfocusedContainerColor = MosqueDeepGreen
                        )
                    )

                    if (jsonErrorMessage != null) {
                        Text(
                            text = jsonErrorMessage!!,
                            color = Color(0xFFFF5252),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Button(
                        onClick = {
                            val clip = clipboardManager.getText()?.text
                            if (!clip.isNullOrBlank()) {
                                jsonInputText = clip
                                jsonErrorMessage = null
                            } else {
                                Toast.makeText(context, "الحافظة لا تحتوي على نصوص", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MosqueDarkGreen),
                        border = BorderStroke(1.dp, MosqueGold.copy(alpha = 0.6f)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentPaste,
                            contentDescription = null,
                            tint = MosqueGold,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("لصق من الحافظة", color = MosqueGold, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val trimmed = jsonInputText.trim()
                        if (trimmed.isBlank()) {
                            jsonErrorMessage = "الرجاء إدخال بيانات JSON أولاً"
                            return@Button
                        }
                        val parsed = repository.parseSchedule(trimmed)
                        if (parsed != null && parsed.months.isNotEmpty()) {
                            workingSchedule = parsed
                            onSaveSchedule(parsed)
                            Toast.makeText(
                                context,
                                "تم حفظ وتطبيق جدول المواقيت بنجاح (${parsed.months.count { it.days.isNotEmpty() }} شهراً)",
                                Toast.LENGTH_LONG
                            ).show()
                            showJsonPasteDialog = false
                        } else {
                            jsonErrorMessage = "تنسيق JSON غير صالح أو لا يحتوي على أشهر صالحة. يرجى التحقق من الملف."
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MosqueGold),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("حفظ وتطبيق", color = MosqueVeryDarkGreen, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showJsonPasteDialog = false }) {
                    Text("إلغاء", color = MosqueLightGold)
                }
            }
        )
    }

    // Dialog confirming file replacement
    if (showConfirmReplaceDialog && pendingImportUri != null) {
        val targetUri = pendingImportUri!!
        AlertDialog(
            onDismissRequest = {
                showConfirmReplaceDialog = false
                pendingImportUri = null
            },
            containerColor = MosqueVeryDarkGreen,
            shape = RoundedCornerShape(14.dp),
            title = {
                Text(
                    text = "تأكيد استبدال الجدول",
                    color = MosqueGold,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = "يوجد جدول سنوي مخصص محفوظ حالياً. هل تريد استبداله بالملف الجديد المختار؟",
                    color = MosqueIvory,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val result = onImportAnnualScheduleUri(targetUri)
                        if (result.isSuccess) {
                            val newSched = result.getOrThrow()
                            workingSchedule = newSched
                            onSaveSchedule(newSched)
                            Toast.makeText(context, "تم استيراد الجدول بنجاح", Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(context, "خطأ في الاستيراد: ${result.exceptionOrNull()?.message ?: ""}", Toast.LENGTH_LONG).show()
                        }
                        showConfirmReplaceDialog = false
                        pendingImportUri = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MosqueGold),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("نعم، استبدل", color = MosqueVeryDarkGreen, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showConfirmReplaceDialog = false
                        pendingImportUri = null
                    }
                ) {
                    Text("إلغاء", color = MosqueLightGold)
                }
            }
        )
    }

    // Dialog confirming restoring original default schedule
    if (showRestoreConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showRestoreConfirmDialog = false },
            containerColor = MosqueVeryDarkGreen,
            shape = RoundedCornerShape(14.dp),
            title = {
                Text(
                    text = "استعادة الجدول الافتراضي",
                    color = MosqueGold,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = "هل تريد استعادة جدول المواقيت المصحح الافتراضي الأصلي وحذف أي جدول مستورد مخصص؟",
                    color = MosqueIvory,
                    fontSize = 13.5.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onRestoreDefaultSchedule()
                        workingSchedule = repository.loadSchedule()
                        onSaveSchedule(workingSchedule)
                        showRestoreConfirmDialog = false
                        Toast.makeText(context, "تمت استعادة الجدول الأصلي بنجاح", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("تأكيد الاستعادة", color = MosqueWhite, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRestoreConfirmDialog = false }) {
                    Text("إلغاء", color = MosqueLightGold)
                }
            }
        )
    }
}

/**
 * Reusable Card item matching the exact style of the reference screenshot:
 * - Rounded Dark Blue/Green card with gold border
 * - Right: Circular golden badge with action icon
 * - Center: Title with number prefix (bold white) + explanatory subtitle
 * - Left: Navigation arrow pointing left
 */
@Composable
private fun DataMenuCard(
    numberPrefix: String,
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MosqueDarkGreen
        ),
        border = BorderStroke(1.2.dp, MosqueGold.copy(alpha = 0.85f)),
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Right Side (in RTL): Gold Icon Badge + Titles
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.weight(1f)
            ) {
                // Gold Icon Badge
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(MosqueGold),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = MosqueVeryDarkGreen,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Column(
                    verticalArrangement = Arrangement.spacedBy(3.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = "$numberPrefix $title",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MosqueWhite,
                        fontFamily = NotoNaskhArabicFamily
                    )
                    Text(
                        text = subtitle,
                        fontSize = 11.5.sp,
                        color = MosqueLightGold.copy(alpha = 0.85f),
                        lineHeight = 16.sp,
                        fontFamily = NotoNaskhArabicFamily
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Left Side (in RTL): Navigation Arrow pointing left
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = null,
                tint = MosqueGold.copy(alpha = 0.8f),
                modifier = Modifier.size(18.dp)
            )
        }
    }
}
