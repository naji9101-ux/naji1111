package com.example.ui.settings

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppSettings
import com.example.model.AudioFileItem
import com.example.model.PrayerType
import com.example.model.SinglePrayerConfig
import com.example.ui.components.PrayerIconBox
import com.example.ui.components.SelectedAudioBox
import com.example.ui.components.AudioSourceSelectionRow
import com.example.ui.theme.*

@Composable
fun AdhanSettingsTab(
    settings: AppSettings,
    isPlayingTest: Boolean,
    onTestAdhan: (String?) -> Unit,
    onStopAdhan: () -> Unit,
    onAddGeneralAdhan: (String, Uri) -> AudioFileItem?,
    onAddFajrAdhan: (String, Uri) -> AudioFileItem?,
    onDeleteGeneralAdhan: (AudioFileItem) -> Unit,
    onDeleteFajrAdhan: (AudioFileItem) -> Unit,
    onSelectCommonAdhan: (AudioFileItem) -> Unit,
    onClearCommonAdhan: () -> Unit,
    onSelectPrayerAdhan: (PrayerType, AudioFileItem) -> Unit,
    onClearPrayerAdhan: (PrayerType) -> Unit,
    onUpdatePrayerConfig: (SinglePrayerConfig) -> Unit,
    onUpdate: (AppSettings) -> Unit
) {
    val context = LocalContext.current
    var currentlyPlayingSound by remember { mutableStateOf<String?>(null) }
    var prayerForLibraryDialog by remember { mutableStateOf<PrayerType?>(null) }
    var prayerForPhoneFilePicker by remember { mutableStateOf<PrayerType?>(null) }
    var showCommonLibraryDialog by remember { mutableStateOf(false) }

    // Launcher for unified adhan file from phone
    val unifiedPhonePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val fileName = uri.lastPathSegment?.substringAfterLast("/") ?: "أذان موحد"
            val item = onAddGeneralAdhan(fileName, uri)
            if (item != null) {
                onSelectCommonAdhan(item)
                Toast.makeText(context, "تمت إضافة الأذان الموحد واختياره بنجاح", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Launcher for picking adhan directly from phone for a specific prayer
    val prayerPhonePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        val targetPrayer = prayerForPhoneFilePicker
        if (uri != null && targetPrayer != null) {
            val isFajrFirst = targetPrayer == PrayerType.FAJR_FIRST
            val fileName = uri.lastPathSegment?.substringAfterLast("/") ?: "أذان ${targetPrayer.defaultName}"
            val item = if (isFajrFirst) {
                onAddFajrAdhan(fileName, uri)
            } else {
                onAddGeneralAdhan(fileName, uri)
            }
            if (item != null) {
                onSelectPrayerAdhan(targetPrayer, item)
                Toast.makeText(context, "تم اختيار وتفعيل الصوت لـ ${targetPrayer.defaultName}", Toast.LENGTH_SHORT).show()
            }
        }
        prayerForPhoneFilePicker = null
    }

    val isFridayFirstActive = settings.firstAdhansMasterEnabled && settings.isFridayFirstEnabled

    // All prayers with adhan supported independently (Sunrise has NO adhan)
    val prayersWithAdhan = buildList {
        add(PrayerType.FAJR_FIRST to "الفجر الأول")
        add(PrayerType.FAJR_SECOND to "الفجر الثاني")
        add(PrayerType.DHUHR to "الظهر")
        add(PrayerType.ASR to "العصر")
        add(PrayerType.MAGHRIB to "المغرب")
        add(PrayerType.ISHA to "العشاء")
        if (isFridayFirstActive) {
            add(PrayerType.FRIDAY_FIRST to "الأذان الأول")
            add(PrayerType.FRIDAY_SECOND to "الأذان الثاني")
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // =========================================================================
        // 1. تفعيل / تطبيق صوت الأذان المختار على جميع الأذانات (OFF افتراضياً)
        // =========================================================================
        Card(
            colors = CardDefaults.cardColors(containerColor = MosqueDeepGreen),
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.2.dp, MosqueGold),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        horizontalAlignment = Alignment.Start,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = "تطبيق صوت الأذان المختار على جميع الصلوات",
                            color = MosqueGold,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (settings.useCommonAdhan) "مفعل (يعمم على كافة الصلوات عدا الفجر الأول)" else "معطل (كل صلاة بصوتها المستقل)",
                            color = if (settings.useCommonAdhan) MosqueWhite else MosqueLightGold.copy(alpha = 0.7f),
                            fontSize = 11.5.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Switch(
                        checked = settings.useCommonAdhan,
                        onCheckedChange = { isChecked ->
                            onUpdate(settings.copy(useCommonAdhan = isChecked))
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = MosqueVeryDarkGreen,
                            checkedTrackColor = MosqueGold
                        )
                    )
                }

                if (settings.useCommonAdhan) {
                    HorizontalDivider(color = MosqueGold.copy(alpha = 0.25f))
                    Text(
                        text = "الصوت الموحد لجميع الصلوات:",
                        color = MosqueLightGold,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    val unifiedSoundUri = settings.commonAdhanSound
                    val unifiedTitle = if (unifiedSoundUri.isNotBlank()) {
                        settings.commonAdhanName.ifBlank {
                            settings.savedAdhanSounds.find { it.uri == unifiedSoundUri }?.name
                                ?: unifiedSoundUri.substringAfterLast("/")
                        }
                    } else {
                        "لم يتم اختيار صوت"
                    }

                    // Selected Sound Box (Card above the action buttons)
                    SelectedAudioBox(
                        soundTitle = unifiedTitle,
                        isPlaying = isPlayingTest && currentlyPlayingSound == "unified_adhan",
                        soundUriOrKey = unifiedSoundUri.ifBlank { unifiedTitle },
                        enabled = settings.useCommonAdhan,
                        onPlayPause = {
                            if (!settings.useCommonAdhan) return@SelectedAudioBox
                            if (isPlayingTest && currentlyPlayingSound == "unified_adhan") {
                                onStopAdhan()
                                currentlyPlayingSound = null
                            } else {
                                onStopAdhan()
                                currentlyPlayingSound = "unified_adhan"
                                onTestAdhan(unifiedSoundUri.ifBlank { unifiedTitle })
                            }
                        },
                        onClear = if (settings.useCommonAdhan && unifiedSoundUri.isNotEmpty()) {
                            { onClearCommonAdhan() }
                        } else null
                    )

                    // Action buttons
                    AudioSourceSelectionRow(
                        enabled = settings.useCommonAdhan,
                        libraryButtonText = "اختيار من المكتبة",
                        phoneButtonText = "ملف من الهاتف",
                        onOpenLibrary = { if (settings.useCommonAdhan) showCommonLibraryDialog = true },
                        onPickFromPhone = { if (settings.useCommonAdhan) unifiedPhonePicker.launch("audio/*") }
                    )
                }
            }
        }

        // =========================================================================
        // 2. إعدادات كل صلاة بشكل مستقل (8 صلوات)
        // =========================================================================
        Text(
            text = "إعدادات الأذان لكل صلاة (8 صلوات):",
            color = MosqueLightGold,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
        )

        prayersWithAdhan.forEach { (prayerType, prayerDisplayName) ->
            val pConfig = settings.getPrayerConfig(prayerType)
            val isFajrFirst = prayerType == PrayerType.FAJR_FIRST
            val isOverriddenByUnified = settings.useCommonAdhan && !isFajrFirst

            val activeSoundUri = if (isOverriddenByUnified) {
                settings.commonAdhanSound
            } else {
                pConfig.adhanSoundUri?.takeIf { it.isNotEmpty() }
                    ?: pConfig.adhanSoundPreset
            }

            val soundTitle = if (activeSoundUri.isNotBlank()) {
                if (isOverriddenByUnified) {
                    settings.commonAdhanName.ifBlank {
                        settings.savedAdhanSounds.find { it.uri == activeSoundUri }?.name
                            ?: activeSoundUri.substringAfterLast("/")
                    }
                } else if (pConfig.adhanSoundName?.isNotBlank() == true) {
                    pConfig.adhanSoundName
                } else {
                    val found = if (isFajrFirst) {
                        settings.savedFajrAdhanSounds.find { it.uri == activeSoundUri }?.name
                    } else {
                        settings.savedAdhanSounds.find { it.uri == activeSoundUri }?.name
                    }
                    found ?: activeSoundUri.substringAfterLast("/")
                }
            } else {
                "لم يتم اختيار صوت"
            }

            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isFajrFirst) MosqueDeepGreen else MosqueDarkGreen
                ),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(
                    1.2.dp,
                    if (isFajrFirst) MosqueGold else MosqueGold.copy(alpha = 0.5f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("adhan_card_${prayerType.id}")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Header: Prayer Name, Icon & Activation Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            PrayerIconBox(prayerType = prayerType, boxSize = 38.dp)
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "أذان $prayerDisplayName",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MosqueWhite
                                    )
                                    if (isFajrFirst) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Surface(
                                            color = MosqueGold.copy(alpha = 0.2f),
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text(
                                                text = "مكتبة أذان الفجر خاصة",
                                                color = MosqueLightGold,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }
                                Text(
                                    text = if (pConfig.adhanEnabled) "الأذان مفعل" else "الأذان معطل",
                                    fontSize = 11.5.sp,
                                    color = if (pConfig.adhanEnabled) MosqueGold else Color(0xFFFF8A80)
                                )
                            }
                        }

                        // Independent ON/OFF switch per prayer - stays ON/OFF immediately!
                        Switch(
                            checked = pConfig.adhanEnabled,
                            onCheckedChange = { isChecked ->
                                val updatedCfg = pConfig.copy(adhanEnabled = isChecked)
                                onUpdatePrayerConfig(updatedCfg)
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = MosqueVeryDarkGreen,
                                checkedTrackColor = MosqueGold
                            )
                        )
                    }

                    HorizontalDivider(color = MosqueGold.copy(alpha = 0.2f))

                    // 1. [ مستطيل جميل للصوت المختار ]
                    // ▶ اسم الصوت المختار
                    // تشغيل / معاينة
                    SelectedAudioBox(
                        soundTitle = soundTitle,
                        isPlaying = isPlayingTest && currentlyPlayingSound == "${prayerType.id}_adhan",
                        label = if (isOverriddenByUnified) "الصوت الموحد المطبق:" else "صوت الأذان المختار:",
                        soundUriOrKey = activeSoundUri.ifBlank { soundTitle },
                        enabled = pConfig.adhanEnabled,
                        onPlayPause = {
                            if (!pConfig.adhanEnabled) return@SelectedAudioBox
                            if (isPlayingTest && currentlyPlayingSound == "${prayerType.id}_adhan") {
                                onStopAdhan()
                                currentlyPlayingSound = null
                            } else {
                                onStopAdhan()
                                currentlyPlayingSound = "${prayerType.id}_adhan"
                                val toPlay = activeSoundUri.ifBlank { soundTitle }
                                onTestAdhan(toPlay)
                            }
                        },
                        onClear = if (pConfig.adhanEnabled && !isOverriddenByUnified && activeSoundUri.isNotBlank()) {
                            { onClearPrayerAdhan(prayerType) }
                        } else null
                    )

                    // 2. [ اختيار من مكتبة الأذان ] & [ اختيار ملف أذان من الهاتف ]
                    // Positioned below the selected audio rectangle matching reference screenshot
                    if (!isOverriddenByUnified || isFajrFirst) {
                        AudioSourceSelectionRow(
                            enabled = pConfig.adhanEnabled,
                            libraryButtonText = if (isFajrFirst) "مكتبة أذان الفجر" else "اختيار من المكتبة",
                            phoneButtonText = "ملف من الهاتف",
                            onOpenLibrary = { if (pConfig.adhanEnabled) prayerForLibraryDialog = prayerType },
                            onPickFromPhone = {
                                if (pConfig.adhanEnabled) {
                                    prayerForPhoneFilePicker = prayerType
                                    prayerPhonePicker.launch("audio/*")
                                }
                            }
                        )
                    } else {
                        Text(
                            text = "ملاحظة: هذا الأذان يتبع الصوت الموحد تلقائياً لأن خيار التعميم مفعل.",
                            color = MosqueLightGold.copy(alpha = 0.7f),
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }

    // Modal dialog for selecting unified sound
    if (showCommonLibraryDialog) {
        AudioLibrarySelectionDialog(
            title = "مكتبة الأذان العامة الموحدة",
            subtitle = "اختر صوتاً لتعميمه على جميع الأذانات",
            initialSelectedUri = settings.commonAdhanSound,
            librarySounds = settings.savedAdhanSounds,
            isPlayingTest = isPlayingTest,
            playingSoundKey = currentlyPlayingSound,
            onTestSound = { sound ->
                currentlyPlayingSound = sound
                onTestAdhan(sound)
            },
            onStopSound = {
                onStopAdhan()
                currentlyPlayingSound = null
            },
            onImportFileFromPhone = { name, uri ->
                onAddGeneralAdhan(name, uri)
            },
            onDeleteSound = { item ->
                onDeleteGeneralAdhan(item)
            },
            onConfirmSelection = { item ->
                onSelectCommonAdhan(item)
                showCommonLibraryDialog = false
            },
            onDismiss = {
                showCommonLibraryDialog = false
            }
        )
    }

    // Modal dialog for selecting sound for a specific prayer
    if (prayerForLibraryDialog != null) {
        val targetPrayer = prayerForLibraryDialog!!
        val isFajrFirst = targetPrayer == PrayerType.FAJR_FIRST
        val targetConfig = settings.getPrayerConfig(targetPrayer)
        val initialUri = targetConfig.adhanSoundUri ?: targetConfig.adhanSoundPreset
        val libraryToUse = if (isFajrFirst) settings.savedFajrAdhanSounds else settings.savedAdhanSounds

        val targetDisplayName = settings.getPrayerDisplayName(targetPrayer)
        AudioLibrarySelectionDialog(
            title = if (isFajrFirst) "مكتبة أذان الفجر (خاصة بالفجر الأول)" else "مكتبة الأذان لـ $targetDisplayName",
            subtitle = if (isFajrFirst) "ملفات أذان الفجر الأول المستقلة" else "اختر صوت الأذان المناسب لهذه الصلاة",
            initialSelectedUri = initialUri,
            librarySounds = libraryToUse,
            isPlayingTest = isPlayingTest,
            playingSoundKey = currentlyPlayingSound,
            onTestSound = { sound ->
                currentlyPlayingSound = sound
                onTestAdhan(sound)
            },
            onStopSound = {
                onStopAdhan()
                currentlyPlayingSound = null
            },
            onImportFileFromPhone = { name, uri ->
                if (isFajrFirst) onAddFajrAdhan(name, uri) else onAddGeneralAdhan(name, uri)
            },
            onDeleteSound = { item ->
                if (isFajrFirst) onDeleteFajrAdhan(item) else onDeleteGeneralAdhan(item)
            },
            onConfirmSelection = { item ->
                onSelectPrayerAdhan(targetPrayer, item)
                Toast.makeText(context, "تم اختيار ${item.name} لـ $targetDisplayName", Toast.LENGTH_SHORT).show()
                prayerForLibraryDialog = null
            },
            onDismiss = {
                prayerForLibraryDialog = null
            }
        )
    }
}
