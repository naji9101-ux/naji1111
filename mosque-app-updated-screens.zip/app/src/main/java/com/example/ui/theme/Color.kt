package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Mosque Colors - Synchronized with Abbasi Royal Navy Blue & Gold Theme
val MosqueWhite = Color(0xFFFFFFFF)
val MosqueIvory = Color(0xFFFAF7EE)
val MosqueIvoryDark = Color(0xFFF3EEDC)

// Uniform Royal Navy Blue palette for all settings, dialogs, cards, and containers
val MosqueDarkGreen = Color(0xFF0B3B70)     // Rich Royal Navy for cards, surfaces, tabs, and list items (replaces old green #123C2E)
val MosqueVeryDarkGreen = Color(0xFF082D59) // Primary Royal Navy for dialogs, main panels, and screen surfaces (replaces old green #0B2F24)
val MosqueDeepGreen = Color(0xFF051D3A)     // Deep Midnight Navy for inner cards, containers, and primary buttons (replaces old green #071F18)

// Explicit Navy semantic aliases
val MosqueNavyDark = Color(0xFF082D59)
val MosqueNavySurface = Color(0xFF0B3B70)
val MosqueNavyDeep = Color(0xFF051D3A)
val MosqueNavyCard = Color(0xFF092B52)
val MosqueNavyBorder = Color(0xFF1A6194)

val MosqueGold = Color(0xFFECC469)
val MosqueLightGold = Color(0xFFFFE082)
val MosquePaleGold = Color(0xFFFFF7DD)
val MosqueGoldBorder = Color(0xFFECC469).copy(alpha = 0.6f)
val MosqueBlack = Color(0xFF111111)
val ActivePrayerHighlight = Color(0xFF0288D1)
val IqamaActiveGlow = Color(0xFF079FDC)
val AdhanActiveGlow = Color(0xFF0288D1)

// Reference Screenshot Modern Navy & Gold Palette
val ScreenshotNavyDark = Color(0xFF08274C)
val ScreenshotNavySurface = Color(0xFF0B3B70)
val ScreenshotNavyBg = Color(0xFF071F3D)
val ScreenshotGoldPrimary = Color(0xFFECC469)
val ScreenshotGoldAccent = Color(0xFFD8B64F)
val ScreenshotCyanAccent = Color(0xFF079FDC)
val ScreenshotBorderBlue = Color(0xFF1A6194)
