package com.example.ui.components

import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.floor
import kotlin.math.min

/**
 * A responsive, overflow-free clock text component.
 * Automatically fits inside its bounding box (width and height) by scaling down
 * if the user's selected font size exceeds the container bounds.
 * Maintains an explicit safety margin from all boundaries so text never touches or clips borders.
 * Keeps the text centered both horizontally and vertically on a single line.
 */
@Composable
fun AutoSizedClockText(
    text: String,
    targetFontSizeSp: Float,
    color: Color,
    modifier: Modifier = Modifier,
    fontWeight: FontWeight = FontWeight.Bold,
    fontFamily: FontFamily = FontFamily.SansSerif,
    letterSpacing: TextUnit = 1.5.sp,
    minFontSizeSp: Float = 14f,
    horizontalSafetyPadding: Dp = 16.dp,
    verticalSafetyPadding: Dp = 6.dp
) {
    BoxWithConstraints(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        val density = LocalDensity.current
        val textMeasurer = rememberTextMeasurer()

        // Available inner area with guaranteed safety margins on all sides
        val availableWidthPx = with(density) { (maxWidth - horizontalSafetyPadding * 2).toPx().coerceAtLeast(10f) }
        val availableHeightPx = with(density) { (maxHeight - verticalSafetyPadding * 2).toPx().coerceAtLeast(10f) }

        // Use a prototype string with '8' for digits to guarantee maximum width representation
        // and eliminate per-second measurement layout jitter.
        val measureTemplate = remember(text) {
            text.map { if (it.isDigit()) '8' else it }.joinToString("")
        }

        val optimalSizeSp = remember(
            measureTemplate,
            targetFontSizeSp,
            availableWidthPx,
            availableHeightPx,
            fontWeight,
            fontFamily,
            letterSpacing,
            minFontSizeSp
        ) {
            val baseStyle = TextStyle(
                fontWeight = fontWeight,
                fontFamily = fontFamily,
                letterSpacing = letterSpacing
            )

            // Measure at user's desired font size
            val targetMeasure = textMeasurer.measure(
                text = measureTemplate,
                style = baseStyle.copy(fontSize = targetFontSizeSp.sp),
                maxLines = 1,
                softWrap = false
            )

            val widthRatio = availableWidthPx / targetMeasure.size.width.toFloat().coerceAtLeast(1f)
            val heightRatio = availableHeightPx / targetMeasure.size.height.toFloat().coerceAtLeast(1f)
            val scaleFactor = min(1.0f, min(widthRatio, heightRatio))

            if (scaleFactor >= 1.0f) {
                targetFontSizeSp
            } else {
                // Apply scaling with a 5% margin to guarantee no glyph or sub-pixel overflow
                val initialScaledSp = targetFontSizeSp * scaleFactor * 0.95f
                val candidateSp = floor(initialScaledSp).coerceAtLeast(minFontSizeSp)

                // Double check measured fit at candidate size
                val checkMeasure = textMeasurer.measure(
                    text = measureTemplate,
                    style = baseStyle.copy(fontSize = candidateSp.sp),
                    maxLines = 1,
                    softWrap = false
                )

                if (checkMeasure.size.width > availableWidthPx || checkMeasure.size.height > availableHeightPx) {
                    val secondaryRatio = min(
                        availableWidthPx / checkMeasure.size.width.toFloat().coerceAtLeast(1f),
                        availableHeightPx / checkMeasure.size.height.toFloat().coerceAtLeast(1f)
                    )
                    floor(candidateSp * secondaryRatio * 0.95f).coerceAtLeast(minFontSizeSp)
                } else {
                    candidateSp
                }
            }
        }

        Text(
            text = text,
            color = color,
            fontSize = optimalSizeSp.sp,
            fontWeight = fontWeight,
            fontFamily = fontFamily,
            letterSpacing = letterSpacing,
            textAlign = TextAlign.Center,
            maxLines = 1,
            softWrap = false
        )
    }
}
