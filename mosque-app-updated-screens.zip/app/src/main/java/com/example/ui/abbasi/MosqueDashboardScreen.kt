package com.example.ui.abbasi

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.example.model.ActiveCountdown
import com.example.model.AppSettings
import com.example.model.PrayerRowItem
import com.example.model.PrayerType
import com.example.ui.components.HtmlDesignScreen
import org.json.JSONArray
import org.json.JSONObject

/** The supplied dashboard design, backed by the application's existing prayer data. */
@Composable
fun MosqueDashboardScreen(
    currentTimeFormatted: String,
    dayOfWeek: String,
    hijriDate: String,
    gregorianDate: String,
    prayerRows: List<PrayerRowItem>,
    iqamaCountdown: ActiveCountdown?,
    adhanCountdown: ActiveCountdown?,
    settings: AppSettings,
    nextUpcomingPrayerType: PrayerType? = null,
    onPrayerClick: (PrayerRowItem) -> Unit,
    onSettingsClick: () -> Unit,
    onScheduleClick: () -> Unit = onSettingsClick,
    modifier: Modifier = Modifier,
    tickerMessage: String = ""
) {
    val displayMosqueName = if (settings.mosqueName.isBlank() ||
        settings.mosqueName == "مسجد الشهداء" || settings.mosqueName == "مسجد عرصه الكبير"
    ) "اسم المسجد" else settings.mosqueName

    val trimmed = currentTimeFormatted.trim()
    val marker = when {
        trimmed.contains("م") || trimmed.contains("PM", ignoreCase = true) -> "م"
        trimmed.contains("ص") || trimmed.contains("AM", ignoreCase = true) -> "ص"
        else -> ""
    }
    val timeOnly = trimmed.replace("ص", "").replace("م", "")
        .replace("AM", "", ignoreCase = true).replace("PM", "", ignoreCase = true).trim()

    // Keep the same ordering and next-prayer selection as the previous dashboard.
    val targetOrder = listOf(
        PrayerType.FAJR_FIRST, PrayerType.FAJR_SECOND, PrayerType.SUNRISE,
        PrayerType.DHUHR, PrayerType.FRIDAY_SECOND, PrayerType.FRIDAY_FIRST,
        PrayerType.ASR, PrayerType.MAGHRIB, PrayerType.ISHA
    )
    val orderedPrayers = targetOrder.mapNotNull { type -> prayerRows.find { it.type == type } }
        .ifEmpty { prayerRows }.take(7)
    fun eligible(type: PrayerType?) = type != null && type != PrayerType.FAJR_FIRST &&
        type != PrayerType.SUNRISE && type != PrayerType.FRIDAY_FIRST
    val targetNextType = if (eligible(nextUpcomingPrayerType)) nextUpcomingPrayerType
        else prayerRows.find { it.isNext }?.type.let { if (eligible(it)) it else PrayerType.FAJR_SECOND }

    val rowsJson = JSONArray()
    orderedPrayers.forEach { row ->
        val icon = when (row.type) {
            PrayerType.FAJR_FIRST -> "fa1"
            PrayerType.FAJR_SECOND -> "fa2"
            PrayerType.SUNRISE -> "rise"
            PrayerType.ASR -> "pc"
            PrayerType.MAGHRIB -> "set"
            PrayerType.ISHA -> "moon"
            else -> "sun"
        }
        val time = row.adhanTime.replace("ص", "").replace("م", "").trim()
        rowsJson.put(JSONObject()
            .put("id", row.type.id)
            .put("name", row.name)
            .put("time", time)
            .put("isNext", row.type == targetNextType)
            .put("icon", icon))
    }
    val state = JSONObject()
        .put("mosqueName", displayMosqueName)
        .put("time", timeOnly)
        .put("amPm", marker)
        .put("hijriDate", hijriDate)
        .put("dateLine", "$dayOfWeek $gregorianDate")
        .put("adhanTime", adhanCountdown?.formattedTime ?: "00:00:00")
        .put("adhanName", adhanCountdown?.prayerName?.let { "صلاة $it" } ?: "")
        .put("iqamaTime", iqamaCountdown?.formattedTime ?: "00:00")
        .put("iqamaName", iqamaCountdown?.prayerName?.let { "إقامة صلاة $it" } ?: "")
        .put("tickerMessage", tickerMessage)
        .put("rows", rowsJson)

    HtmlDesignScreen(
        assetName = "dashboard.html",
        state = state,
        onAction = { action ->
            when {
                action == "settings" -> onSettingsClick()
                action == "schedule" -> onScheduleClick()
                action.startsWith("prayer:") -> orderedPrayers.find {
                    it.type.id == action.removePrefix("prayer:")
                }?.let(onPrayerClick)
            }
        },
        modifier = modifier,
        screenTag = "mosque_dashboard_screen"
    )
}
