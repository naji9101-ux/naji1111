package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.IqamaScreenCustomConfig
import com.example.model.PrayerType
import com.example.ui.theme.ArefRuqaaFamily
import com.example.ui.theme.CairoFamily
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import java.util.Locale

/** شاشة الإقامة بالتصميم المرفق، مع إبقاء العدّاد والإعدادات الأصلية. */
@Composable
fun FullScreenIqamaScreen(
    config: IqamaScreenCustomConfig = IqamaScreenCustomConfig(),
    secondsRemaining: Long = 1200L,
    isFridayKhutbah: Boolean = false,
    prayerName: String = "صلاة الظهر",
    prayerType: PrayerType? = null,
    currentIqamaDurationMinutes: Int = 10,
    currentAdhkarDurationMinutes: Int = 15,
    isAutoIqamaScreenEnabled: Boolean = true,
    onSaveSettings: ((newIqamaDuration: Int, newAdhkarDuration: Int, isEnabled: Boolean) -> Unit)? = null,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (isFridayKhutbah) {
        FridayKhutbahScreen(
            secondsRemaining = secondsRemaining,
            currentDurationMinutes = currentIqamaDurationMinutes,
            isAutoKhutbahEnabled = isAutoIqamaScreenEnabled,
            onSaveSettings = { newDur, isEnabled ->
                onSaveSettings?.invoke(newDur, currentAdhkarDurationMinutes, isEnabled)
            },
            onDismiss = onDismiss,
            modifier = modifier
        )
        return
    }

    val initialSeconds = remember(secondsRemaining) {
        if (secondsRemaining > 0L) secondsRemaining else 1200L
    }
    var currentSecondsLeft by remember(initialSeconds) { mutableLongStateOf(initialSeconds) }
    var showSettingsModal by remember { mutableStateOf(false) }

    LaunchedEffect(initialSeconds) {
        currentSecondsLeft = initialSeconds
        while (isActive && currentSecondsLeft > 0L) {
            delay(1000L)
            currentSecondsLeft -= 1L
            if (currentSecondsLeft <= 0L) {
                onDismiss()
                break
            }
        }
    }

    val formattedCountdown = remember(currentSecondsLeft) {
        val safe = currentSecondsLeft.coerceAtLeast(0L)
        String.format(Locale.US, "%02d:%02d", safe / 60, safe % 60)
    }

    HtmlDesignScreen(
        assetName = "iqama.html",
        state = org.json.JSONObject()
            .put("countdown", formattedCountdown)
            .put("prayerName", prayerName),
        onAction = { action ->
            when (action) {
                "settings" -> showSettingsModal = true
                "dismiss" -> onDismiss()
            }
        },
        modifier = modifier,
        screenTag = "ongoing_prayer_screen"
    )

    if (showSettingsModal) {
        IqamaSettingsModalDialog(
            prayerName = prayerName,
            initialIqamaMinutes = currentIqamaDurationMinutes,
            initialAdhkarMinutes = currentAdhkarDurationMinutes,
            initialEnabled = isAutoIqamaScreenEnabled,
            onSave = { newIqama, newAdhkar, enabled ->
                onSaveSettings?.invoke(newIqama, newAdhkar, enabled)
                showSettingsModal = false
            },
            onDismiss = { showSettingsModal = false }
        )
    }
}

/** الهاتف مع علامة المنع الحمراء — viewBox 200×200 كما في الـSVG الأصلي */
@Composable
private fun VectorPhoneProhibitionIcon(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val s = size.minDimension / 200f
        withTransform({ scale(s, s, Offset.Zero) }) {
            withTransform({ translate(62f, 34f) }) {
                val body = CornerRadius(14f, 14f)
                drawRoundRect(Color(0xFF0B2B54), Offset.Zero, Size(76f, 132f), body)
                drawRoundRect(OvGold, Offset.Zero, Size(76f, 132f), body, style = Stroke(3f))
                val scr = CornerRadius(6f, 6f)
                drawRoundRect(Color(0xFF041832), Offset(6f, 13f), Size(64f, 104f), scr)
                drawRoundRect(Color(0xFF1E4E8C), Offset(6f, 13f), Size(64f, 104f), scr, style = Stroke(1.5f))
                drawRoundRect(OvGold, Offset(27f, 6f), Size(22f, 3f), CornerRadius(1.5f, 1.5f))
                drawRoundRect(OvGold.copy(alpha = 0.8f), Offset(25f, 122f), Size(26f, 3f), CornerRadius(1.5f, 1.5f))
                val line = OvGold.copy(alpha = 0.35f)
                drawLine(line, Offset(20f, 45f), Offset(56f, 45f), strokeWidth = 2.5f, cap = StrokeCap.Round)
                drawLine(line, Offset(16f, 62f), Offset(60f, 62f), strokeWidth = 2.5f, cap = StrokeCap.Round)
                drawLine(line, Offset(22f, 79f), Offset(54f, 79f), strokeWidth = 2.5f, cap = StrokeCap.Round)
            }
            val dark = Color(0xFFDC2626)
            val light = Color(0xFFEF4444)
            val c = Offset(100f, 100f)
            drawCircle(dark, radius = 84f, center = c, style = Stroke(14f))
            drawCircle(light, radius = 84f, center = c, style = Stroke(10f))
            drawLine(dark, Offset(41f, 41f), Offset(159f, 159f), strokeWidth = 14f, cap = StrokeCap.Round)
            drawLine(light, Offset(41f, 41f), Offset(159f, 159f), strokeWidth = 10f, cap = StrokeCap.Round)
        }
    }
}

@Composable
private fun IqamaSettingsModalDialog(
    prayerName: String,
    initialIqamaMinutes: Int,
    initialAdhkarMinutes: Int,
    initialEnabled: Boolean,
    onSave: (newIqama: Int, newAdhkar: Int, isEnabled: Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    var iqamaMinutes by remember { mutableIntStateOf(initialIqamaMinutes.coerceIn(1, 60)) }
    var adhkarMinutes by remember { mutableIntStateOf(initialAdhkarMinutes.coerceIn(1, 180)) }
    var isEnabled by remember { mutableStateOf(initialEnabled) }

    OvModalShell(
        title = "إعدادات شاشة الإقامة — $prayerName",
        subtitle = "ضبط مدة استمرار شاشة «الصلاة قائمة»",
        onSave = { onSave(iqamaMinutes, adhkarMinutes, isEnabled) },
        onDismiss = onDismiss
    ) {
        OvMinuteRowCard(
            title = "مدة شاشة الإقامة",
            subtitle = "بالدقائق بعد الإقامة",
            value = iqamaMinutes,
            min = 1,
            max = 60,
            onChange = { iqamaMinutes = it }
        )

        OvMinuteRowCard(
            title = "مدة شاشة الأذكار",
            subtitle = "بالدقائق بعد الصلاة",
            value = adhkarMinutes,
            min = 1,
            max = 180,
            onChange = { adhkarMinutes = it }
        )

        OvToggleRow(
            title = "تفعيل شاشة الصلاة والأذكار",
            subtitle = "عرض شاشة «الصلاة قائمة» تلقائياً عند الإقامة",
            checked = isEnabled,
            onToggle = { isEnabled = !isEnabled }
        )
    }
}
