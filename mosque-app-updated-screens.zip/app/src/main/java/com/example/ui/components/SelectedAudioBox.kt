package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.AudioRegistry
import com.example.ui.theme.*

/**
 * Modern Selected Audio Box based on the reference design:
 * - Label above the box (e.g., "صوت الأذان المختار:")
 * - Dark Navy rounded card with gold/cyan border
 * - Right: Audio icon inside a rounded badge
 * - Center: Audio Title in bold + Subtitle / status
 * - Left: Pill-shaped "▶ استماع" (Listen) / "■ إيقاف" (Stop) button
 */
@Composable
fun SelectedAudioBox(
    soundTitle: String?,
    isPlaying: Boolean,
    onPlayPause: () -> Unit,
    modifier: Modifier = Modifier,
    label: String? = null,
    subtitle: String? = null,
    onClear: (() -> Unit)? = null,
    soundUriOrKey: String? = null,
    forcedAudioMatched: Boolean? = null,
    enabled: Boolean = true,
    badgeIcon: ImageVector = Icons.Default.GraphicEq
) {
    val isSelected = !soundTitle.isNullOrBlank() && soundTitle != "لم يتم اختيار صوت"
    val displayTitle = if (isSelected) soundTitle!! else "لم يتم اختيار صوت"

    // Calculate audioMatched state dynamically from AudioRegistry
    val audioMatched = remember(soundTitle, soundUriOrKey, forcedAudioMatched) {
        if (!isSelected) {
            false
        } else if (forcedAudioMatched != null) {
            forcedAudioMatched
        } else {
            AudioRegistry.isAudioMatched(soundUriOrKey) || AudioRegistry.isAudioMatched(soundTitle)
        }
    }

    val borderColor by animateColorAsState(
        targetValue = when {
            !enabled -> ScreenshotBorderBlue.copy(alpha = 0.3f)
            isPlaying -> ScreenshotGoldPrimary
            !isSelected -> ScreenshotBorderBlue.copy(alpha = 0.6f)
            audioMatched -> ScreenshotGoldAccent
            else -> Color(0xFFD32F2F).copy(alpha = 0.7f)
        },
        label = "audioBoxBorder"
    )

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        if (!label.isNullOrBlank()) {
            Text(
                text = label,
                fontSize = 12.sp,
                color = if (enabled) ScreenshotGoldPrimary else ScreenshotGoldPrimary.copy(alpha = 0.45f),
                fontWeight = FontWeight.SemiBold
            )
        }

        Surface(
            shape = RoundedCornerShape(14.dp),
            color = if (enabled) ScreenshotNavyDark else ScreenshotNavyDark.copy(alpha = 0.5f),
            border = BorderStroke(1.2.dp, borderColor),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Right side (in RTL): Icon Badge + Title & Subtitle
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Audio Badge Icon
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (enabled) ScreenshotNavySurface else ScreenshotNavySurface.copy(alpha = 0.5f))
                            .border(
                                1.dp,
                                if (isPlaying) ScreenshotGoldPrimary else ScreenshotBorderBlue.copy(alpha = 0.7f),
                                RoundedCornerShape(10.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = badgeIcon,
                            contentDescription = null,
                            tint = when {
                                !enabled -> ScreenshotGoldPrimary.copy(alpha = 0.35f)
                                isPlaying -> ScreenshotGoldPrimary
                                isSelected -> ScreenshotCyanAccent
                                else -> ScreenshotGoldPrimary.copy(alpha = 0.6f)
                            },
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    // Title & Subtitle
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = displayTitle,
                            fontSize = 14.5.sp,
                            fontWeight = if (isSelected && enabled) FontWeight.Bold else FontWeight.Medium,
                            color = if (!enabled) MosqueLightGold.copy(alpha = 0.4f) else if (isSelected) Color.White else MosqueLightGold.copy(alpha = 0.65f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )

                        val resolvedSubtitle = when {
                            !enabled -> "الخيار معطل (قم بتفعيله لتغيير أو تشغيل الصوت)"
                            isPlaying -> "جاري الاستماع الآن..."
                            !subtitle.isNullOrBlank() -> subtitle
                            !isSelected -> "اضغط على الأزرار بالأسفل لاختيار الصوت"
                            audioMatched -> "صوت ندي خاشع (الصوت المعتمد للمسجد)"
                            else -> "ملف صوتي غير متوفر حالياً"
                        }

                        Text(
                            text = resolvedSubtitle,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Normal,
                            color = when {
                                !enabled -> Color(0xFFFF8A80).copy(alpha = 0.7f)
                                isPlaying -> ScreenshotGoldPrimary
                                !audioMatched && isSelected -> Color(0xFFEF9A9A)
                                else -> ScreenshotGoldAccent.copy(alpha = 0.85f)
                            },
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Left side (in RTL): Action Controls (Pill Listen/Stop Button + Clear)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Optional Clear button
                    if (isSelected && onClear != null && enabled) {
                        IconButton(
                            onClick = onClear,
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.3f))
                        ) {
                            Icon(
                                imageVector = Icons.Default.Clear,
                                contentDescription = "إلغاء اختيار الصوت",
                                tint = Color(0xFFFF8A80),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    // Pill Button: "▶ استماع" or "■ إيقاف"
                    val isButtonEnabled = enabled && isSelected && audioMatched
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = when {
                            !isButtonEnabled -> ScreenshotNavySurface.copy(alpha = 0.4f)
                            isPlaying -> Color(0xFFB71C1C)
                            else -> ScreenshotNavySurface
                        },
                        border = BorderStroke(
                            1.2.dp,
                            when {
                                !isButtonEnabled -> ScreenshotGoldAccent.copy(alpha = 0.25f)
                                isPlaying -> Color(0xFFFF8A80)
                                else -> ScreenshotGoldAccent
                            }
                        ),
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .clickable(enabled = isButtonEnabled) { onPlayPause() }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Stop else Icons.Default.PlayArrow,
                                contentDescription = if (isPlaying) "إيقاف" else "استماع",
                                tint = when {
                                    !isButtonEnabled -> ScreenshotGoldAccent.copy(alpha = 0.3f)
                                    isPlaying -> Color.White
                                    else -> ScreenshotGoldPrimary
                                },
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = if (isPlaying) "إيقاف" else "استماع",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = when {
                                    !isButtonEnabled -> ScreenshotGoldAccent.copy(alpha = 0.3f)
                                    isPlaying -> Color.White
                                    else -> ScreenshotGoldPrimary
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Modern Audio Source Buttons row matching the reference design:
 * "مصدر الصوت:"
 * [ 🎵 اختيار من المكتبة ]   [ 📱 ملف من الهاتف ]
 */
@Composable
fun AudioSourceSelectionRow(
    enabled: Boolean = true,
    libraryButtonText: String = "اختيار من المكتبة",
    phoneButtonText: String = "ملف من الهاتف",
    onOpenLibrary: () -> Unit,
    onPickFromPhone: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            text = "مصدر الصوت:",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = if (enabled) ScreenshotGoldAccent else ScreenshotGoldAccent.copy(alpha = 0.4f)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Button 1: Library
            Button(
                onClick = onOpenLibrary,
                enabled = enabled,
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ScreenshotNavySurface,
                    disabledContainerColor = ScreenshotNavySurface.copy(alpha = 0.4f),
                    contentColor = ScreenshotGoldPrimary,
                    disabledContentColor = ScreenshotGoldPrimary.copy(alpha = 0.3f)
                ),
                border = BorderStroke(
                    1.dp,
                    if (enabled) ScreenshotGoldAccent.copy(alpha = 0.85f) else ScreenshotGoldAccent.copy(alpha = 0.25f)
                ),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.LibraryMusic,
                    contentDescription = null,
                    modifier = Modifier.size(17.dp),
                    tint = if (enabled) ScreenshotGoldPrimary else ScreenshotGoldPrimary.copy(alpha = 0.3f)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = libraryButtonText,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (enabled) ScreenshotGoldPrimary else ScreenshotGoldPrimary.copy(alpha = 0.3f),
                    maxLines = 1
                )
            }

            // Button 2: Phone
            Button(
                onClick = onPickFromPhone,
                enabled = enabled,
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ScreenshotNavyDark,
                    disabledContainerColor = ScreenshotNavyDark.copy(alpha = 0.4f),
                    contentColor = Color.White,
                    disabledContentColor = Color.White.copy(alpha = 0.4f)
                ),
                border = BorderStroke(
                    1.dp,
                    if (enabled) ScreenshotBorderBlue else ScreenshotBorderBlue.copy(alpha = 0.3f)
                ),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Smartphone,
                    contentDescription = null,
                    modifier = Modifier.size(17.dp),
                    tint = if (enabled) ScreenshotCyanAccent else ScreenshotCyanAccent.copy(alpha = 0.3f)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = phoneButtonText,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (enabled) Color.White else Color.White.copy(alpha = 0.4f),
                    maxLines = 1
                )
            }
        }
    }
}
