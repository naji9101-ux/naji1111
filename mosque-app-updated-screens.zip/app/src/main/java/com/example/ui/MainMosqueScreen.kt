package com.example.ui

import android.content.res.Configuration
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.model.PrayerState
import com.example.model.PrayerType
import com.example.model.SinglePrayerConfig
import com.example.ui.abbasi.MosqueDashboardScreen
import com.example.ui.components.*
import com.example.ui.settings.PrayerDetailDialog
import com.example.ui.settings.PrayerTimesDataDialog
import com.example.ui.settings.SettingsDialog
import com.example.ui.theme.*
import com.example.viewmodel.PrayerTimesViewModel

@Composable
fun MainMosqueScreen(
    viewModel: PrayerTimesViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentTime by viewModel.currentTimeFormatted.collectAsStateWithLifecycle()
    val dayOfWeek by viewModel.dayOfWeekArabic.collectAsStateWithLifecycle()
    val hijriDate by viewModel.hijriDate.collectAsStateWithLifecycle()
    val gregorianDate by viewModel.gregorianDate.collectAsStateWithLifecycle()
    val prayerRows by viewModel.prayerRows.collectAsStateWithLifecycle()
    val adhanCountdown by viewModel.adhanCountdown.collectAsStateWithLifecycle()
    val nextUpcomingPrayerType by viewModel.nextUpcomingPrayerType.collectAsStateWithLifecycle()
    val iqamaCountdown by viewModel.iqamaCountdown.collectAsStateWithLifecycle()
    val prayerState by viewModel.prayerState.collectAsStateWithLifecycle()
    val currentPrayerName by viewModel.currentActivePrayerName.collectAsStateWithLifecycle()
    val isIqamaNow by viewModel.isIqamaNow.collectAsStateWithLifecycle()
    val currentTickerMessage by viewModel.currentTickerMessage.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val selectedPrayerForDetail by viewModel.selectedPrayerForDetail.collectAsStateWithLifecycle()
    val isPlayingAdhanTest by viewModel.isPlayingAdhanSound.collectAsStateWithLifecycle()

    val isPrayerScreenActive by viewModel.isPrayerScreenActive.collectAsStateWithLifecycle()
    val activePrayerScreenUri by viewModel.activePrayerScreenUri.collectAsStateWithLifecycle()
    val previewPrayerScreenType by viewModel.previewPrayerScreenType.collectAsStateWithLifecycle()

    val isIqamaScreenActive by viewModel.isIqamaScreenActive.collectAsStateWithLifecycle()
    val activeIqamaPrayerType by viewModel.activeIqamaPrayerType.collectAsStateWithLifecycle()
    val isPreviewingIqamaScreen by viewModel.isPreviewingIqamaScreen.collectAsStateWithLifecycle()
    val previewIqamaPrayerType by viewModel.previewIqamaPrayerType.collectAsStateWithLifecycle()
    val iqamaScreenSecondsRemaining by viewModel.iqamaScreenSecondsRemaining.collectAsStateWithLifecycle()

    val isAdhkarScreenActive by viewModel.isAdhkarScreenActive.collectAsStateWithLifecycle()
    val isPreviewingAdhkarScreen by viewModel.isPreviewingAdhkarScreen.collectAsStateWithLifecycle()
    val adhkarScreenSecondsRemaining by viewModel.adhkarScreenSecondsRemaining.collectAsStateWithLifecycle()

    val activePeriodId by viewModel.activePeriodId.collectAsStateWithLifecycle()
    val previewPeriodId by viewModel.previewPeriodId.collectAsStateWithLifecycle()
    val schedule by viewModel.schedule.collectAsStateWithLifecycle()
    val isLocatingGps by viewModel.isLocatingGps.collectAsStateWithLifecycle()

    var showSettingsDialog by remember { mutableStateOf(false) }
    var showPrayerTimesDataDialog by remember { mutableStateOf(false) }
    var settingsDialogTab by remember { mutableIntStateOf(0) }

    val configuration = LocalConfiguration.current
    val isLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    val tableBackgroundAlpha = 0.94f

    BackHandler(enabled = isAdhkarScreenActive || isPreviewingAdhkarScreen || isIqamaScreenActive || isPreviewingIqamaScreen || previewPrayerScreenType != null || selectedPrayerForDetail != null || showPrayerTimesDataDialog) {
        when {
            showPrayerTimesDataDialog -> showPrayerTimesDataDialog = false
            isPreviewingAdhkarScreen -> viewModel.dismissAdhkarPreview()
            isAdhkarScreenActive -> viewModel.dismissAdhkarScreen()
            isPreviewingIqamaScreen -> viewModel.dismissIqamaPreview()
            isIqamaScreenActive -> viewModel.dismissIqamaScreen()
            previewPrayerScreenType != null -> viewModel.dismissPrayerScreen()
            selectedPrayerForDetail != null -> viewModel.dismissPrayerDetail()
        }
    }

    // Kiosk mode: prevent exiting app when kiosk mode is enabled
    BackHandler(enabled = settings.isKioskModeEnabled && !showSettingsDialog && !showPrayerTimesDataDialog && !isAdhkarScreenActive && !isPreviewingAdhkarScreen && !isIqamaScreenActive && !isPreviewingIqamaScreen && previewPrayerScreenType == null && selectedPrayerForDetail == null) {
        // Consumed to prevent leaving mosque display in Kiosk mode
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        containerColor = Color(0xFF082D59)
    ) { _ ->
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            MosqueDashboardScreen(
                currentTimeFormatted = currentTime,
                dayOfWeek = dayOfWeek,
                hijriDate = hijriDate,
                gregorianDate = gregorianDate,
                prayerRows = prayerRows,
                iqamaCountdown = iqamaCountdown,
                adhanCountdown = adhanCountdown,
                settings = settings,
                nextUpcomingPrayerType = nextUpcomingPrayerType,
                onPrayerClick = { viewModel.onPrayerClicked(it) },
                onSettingsClick = {
                    settingsDialogTab = 0
                    showSettingsDialog = true
                },
                onScheduleClick = {
                    showPrayerTimesDataDialog = true
                },
                tickerMessage = currentTickerMessage
            )

            // State Alert Banner floating at the top of screen when prayer alert is active
            if (prayerState != PrayerState.NORMAL &&
                prayerState != PrayerState.FRIDAY_NORMAL &&
                prayerState != PrayerState.AFTER_PRAYER &&
                prayerState != PrayerState.FRIDAY_AFTER
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter)
                        .padding(top = 38.dp, start = 16.dp, end = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    StateAlertBanner(
                        state = prayerState,
                        currentPrayerName = currentPrayerName
                    )
                }
            }

            // Dialogs
            if (showSettingsDialog) {
                SettingsDialog(
                    currentSettings = settings,
                    currentSchedule = schedule,
                    isLocatingGps = isLocatingGps,
                    initialTab = settingsDialogTab,
                    onSaveSchedule = { viewModel.saveManualSchedule(it) },
                    onSaveSettings = { viewModel.updateSettings(it) },
                    onRestoreDefaultSchedule = { viewModel.restoreDefaultSchedule() },
                    onRestoreDefaultSettings = { viewModel.restoreDefaultSettings() },
                    onImportAnnualScheduleUri = { viewModel.importScheduleFromUri(it) },
                    onRequestGpsLocation = { callback ->
                        viewModel.updateScheduleFromGps(context, callback)
                    },
                    onPreviewIqamaScreen = {
                        showSettingsDialog = false
                        viewModel.previewIqamaScreen(it)
                    },
                    onPreviewAdhkarScreen = {
                        showSettingsDialog = false
                        viewModel.previewAdhkarScreen()
                    },
                    onOpenPrayerTimesData = { showPrayerTimesDataDialog = true },
                    onTestAudio = { viewModel.testAdhan(it) },
                    onStopAudio = { viewModel.stopAdhan() },
                    isPlayingTest = isPlayingAdhanTest,
                    onAddAdhanToLibrary = { name, uri -> viewModel.addCustomGeneralAdhan(name, uri) },
                    onAddFajrAdhanToLibrary = { name, uri -> viewModel.addCustomFajrAdhan(name, uri) },
                    onAddIqamaToLibrary = { name, uri -> viewModel.addCustomIqama(name, uri) },
                    onDeleteAdhanFromLibrary = { item -> viewModel.deleteGeneralAdhan(item) },
                    onDeleteFajrAdhanFromLibrary = { item -> viewModel.deleteFajrAdhan(item) },
                    onDeleteIqamaFromLibrary = { item -> viewModel.deleteCustomIqama(item) },
                    onDismiss = { showSettingsDialog = false }
                )
            }

            if (showPrayerTimesDataDialog) {
                PrayerTimesDataDialog(
                    currentSettings = settings,
                    currentSchedule = schedule,
                    isLocatingGps = isLocatingGps,
                    onSaveSchedule = { viewModel.saveManualSchedule(it) },
                    onSaveSettings = { viewModel.updateSettings(it) },
                    onRestoreDefaultSchedule = { viewModel.restoreDefaultSchedule() },
                    onImportAnnualScheduleUri = { viewModel.importScheduleFromUri(it) },
                    onRequestGpsLocation = { callback ->
                        viewModel.updateScheduleFromGps(context, callback)
                    },
                    onDismiss = { showPrayerTimesDataDialog = false }
                )
            }

            // Prayer Detail Dialog (when tapping on a prayer in the table)
            selectedPrayerForDetail?.let { prayer ->
                val currentConfig = settings.getPrayerConfig(prayer.type)
                PrayerDetailDialog(
                    prayer = prayer,
                    currentConfig = currentConfig,
                    settings = settings,
                    savedAdhanSounds = settings.savedAdhanSounds,
                    savedFajrAdhanSounds = settings.savedFajrAdhanSounds,
                    savedIqamaSounds = settings.savedIqamaSounds,
                    onSaveConfig = { viewModel.saveSinglePrayerConfig(it) },
                    onTestAudio = { viewModel.testAdhan(it) },
                    onStopAudio = { viewModel.stopAdhan() },
                    onAddAdhanToLibrary = { name, uri -> viewModel.addCustomGeneralAdhan(name, uri) },
                    onAddFajrAdhanToLibrary = { name, uri -> viewModel.addCustomFajrAdhan(name, uri) },
                    onAddIqamaToLibrary = { name, uri -> viewModel.addCustomIqama(name, uri) },
                    onDeleteAdhanFromLibrary = { item -> viewModel.deleteGeneralAdhan(item) },
                    onDeleteFajrAdhanFromLibrary = { item -> viewModel.deleteFajrAdhan(item) },
                    onDeleteIqamaFromLibrary = { item -> viewModel.deleteCustomIqama(item) },
                    isPlayingTest = isPlayingAdhanTest,
                    onDismiss = { viewModel.dismissPrayerDetail() }
                )
            }

            // Dedicated Prayer Screen Preview Overlay
            if (previewPrayerScreenType != null) {
                val previewType = previewPrayerScreenType
                val targetPrayerName = if (previewType != null) previewType.defaultName else currentPrayerName
                val targetImageUri = if (previewType != null) {
                    settings.getPrayerConfig(previewType).prayerScreenUri
                } else {
                    activePrayerScreenUri
                }
                DedicatedPrayerScreen(
                    prayerName = targetPrayerName,
                    imageUri = targetImageUri,
                    mosqueName = settings.mosqueName,
                    currentTime = currentTime,
                    iqamaCountdown = iqamaCountdown?.formattedTime ?: "",
                    prayerState = prayerState,
                    onDismiss = { viewModel.dismissPrayerScreen() }
                )
            }

            // Full-Screen Programmatic Iqama Screen Overlay
            if (isIqamaScreenActive || isPreviewingIqamaScreen) {
                val targetPrayerType = if (isPreviewingIqamaScreen) previewIqamaPrayerType else activeIqamaPrayerType
                val isFridayKhutbah = targetPrayerType == PrayerType.FRIDAY_SECOND
                val prayerCfg = targetPrayerType?.let { settings.getPrayerConfig(it) }
                val iqamaConfig = prayerCfg?.iqamaScreenCustomConfig ?: settings.iqamaScreenCustomConfig
                val durationMins = if (isFridayKhutbah) {
                    settings.fridayKhutbahDurationMinutes
                } else {
                    prayerCfg?.iqamaScreenDurationMinutes ?: settings.globalIqamaScreenDurationMinutes
                }
                val defaultSecs = (durationMins * 60L).coerceAtLeast(60L)
                val secondsRemaining = if (isPreviewingIqamaScreen) defaultSecs else {
                    if (iqamaScreenSecondsRemaining > 0L) iqamaScreenSecondsRemaining else defaultSecs
                }

                val prayerDisplayName = targetPrayerType?.displayName(settings.isFridayFirstActive)
                    ?: currentPrayerName.ifEmpty { "صلاة الظهر" }
                val iqamaMinutes = durationMins
                val adhkarMinutes = settings.postPrayerAdhkarDurationMinutes
                val isScreenEnabled = if (isFridayKhutbah) settings.isFridayKhutbahMode else (prayerCfg?.iqamaScreenEnabled ?: true)

                if (isFridayKhutbah) {
                    FridayKhutbahScreen(
                        secondsRemaining = secondsRemaining,
                        currentDurationMinutes = durationMins,
                        isAutoKhutbahEnabled = isScreenEnabled,
                        onSaveSettings = { newDur, isEnabled ->
                            val existingConfig = settings.getPrayerConfig(PrayerType.FRIDAY_SECOND)
                            val updatedSettings = settings.copy(
                                isFridayKhutbahMode = isEnabled,
                                fridayKhutbahDurationMinutes = newDur
                            ).withPrayerConfig(existingConfig.copy(iqamaScreenDurationMinutes = newDur))
                            viewModel.updateSettings(updatedSettings)
                        },
                        onDismiss = {
                            if (isPreviewingIqamaScreen) {
                                viewModel.dismissIqamaPreview()
                            } else {
                                viewModel.dismissIqamaScreen()
                            }
                        }
                    )
                } else {
                    FullScreenIqamaScreen(
                        config = iqamaConfig,
                        secondsRemaining = secondsRemaining,
                        isFridayKhutbah = false,
                        prayerName = prayerDisplayName,
                        prayerType = targetPrayerType,
                        currentIqamaDurationMinutes = iqamaMinutes,
                        currentAdhkarDurationMinutes = adhkarMinutes,
                        isAutoIqamaScreenEnabled = isScreenEnabled,
                        onSaveSettings = { newIqamaDur, newAdhkarDur, isEnabled ->
                            val targetType = targetPrayerType ?: PrayerType.DHUHR
                            val existingConfig = settings.getPrayerConfig(targetType)
                            val updatedPrayerConfig = existingConfig.copy(
                                iqamaScreenDurationMinutes = newIqamaDur,
                                iqamaScreenEnabled = isEnabled
                            )
                            val updatedSettings = settings.copy(
                                globalIqamaScreenDurationMinutes = newIqamaDur,
                                postPrayerAdhkarDurationMinutes = newAdhkarDur
                            ).withPrayerConfig(updatedPrayerConfig)
                            viewModel.updateSettings(updatedSettings)
                        },
                        onDismiss = {
                            if (isPreviewingIqamaScreen) {
                                viewModel.dismissIqamaPreview()
                            } else {
                                viewModel.dismissIqamaScreen()
                            }
                        }
                    )
                }
            }

            // Full-Screen Post-Prayer Adhkar Screen Overlay («أذكار بعد الصلاة»)
            if (isAdhkarScreenActive || isPreviewingAdhkarScreen) {
                val totalDurationSecs = (settings.postPrayerAdhkarDurationMinutes * 60L).coerceAtLeast(60L)
                val secondsRemaining = if (adhkarScreenSecondsRemaining > 0L) {
                    adhkarScreenSecondsRemaining
                } else {
                    totalDurationSecs
                }

                PostPrayerAdhkarScreen(
                    secondsRemaining = secondsRemaining,
                    onDismiss = {
                        if (isPreviewingAdhkarScreen) {
                            viewModel.dismissAdhkarPreview()
                        } else {
                            viewModel.dismissAdhkarScreen()
                        }
                    },
                    onOpenSettings = {
                        settingsDialogTab = 2
                        showSettingsDialog = true
                    }
                )
            }
        }
    }
}
