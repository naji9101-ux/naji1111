package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun MinuteAdjuster(
    value: Int,
    onValueChange: (Int) -> Unit,
    minValue: Int = 1,
    maxValue: Int = 120,
    title: String = "تعديل القيمة",
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    var showEditDialog by remember { mutableStateOf(false) }

    Surface(
        shape = RoundedCornerShape(10.dp),
        color = if (enabled) MosqueDeepGreen else MosqueDeepGreen.copy(alpha = 0.4f),
        border = BorderStroke(1.2.dp, if (enabled) MosqueGold.copy(alpha = 0.85f) else MosqueGold.copy(alpha = 0.25f)),
        modifier = modifier
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.padding(horizontal = 2.dp, vertical = 2.dp)
        ) {
            // Button + FIRST (appears on the RIGHT in RTL)
            IconButton(
                onClick = {
                    val newVal = (value + 1).coerceAtMost(maxValue)
                    onValueChange(newVal)
                },
                enabled = enabled,
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(8.dp))
            ) {
                Text(
                    text = "+",
                    color = if (enabled) MosqueLightGold else MosqueLightGold.copy(alpha = 0.3f),
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center
                )
            }

            Box(
                modifier = Modifier
                    .defaultMinSize(minWidth = 56.dp, minHeight = 38.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (enabled) MosqueVeryDarkGreen else MosqueVeryDarkGreen.copy(alpha = 0.4f))
                    .border(1.dp, if (enabled) MosqueGold.copy(alpha = 0.6f) else MosqueGold.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                    .clickable(enabled = enabled) { showEditDialog = true }
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "$value",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    color = if (enabled) MosqueWhite else MosqueWhite.copy(alpha = 0.4f),
                    fontFamily = FontFamily.SansSerif,
                    textAlign = TextAlign.Center
                )
            }

            // Button - LAST (appears on the LEFT in RTL)
            IconButton(
                onClick = {
                    val newVal = (value - 1).coerceAtLeast(minValue)
                    onValueChange(newVal)
                },
                enabled = enabled,
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(8.dp))
            ) {
                Text(
                    text = "-",
                    color = if (enabled) MosqueLightGold else MosqueLightGold.copy(alpha = 0.3f),
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center
                )
            }
        }
    }

    if (showEditDialog) {
        var textInput by remember {
            mutableStateOf(
                TextFieldValue(
                    text = value.toString(),
                    selection = TextRange(0, value.toString().length)
                )
            )
        }
        val focusRequester = remember { FocusRequester() }

        AlertDialog(
            onDismissRequest = { showEditDialog = false },
            containerColor = MosqueVeryDarkGreen,
            shape = RoundedCornerShape(16.dp),
            title = {
                Text(
                    text = title,
                    color = MosqueLightGold,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "أدخل القيمة يدوياً ($minValue إلى $maxValue):",
                        color = MosqueIvory,
                        fontSize = 14.sp
                    )
                    OutlinedTextField(
                        value = textInput,
                        onValueChange = {
                            val filtered = it.text.filter { ch -> ch.isDigit() }
                            textInput = it.copy(text = filtered)
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Number,
                            imeAction = ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(
                            onDone = {
                                val entered = textInput.text.toIntOrNull()
                                if (entered != null) {
                                    onValueChange(entered.coerceIn(minValue, maxValue))
                                }
                                showEditDialog = false
                            }
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = MosqueWhite,
                            unfocusedTextColor = MosqueWhite,
                            focusedBorderColor = MosqueGold,
                            unfocusedBorderColor = MosqueGold.copy(alpha = 0.5f),
                            cursorColor = MosqueLightGold
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .focusRequester(focusRequester)
                    )
                    LaunchedEffect(Unit) {
                        focusRequester.requestFocus()
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val entered = textInput.text.toIntOrNull()
                        if (entered != null) {
                            onValueChange(entered.coerceIn(minValue, maxValue))
                        }
                        showEditDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MosqueGold),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("تأكيد", color = MosqueVeryDarkGreen, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditDialog = false }) {
                    Text("إلغاء", color = MosqueLightGold)
                }
            }
        )
    }
}
