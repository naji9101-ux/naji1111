package com.example.ui.abbasi

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/**
 * Color palette and gradient specifications for the Abbasi Blue & Gold Mosque Theme.
 * Derived with pixel-level precision from the reference visual design.
 */
object AbbasiThemeColors {
    // Background gradients
    val GradientTop = Color(0xFF0F4F8E)
    val GradientMid = Color(0xFF13589D)
    val GradientDeep = Color(0xFF0A3366)
    val GradientBottom = Color(0xFF051D3C)

    val BackgroundGradient = Brush.verticalGradient(
        colors = listOf(
            GradientTop,
            GradientMid,
            GradientDeep,
            GradientBottom
        )
    )

    // Top Header Banner
    val HeaderBannerSky = Color(0xFF0288D1)
    val HeaderBannerBright = Color(0xFF03A9F4)
    val HeaderBannerGradient = Brush.horizontalGradient(
        colors = listOf(
            Color(0xFF0277BD),
            HeaderBannerBright,
            Color(0xFF0277BD)
        )
    )

    // Gold Tones (Accent, Borders, Calligraphy)
    val PrimaryGold = Color(0xFFECC469)
    val LightGold = Color(0xFFFFE082)
    val BrightGold = Color(0xFFFFD54F)
    val DeepGold = Color(0xFFC79E3A)
    val FrameGold = Color(0xFFE5C158)
    val FrameGoldInner = Color(0xFFD4AF37)

    // Time Boxes & Containers
    val TimeBoxBackground = Color(0xFF08274C)
    val TimeBoxBorder = Color(0xFFE5C158).copy(alpha = 0.85f)

    // Active Prayer Highlight
    val ActiveTimeBoxBackground = Color(0xFF0288D1)
    val ActiveTimeBoxBorder = Color(0xFFFFD54F)
    val ActivePrayerGlow = Color(0xFF40C4FF)

    // Analog Clock
    val ClockDialBackground = Color(0xFF072142)
    val ClockRim = Color(0xFFFFFFFF)
    val ClockNumerals = Color(0xFFFFFFFF)
    val ClockHandsWhite = Color(0xFFFFFFFF)
    val ClockSecondHand = Color(0xFFFFC107)

    // Architectural Silhouettes
    val SilhouetteBlue = Color(0xFF64B5F6)
    val SilhouetteAlpha = 0.16f

    // Lantern
    val LanternGold = Color(0xFFECC469)
    val LanternGlow = Color(0xFFFFE57F)

    // Reference Screenshot specific colors (عاشرًا: الألوان المقترحة)
    val BackgroundNavy = Color(0xFF082D59)
    val InnerNavy = Color(0xFF0B3B70)
    val BoxDarkNavy = Color(0xFF092B52)
    val BoxDarkNavyEnd = Color(0xFF051D3A)
    val BrightCyan = Color(0xFF079FDC)
    val BrightCyanEnd = Color(0xFF0277BD)
    val PrimaryGoldExact = Color(0xFFD8B64F)
    val LightGoldExact = Color(0xFFF1D77A)
    val WhiteExact = Color(0xFFFFFFFF)
    val DividerBlue = Color(0xFF1A6194)

    val MosqueStripCyan = Color(0xFF079FDC)
    val ActiveBorderCyan = Color(0xFF079FDC)
    val ActiveBoxBorderCyan = Color(0xFF00E5FF)
    val ActiveBoxBgCyan = Color(0xFF0288D1)
    val ScreenDarkBackground = Color(0xFF082D59)

    // Professional Metallic Gold Gradients
    val MetallicGoldGradient = Brush.linearGradient(
        colors = listOf(
            Color(0xFFECC469),
            Color(0xFFFFF1B0),
            Color(0xFFD4AF37),
            Color(0xFFFFDF73),
            Color(0xFFC79E3A)
        )
    )

    val SubtleGoldBorder = Brush.linearGradient(
        colors = listOf(
            Color(0xFFE5C158),
            Color(0xFFFFE082),
            Color(0xFFD4AF37),
            Color(0xFFFFD54F)
        )
    )

    // Digital Box Gradients
    val DigitalBoxGradient = Brush.verticalGradient(
        colors = listOf(
            Color(0xFF0C3464),
            Color(0xFF08264A),
            Color(0xFF061E3B)
        )
    )

    val ActivePrayerGlowGradient = Brush.verticalGradient(
        colors = listOf(
            Color(0xFF03A9F4),
            Color(0xFF0288D1),
            Color(0xFF01579B)
        )
    )

    val CyanStripGradient = Brush.verticalGradient(
        colors = listOf(
            Color(0xFF03A9F4),
            Color(0xFF079FDC),
            Color(0xFF0277BD)
        )
    )

    val DividerBlueGradient = Brush.verticalGradient(
        colors = listOf(
            Color(0x001A6194),
            Color(0xFF1A6194),
            Color(0xFF2980B9),
            Color(0xFF1A6194),
            Color(0x001A6194)
        )
    )
}
