package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PrayerRowItem
import com.example.model.PrayerType
import com.example.ui.theme.*

@Composable
fun PrayerTableSection(
    prayers: List<PrayerRowItem>,
    highlightCurrentPrayer: Boolean = false,
    backgroundAlpha: Float = 0.94f,
    elementsSize: Int = 18,
    onPrayerClick: (PrayerRowItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val isTransparent = backgroundAlpha <= 0.05f

    Column(
        modifier = modifier
            .fillMaxHeight()
            .then(
                if (!isTransparent) Modifier.shadow(4.dp, RoundedCornerShape(16.dp))
                else Modifier
            )
            .clip(RoundedCornerShape(16.dp))
            .background(
                if (isTransparent) Color.Transparent
                else MosqueVeryDarkGreen.copy(alpha = backgroundAlpha.coerceIn(0.0f, 0.98f))
            )
            .border(
                1.2.dp,
                MosqueGold,
                RoundedCornerShape(16.dp)
            )
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Table Header: الصلاة (Right) | الأذان والرمز (Left, close to each other)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "الصلاة",
                modifier = Modifier
                    .weight(1.3f)
                    .padding(start = 8.dp),
                textAlign = TextAlign.Start,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MosqueLightGold
            )
            Text(
                text = "الأذان",
                modifier = Modifier.weight(1.05f),
                textAlign = TextAlign.Center,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MosqueLightGold
            )
            Text(
                text = "الرمز",
                modifier = Modifier.weight(0.45f),
                textAlign = TextAlign.Center,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MosqueLightGold
            )
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(MosqueGold.copy(alpha = 0.35f))
        )

        // Distribute height evenly across prayer rows
        prayers.forEach { prayer ->
            PrayerRow(
                prayer = prayer,
                highlightCurrentPrayer = highlightCurrentPrayer,
                elementsSize = elementsSize,
                onClick = { onPrayerClick(prayer) },
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            )
        }
    }
}

@Composable
fun PrayerRow(
    prayer: PrayerRowItem,
    highlightCurrentPrayer: Boolean = false,
    elementsSize: Int = 18,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isNextActive = prayer.isNext
    val isCurrentActive = highlightCurrentPrayer && prayer.isCurrent
    val scaleFactor = (elementsSize.toFloat() / 18f).coerceIn(0.65f, 1.45f)

    // Row Background Color
    val rowBgColor by animateColorAsState(
        targetValue = when {
            isNextActive -> MosqueGold
            isCurrentActive -> Color(0xFF2E7D32)
            else -> Color.Transparent
        },
        animationSpec = tween(500),
        label = "prayerRowBg"
    )

    // Row Outer Border
    val rowBorderColor by animateColorAsState(
        targetValue = when {
            isNextActive -> MosqueLightGold
            isCurrentActive -> Color(0xFF81C784)
            else -> Color.Transparent
        },
        animationSpec = tween(500),
        label = "prayerRowBorder"
    )

    val rowBorderWidth = if (isNextActive || isCurrentActive) 1.5.dp else 0.dp

    Row(
        modifier = modifier
            .testTag("prayer_row_${prayer.type.id}")
            .clip(RoundedCornerShape(8.dp))
            .background(rowBgColor)
            .border(rowBorderWidth, rowBorderColor, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // 1. Prayer Name Container (Right side - Independent and prominent)
        Box(
            modifier = Modifier
                .weight(1.3f)
                .padding(start = 6.dp, end = 2.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            if (isNextActive || isCurrentActive) {
                Box(
                    modifier = Modifier
                        .wrapContentWidth()
                        .heightIn(min = (28f * scaleFactor).coerceIn(24f, 40f).dp, max = (36f * scaleFactor).coerceIn(30f, 46f).dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MosqueVeryDarkGreen)
                        .border(1.dp, MosqueGold.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = prayer.name,
                        fontSize = if (prayer.isFriday) (14.5f * scaleFactor).sp else (17f * scaleFactor).sp,
                        fontWeight = FontWeight.Bold,
                        color = MosqueWhite,
                        maxLines = 1,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                Text(
                    text = prayer.name,
                    fontSize = if (prayer.isFriday) (15.5f * scaleFactor).sp else (18f * scaleFactor).sp,
                    fontWeight = FontWeight.Bold,
                    color = MosqueWhite,
                    maxLines = 1,
                    textAlign = TextAlign.Start,
                    modifier = Modifier.padding(horizontal = 2.dp)
                )
            }
        }

        // 2. Adhan Time Container (Opposite side, closely paired with Icon)
        Box(
            modifier = Modifier
                .weight(1.05f)
                .padding(horizontal = 2.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = (28f * scaleFactor).coerceIn(24f, 40f).dp, max = (36f * scaleFactor).coerceIn(30f, 46f).dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MosqueIvory)
                    .border(1.2.dp, MosqueGold.copy(alpha = 0.75f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 4.dp, vertical = 2.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = prayer.adhanTime,
                    fontSize = (18.5f * scaleFactor).sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MosqueVeryDarkGreen,
                    fontFamily = FontFamily.SansSerif,
                    textAlign = TextAlign.Center,
                    maxLines = 1
                )
            }
        }

        // 3. Icon Container (Opposite side, right next to Adhan with small tight gap)
        Box(
            modifier = Modifier
                .weight(0.45f)
                .padding(start = 2.dp, end = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            PrayerIconBox(
                prayerType = prayer.type,
                customIconUri = prayer.customIconUri,
                boxSize = (34f * scaleFactor).coerceIn(24f, 46f).dp,
                iconColor = MosqueLightGold,
                backgroundColor = MosqueDeepGreen,
                borderColor = MosqueGold.copy(alpha = 0.5f),
                cornerRadius = (8f * scaleFactor).coerceIn(6f, 12f).dp
            )
        }
    }
}
