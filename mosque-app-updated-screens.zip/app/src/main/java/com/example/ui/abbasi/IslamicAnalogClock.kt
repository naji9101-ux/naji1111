package com.example.ui.abbasi

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import java.time.LocalTime
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * High-precision Islamic Analog Clock with clean circular dial,
 * 1-12 Arabic-European numerals, minute tick marks, hands, and digital time overlay.
 */
@Composable
fun IslamicAnalogClock(
    currentTime: LocalTime,
    modifier: Modifier = Modifier,
    size: Dp = 120.dp,
    showSeconds: Boolean = true,
    showDigitalInside: Boolean = true
) {
    Box(
        modifier = modifier
            .size(size)
            .aspectRatio(1f),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasWidth = this.size.width
            val canvasHeight = this.size.height
            val center = Offset(canvasWidth / 2f, canvasHeight / 2f)
            val outerRadius = min(canvasWidth, canvasHeight) / 2f - 4f
            val clockDialColor = AbbasiThemeColors.ClockDialBackground
            val rimColor = AbbasiThemeColors.ClockRim

            // 1. Clock Face Background
            drawCircle(
                color = clockDialColor,
                radius = outerRadius,
                center = center
            )

            // 2. Outer Thin White Rim
            drawCircle(
                color = rimColor,
                radius = outerRadius,
                center = center,
                style = Stroke(width = 2.dp.toPx())
            )

            // Inner subtle concentric guide
            drawCircle(
                color = Color.White.copy(alpha = 0.12f),
                radius = outerRadius * 0.94f,
                center = center,
                style = Stroke(width = 1.dp.toPx())
            )

            // 3. Tick Marks
            for (i in 0 until 60) {
                val angleRad = Math.toRadians((i * 6.0))
                val isHourMark = i % 5 == 0
                val tickLength = if (isHourMark) outerRadius * 0.10f else outerRadius * 0.05f
                val strokeWidth = if (isHourMark) 1.8.dp.toPx() else 0.9.dp.toPx()
                val tickColor = if (isHourMark) Color.White else Color.White.copy(alpha = 0.55f)

                val startRadius = outerRadius * 0.92f - tickLength
                val endRadius = outerRadius * 0.92f

                val startX = center.x + startRadius * sin(angleRad).toFloat()
                val startY = center.y - startRadius * cos(angleRad).toFloat()
                val endX = center.x + endRadius * sin(angleRad).toFloat()
                val endY = center.y - endRadius * cos(angleRad).toFloat()

                drawLine(
                    color = tickColor,
                    start = Offset(startX, startY),
                    end = Offset(endX, endY),
                    strokeWidth = strokeWidth,
                    cap = StrokeCap.Round
                )
            }

            // 4. Numbers 1 to 12
            val textPaint = Paint().apply {
                color = android.graphics.Color.WHITE
                textAlign = Paint.Align.CENTER
                textSize = outerRadius * 0.19f
                isAntiAlias = true
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            }

            val numeralRadius = outerRadius * 0.70f
            for (hour in 1..12) {
                val angleRad = Math.toRadians((hour * 30.0))
                val x = center.x + numeralRadius * sin(angleRad).toFloat()
                val y = center.y - numeralRadius * cos(angleRad).toFloat() + (textPaint.textSize / 3f)

                drawContext.canvas.nativeCanvas.drawText(
                    hour.toString(),
                    x,
                    y,
                    textPaint
                )
            }

            // 5. Digital Time inside the dial (e.g. 11:20)
            if (showDigitalInside) {
                val digitalPaint = Paint().apply {
                    color = android.graphics.Color.WHITE
                    textAlign = Paint.Align.CENTER
                    textSize = outerRadius * 0.22f
                    isAntiAlias = true
                    typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                }
                val digitalY = center.y + outerRadius * 0.38f
                val digitalText = String.format(java.util.Locale.US, "%02d:%02d", currentTime.hour, currentTime.minute)
                drawContext.canvas.nativeCanvas.drawText(
                    digitalText,
                    center.x,
                    digitalY,
                    digitalPaint
                )
            }

            // 6. Clock Hands
            val hours = currentTime.hour % 12
            val minutes = currentTime.minute
            val seconds = currentTime.second

            // Hour Hand
            val hourAngleRad = Math.toRadians(((hours + minutes / 60.0 + seconds / 3600.0) * 30.0))
            val hourHandLength = outerRadius * 0.50f
            val hourEndX = center.x + hourHandLength * sin(hourAngleRad).toFloat()
            val hourEndY = center.y - hourHandLength * cos(hourAngleRad).toFloat()

            drawLine(
                color = Color.White,
                start = center,
                end = Offset(hourEndX, hourEndY),
                strokeWidth = 3.5.dp.toPx(),
                cap = StrokeCap.Round
            )

            // Minute Hand
            val minuteAngleRad = Math.toRadians(((minutes + seconds / 60.0) * 6.0))
            val minuteHandLength = outerRadius * 0.72f
            val minuteEndX = center.x + minuteHandLength * sin(minuteAngleRad).toFloat()
            val minuteEndY = center.y - minuteHandLength * cos(minuteAngleRad).toFloat()

            drawLine(
                color = Color.White,
                start = center,
                end = Offset(minuteEndX, minuteEndY),
                strokeWidth = 2.4.dp.toPx(),
                cap = StrokeCap.Round
            )

            // Second Hand (if enabled)
            if (showSeconds) {
                val secondAngleRad = Math.toRadians((seconds * 6.0))
                val secondHandLength = outerRadius * 0.82f
                val secondTailLength = outerRadius * 0.18f

                val secondEndX = center.x + secondHandLength * sin(secondAngleRad).toFloat()
                val secondEndY = center.y - secondHandLength * cos(secondAngleRad).toFloat()
                val secondTailX = center.x - secondTailLength * sin(secondAngleRad).toFloat()
                val secondTailY = center.y + secondTailLength * cos(secondAngleRad).toFloat()

                drawLine(
                    color = AbbasiThemeColors.ClockSecondHand,
                    start = Offset(secondTailX, secondTailY),
                    end = Offset(secondEndX, secondEndY),
                    strokeWidth = 1.2.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }

            // 7. Center Golden Pin
            drawCircle(
                color = AbbasiThemeColors.PrimaryGold,
                radius = 3.8.dp.toPx(),
                center = center
            )
            drawCircle(
                color = Color.White,
                radius = 1.5.dp.toPx(),
                center = center
            )
        }
    }
}
