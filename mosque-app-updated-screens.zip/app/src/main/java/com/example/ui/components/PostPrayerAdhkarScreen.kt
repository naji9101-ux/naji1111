package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import com.example.R
import java.util.Locale
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

// =====================================================================
//  شاشة «أذكار بعد الصلاة» — تعرض ملف HTML المرفق مع عدّاد التطبيق وإعداداته.
//  الدوال الرسومية السابقة أدناه محفوظة؛ العرض الحالي يستخدم HtmlDesignScreen.
// =====================================================================

private val AdhkarFont = FontFamily(
    Font(R.font.cairo_design, FontWeight.Normal),
    Font(R.font.cairo_design_bold, FontWeight.Bold)
)

// ===== الألوان (تُعدَّل من هنا فقط) =====
private val CreamLight = Color(0xFFFFF9EA)
private val CreamDark = Color(0xFFF3E6C6)
private val GoldBright = Color(0xFFF6D56A)
private val GoldMid = Color(0xFFD9A93B)
private val GoldDark = Color(0xFF9A6A12)
private val BlueTop = Color(0xFF2456B8)
private val BlueBottom = Color(0xFF0B2A6E)
private val BannerTop = Color(0xFF123F98)
private val BannerBottom = Color(0xFF071F58)
private val CardTop = Color(0xFFFFFDF8)
private val CardBottom = Color(0xFFF6EBD0)
private val InkNavy = Color(0xFF0E1B4A)
private val SilhouetteGold = Color(0xFFC79A3E)

private val GoldEdge = Brush.verticalGradient(listOf(GoldBright, GoldMid, GoldDark))

/** محوّل وحدة التصميم المرجعي إلى dp/sp */
private class AdhkarUnit(val u: Float, private val density: Density) {
    fun dp(x: Float): Dp = (x * u).dp
    fun sp(x: Float): TextUnit = with(density) { (x * u).dp.toSp() }
}

private class CardData(val number: Int, val text: String, val size: Float)

private val RightCards = listOf(
    CardData(1, "أَسْتَغْفِرُ اللَّهَ ، أَسْتَغْفِرِ اللَّهَ ، أَسْتَغْفِرُ اللَّهَ", 34f) to 94f,
    CardData(2, "اللهم أنت السلام، ومنك السلام،\nتباركت يا ذا الجلال والإكرام", 33f) to 109f,
    CardData(
        3,
        "لا إله إلا الله وحده لا شريك له، له المُلك وله الحمد،\n" +
            "وهو على كلِ شيءٍ قدير، لا حولَ ولا قوة إلا بالله،\n" +
            "لا إله إلا الله، ولا نعبد إلا إياهُ، له النعمة وله الفضلُ،\n" +
            "وله الثناء الحسن، لا إله إلا اللهُ مخلصين له الدين\n" +
            "ولو كره الكافرون",
        29f
    ) to 223f,
    CardData(4, "اللهم لا مانع لما أعطيت، ولا معطي لما منعت،\nولا ينفع ذا الجد منك الجد", 31f) to 110f,
    CardData(
        5,
        "سبحان الله (33)، والحمد لله (33)، والله أكبر (33)\n" +
            "— وتمام المئة: لا إله إلا الله وحده لا شريك له،\n" +
            "له المُلك وله الحمد، وهو على كلِ شيءٍ قدير",
        29f
    ) to 145f
)

private val LeftCards = listOf(
    CardData(
        6,
        "لا إله إلا الله وحده لا شريك له، له المُلك وله الحمد،\n" +
            "يحيي ويميت وهو على كل شيءٍ قدير\n" +
            "(عشر مرات بعد صلاتي الفجر والمغرب)",
        28.5f
    ) to 141f,
    CardData(7, "آيةُ الكرسي: «اَللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ»\n(البقرة 255 — مرة واحدة)", 31f) to 121f,
    CardData(
        8,
        "المعوِّذات: «قَلْ هو الله أحد»\n" +
            "«قَلَ أعوذ برب الفلق»، «قل أعوذ برب الناس»\n" +
            "(مرة، وثلاثاً بعد الفجر والمغرب)",
        30f
    ) to 157f,
    CardData(
        9,
        "اللهم إني أسألك علماً نافعاً، ورزقاً طيباً،\nوعملاً متقبلاً\n(بعد السلام من صلاة الفجر)",
        30f
    ) to 147f,
    CardData(10, "اللهم أعني على ذكرك وشكرك\nوحسن عبادتك", 34f) to 118f
)

// ---------------------------- الشاشة ----------------------------

@Composable
fun PostPrayerAdhkarScreen(
    secondsRemaining: Long,
    onDismiss: () -> Unit,
    onOpenSettings: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onDismiss)

    LaunchedEffect(secondsRemaining) {
        if (secondsRemaining <= 0L) {
            onDismiss()
        }
    }

    val safeSeconds = secondsRemaining.coerceAtLeast(0L)
    val timeText = String.format(Locale.US, "%d:%02d", safeSeconds / 60, safeSeconds % 60)
    HtmlDesignScreen(
        assetName = "adhkar.html",
        state = org.json.JSONObject().put("countdown", timeText),
        onAction = { action ->
            when (action) {
                "settings" -> onOpenSettings()
                "dismiss" -> onDismiss()
            }
        },
        modifier = modifier,
        screenTag = "post_prayer_adhkar_screen"
    )
}

@Composable
private fun LandscapeContent(ud: AdhkarUnit) {
    Row(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = ud.dp(206f), bottom = ud.dp(20f), start = ud.dp(32f), end = ud.dp(35f))
    ) {
        // أول عنصر في RTL = العمود الأيمن (1 → 5)
        Column(
            modifier = Modifier.weight(1f).fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(ud.dp(9f))
        ) {
            RightCards.forEach { (card, h) -> AdhkarCard(ud, card, Modifier.weight(h)) }
        }
        Spacer(Modifier.width(ud.dp(55f)))
        Column(
            modifier = Modifier.weight(1f).fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(ud.dp(10f))
        ) {
            LeftCards.forEach { (card, h) -> AdhkarCard(ud, card, Modifier.weight(h)) }
        }
    }
}

@Composable
private fun PortraitContent(ud: AdhkarUnit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(start = ud.dp(24f), end = ud.dp(24f), top = ud.dp(210f), bottom = ud.dp(30f)),
        verticalArrangement = Arrangement.spacedBy(ud.dp(12f))
    ) {
        (RightCards + LeftCards).sortedBy { it.first.number }.forEach { (card, h) ->
            AdhkarCard(ud, card, Modifier.height(ud.dp(h * 1.15f)))
        }
    }
}

// ---------------------------- البطاقة ----------------------------

@Composable
private fun AdhkarCard(ud: AdhkarUnit, card: CardData, modifier: Modifier) {
    val shape = RoundedCornerShape(ud.dp(16f))
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.verticalGradient(listOf(CardTop, CardBottom)))
            .border(ud.dp(2.6f), GoldEdge, shape)
            .padding(ud.dp(4f))
            .border(ud.dp(1f), GoldMid.copy(alpha = 0.35f), RoundedCornerShape(ud.dp(12f)))
    ) {
        Row(
            modifier = Modifier.fillMaxSize().padding(horizontal = ud.dp(10f)),
            verticalAlignment = Alignment.CenterVertically
        ) {
            NumberBadge(ud, card.number)
            OvFitBox(modifier = Modifier.weight(1f).fillMaxHeight()) {
                Text(
                    text = card.text,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = ud.dp(8f)),
                    style = TextStyle(
                        fontFamily = AdhkarFont,
                        fontWeight = FontWeight.Bold,
                        fontSize = ud.sp(card.size),
                        lineHeight = ud.sp(card.size * 1.38f),
                        color = InkNavy,
                        textAlign = TextAlign.Center
                    )
                )
            }
        }
    }
}

@Composable
private fun NumberBadge(ud: AdhkarUnit, n: Int) {
    Box(Modifier.size(ud.dp(62f)), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = size.minDimension / 2f
            drawCircle(
                Brush.radialGradient(
                    listOf(Color(0xFFFFE9A6), Color(0xFFE0A52A), Color(0xFF9A6410)),
                    center = Offset(r * 0.85f, r * 0.7f),
                    radius = r * 1.35f
                ),
                radius = r
            )
            drawCircle(Color(0xFF7B4B10), radius = r * 0.95f, style = Stroke(r * 0.1f))
            drawCircle(Color(0xFFFFE08A), radius = r * 0.78f, style = Stroke(r * 0.04f))
        }
        Text(
            text = n.toString(),
            style = TextStyle(
                fontFamily = AdhkarFont,
                fontWeight = FontWeight.Bold,
                fontSize = ud.sp(34f),
                color = Color.White,
                shadow = Shadow(Color(0xAA5A3300), Offset(0f, 3f), 4f)
            )
        )
    }
}

// ---------------------------- أزرار ----------------------------

@Composable
private fun RoundGoldButton(ud: AdhkarUnit, tag: String, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .size(ud.dp(52f))
            .testTag(tag)
            .clip(CircleShape)
            .background(Brush.verticalGradient(listOf(BannerTop, BannerBottom)))
            .border(ud.dp(2.6f), GoldEdge, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
private fun CloseGlyph(size: Dp, stroke: Dp) {
    Canvas(Modifier.size(size)) {
        val s = this.size.minDimension
        val w = stroke.toPx()
        drawLine(GoldBright, Offset(0f, 0f), Offset(s, s), strokeWidth = w, cap = StrokeCap.Round)
        drawLine(GoldBright, Offset(s, 0f), Offset(0f, s), strokeWidth = w, cap = StrokeCap.Round)
    }
}

@Composable
private fun GearStar(size: Dp) {
    Canvas(Modifier.size(size)) {
        val s = this.size.minDimension
        val c = Offset(s / 2f, s / 2f)
        val path = starPath(c, s * 0.5f, s * 0.38f, 8)
        drawPath(path, GoldBright)
        drawPath(path, GoldBright, style = Stroke(s * 0.06f, join = StrokeJoin.Round))
        drawCircle(BannerBottom, radius = s * 0.2f, center = c)
        drawCircle(GoldBright, radius = s * 0.07f, center = c)
    }
}

private fun starPath(c: Offset, outer: Float, inner: Float, points: Int): Path {
    val path = Path()
    for (i in 0 until points * 2) {
        val ang = Math.PI * i / points - Math.PI / 2.0
        val r = if (i % 2 == 0) outer else inner
        val x = c.x + (r * cos(ang)).toFloat()
        val y = c.y + (r * sin(ang)).toFloat()
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    return path
}

// ---------------------------- الزخارف (بإحداثيات التصميم 1672×941) ----------------------------

private fun DrawScope.drawDecor(w: Float, h: Float, landscape: Boolean) {
    // الإطار الذهبي الرفيع
    drawRoundRect(
        brush = GoldEdge,
        topLeft = Offset(4f, 4f),
        size = Size(w - 8f, h - 8f),
        cornerRadius = CornerRadius(14f, 14f),
        style = Stroke(5f)
    )

    // الزوايا الزرقاء الأربع
    val topScale = if (landscape) 1f else 0.62f
    val botScale = topScale * 0.62f
    withTransform({ scale(topScale, topScale, Offset(0f, 0f)) }) { drawBlueCorner() }
    withTransform({ translate(w, 0f); scale(-topScale, topScale, Offset.Zero) }) { drawBlueCorner() }
    withTransform({ translate(0f, h); scale(botScale, -botScale, Offset.Zero) }) { drawBlueCorner() }
    withTransform({ translate(w, h); scale(-botScale, -botScale, Offset.Zero) }) { drawBlueCorner() }

    if (landscape) {
        // المساجد والفوانيس
        drawMosques()
        withTransform({ translate(w, 0f); scale(-1f, 1f, Offset.Zero) }) { drawMosques() }
    }
    drawLantern(if (landscape) 165f else 120f, 0f)
    drawLantern(w - (if (landscape) 165f else 120f), 0f)

    // إطار العنوان والشريط الفرعي
    val k = if (landscape) 1f else ((w - 60f).coerceAtMost(864f) / 864f)
    drawBanner(w / 2f, k)

    // الفاصل الأوسط
    if (landscape) drawCenterDivider(w / 2f, h)
}

private fun DrawScope.drawBlueCorner() {
    val cw = 215f
    val ch = 290f
    val path = Path().apply {
        moveTo(0f, 0f)
        lineTo(cw, 0f)
        cubicTo(cw * 0.60f, ch * 0.04f, cw * 0.36f, ch * 0.22f, cw * 0.32f, ch * 0.42f)
        cubicTo(cw * 0.28f, ch * 0.64f, cw * 0.12f, ch * 0.82f, 0f, ch)
        close()
    }
    drawPath(
        path,
        Brush.linearGradient(listOf(BlueTop, BlueBottom), start = Offset(0f, 0f), end = Offset(cw, ch))
    )
    // زخرفة ذهبية: أقواس متحدة المركز + نجمة + نقاط
    val gold = GoldBright.copy(alpha = 0.75f)
    listOf(0.28f, 0.46f, 0.64f).forEach { f ->
        drawArc(
            color = gold, startAngle = 0f, sweepAngle = 90f, useCenter = false,
            topLeft = Offset(-cw * f, -cw * f), size = Size(cw * f * 2f, cw * f * 2f),
            style = Stroke(2.2f)
        )
    }
    drawPath(starPath(Offset(cw * 0.22f, ch * 0.2f), 34f, 22f, 8), gold, style = Stroke(2.4f, join = StrokeJoin.Round))
    drawCircle(gold, radius = 5f, center = Offset(cw * 0.22f, ch * 0.2f))
    drawCircle(gold, radius = 3.5f, center = Offset(cw * 0.55f, ch * 0.1f))
    drawCircle(gold, radius = 3.5f, center = Offset(cw * 0.12f, ch * 0.55f))
    // حدّ ذهبي مزدوج
    drawPath(path, GoldBright, style = Stroke(6f, join = StrokeJoin.Round))
    drawPath(path, GoldDark.copy(alpha = 0.6f), style = Stroke(1.6f, join = StrokeJoin.Round))
}

private fun DrawScope.drawMosques() {
    val fade = Brush.verticalGradient(
        listOf(SilhouetteGold.copy(alpha = 0.70f), SilhouetteGold.copy(alpha = 0.05f)),
        startY = 50f, endY = 192f
    )
    // قاعدة
    drawRoundRect(fade, Offset(40f, 168f), Size(440f, 22f), CornerRadius(8f, 8f))
    // قبة صغيرة يسار
    drawOval(fade, Offset(53f, 126f), Size(54f, 52f))
    drawRect(fade, Offset(58f, 150f), Size(44f, 40f))
    // المئذنة
    drawRect(fade, Offset(205f, 92f), Size(33f, 98f))
    drawRect(fade, Offset(199f, 84f), Size(45f, 12f))
    drawRect(fade, Offset(208f, 60f), Size(26f, 26f))
    drawOval(fade, Offset(206f, 34f), Size(30f, 38f))
    drawLine(SilhouetteGold.copy(alpha = 0.6f), Offset(221f, 20f), Offset(221f, 38f), strokeWidth = 3f)
    // القبة الكبرى
    val dome = Path().apply {
        moveTo(235f, 190f)
        lineTo(235f, 150f)
        cubicTo(235f, 100f, 275f, 84f, 303f, 84f)
        cubicTo(331f, 84f, 372f, 100f, 372f, 150f)
        lineTo(372f, 190f)
        close()
    }
    drawPath(dome, fade)
    drawArc(
        SilhouetteGold.copy(alpha = 0.85f), 40f, 280f, false,
        Offset(293f, 62f), Size(20f, 20f), style = Stroke(3.5f)
    )
    // مئذنة صغيرة يمين
    drawRect(fade, Offset(372f, 122f), Size(18f, 68f))
    drawOval(fade, Offset(370f, 104f), Size(22f, 28f))
    // قباب صغيرة بين العناصر
    drawOval(fade, Offset(110f, 160f), Size(30f, 26f))
    drawOval(fade, Offset(395f, 158f), Size(34f, 28f))
}

private fun DrawScope.drawLantern(cx: Float, top: Float) {
    val gold = Brush.verticalGradient(listOf(GoldBright, GoldMid, GoldDark), startY = top + 60f, endY = top + 175f)
    drawLine(GoldMid, Offset(cx, top), Offset(cx, top + 54f), strokeWidth = 2f)
    drawCircle(GoldMid, radius = 5f, center = Offset(cx, top + 58f), style = Stroke(2.4f))
    // وهج
    drawCircle(
        Brush.radialGradient(
            listOf(Color(0x99FFE9A0), Color(0x00FFE9A0)),
            center = Offset(cx, top + 112f), radius = 70f
        ),
        radius = 70f, center = Offset(cx, top + 112f)
    )
    // الغطاء
    val cap = Path().apply {
        moveTo(cx - 12f, top + 62f)
        lineTo(cx + 12f, top + 62f)
        lineTo(cx + 27f, top + 80f)
        lineTo(cx - 27f, top + 80f)
        close()
    }
    drawPath(cap, gold)
    // الجسم المضيء
    drawRoundRect(
        Brush.verticalGradient(listOf(Color(0xFFFFF6C8), Color(0xFFF4D273)), startY = top + 80f, endY = top + 148f),
        Offset(cx - 26f, top + 80f), Size(52f, 68f), CornerRadius(4f, 4f)
    )
    listOf(-26f, -9f, 9f, 26f).forEach { dx ->
        drawLine(GoldMid, Offset(cx + dx, top + 80f), Offset(cx + dx, top + 148f), strokeWidth = 3.4f)
    }
    drawRoundRect(gold, Offset(cx - 29f, top + 76f), Size(58f, 7f), CornerRadius(3f, 3f))
    drawRoundRect(gold, Offset(cx - 29f, top + 145f), Size(58f, 9f), CornerRadius(3f, 3f))
    // الطرف السفلي
    val tip = Path().apply {
        moveTo(cx - 20f, top + 154f)
        lineTo(cx + 20f, top + 154f)
        lineTo(cx, top + 174f)
        close()
    }
    drawPath(tip, gold)
}

private fun DrawScope.drawBanner(cx: Float, k: Float) {
    // شريط العنوان الأزرق
    val bw = 864f * k
    val bh = 114f * k
    val bx = cx - bw / 2f
    val by = 8f
    val r = 44f * k
    drawRoundRect(
        Brush.verticalGradient(listOf(BannerTop, BannerBottom), startY = by, endY = by + bh),
        Offset(bx, by), Size(bw, bh), CornerRadius(r, r)
    )
    drawRoundRect(GoldEdge, Offset(bx, by), Size(bw, bh), CornerRadius(r, r), style = Stroke(6f))
    drawRoundRect(
        GoldBright.copy(alpha = 0.55f), Offset(bx + 10f, by + 10f), Size(bw - 20f, bh - 20f),
        CornerRadius(r - 8f, r - 8f), style = Stroke(1.6f)
    )
    // أذنا الشريط الجانبيتان
    listOf(bx, bx + bw).forEach { ex ->
        drawCircle(GoldEdge, radius = 11f * k, center = Offset(ex, by + bh / 2f))
        drawCircle(BannerBottom, radius = 6f * k, center = Offset(ex, by + bh / 2f))
    }

    // الشريط الفرعي الكريمي
    val rw = 724f * k
    val rh = 58f * k
    val rx = cx - rw / 2f
    val ry = 124f * k + 8f * (1f - k)
    drawRoundRect(
        Brush.verticalGradient(listOf(Color(0xFFFFF6D6), Color(0xFFF1D78C)), startY = ry, endY = ry + rh),
        Offset(rx, ry), Size(rw, rh), CornerRadius(rh / 2f, rh / 2f)
    )
    drawRoundRect(GoldEdge, Offset(rx, ry), Size(rw, rh), CornerRadius(rh / 2f, rh / 2f), style = Stroke(4f))
}

private fun DrawScope.drawCenterDivider(cx: Float, h: Float) {
    val top = 205f
    val bottom = h - 20f
    drawLine(GoldEdge, Offset(cx, top), Offset(cx, bottom), strokeWidth = 3.6f)
    val my = (top + bottom) / 2f
    // زخرفة المعيّن في المنتصف
    val outer = Path().apply {
        moveTo(cx, my - 44f); lineTo(cx + 24f, my); lineTo(cx, my + 44f); lineTo(cx - 24f, my); close()
    }
    drawPath(outer, Brush.verticalGradient(listOf(BannerTop, BannerBottom), startY = my - 44f, endY = my + 44f))
    drawPath(outer, GoldEdge, style = Stroke(4f, join = StrokeJoin.Round))
    val inner = Path().apply {
        moveTo(cx, my - 22f); lineTo(cx + 11f, my); lineTo(cx, my + 22f); lineTo(cx - 11f, my); close()
    }
    drawPath(inner, GoldBright)
    drawCircle(BannerBottom, radius = 3.5f, center = Offset(cx, my))
    listOf(-1f, 1f).forEach { s ->
        drawCircle(GoldBright, radius = 5f, center = Offset(cx, my + s * 62f))
    }
}
