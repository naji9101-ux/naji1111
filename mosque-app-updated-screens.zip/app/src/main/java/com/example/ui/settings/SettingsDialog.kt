package com.example.ui.settings

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.VolumeUp
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import com.example.model.AudioFileItem
import com.example.ui.components.SelectedAudioBox
import com.example.ui.components.AudioSourceSelectionRow
import java.time.LocalTime
import java.util.Locale
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.HijriCalendarHelper
import com.example.model.AppSettings
import com.example.model.MosqueSchedule
import com.example.model.PrayerType
import com.example.ui.theme.*
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit

// Theme Colors - Unified Royal Navy Blue & Gold Theme (Matching PrayerDetailDialog & IqamaSettingsTab)
private val ColorAdminBg = ScreenshotNavyBg                   // Color(0xFF071F3D) - نفس خلفية إعدادات الصلوات
private val ColorTopBarBg = ScreenshotNavyDark                // Color(0xFF08274C) - شريط عنوان أزرق كحلي ملكي
private val ColorCardBg = ScreenshotNavyDark                  // Color(0xFF08274C) - نفس لون بطاقات إعدادات الصلوات
private val ColorCardBorder = ScreenshotBorderBlue            // Color(0xFF1A6194) - نفس حدود بطاقات إعدادات الصلوات
private val ColorGoldTitle = ScreenshotGoldPrimary            // Color(0xFFECC469) - نفس ذهبي عناوين إعدادات الصلوات
private val ColorGoldLight = MosqueLightGold                  // Color(0xFFFFE082) - ذهبي فاتح مميز
private val ColorTextDesc = MosqueLightGold.copy(alpha = 0.85f)// نفس لون النصوص التوضيحية في إعدادات الصلوات
private val ColorSaveBtn = ScreenshotNavySurface              // Color(0xFF0B3B70) - نفس كحلي الأزرار والأسطح

@Composable
fun SettingsDialog(
    currentSettings: AppSettings,
    currentSchedule: MosqueSchedule,
    isLocatingGps: Boolean = false,
    initialTab: Int = 0,
    onSaveSchedule: (MosqueSchedule) -> Unit,
    onSaveSettings: (AppSettings) -> Unit,
    onRestoreDefaultSchedule: () -> Unit = {},
    onRestoreDefaultSettings: () -> Unit = {},
    onImportAnnualScheduleUri: (Uri) -> Result<MosqueSchedule> = { Result.failure(Exception()) },
    onRequestGpsLocation: (onResult: (Boolean, String, MosqueSchedule?) -> Unit) -> Unit = {},
    onResetDesignOnly: () -> Unit = {},
    onPreviewIqamaScreen: (PrayerType?) -> Unit = {},
    onPreviewPeriod: (String) -> Unit = {},
    onPreviewAdhkarScreen: () -> Unit = {},
    onOpenPrayerTimesData: (() -> Unit)? = null,
    onTestAudio: ((String?) -> Unit)? = null,
    onStopAudio: (() -> Unit)? = null,
    isPlayingTest: Boolean = false,
    onAddAdhanToLibrary: ((String, Uri) -> AudioFileItem?)? = null,
    onAddFajrAdhanToLibrary: ((String, Uri) -> AudioFileItem?)? = null,
    onAddIqamaToLibrary: ((String, Uri) -> AudioFileItem?)? = null,
    onDeleteAdhanFromLibrary: ((AudioFileItem) -> Unit)? = null,
    onDeleteFajrAdhanFromLibrary: ((AudioFileItem) -> Unit)? = null,
    onDeleteIqamaFromLibrary: ((AudioFileItem) -> Unit)? = null,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    var isUnlocked by remember { mutableStateOf(!currentSettings.isAdminPinEnabled) }
    var pinInput by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }

    // Draft state for live edits
    var draftSettings by remember(currentSettings) { mutableStateOf(currentSettings) }
    LaunchedEffect(currentSettings) {
        if (draftSettings != currentSettings) {
            draftSettings = currentSettings
        }
    }

    // Audio Library dialog states
    var showFajrLibraryDialog by remember { mutableStateOf(false) }
    var showIqamaLibraryDialog by remember { mutableStateOf(false) }
    var showGeneralAdhanLibraryDialog by remember { mutableStateOf(false) }
    var currentlyTestingAudioKey by remember { mutableStateOf<String?>(null) }

    val fajrPhonePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val fileName = uri.lastPathSegment?.substringAfterLast("/") ?: "أذان فجر مخصص"
            val item = onAddFajrAdhanToLibrary?.invoke(fileName, uri)
            if (item != null) {
                val cfg = draftSettings.getPrayerConfig(PrayerType.FAJR_FIRST)
                val updated = draftSettings.withPrayerConfig(cfg.copy(adhanSoundUri = item.uri, adhanSoundName = item.name))
                draftSettings = updated
                onSaveSettings(updated)
            }
        }
    }

    val iqamaPhonePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val fileName = uri.lastPathSegment?.substringAfterLast("/") ?: "إقامة مخصصة"
            val item = onAddIqamaToLibrary?.invoke(fileName, uri)
            if (item != null) {
                val updated = draftSettings.copy(defaultIqamaSound = item.uri)
                draftSettings = updated
                onSaveSettings(updated)
            }
        }
    }

    val adhanPhonePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val fileName = uri.lastPathSegment?.substringAfterLast("/") ?: "أذان مخصص"
            val item = onAddAdhanToLibrary?.invoke(fileName, uri)
            if (item != null) {
                val updated = draftSettings.copy(commonAdhanSound = item.uri)
                draftSettings = updated
                onSaveSettings(updated)
            }
        }
    }

    // Kiosk Mode & Auto-start Home Mode States
    var isKioskModeEnabled by remember(draftSettings.isKioskModeEnabled) {
        mutableStateOf(draftSettings.isKioskModeEnabled)
    }
    var isAutoStartHomeEnabled by remember(draftSettings.isAutoStartHomeEnabled) {
        mutableStateOf(draftSettings.isAutoStartHomeEnabled)
    }

    // Per-section working state
    var mosqueNameInput by remember(draftSettings.mosqueName) { mutableStateOf(draftSettings.mosqueName) }
    var isTimeCorrectionEnabled by remember(draftSettings.isTimeCorrectionEnabled) {
        mutableStateOf(draftSettings.isTimeCorrectionEnabled)
    }
    var timeOffsetHours by remember(draftSettings.timeOffsetHours) {
        mutableIntStateOf(draftSettings.timeOffsetHours)
    }
    var timeOffsetMinutes by remember(draftSettings.timeOffsetMinutes) {
        mutableIntStateOf(draftSettings.timeOffsetMinutes)
    }
    var showDateTimeDialog by remember { mutableStateOf(false) }

    // Clock Picker working state for interactive manual clock adjustment
    val initialEffectiveTime = remember(draftSettings.isTimeCorrectionEnabled, draftSettings.timeOffsetHours, draftSettings.timeOffsetMinutes) {
        val sys = LocalTime.now()
        if (draftSettings.isTimeCorrectionEnabled) {
            val totalMins = (draftSettings.timeOffsetHours.toLong() * 60L) + draftSettings.timeOffsetMinutes.toLong()
            sys.plusMinutes(totalMins)
        } else {
            sys
        }
    }
    var targetHour12 by remember(draftSettings) {
        val h = initialEffectiveTime.hour % 12
        mutableIntStateOf(if (h == 0) 12 else h)
    }
    var targetMinute by remember(draftSettings) {
        mutableIntStateOf(initialEffectiveTime.minute)
    }
    var targetIsPm by remember(draftSettings) {
        mutableStateOf(initialEffectiveTime.hour >= 12)
    }
    var hourInputText by remember(draftSettings) {
        mutableStateOf(String.format(Locale.US, "%02d", targetHour12))
    }
    var minuteInputText by remember(draftSettings) {
        mutableStateOf(String.format(Locale.US, "%02d", targetMinute))
    }
    var isHourFocused by remember { mutableStateOf(false) }
    var isMinuteFocused by remember { mutableStateOf(false) }

    LaunchedEffect(targetHour12) {
        if (!isHourFocused) {
            hourInputText = String.format(Locale.US, "%02d", targetHour12)
        }
    }
    LaunchedEffect(targetMinute) {
        if (!isMinuteFocused) {
            minuteInputText = String.format(Locale.US, "%02d", targetMinute)
        }
    }

    fun calculateOffsetsFromTarget(h12: Int, min: Int, pm: Boolean): Pair<Int, Int> {
        val sysNow = LocalTime.now()
        val sysTotalMinutes = sysNow.hour * 60 + sysNow.minute
        val h24 = when {
            pm && h12 < 12 -> h12 + 12
            !pm && h12 == 12 -> 0
            else -> h12
        }
        val targetTotalMinutes = h24 * 60 + min
        var diffMinutes = targetTotalMinutes - sysTotalMinutes
        while (diffMinutes > 720) diffMinutes -= 1440
        while (diffMinutes < -720) diffMinutes += 1440
        return Pair(diffMinutes / 60, diffMinutes % 60)
    }

    fun addMinutesToTarget(deltaMinutes: Int) {
        val curH24 = when {
            targetIsPm && targetHour12 < 12 -> targetHour12 + 12
            !targetIsPm && targetHour12 == 12 -> 0
            else -> targetHour12
        }
        val currentTotal = (curH24 * 60 + targetMinute + deltaMinutes) % 1440
        val normalizedTotal = if (currentTotal < 0) currentTotal + 1440 else currentTotal
        val newH24 = normalizedTotal / 60
        val newMin = normalizedTotal % 60
        targetHour12 = when (val h = newH24 % 12) {
            0 -> 12
            else -> h
        }
        targetMinute = newMin
        targetIsPm = newH24 >= 12
        hourInputText = String.format(Locale.US, "%02d", targetHour12)
        minuteInputText = String.format(Locale.US, "%02d", targetMinute)
        val (h, m) = calculateOffsetsFromTarget(targetHour12, targetMinute, targetIsPm)
        timeOffsetHours = h
        timeOffsetMinutes = m
        isTimeCorrectionEnabled = true
    }

    fun resetToDeviceTime() {
        val sysNow = LocalTime.now()
        targetHour12 = when (val h = sysNow.hour % 12) {
            0 -> 12
            else -> h
        }
        targetMinute = sysNow.minute
        targetIsPm = sysNow.hour >= 12
        hourInputText = String.format(Locale.US, "%02d", targetHour12)
        minuteInputText = String.format(Locale.US, "%02d", targetMinute)
        timeOffsetHours = 0
        timeOffsetMinutes = 0
        isTimeCorrectionEnabled = false
    }

    // Gregorian Date Picker working state
    val initialEffectiveDate = remember(draftSettings.isDateCorrectionEnabled, draftSettings.gregorianDayOffset) {
        val sysDate = LocalDate.now()
        if (draftSettings.isDateCorrectionEnabled && draftSettings.gregorianDayOffset != 0) {
            sysDate.plusDays(draftSettings.gregorianDayOffset.toLong())
        } else {
            sysDate
        }
    }
    var isDateCorrectionEnabled by remember(draftSettings.isDateCorrectionEnabled) {
        mutableStateOf(draftSettings.isDateCorrectionEnabled)
    }
    var gregorianDayOffset by remember(draftSettings.gregorianDayOffset) {
        mutableIntStateOf(draftSettings.gregorianDayOffset)
    }
    var targetYear by remember(draftSettings) {
        mutableIntStateOf(initialEffectiveDate.year)
    }
    var targetMonth by remember(draftSettings) {
        mutableIntStateOf(initialEffectiveDate.monthValue)
    }
    var targetDay by remember(draftSettings) {
        mutableIntStateOf(initialEffectiveDate.dayOfMonth)
    }

    var dayInputText by remember(draftSettings) {
        mutableStateOf(String.format(Locale.US, "%02d", targetDay))
    }
    var monthInputText by remember(draftSettings) {
        mutableStateOf(String.format(Locale.US, "%02d", targetMonth))
    }
    var yearInputText by remember(draftSettings) {
        mutableStateOf(String.format(Locale.US, "%04d", targetYear))
    }

    var isDayFocused by remember { mutableStateOf(false) }
    var isMonthFocused by remember { mutableStateOf(false) }
    var isYearFocused by remember { mutableStateOf(false) }

    LaunchedEffect(targetDay) {
        if (!isDayFocused) {
            dayInputText = String.format(Locale.US, "%02d", targetDay)
        }
    }
    LaunchedEffect(targetMonth) {
        if (!isMonthFocused) {
            monthInputText = String.format(Locale.US, "%02d", targetMonth)
        }
    }
    LaunchedEffect(targetYear) {
        if (!isYearFocused) {
            yearInputText = String.format(Locale.US, "%04d", targetYear)
        }
    }

    fun calculateDayOffsetFromTarget(year: Int, month: Int, day: Int): Int {
        return try {
            val maxDaysInMonth = YearMonth.of(year, month).lengthOfMonth()
            val validDay = day.coerceIn(1, maxDaysInMonth)
            val target = LocalDate.of(year, month, validDay)
            val sysDate = LocalDate.now()
            ChronoUnit.DAYS.between(sysDate, target).toInt()
        } catch (e: Exception) {
            0
        }
    }

    fun updateTargetDate(newDate: LocalDate) {
        targetYear = newDate.year
        targetMonth = newDate.monthValue
        targetDay = newDate.dayOfMonth
        dayInputText = String.format(Locale.US, "%02d", targetDay)
        monthInputText = String.format(Locale.US, "%02d", targetMonth)
        yearInputText = String.format(Locale.US, "%04d", targetYear)
        gregorianDayOffset = calculateDayOffsetFromTarget(targetYear, targetMonth, targetDay)
        isDateCorrectionEnabled = true
    }

    fun addDaysToTarget(deltaDays: Int) {
        try {
            val maxDays = YearMonth.of(targetYear, targetMonth).lengthOfMonth()
            val curDay = targetDay.coerceIn(1, maxDays)
            val curDate = LocalDate.of(targetYear, targetMonth, curDay)
            val nextDate = curDate.plusDays(deltaDays.toLong())
            updateTargetDate(nextDate)
        } catch (e: Exception) {
            // Fallback
        }
    }

    fun addMonthsToTarget(deltaMonths: Int) {
        try {
            val curDate = LocalDate.of(targetYear, targetMonth, 1)
            val nextMonthDate = curDate.plusMonths(deltaMonths.toLong())
            val maxDays = nextMonthDate.lengthOfMonth()
            val validDay = targetDay.coerceIn(1, maxDays)
            updateTargetDate(LocalDate.of(nextMonthDate.year, nextMonthDate.monthValue, validDay))
        } catch (e: Exception) {
            // Fallback
        }
    }

    fun addYearsToTarget(deltaYears: Int) {
        try {
            val newY = (targetYear + deltaYears).coerceIn(2020, 2060)
            val maxDays = YearMonth.of(newY, targetMonth).lengthOfMonth()
            val validDay = targetDay.coerceIn(1, maxDays)
            updateTargetDate(LocalDate.of(newY, targetMonth, validDay))
        } catch (e: Exception) {
            // Fallback
        }
    }

    fun resetToDeviceDate() {
        val sysDate = LocalDate.now()
        targetYear = sysDate.year
        targetMonth = sysDate.monthValue
        targetDay = sysDate.dayOfMonth
        dayInputText = String.format(Locale.US, "%02d", targetDay)
        monthInputText = String.format(Locale.US, "%02d", targetMonth)
        yearInputText = String.format(Locale.US, "%04d", targetYear)
        gregorianDayOffset = 0
        isDateCorrectionEnabled = false
    }

    // Prayer screen & Adhkar & Khutbah
    var isPrayerScreenEnabled by remember(draftSettings.prayerInterfacesMasterEnabled) {
        mutableStateOf(draftSettings.prayerInterfacesMasterEnabled)
    }

    // Prayer durations (Fajr, Dhuhr, Asr, Maghrib, Isha)
    var fajrDuration by remember(draftSettings) {
        mutableIntStateOf(draftSettings.getPrayerConfig(PrayerType.FAJR_SECOND).iqamaScreenDurationMinutes)
    }
    var dhuhrDuration by remember(draftSettings) {
        mutableIntStateOf(draftSettings.getPrayerConfig(PrayerType.DHUHR).iqamaScreenDurationMinutes)
    }
    var asrDuration by remember(draftSettings) {
        mutableIntStateOf(draftSettings.getPrayerConfig(PrayerType.ASR).iqamaScreenDurationMinutes)
    }
    var maghribDuration by remember(draftSettings) {
        mutableIntStateOf(draftSettings.getPrayerConfig(PrayerType.MAGHRIB).iqamaScreenDurationMinutes)
    }
    var ishaDuration by remember(draftSettings) {
        mutableIntStateOf(draftSettings.getPrayerConfig(PrayerType.ISHA).iqamaScreenDurationMinutes)
    }

    // Adhkar duration
    var adhkarDuration by remember(draftSettings.postPrayerAdhkarDurationMinutes) {
        mutableIntStateOf(draftSettings.postPrayerAdhkarDurationMinutes)
    }

    // Friday Khutbah mode & duration
    var isFridayKhutbahMode by remember(draftSettings.isFridayKhutbahMode) {
        mutableStateOf(draftSettings.isFridayKhutbahMode)
    }
    var fridayKhutbahDuration by remember(draftSettings.fridayKhutbahDurationMinutes) {
        mutableIntStateOf(draftSettings.fridayKhutbahDurationMinutes)
    }

    // Hijri Day Offset
    var hijriDayOffset by remember(draftSettings.hijriDayOffset) {
        mutableIntStateOf(draftSettings.hijriDayOffset)
    }

    // Display & Clock formatting
    var is12HourFormat by remember(draftSettings.is24Hour) {
        mutableStateOf(!draftSettings.is24Hour)
    }
    var showSeconds by remember(draftSettings.showSeconds) {
        mutableStateOf(draftSettings.showSeconds)
    }

    fun compileCurrentSettings(): AppSettings {
        val (computedH, computedM) = calculateOffsetsFromTarget(targetHour12, targetMinute, targetIsPm)
        var updated = draftSettings.copy(
            isKioskModeEnabled = isKioskModeEnabled,
            isAutoStartHomeEnabled = isAutoStartHomeEnabled,
            mosqueName = mosqueNameInput.trim().ifEmpty { "اسم المسجد" },
            isTimeCorrectionEnabled = isTimeCorrectionEnabled,
            timeOffsetHours = if (isTimeCorrectionEnabled) computedH else 0,
            timeOffsetMinutes = if (isTimeCorrectionEnabled) computedM else 0,
            prayerInterfacesMasterEnabled = isPrayerScreenEnabled,
            postPrayerAdhkarEnabled = isPrayerScreenEnabled,
            postPrayerAdhkarDurationMinutes = adhkarDuration,
            isFridayKhutbahMode = isFridayKhutbahMode,
            fridayKhutbahDurationMinutes = fridayKhutbahDuration,
            hijriDayOffset = hijriDayOffset,
            is24Hour = !is12HourFormat,
            showSeconds = showSeconds
        )

        // Update individual prayer durations
        val prayersToUpdate = listOf(
            PrayerType.FAJR_SECOND to fajrDuration,
            PrayerType.DHUHR to dhuhrDuration,
            PrayerType.ASR to asrDuration,
            PrayerType.MAGHRIB to maghribDuration,
            PrayerType.ISHA to ishaDuration,
            PrayerType.FRIDAY_SECOND to fridayKhutbahDuration
        )
        for ((pType, dur) in prayersToUpdate) {
            val existing = updated.getPrayerConfig(pType)
            updated = updated.withPrayerConfig(existing.copy(iqamaScreenDurationMinutes = dur))
        }
        return updated
    }

    fun saveSingleSection(sectionName: String, onApply: (AppSettings) -> AppSettings) {
        val compiled = compileCurrentSettings()
        val finalUpdated = onApply(compiled)
        draftSettings = finalUpdated
        onSaveSettings(finalUpdated)
        Toast.makeText(context, "تم حفظ إعدادات $sectionName بنجاح", Toast.LENGTH_SHORT).show()
    }

    // الخياران مستقلان تماماً: كل خيار يحفظ حالته فقط ولا يغيّر الآخر
    fun applyKioskToggle(newState: Boolean) {
        isKioskModeEnabled = newState
        saveSingleSection("وضع الشاشة الثابتة") { it.copy(isKioskModeEnabled = newState) }
        if (newState) {
            Toast.makeText(context, com.example.util.KioskManager.enableMessage(context), Toast.LENGTH_LONG).show()
        }
    }

    fun applyAutoStartToggle(newState: Boolean) {
        isAutoStartHomeEnabled = newState
        saveSingleSection("وضع الشاشة الرئيسية") { it.copy(isAutoStartHomeEnabled = newState) }
        if (newState) {
            com.example.util.AutoLaunchManager.requestSetup(context)
        } else {
            com.example.util.AutoLaunchManager.cancelPending(context)
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                color = ColorAdminBg,
                modifier = Modifier.fillMaxSize()
            ) {
                if (!isUnlocked) {
                    // PIN Protection Dialog
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = ColorCardBg),
                            border = BorderStroke(1.5.dp, ColorGoldTitle),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth(0.85f)
                                .padding(20.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(28.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = ColorGoldTitle,
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(modifier = Modifier.height(14.dp))
                                Text(
                                    text = "أدخل رمز PIN للمتابعة إلى صفحة الإدارة",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = CairoFamily,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.height(14.dp))
                                OutlinedTextField(
                                    value = pinInput,
                                    onValueChange = {
                                        pinInput = it
                                        pinError = false
                                    },
                                    label = { Text("رمز PIN (الافتراضي: 1234)", color = ColorTextDesc) },
                                    visualTransformation = PasswordVisualTransformation(),
                                    singleLine = true,
                                    isError = pinError,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White,
                                        focusedBorderColor = ColorGoldTitle,
                                        unfocusedBorderColor = ColorCardBorder
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                )
                                if (pinError) {
                                    Text(
                                        text = "رمز PIN غير صحيح",
                                        color = Color.Red,
                                        fontSize = 13.sp,
                                        fontFamily = CairoFamily,
                                        modifier = Modifier.padding(top = 4.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(18.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = onDismiss,
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = ColorGoldTitle),
                                        border = BorderStroke(1.dp, ScreenshotGoldAccent.copy(alpha = 0.6f)),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(46.dp)
                                    ) {
                                        Text(
                                            text = "إلغاء",
                                            fontWeight = FontWeight.Bold,
                                            color = ColorGoldTitle,
                                            fontSize = 14.5.sp,
                                            fontFamily = CairoFamily
                                        )
                                    }
                                    Button(
                                        onClick = {
                                            if (pinInput == draftSettings.adminPin) {
                                                isUnlocked = true
                                            } else {
                                                pinError = true
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = ColorGoldTitle,
                                            contentColor = Color(0xFF071F3D)
                                        ),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(46.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = null,
                                            tint = Color(0xFF071F3D),
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "دخول",
                                            color = Color(0xFF071F3D),
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.5.sp,
                                            fontFamily = CairoFamily
                                        )
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // Full Admin Page Layout
                    // Left Narrow Black Strip (~52px) on the far left edge + Content Area
                    Row(
                        modifier = Modifier.fillMaxSize()
                    ) {
                        // 1. Right / Center Content Area (RTL Start)
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .background(ColorAdminBg)
                        ) {
                            // -------------------------------------------------------------
                            // شريط العنوان العلوي (Fixed Top Header Bar - Height ~100px)
                            // -------------------------------------------------------------
                            Surface(
                                color = ColorTopBarBg,
                                shadowElevation = 0.dp,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(100.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(horizontal = 24.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    // عنوان الصفحة في المنتصف تماماً
                                    Text(
                                        text = "صفحة الإدارة",
                                        fontSize = 32.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = CairoFamily,
                                        color = ColorGoldTitle,
                                        textAlign = TextAlign.Center
                                    )

                                    // سهم الرجوع في أقصى اليمين (في RTL: Start)
                                    // بحجم يقارب 36px ولون ذهبي ويشير لليمين لتأكيد الرجوع
                                    Surface(
                                        shape = CircleShape,
                                        color = ScreenshotNavySurface,
                                        border = BorderStroke(1.dp, ScreenshotGoldAccent.copy(alpha = 0.6f)),
                                        modifier = Modifier
                                            .align(Alignment.CenterStart)
                                            .size(42.dp)
                                    ) {
                                        IconButton(
                                            onClick = onDismiss,
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .testTag("admin_back_button")
                                        ) {
                                            Icon(
                                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                                contentDescription = "الرجوع",
                                                tint = ColorGoldTitle,
                                                modifier = Modifier.size(22.dp)
                                            )
                                        }
                                    }

                                    // زر حفظ التعديلات في أقصى اليسار (في RTL: End)
                                    Button(
                                        onClick = {
                                            val finalSettings = compileCurrentSettings()
                                            onSaveSettings(finalSettings)
                                            onSaveSchedule(currentSchedule)
                                            Toast.makeText(context, "تم حفظ جميع التعديلات بنجاح", Toast.LENGTH_SHORT).show()
                                            onDismiss()
                                        },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = ColorGoldTitle,
                                            contentColor = Color(0xFF071F3D)
                                        ),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier
                                            .align(Alignment.CenterEnd)
                                            .height(46.dp)
                                            .testTag("admin_save_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = null,
                                            tint = Color(0xFF071F3D),
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "حفظ التعديلات والتطبيق",
                                            fontSize = 14.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = CairoFamily,
                                            color = Color(0xFF071F3D)
                                        )
                                    }
                                }
                            }

                            // -------------------------------------------------------------
                            // المحتوى القابل للتمرير رأسياً (Scrollable Content Area)
                            // هوامش جانبية 30px بين البطاقات وحدود مساحة المحتوى
                            // -------------------------------------------------------------
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .verticalScroll(rememberScrollState())
                                    .padding(horizontal = 30.dp, vertical = 26.dp)
                            ) {
                                // =========================================================
                                // إعدادات المسجد والمواقيت والعرض
                                // =========================================================
                                Text(
                                    text = "إعدادات المسجد والمواقيت والعرض",
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = CairoFamily,
                                    color = ColorGoldTitle
                                )

                                Spacer(modifier = Modifier.height(18.dp))

                                // 1. قسم اسم المسجد
                                SettingsCard(
                                    title = "اسم المسجد",
                                    description = "يظهر اسم المسجد في الواجهة الرئيسية والجدول السنوي لمواقيت الصلاة"
                                ) {
                                    OutlinedTextField(
                                        value = mosqueNameInput,
                                        onValueChange = { mosqueNameInput = it },
                                        singleLine = true,
                                        shape = RoundedCornerShape(12.dp),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedTextColor = Color.White,
                                            unfocusedTextColor = Color.White,
                                            focusedBorderColor = ColorGoldTitle,
                                            unfocusedBorderColor = ColorCardBorder,
                                            focusedContainerColor = ColorAdminBg,
                                            unfocusedContainerColor = ColorAdminBg
                                        ),
                                        modifier = Modifier.fillMaxWidth()
                                    )

                                    Spacer(modifier = Modifier.height(14.dp))

                                    SectionSaveButton(
                                        text = "حفظ اسم المسجد",
                                        onClick = {
                                            saveSingleSection("اسم المسجد") {
                                                it.copy(mosqueName = mosqueNameInput.trim().ifEmpty { "اسم المسجد" })
                                            }
                                        }
                                    )
                                }

                                Spacer(modifier = Modifier.height(24.dp))

                                // 2. قسم مكتبات الأذان والإقامة
                                SettingsCard(
                                    title = "مكتبات الأذان والإقامة",
                                    description = "إدارة وربط الأصوات: ملفات أذان الفجر الأول من الملف المضغوط، وأصوات الإقامة للإقامة فقط دون خلط بالأذان"
                                ) {
                                    // أ) أذان الفجر الأول (المستخرج من الملف المضغوط)
                                    val fajrFirstConfig = draftSettings.getPrayerConfig(PrayerType.FAJR_FIRST)
                                    val fajrFirstTitle = fajrFirstConfig.adhanSoundName?.takeIf { it.isNotBlank() }
                                        ?: draftSettings.savedFajrAdhanSounds.find { it.uri == fajrFirstConfig.adhanSoundUri }?.name
                                        ?: if (!fajrFirstConfig.adhanSoundUri.isNullOrBlank()) fajrFirstConfig.adhanSoundUri!!.substringAfterLast('/') else "لم يتم اختيار صوت"
                                    val fajrFirstUriToUse = fajrFirstConfig.adhanSoundUri ?: fajrFirstConfig.adhanSoundPreset ?: ""

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "أذان الفجر الأول (من الملفات المضغوطة)",
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.Bold,
                                                fontFamily = CairoFamily,
                                                color = Color.White
                                            )
                                            Text(
                                                text = "أصوات أذان الفجر الأول الحصرية المستخرجة من الملف المضغوط",
                                                fontSize = 13.sp,
                                                fontFamily = CairoFamily,
                                                color = ColorTextDesc
                                            )
                                        }

                                        Switch(
                                            checked = draftSettings.isFajrFirstEnabled,
                                            onCheckedChange = { newState ->
                                                saveSingleSection("أذان الفجر الأول") {
                                                    it.copy(isFajrFirstEnabled = newState)
                                                }
                                            },
                                            colors = SwitchDefaults.colors(
                                                checkedThumbColor = ColorGoldTitle,
                                                checkedTrackColor = ColorCardBorder,
                                                uncheckedThumbColor = ColorTextDesc.copy(alpha = 0.5f),
                                                uncheckedTrackColor = ColorAdminBg
                                            )
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    SelectedAudioBox(
                                        soundTitle = fajrFirstTitle,
                                        isPlaying = isPlayingTest && currentlyTestingAudioKey == "fajr_first",
                                        label = "أذان الفجر الأول المختار حالياً:",
                                        soundUriOrKey = fajrFirstUriToUse,
                                        enabled = draftSettings.isFajrFirstEnabled,
                                        onPlayPause = {
                                            if (!draftSettings.isFajrFirstEnabled) return@SelectedAudioBox
                                            if (isPlayingTest && currentlyTestingAudioKey == "fajr_first") {
                                                onStopAudio?.invoke()
                                                currentlyTestingAudioKey = null
                                            } else {
                                                onStopAudio?.invoke()
                                                currentlyTestingAudioKey = "fajr_first"
                                                val soundToPlay = if (fajrFirstUriToUse.isNotBlank()) fajrFirstUriToUse else fajrFirstTitle
                                                onTestAudio?.invoke(soundToPlay)
                                            }
                                        },
                                        onClear = if (draftSettings.isFajrFirstEnabled && !fajrFirstConfig.adhanSoundUri.isNullOrBlank()) {
                                            {
                                                val updated = draftSettings.withPrayerConfig(fajrFirstConfig.copy(adhanSoundUri = null, adhanSoundPreset = "", adhanSoundName = null))
                                                draftSettings = updated
                                                onSaveSettings(updated)
                                            }
                                        } else null
                                    )

                                    Spacer(modifier = Modifier.height(8.dp))

                                    AudioSourceSelectionRow(
                                        enabled = draftSettings.isFajrFirstEnabled,
                                        libraryButtonText = "مكتبة أذان الفجر (الملف المضغوط)",
                                        phoneButtonText = "ملف من الهاتف",
                                        onOpenLibrary = { if (draftSettings.isFajrFirstEnabled) showFajrLibraryDialog = true },
                                        onPickFromPhone = { if (draftSettings.isFajrFirstEnabled) fajrPhonePickerLauncher.launch("audio/*") }
                                    )

                                    Spacer(modifier = Modifier.height(20.dp))
                                    HorizontalDivider(color = ColorCardBorder.copy(alpha = 0.6f))
                                    Spacer(modifier = Modifier.height(20.dp))

                                    // ب) مكتبة أصوات الإقامة (للإقامة فقط)
                                    val iqamaTitle = draftSettings.savedIqamaSounds.find { it.uri == draftSettings.defaultIqamaSound }?.name
                                        ?: if (draftSettings.defaultIqamaSound.isNotBlank()) draftSettings.defaultIqamaSound.substringAfterLast('/') else "لم يتم اختيار صوت"

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "صوت الإقامة الموحد (للإقامة فقط)",
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.Bold,
                                                fontFamily = CairoFamily,
                                                color = Color.White
                                            )
                                            Text(
                                                text = "أصوات الإقامة المستقلة المخصصة للإقامة دون خلطها بالأذان",
                                                fontSize = 13.sp,
                                                fontFamily = CairoFamily,
                                                color = ColorTextDesc
                                            )
                                        }

                                        Switch(
                                            checked = draftSettings.applyIqamaSoundToAll,
                                            onCheckedChange = { newState ->
                                                saveSingleSection("صوت الإقامة الموحد") {
                                                    it.copy(applyIqamaSoundToAll = newState)
                                                }
                                            },
                                            colors = SwitchDefaults.colors(
                                                checkedThumbColor = ColorGoldTitle,
                                                checkedTrackColor = ColorCardBorder,
                                                uncheckedThumbColor = ColorTextDesc.copy(alpha = 0.5f),
                                                uncheckedTrackColor = ColorAdminBg
                                            )
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    SelectedAudioBox(
                                        soundTitle = iqamaTitle,
                                        isPlaying = isPlayingTest && currentlyTestingAudioKey == "iqama_common",
                                        label = "صوت الإقامة الموحد المختار:",
                                        soundUriOrKey = draftSettings.defaultIqamaSound,
                                        enabled = draftSettings.applyIqamaSoundToAll,
                                        onPlayPause = {
                                            if (!draftSettings.applyIqamaSoundToAll) return@SelectedAudioBox
                                            if (isPlayingTest && currentlyTestingAudioKey == "iqama_common") {
                                                onStopAudio?.invoke()
                                                currentlyTestingAudioKey = null
                                            } else {
                                                onStopAudio?.invoke()
                                                currentlyTestingAudioKey = "iqama_common"
                                                val soundToPlay = if (draftSettings.defaultIqamaSound.isNotBlank()) draftSettings.defaultIqamaSound else iqamaTitle
                                                onTestAudio?.invoke(soundToPlay)
                                            }
                                        },
                                        onClear = if (draftSettings.applyIqamaSoundToAll && draftSettings.defaultIqamaSound.isNotBlank()) {
                                            {
                                                val updated = draftSettings.copy(defaultIqamaSound = "")
                                                draftSettings = updated
                                                onSaveSettings(updated)
                                            }
                                        } else null
                                    )

                                    Spacer(modifier = Modifier.height(8.dp))

                                    AudioSourceSelectionRow(
                                        enabled = draftSettings.applyIqamaSoundToAll,
                                        libraryButtonText = "مكتبة الإقامة (للإقامة فقط)",
                                        phoneButtonText = "ملف من الهاتف",
                                        onOpenLibrary = { if (draftSettings.applyIqamaSoundToAll) showIqamaLibraryDialog = true },
                                        onPickFromPhone = { if (draftSettings.applyIqamaSoundToAll) iqamaPhonePickerLauncher.launch("audio/*") }
                                    )

                                    Spacer(modifier = Modifier.height(20.dp))
                                    HorizontalDivider(color = ColorCardBorder.copy(alpha = 0.6f))
                                    Spacer(modifier = Modifier.height(20.dp))

                                    // ج) مكتبة الأذان العامة الموحدة
                                    val commonAdhanTitle = draftSettings.savedAdhanSounds.find { it.uri == draftSettings.commonAdhanSound }?.name
                                        ?: if (draftSettings.commonAdhanSound.isNotBlank()) draftSettings.commonAdhanSound.substringAfterLast('/') else "لم يتم اختيار صوت"

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "صوت الأذان الموحد لجميع الصلوات",
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.Bold,
                                                fontFamily = CairoFamily,
                                                color = Color.White
                                            )
                                            Text(
                                                text = "تطبيق أذان موحد من مكتبة الأذان العامة على جميع الصلوات",
                                                fontSize = 13.sp,
                                                fontFamily = CairoFamily,
                                                color = ColorTextDesc
                                            )
                                        }

                                        Switch(
                                            checked = draftSettings.useCommonAdhan,
                                            onCheckedChange = { newState ->
                                                saveSingleSection("صوت الأذان الموحد") {
                                                    it.copy(useCommonAdhan = newState)
                                                }
                                            },
                                            colors = SwitchDefaults.colors(
                                                checkedThumbColor = ColorGoldTitle,
                                                checkedTrackColor = ColorCardBorder,
                                                uncheckedThumbColor = ColorTextDesc.copy(alpha = 0.5f),
                                                uncheckedTrackColor = ColorAdminBg
                                            )
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    SelectedAudioBox(
                                        soundTitle = commonAdhanTitle,
                                        isPlaying = isPlayingTest && currentlyTestingAudioKey == "adhan_common",
                                        label = "صوت الأذان الموحد المختار:",
                                        soundUriOrKey = draftSettings.commonAdhanSound,
                                        enabled = draftSettings.useCommonAdhan,
                                        onPlayPause = {
                                            if (!draftSettings.useCommonAdhan) return@SelectedAudioBox
                                            if (isPlayingTest && currentlyTestingAudioKey == "adhan_common") {
                                                onStopAudio?.invoke()
                                                currentlyTestingAudioKey = null
                                            } else {
                                                onStopAudio?.invoke()
                                                currentlyTestingAudioKey = "adhan_common"
                                                val soundToPlay = if (draftSettings.commonAdhanSound.isNotBlank()) draftSettings.commonAdhanSound else commonAdhanTitle
                                                onTestAudio?.invoke(soundToPlay)
                                            }
                                        },
                                        onClear = if (draftSettings.useCommonAdhan && draftSettings.commonAdhanSound.isNotBlank()) {
                                            {
                                                val updated = draftSettings.copy(commonAdhanSound = "")
                                                draftSettings = updated
                                                onSaveSettings(updated)
                                            }
                                        } else null
                                    )

                                    Spacer(modifier = Modifier.height(8.dp))

                                    AudioSourceSelectionRow(
                                        enabled = draftSettings.useCommonAdhan,
                                        libraryButtonText = "اختيار من مكتبة الأذان العامة",
                                        phoneButtonText = "ملف من الهاتف",
                                        onOpenLibrary = { if (draftSettings.useCommonAdhan) showGeneralAdhanLibraryDialog = true },
                                        onPickFromPhone = { if (draftSettings.useCommonAdhan) adhanPhonePickerLauncher.launch("audio/*") }
                                    )
                                }

                                Spacer(modifier = Modifier.height(24.dp))

                                // 3. قسم التاريخ والوقت
                                SettingsCard(
                                    title = "التاريخ والوقت",
                                    description = "ضبط وتعديل التاريخ الميلادي والوقت للشاشة الرئيسية ومواقيت الصلاة"
                                ) {
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = ColorAdminBg),
                                        border = BorderStroke(
                                            1.5.dp,
                                            if (isTimeCorrectionEnabled || isDateCorrectionEnabled) ColorGoldTitle else ColorCardBorder
                                        ),
                                        shape = RoundedCornerShape(16.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(16.dp))
                                            .clickable { showDateTimeDialog = true }
                                    ) {
                                        Column(modifier = Modifier.padding(18.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    modifier = Modifier.weight(1f)
                                                ) {
                                                    Box(
                                                        modifier = Modifier
                                                            .size(44.dp)
                                                            .clip(CircleShape)
                                                            .background(ColorGoldTitle.copy(alpha = 0.15f))
                                                            .border(1.dp, ColorGoldTitle.copy(alpha = 0.4f), CircleShape),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Icon(
                                                            imageVector = Icons.Default.Schedule,
                                                            contentDescription = null,
                                                            tint = ColorGoldTitle,
                                                            modifier = Modifier.size(24.dp)
                                                        )
                                                    }
                                                    Spacer(modifier = Modifier.width(12.dp))
                                                    Column {
                                                        Text(
                                                            text = "ضبط التاريخ الميلادي والوقت",
                                                            fontSize = 16.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            fontFamily = CairoFamily,
                                                            color = Color.White
                                                        )
                                                        Text(
                                                            text = if (isTimeCorrectionEnabled || isDateCorrectionEnabled)
                                                                "مفعّل يدوياً (تاريخ/وقت مخصص للرئيسية)"
                                                            else
                                                                "تلقائي (مطابق لتوقيت وتاريخ الجهاز)",
                                                            fontSize = 12.5.sp,
                                                            fontFamily = CairoFamily,
                                                            color = if (isTimeCorrectionEnabled || isDateCorrectionEnabled) ColorGoldLight else ColorTextDesc
                                                        )
                                                    }
                                                }

                                                Surface(
                                                    shape = RoundedCornerShape(20.dp),
                                                    color = if (isTimeCorrectionEnabled || isDateCorrectionEnabled) ColorGoldTitle.copy(alpha = 0.2f) else ColorCardBg,
                                                    border = BorderStroke(1.dp, if (isTimeCorrectionEnabled || isDateCorrectionEnabled) ColorGoldTitle else ColorCardBorder)
                                                ) {
                                                    Text(
                                                        text = if (isTimeCorrectionEnabled || isDateCorrectionEnabled) "معدّل" else "تلقائي",
                                                        fontSize = 11.5.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        fontFamily = CairoFamily,
                                                        color = if (isTimeCorrectionEnabled || isDateCorrectionEnabled) ColorGoldTitle else ColorTextDesc,
                                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                                    )
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(14.dp))

                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clip(RoundedCornerShape(10.dp))
                                                    .background(ColorCardBg)
                                                    .border(1.dp, ColorCardBorder.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                                                    .padding(12.dp),
                                                horizontalArrangement = Arrangement.SpaceAround,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        Icon(
                                                            imageVector = Icons.Default.Schedule,
                                                            contentDescription = null,
                                                            tint = ColorGoldTitle,
                                                            modifier = Modifier.size(15.dp)
                                                        )
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text(
                                                            text = "الوقت",
                                                            fontSize = 12.sp,
                                                            fontFamily = CairoFamily,
                                                            color = ColorTextDesc
                                                        )
                                                    }
                                                    Text(
                                                        text = String.format(
                                                            Locale.US,
                                                            "%02d:%02d %s",
                                                            targetHour12,
                                                            targetMinute,
                                                            if (targetIsPm) "م" else "ص"
                                                        ),
                                                        fontSize = 16.sp,
                                                        fontWeight = FontWeight.ExtraBold,
                                                        fontFamily = CairoFamily,
                                                        color = if (isTimeCorrectionEnabled) ColorGoldLight else Color.White
                                                    )
                                                }

                                                Box(
                                                    modifier = Modifier
                                                        .width(1.dp)
                                                        .height(30.dp)
                                                        .background(ColorCardBorder)
                                                )

                                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        Icon(
                                                            imageVector = Icons.Default.CalendarMonth,
                                                            contentDescription = null,
                                                            tint = ColorGoldTitle,
                                                            modifier = Modifier.size(15.dp)
                                                        )
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text(
                                                            text = "التاريخ الميلادي",
                                                            fontSize = 12.sp,
                                                            fontFamily = CairoFamily,
                                                            color = ColorTextDesc
                                                        )
                                                    }
                                                    Text(
                                                        text = String.format(Locale.US, "%04d/%02d/%02d", targetYear, targetMonth, targetDay),
                                                        fontSize = 16.sp,
                                                        fontWeight = FontWeight.ExtraBold,
                                                        fontFamily = CairoFamily,
                                                        color = if (isDateCorrectionEnabled) ColorGoldLight else Color.White
                                                    )
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(14.dp))

                                            Button(
                                                onClick = { showDateTimeDialog = true },
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(46.dp),
                                                shape = RoundedCornerShape(12.dp),
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = ColorGoldTitle,
                                                    contentColor = ColorAdminBg
                                                )
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Edit,
                                                    contentDescription = null,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = "فتح نافذة تعديل التاريخ والوقت",
                                                    fontSize = 14.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    fontFamily = CairoFamily
                                                )
                                            }
                                        }
                                    }
                                }

                                if (showDateTimeDialog) {
                                    DateTimeAdjustmentDialog(
                                        initialTargetYear = targetYear,
                                        initialTargetMonth = targetMonth,
                                        initialTargetDay = targetDay,
                                        initialTargetHour12 = targetHour12,
                                        initialTargetMinute = targetMinute,
                                        initialTargetIsPm = targetIsPm,
                                        initialIsTimeCorrectionEnabled = isTimeCorrectionEnabled,
                                        initialIsDateCorrectionEnabled = isDateCorrectionEnabled,
                                        hijriDayOffset = draftSettings.hijriDayOffset,
                                        onSave = { isTimeEn, newHOff, newMOff, isDateEn, newDayOff, newY, newM, newD, newH12, newMin, newPm ->
                                            isTimeCorrectionEnabled = isTimeEn
                                            timeOffsetHours = newHOff
                                            timeOffsetMinutes = newMOff
                                            isDateCorrectionEnabled = isDateEn
                                            gregorianDayOffset = newDayOff
                                            targetYear = newY
                                            targetMonth = newM
                                            targetDay = newD
                                            targetHour12 = newH12
                                            targetMinute = newMin
                                            targetIsPm = newPm
                                            hourInputText = String.format(Locale.US, "%02d", newH12)
                                            minuteInputText = String.format(Locale.US, "%02d", newMin)
                                            dayInputText = String.format(Locale.US, "%02d", newD)
                                            monthInputText = String.format(Locale.US, "%02d", newM)
                                            yearInputText = String.format(Locale.US, "%04d", newY)
                                            saveSingleSection("التاريخ والوقت") {
                                                it.copy(
                                                    isTimeCorrectionEnabled = isTimeEn,
                                                    timeOffsetHours = if (isTimeEn) newHOff else 0,
                                                    timeOffsetMinutes = if (isTimeEn) newMOff else 0,
                                                    isDateCorrectionEnabled = isDateEn,
                                                    gregorianDayOffset = if (isDateEn) newDayOff else 0
                                                )
                                            }
                                            showDateTimeDialog = false
                                        },
                                        onDismiss = {
                                            showDateTimeDialog = false
                                        }
                                    )
                                }

                                Spacer(modifier = Modifier.height(24.dp))

                                // 3. قسم شاشة الصلاة والأذكار وخطبة الجمعة
                                SettingsCard(
                                    title = "شاشة الصلاة والأذكار وخطبة الجمعة",
                                    description = "ضبط مدد أداء الصلوات، شاشة الأذكار بعدها، وضع خطبة الجمعة ومعاينة الواجهات"
                                ) {
                                    // مفتاح تفعيل شاشة الصلاة والأذكار
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "تفعيل شاشة الصلاة والأذكار",
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.Bold,
                                                fontFamily = CairoFamily,
                                                color = Color.White
                                            )
                                            Text(
                                                text = "عرض شاشة «الصلاة قائمة» والأذكار تلقائياً عند الإقامة",
                                                fontSize = 13.sp,
                                                fontFamily = CairoFamily,
                                                color = ColorTextDesc
                                            )
                                        }

                                        Switch(
                                            checked = isPrayerScreenEnabled,
                                            onCheckedChange = { isPrayerScreenEnabled = it },
                                            colors = SwitchDefaults.colors(
                                                checkedThumbColor = ColorGoldTitle,
                                                checkedTrackColor = ColorCardBorder,
                                                uncheckedThumbColor = ColorTextDesc.copy(alpha = 0.5f),
                                                uncheckedTrackColor = ColorAdminBg
                                            )
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(18.dp))

                                    // مدد الصلوات
                                    Text(
                                        text = "مدة أداء الصلاة قبل الانتقال للأذكار (بالدقائق)",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = CairoFamily,
                                        color = ColorGoldLight
                                    )

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(ColorAdminBg)
                                            .border(1.dp, ColorCardBorder, RoundedCornerShape(12.dp))
                                            .padding(horizontal = 14.dp, vertical = 6.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        PrayerDurationRow(name = "صلاة الفجر", duration = fajrDuration, onChange = { fajrDuration = it })
                                        PrayerDurationRow(name = "صلاة الظهر", duration = dhuhrDuration, onChange = { dhuhrDuration = it })
                                        PrayerDurationRow(name = "صلاة العصر", duration = asrDuration, onChange = { asrDuration = it })
                                        PrayerDurationRow(name = "صلاة المغرب", duration = maghribDuration, onChange = { maghribDuration = it })
                                        PrayerDurationRow(name = "صلاة العشاء", duration = ishaDuration, onChange = { ishaDuration = it })
                                    }

                                    Spacer(modifier = Modifier.height(18.dp))

                                    // مدة شاشة الأذكار
                                    Text(
                                        text = "مدة عرض شاشة الأذكار (بالدقائق)",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = CairoFamily,
                                        color = ColorGoldLight
                                    )

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "المدة المحددة:",
                                            fontSize = 14.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = CairoFamily,
                                            color = Color.White
                                        )

                                        UnifiedNumberAdjuster(
                                            valueText = "$adhkarDuration دقيقة",
                                            onIncrement = { if (adhkarDuration < 180) adhkarDuration += 1 },
                                            onDecrement = { if (adhkarDuration > 1) adhkarDuration -= 1 },
                                            minBoxWidth = 84.dp
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    DurationPresetChips(
                                        presets = listOf(10, 15, 20, 30, 45, 60),
                                        selected = adhkarDuration,
                                        onSelect = { adhkarDuration = it }
                                    )

                                    Spacer(modifier = Modifier.height(18.dp))

                                    // وضع خطبة الجمعة
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "وضع خطبة الجمعة (بدل إقامة الظهر)",
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.Bold,
                                                fontFamily = CairoFamily,
                                                color = Color.White
                                            )
                                            Text(
                                                text = "عرض واجهة «استمع للخطبة» يوم الجمعة بعد الأذان الثاني",
                                                fontSize = 13.sp,
                                                fontFamily = CairoFamily,
                                                color = ColorTextDesc
                                            )
                                        }

                                        Switch(
                                            checked = isFridayKhutbahMode,
                                            onCheckedChange = { isFridayKhutbahMode = it },
                                            colors = SwitchDefaults.colors(
                                                checkedThumbColor = ColorGoldTitle,
                                                checkedTrackColor = ColorCardBorder,
                                                uncheckedThumbColor = ColorTextDesc.copy(alpha = 0.5f),
                                                uncheckedTrackColor = ColorAdminBg
                                            )
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(14.dp))

                                    Text(
                                        text = "مدة عرض شاشة استمع للخطبة (بالدقائق)",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = CairoFamily,
                                        color = ColorGoldLight
                                    )

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "المدة المحددة للخطبة:",
                                            fontSize = 14.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = CairoFamily,
                                            color = Color.White
                                        )

                                        UnifiedNumberAdjuster(
                                            valueText = "$fridayKhutbahDuration دقيقة",
                                            onIncrement = { if (fridayKhutbahDuration < 120) fridayKhutbahDuration += 1 },
                                            onDecrement = { if (fridayKhutbahDuration > 5) fridayKhutbahDuration -= 1 },
                                            minBoxWidth = 84.dp
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    DurationPresetChips(
                                        presets = listOf(15, 20, 25, 30, 45, 60),
                                        selected = fridayKhutbahDuration,
                                        onSelect = { fridayKhutbahDuration = it }
                                    )

                                    Spacer(modifier = Modifier.height(20.dp))

                                    // بطاقات المعاينة الثلاث
                                    PreviewRowCard(
                                        title = "معاينة شاشة استمع للخطبة",
                                        description = "معاينة واجهة خطبة الجمعة التذكيرية كاملة",
                                        onPreview = { onPreviewIqamaScreen(PrayerType.FRIDAY_SECOND) }
                                    )

                                    Spacer(modifier = Modifier.height(10.dp))

                                    PreviewRowCard(
                                        title = "معاينة شاشة الصلاة قائمة",
                                        description = "معاينة واجهة الإقامة والتنبيه بإغلاق الهاتف",
                                        onPreview = { onPreviewIqamaScreen(PrayerType.DHUHR) }
                                    )

                                    Spacer(modifier = Modifier.height(10.dp))

                                    PreviewRowCard(
                                        title = "معاينة شاشة أذكار ما بعد الصلاة",
                                        description = "معاينة واجهة الأذكار والأدعية بعد انتهاء الصلاة",
                                        onPreview = { onPreviewAdhkarScreen() }
                                    )

                                    Spacer(modifier = Modifier.height(16.dp))

                                    SectionSaveButton(
                                        text = "حفظ إعدادات شاشة الصلاة والأذكار والخطبة",
                                        onClick = {
                                            saveSingleSection("شاشة الصلاة والأذكار والخطبة") { current ->
                                                var updated = current.copy(
                                                    prayerInterfacesMasterEnabled = isPrayerScreenEnabled,
                                                    postPrayerAdhkarEnabled = isPrayerScreenEnabled,
                                                    postPrayerAdhkarDurationMinutes = adhkarDuration,
                                                    isFridayKhutbahMode = isFridayKhutbahMode,
                                                    fridayKhutbahDurationMinutes = fridayKhutbahDuration
                                                )
                                                val list = listOf(
                                                    PrayerType.FAJR_SECOND to fajrDuration,
                                                    PrayerType.DHUHR to dhuhrDuration,
                                                    PrayerType.ASR to asrDuration,
                                                    PrayerType.MAGHRIB to maghribDuration,
                                                    PrayerType.ISHA to ishaDuration,
                                                    PrayerType.FRIDAY_SECOND to fridayKhutbahDuration
                                                )
                                                for ((type, dur) in list) {
                                                    val cfg = updated.getPrayerConfig(type)
                                                    updated = updated.withPrayerConfig(cfg.copy(iqamaScreenDurationMinutes = dur))
                                                }
                                                updated
                                            }
                                        }
                                    )
                                }

                                Spacer(modifier = Modifier.height(24.dp))

                                // 4. قسم ضبط التقويم الهجري
                                SettingsCard(
                                    title = "ضبط التقويم الهجري",
                                    description = "تقديم التاريخ الهجري أو تأخيره لمطابقة الرؤية الشرعية للهلال"
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "تعديل الأيام:",
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = CairoFamily,
                                            color = Color.White
                                        )

                                        val dayText = when {
                                            hijriDayOffset > 0 -> "+$hijriDayOffset يوم (تقديم)"
                                            hijriDayOffset < 0 -> "$hijriDayOffset يوم (تأخير)"
                                            else -> "0 يوم (مطابق)"
                                        }

                                        UnifiedNumberAdjuster(
                                            valueText = dayText,
                                            onIncrement = { if (hijriDayOffset < 3) hijriDayOffset += 1 },
                                            onDecrement = { if (hijriDayOffset > -3) hijriDayOffset -= 1 },
                                            minBoxWidth = 140.dp
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(14.dp))

                                    val today = LocalDate.now()
                                    val resultingHijri = HijriCalendarHelper.getHijriDateString(today, hijriDayOffset)

                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = ColorAdminBg,
                                        border = BorderStroke(1.dp, ColorGoldTitle.copy(alpha = 0.6f)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.CalendarMonth,
                                                contentDescription = null,
                                                tint = ColorGoldTitle,
                                                modifier = Modifier.size(20.dp)
                                            )
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Column {
                                                Text(
                                                    text = "التاريخ الهجري الناتج بعد التعديل:",
                                                    fontSize = 12.5.sp,
                                                    fontFamily = CairoFamily,
                                                    color = ColorTextDesc
                                                )
                                                Text(
                                                    text = resultingHijri,
                                                    fontSize = 15.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    fontFamily = CairoFamily,
                                                    color = ColorGoldLight
                                                )
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(14.dp))

                                    SectionSaveButton(
                                        text = "حفظ إعدادات التقويم الهجري",
                                        onClick = {
                                            saveSingleSection("ضبط التقويم الهجري") {
                                                it.copy(hijriDayOffset = hijriDayOffset)
                                            }
                                        }
                                    )
                                }

                                Spacer(modifier = Modifier.height(24.dp))

                                // 5. قسم تنسيق العرض والساعة
                                SettingsCard(
                                    title = "تنسيق العرض والساعة",
                                    description = "خيارات عرض الساعة والتاريخ في الشاشة الرئيسية والتطبيقات"
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "نظام 12 ساعة (ص/م)",
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.Bold,
                                                fontFamily = CairoFamily,
                                                color = Color.White
                                            )
                                            Text(
                                                text = if (is12HourFormat) "مفعّل: عرض الوقت بصيغة 12 ساعة مع ص / م" else "غير مفعّل: عرض الوقت بصيغة 24 ساعة",
                                                fontSize = 13.sp,
                                                fontFamily = CairoFamily,
                                                color = ColorTextDesc
                                            )
                                        }

                                        Switch(
                                            checked = is12HourFormat,
                                            onCheckedChange = { is12HourFormat = it },
                                            colors = SwitchDefaults.colors(
                                                checkedThumbColor = ColorGoldTitle,
                                                checkedTrackColor = ColorCardBorder,
                                                uncheckedThumbColor = ColorTextDesc.copy(alpha = 0.5f),
                                                uncheckedTrackColor = ColorAdminBg
                                            )
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(14.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "إظهار الثواني في الساعة الرقمية",
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.Bold,
                                                fontFamily = CairoFamily,
                                                color = Color.White
                                            )
                                            Text(
                                                text = "عرض عداد الثواني المتحرك في الساعة",
                                                fontSize = 13.sp,
                                                fontFamily = CairoFamily,
                                                color = ColorTextDesc
                                            )
                                        }

                                        Switch(
                                            checked = showSeconds,
                                            onCheckedChange = { showSeconds = it },
                                            colors = SwitchDefaults.colors(
                                                checkedThumbColor = ColorGoldTitle,
                                                checkedTrackColor = ColorCardBorder,
                                                uncheckedThumbColor = ColorTextDesc.copy(alpha = 0.5f),
                                                uncheckedTrackColor = ColorAdminBg
                                            )
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(16.dp))

                                    SectionSaveButton(
                                        text = "حفظ تنسيق العرض والساعة",
                                        onClick = {
                                            saveSingleSection("تنسيق العرض والساعة") {
                                                it.copy(
                                                    is24Hour = !is12HourFormat,
                                                    showSeconds = showSeconds
                                                )
                                            }
                                        }
                                    )
                                }

                                Spacer(modifier = Modifier.height(36.dp))

                                // =========================================================
                                // وضع الشاشة الثابتة ووضع الشاشة الرئيسية في نهاية الإعدادات
                                // =========================================================
                                Text(
                                    text = "إعدادات أوضاع الشاشة والنظام",
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = CairoFamily,
                                    color = ColorGoldTitle
                                )

                                Spacer(modifier = Modifier.height(18.dp))

                                // بطاقة وضع الشاشة الثابتة (Kiosk)
                                SettingsCard(
                                    title = "وضع الشاشة الثابتة (Kiosk)",
                                    description = "يمنع الخروج من التطبيق عند التفعيل — مناسب لشاشة المسجد"
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "قفل التطبيق في وضع الشاشة الثابتة",
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.Bold,
                                                fontFamily = CairoFamily,
                                                color = Color.White
                                            )
                                            Text(
                                                text = if (isKioskModeEnabled) "مفعّل: يمنع الخروج من التطبيق" else "متوقف: يمكن إغلاق التطبيق أو الرجوع للخلف",
                                                fontSize = 13.sp,
                                                fontFamily = CairoFamily,
                                                color = if (isKioskModeEnabled) ColorGoldLight else ColorTextDesc
                                            )
                                        }

                                        Switch(
                                            checked = isKioskModeEnabled,
                                            onCheckedChange = { newState -> applyKioskToggle(newState) },
                                            colors = SwitchDefaults.colors(
                                                checkedThumbColor = ColorGoldTitle,
                                                checkedTrackColor = ColorCardBorder,
                                                uncheckedThumbColor = ColorTextDesc.copy(alpha = 0.5f),
                                                uncheckedTrackColor = ColorAdminBg
                                            ),
                                            modifier = Modifier.testTag("switch_kiosk_mode")
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(16.dp))

                                    SectionSaveButton(
                                        text = if (isKioskModeEnabled) "تعطيل وضع الشاشة الثابتة" else "تفعيل وحفظ وضع الشاشة الثابتة",
                                        onClick = { applyKioskToggle(!isKioskModeEnabled) }
                                    )
                                }

                                Spacer(modifier = Modifier.height(24.dp))

                                // بطاقة وضع الشاشة الرئيسية (تشغيل تلقائي)
                                SettingsCard(
                                    title = "وضع الشاشة الرئيسية (تشغيل تلقائي)",
                                    description = "عند التفعيل يفتح التطبيق تلقائياً بعد إعادة تشغيل الجهاز. اختر تطبيقاً افتراضياً للشاشة الرئيسية عند طلب النظام. أوقف الوضع من هنا عند الحاجة للصيانة"
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "تشغيل التطبيق تلقائياً كشاشة رئيسية",
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.Bold,
                                                fontFamily = CairoFamily,
                                                color = Color.White
                                            )
                                            Text(
                                                text = if (isAutoStartHomeEnabled) "مفعّل: فتح التطبيق تلقائياً بعد الإقلاع" else "متوقف: الوضع العادي للنظام",
                                                fontSize = 13.sp,
                                                fontFamily = CairoFamily,
                                                color = if (isAutoStartHomeEnabled) ColorGoldLight else ColorTextDesc
                                            )
                                        }

                                        Switch(
                                            checked = isAutoStartHomeEnabled,
                                            onCheckedChange = { newState -> applyAutoStartToggle(newState) },
                                            colors = SwitchDefaults.colors(
                                                checkedThumbColor = ColorGoldTitle,
                                                checkedTrackColor = ColorCardBorder,
                                                uncheckedThumbColor = ColorTextDesc.copy(alpha = 0.5f),
                                                uncheckedTrackColor = ColorAdminBg
                                            ),
                                            modifier = Modifier.testTag("switch_autostart_home")
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(16.dp))

                                    SectionSaveButton(
                                        text = if (isAutoStartHomeEnabled) "تعطيل وضع الشاشة الرئيسية" else "تفعيل وحفظ وضع الشاشة الرئيسية",
                                        onClick = { applyAutoStartToggle(!isAutoStartHomeEnabled) }
                                    )
                                }

                                Spacer(modifier = Modifier.height(42.dp))
                            }
                        }

                        // 2. Left Narrow Black Strip (~52px) along the far left edge of the screen
                        Box(
                            modifier = Modifier
                                .width(52.dp)
                                .fillMaxHeight()
                                .background(Color.Black)
                        )
                    }
                }
            }
        }
    }

    // Modal dialogs for selecting audio in admin page
    if (showFajrLibraryDialog) {
        AudioLibrarySelectionDialog(
            title = "مكتبة أذان الفجر الأول (الملفات المضغوطة)",
            subtitle = "أصوات أذان الفجر الأول المستخرجة من الملف المضغوط",
            initialSelectedUri = draftSettings.getPrayerConfig(PrayerType.FAJR_FIRST).adhanSoundUri,
            librarySounds = draftSettings.savedFajrAdhanSounds,
            isPlayingTest = isPlayingTest && currentlyTestingAudioKey == "fajr_first",
            playingSoundKey = if (isPlayingTest && currentlyTestingAudioKey == "fajr_first") draftSettings.getPrayerConfig(PrayerType.FAJR_FIRST).adhanSoundUri else null,
            onTestSound = { sound ->
                currentlyTestingAudioKey = "fajr_first"
                onTestAudio?.invoke(sound)
            },
            onStopSound = {
                onStopAudio?.invoke()
                currentlyTestingAudioKey = null
            },
            onImportFileFromPhone = { name, uri ->
                onAddFajrAdhanToLibrary?.invoke(name, uri)
            },
            onDeleteSound = { item ->
                onDeleteFajrAdhanFromLibrary?.invoke(item)
            },
            onConfirmSelection = { item ->
                val cfg = draftSettings.getPrayerConfig(PrayerType.FAJR_FIRST)
                val updatedCfg = cfg.copy(adhanSoundUri = item.uri, adhanSoundName = item.name)
                val updated = draftSettings.withPrayerConfig(updatedCfg)
                draftSettings = updated
                onSaveSettings(updated)
                showFajrLibraryDialog = false
            },
            onDismiss = { showFajrLibraryDialog = false }
        )
    }

    if (showIqamaLibraryDialog) {
        AudioLibrarySelectionDialog(
            title = "مكتبة أصوات الإقامة (للإقامة فقط)",
            subtitle = "أصوات الإقامة المستقلة المخصصة للإقامة دون خلطها بالأذان",
            initialSelectedUri = draftSettings.defaultIqamaSound,
            librarySounds = draftSettings.savedIqamaSounds,
            isPlayingTest = isPlayingTest && currentlyTestingAudioKey == "iqama_common",
            playingSoundKey = if (isPlayingTest && currentlyTestingAudioKey == "iqama_common") draftSettings.defaultIqamaSound else null,
            onTestSound = { sound ->
                currentlyTestingAudioKey = "iqama_common"
                onTestAudio?.invoke(sound)
            },
            onStopSound = {
                onStopAudio?.invoke()
                currentlyTestingAudioKey = null
            },
            onImportFileFromPhone = { name, uri ->
                onAddIqamaToLibrary?.invoke(name, uri)
            },
            onDeleteSound = { item ->
                onDeleteIqamaFromLibrary?.invoke(item)
            },
            onConfirmSelection = { item ->
                val updated = draftSettings.copy(defaultIqamaSound = item.uri)
                draftSettings = updated
                onSaveSettings(updated)
                showIqamaLibraryDialog = false
            },
            onDismiss = { showIqamaLibraryDialog = false }
        )
    }

    if (showGeneralAdhanLibraryDialog) {
        AudioLibrarySelectionDialog(
            title = "مكتبة الأذان العامة الموحدة",
            subtitle = "اختر صوتاً لتعميمه على جميع الأذانات",
            initialSelectedUri = draftSettings.commonAdhanSound,
            librarySounds = draftSettings.savedAdhanSounds,
            isPlayingTest = isPlayingTest && currentlyTestingAudioKey == "adhan_common",
            playingSoundKey = if (isPlayingTest && currentlyTestingAudioKey == "adhan_common") draftSettings.commonAdhanSound else null,
            onTestSound = { sound ->
                currentlyTestingAudioKey = "adhan_common"
                onTestAudio?.invoke(sound)
            },
            onStopSound = {
                onStopAudio?.invoke()
                currentlyTestingAudioKey = null
            },
            onImportFileFromPhone = { name, uri ->
                onAddAdhanToLibrary?.invoke(name, uri)
            },
            onDeleteSound = { item ->
                onDeleteAdhanFromLibrary?.invoke(item)
            },
            onConfirmSelection = { item ->
                val updated = draftSettings.copy(commonAdhanSound = item.uri)
                draftSettings = updated
                onSaveSettings(updated)
                showGeneralAdhanLibraryDialog = false
            },
            onDismiss = { showGeneralAdhanLibraryDialog = false }
        )
    }
}


/**
 * بطاقة إعدادات قياسية لصفحة الإدارة بتصميم موحد وزوايا مستديرة 14px وحدود كحلية زرقاء 1.2px.
 */
@Composable
private fun SettingsCard(
    title: String,
    description: String,
    content: @Composable () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = ColorCardBg),
        border = BorderStroke(1.2.dp, ColorCardBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(24.dp)
        ) {
            Text(
                text = title,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = CairoFamily,
                color = ColorGoldTitle
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = description,
                fontSize = 14.sp,
                fontFamily = CairoFamily,
                color = ColorTextDesc
            )

            Spacer(modifier = Modifier.height(16.dp))

            content()
        }
    }
}

/**
 * زر حفظ خاص بكل قسم مطابق تماماً لأزرار الحفظ في إعدادات الصلوات (PrayerDetailDialog).
 * يتميز باللون الذهبي الملكي وأيقونة التأكيد مع كتابة كحلية داكنة وزوايا مستديرة 12dp.
 */
@Composable
private fun SectionSaveButton(
    text: String = "حفظ هذا القسم",
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = ColorGoldTitle,
            contentColor = Color(0xFF071F3D)
        ),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .height(46.dp)
    ) {
        Icon(
            imageVector = Icons.Default.Check,
            contentDescription = null,
            tint = Color(0xFF071F3D),
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = text,
            fontSize = 14.5.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = CairoFamily,
            color = Color(0xFF071F3D)
        )
    }
}

/**
 * أداة ضبط الأرقام والمدد (+ 10 -) مطابقة تماماً لإعدادات كل صلاة (MinuteAdjuster).
 * حاوية موحدة ذات زوايا مستديرة وخلفية كحلية داكنة مع إطار ذهبي وزر (+) وزر (-) ومربع قيمة في المنتصف.
 */
@Composable
private fun UnifiedNumberAdjuster(
    valueText: String,
    onIncrement: () -> Unit,
    onDecrement: () -> Unit,
    minBoxWidth: androidx.compose.ui.unit.Dp = 56.dp,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = MosqueDeepGreen,
        border = BorderStroke(1.2.dp, MosqueGold.copy(alpha = 0.85f)),
        modifier = modifier
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.padding(horizontal = 2.dp, vertical = 2.dp)
        ) {
            // زر الزيادة (+) في اليمين (في RTL)
            IconButton(
                onClick = onIncrement,
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
            ) {
                Text(
                    text = "+",
                    color = MosqueLightGold,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center
                )
            }

            // مربع القيمة في المنتصف بخلفية كحلية وإطار ذهبي مطابق لإعدادات الصلوات
            Box(
                modifier = Modifier
                    .defaultMinSize(minWidth = minBoxWidth, minHeight = 36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MosqueVeryDarkGreen)
                    .border(1.dp, MosqueGold.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = valueText,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    color = MosqueWhite,
                    fontFamily = CairoFamily,
                    textAlign = TextAlign.Center
                )
            }

            // زر النقصان (-) في اليسار (في RTL)
            IconButton(
                onClick = onDecrement,
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
            ) {
                Text(
                    text = "-",
                    color = MosqueLightGold,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

/**
 * صف لعرض مدة صلاة واحدة مع أداة الضبط الموحدة (+ 10 -).
 */
@Composable
private fun PrayerDurationRow(
    name: String,
    duration: Int,
    onChange: (Int) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = name,
            fontSize = 14.5.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = CairoFamily,
            color = Color.White
        )

        UnifiedNumberAdjuster(
            valueText = "$duration د",
            onIncrement = { if (duration < 60) onChange(duration + 1) },
            onDecrement = { if (duration > 1) onChange(duration - 1) },
            minBoxWidth = 56.dp
        )
    }
}

/**
 * أزرار خيارات جاهزة للمدد بتصميم منسجم مع إعدادات الصلاة.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DurationPresetChips(
    presets: List<Int>,
    selected: Int,
    onSelect: (Int) -> Unit
) {
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        presets.forEach { preset ->
            val isSelected = selected == preset
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (isSelected) MosqueGold else MosqueDarkGreen,
                border = BorderStroke(
                    1.dp,
                    if (isSelected) MosqueGold else MosqueGold.copy(alpha = 0.45f)
                ),
                modifier = Modifier.clickable { onSelect(preset) }
            ) {
                Text(
                    text = "$preset دقيقة",
                    fontSize = 13.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                    fontFamily = CairoFamily,
                    color = if (isSelected) MosqueVeryDarkGreen else MosqueLightGold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
            }
        }
    }
}

/**
 * بطاقة معاينة واجهة مستقلة ومطابقة للمواصفات:
 * عنوانها ووصفها في الجهة اليمنى، وزر المعاينة الذهبي في الجهة اليسرى.
 */
@Composable
private fun PreviewRowCard(
    title: String,
    description: String,
    onPreview: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = ColorAdminBg),
        border = BorderStroke(1.dp, ColorCardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 14.5.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = CairoFamily,
                    color = Color.White
                )
                Text(
                    text = description,
                    fontSize = 12.5.sp,
                    fontFamily = CairoFamily,
                    color = ColorTextDesc
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Button(
                onClick = onPreview,
                colors = ButtonDefaults.buttonColors(
                    containerColor = ColorGoldTitle,
                    contentColor = MosqueVeryDarkGreen
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.height(42.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Visibility,
                    contentDescription = null,
                    tint = MosqueVeryDarkGreen,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "معاينة الواجهة",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = CairoFamily,
                    color = MosqueVeryDarkGreen
                )
            }
        }
    }
}
