package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PrayerState
import com.example.ui.theme.*

@Composable
fun StateAlertBanner(
    state: PrayerState,
    currentPrayerName: String,
    modifier: Modifier = Modifier
) {
    val alertText: String? = when (state) {
        PrayerState.PRE_PRAYER -> {
            if (currentPrayerName.contains("شروق") || currentPrayerName.contains("الشروق")) null
            else "اقترب موعد أذان $currentPrayerName"
        }
        PrayerState.ADHAN -> {
            if (currentPrayerName.contains("شروق") || currentPrayerName.contains("الشروق")) null
            else "حان الآن موعد أذان $currentPrayerName"
        }
        PrayerState.IQAMA -> "حان موعد إقامة صلاة $currentPrayerName .. استووا"
        PrayerState.FRIDAY_PRE_FIRST -> "اقترب موعد الأذان الأول"
        PrayerState.FRIDAY_FIRST_ADHAN -> "حان الآن موعد الأذان الأول"
        PrayerState.FRIDAY_BETWEEN_ADHANS -> "بين الأذانين .. استعدوا للخطبة"
        PrayerState.FRIDAY_SECOND_ADHAN -> "حان الآن موعد الأذان الثاني"
        PrayerState.FRIDAY_IQAMA -> "صلاة الجمعة .. استمع للخطبة"
        else -> null
    }

    AnimatedVisibility(
        visible = alertText != null,
        enter = slideInVertically() + fadeIn(),
        exit = slideOutVertically() + fadeOut(),
        modifier = modifier
    ) {
        if (alertText != null) {
            val bgBrush = when (state) {
                PrayerState.ADHAN, PrayerState.FRIDAY_FIRST_ADHAN, PrayerState.FRIDAY_SECOND_ADHAN ->
                    Brush.horizontalGradient(listOf(Color(0xFF8B1E1E), Color(0xFFB71C1C), Color(0xFF8B1E1E)))
                PrayerState.IQAMA, PrayerState.FRIDAY_IQAMA ->
                    Brush.horizontalGradient(listOf(Color(0xFF1B5E20), Color(0xFF2E7D32), Color(0xFF1B5E20)))
                else ->
                    Brush.horizontalGradient(listOf(MosqueDarkGreen, MosqueVeryDarkGreen, MosqueDarkGreen))
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .shadow(8.dp, RoundedCornerShape(14.dp))
                    .clip(RoundedCornerShape(14.dp))
                    .background(bgBrush)
                    .border(1.5.dp, MosqueGold, RoundedCornerShape(14.dp))
                    .padding(vertical = 10.dp, horizontal = 20.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = alertText,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    color = MosqueLightGold,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}
