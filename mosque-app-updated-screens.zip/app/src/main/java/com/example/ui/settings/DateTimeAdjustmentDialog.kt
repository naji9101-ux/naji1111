package com.example.ui.settings

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.HijriCalendarHelper
import com.example.ui.theme.*
import java.time.LocalDate
import java.time.LocalTime
import java.time.YearMonth
import java.time.temporal.ChronoUnit
import java.util.Locale

private val ColorAdminBg = ScreenshotNavyBg
private val ColorCardBg = ScreenshotNavyDark
private val ColorCardBorder = ScreenshotBorderBlue
private val ColorGoldTitle = ScreenshotGoldPrimary
private val ColorGoldLight = MosqueLightGold
private val ColorTextDesc = MosqueLightGold.copy(alpha = 0.85f)

@Composable
fun DateTimeAdjustmentDialog(
    initialTargetYear: Int,
    initialTargetMonth: Int,
    initialTargetDay: Int,
    initialTargetHour12: Int,
    initialTargetMinute: Int,
    initialTargetIsPm: Boolean,
    initialIsTimeCorrectionEnabled: Boolean,
    initialIsDateCorrectionEnabled: Boolean,
    hijriDayOffset: Int,
    onSave: (
        isTimeEnabled: Boolean,
        timeOffsetHours: Int,
        timeOffsetMinutes: Int,
        isDateEnabled: Boolean,
        gregorianDayOffset: Int,
        targetYear: Int,
        targetMonth: Int,
        targetDay: Int,
        targetHour12: Int,
        targetMinute: Int,
        targetIsPm: Boolean
    ) -> Unit,
    onDismiss: () -> Unit
) {
    val focusManager = LocalFocusManager.current

    var isTimeCorrectionEnabled by remember { mutableStateOf(initialIsTimeCorrectionEnabled) }
    var isDateCorrectionEnabled by remember { mutableStateOf(initialIsDateCorrectionEnabled) }

    var targetHour12 by remember { mutableIntStateOf(initialTargetHour12) }
    var targetMinute by remember { mutableIntStateOf(initialTargetMinute) }
    var targetIsPm by remember { mutableStateOf(initialTargetIsPm) }

    var hourInputText by remember { mutableStateOf(String.format(Locale.US, "%02d", initialTargetHour12)) }
    var minuteInputText by remember { mutableStateOf(String.format(Locale.US, "%02d", initialTargetMinute)) }
    var isHourFocused by remember { mutableStateOf(false) }
    var isMinuteFocused by remember { mutableStateOf(false) }

    var targetYear by remember { mutableIntStateOf(initialTargetYear) }
    var targetMonth by remember { mutableIntStateOf(initialTargetMonth) }
    var targetDay by remember { mutableIntStateOf(initialTargetDay) }

    var yearInputText by remember { mutableStateOf(String.format(Locale.US, "%04d", initialTargetYear)) }
    var monthInputText by remember { mutableStateOf(String.format(Locale.US, "%02d", initialTargetMonth)) }
    var dayInputText by remember { mutableStateOf(String.format(Locale.US, "%02d", initialTargetDay)) }

    var isYearFocused by remember { mutableStateOf(false) }
    var isMonthFocused by remember { mutableStateOf(false) }
    var isDayFocused by remember { mutableStateOf(false) }

    fun calculateOffsetsFromTarget(h12: Int, minute: Int, isPm: Boolean): Pair<Int, Int> {
        val sys = LocalTime.now()
        val curH24 = when {
            isPm && h12 == 12 -> 12
            isPm -> h12 + 12
            !isPm && h12 == 12 -> 0
            else -> h12
        }
        val targetTotal = curH24 * 60 + minute
        val sysTotal = sys.hour * 60 + sys.minute
        var diff = targetTotal - sysTotal
        if (diff > 720) diff -= 1440
        if (diff < -720) diff += 1440
        val offH = diff / 60
        val offM = diff % 60
        return Pair(offH, offM)
    }

    fun calculateDayOffsetFromTarget(year: Int, month: Int, day: Int): Int {
        return try {
            val maxDaysInMonth = YearMonth.of(year, month).lengthOfMonth()
            val validDay = day.coerceIn(1, maxDaysInMonth)
            val target = LocalDate.of(year, month, validDay)
            val sysDate = LocalDate.now()
            ChronoUnit.DAYS.between(sysDate, target).toInt()
        } catch (e: Exception) {
            0
        }
    }

    fun addMinutesToTarget(deltaMinutes: Int) {
        val curH24 = when {
            targetIsPm && targetHour12 == 12 -> 12
            targetIsPm -> targetHour12 + 12
            !targetIsPm && targetHour12 == 12 -> 0
            else -> targetHour12
        }
        val currentTotal = (curH24 * 60 + targetMinute + deltaMinutes) % 1440
        val normalizedTotal = if (currentTotal < 0) currentTotal + 1440 else currentTotal
        val newH24 = normalizedTotal / 60
        val newMin = normalizedTotal % 60
        targetHour12 = when (val h = newH24 % 12) {
            0 -> 12
            else -> h
        }
        targetMinute = newMin
        targetIsPm = newH24 >= 12
        hourInputText = String.format(Locale.US, "%02d", targetHour12)
        minuteInputText = String.format(Locale.US, "%02d", targetMinute)
        isTimeCorrectionEnabled = true
    }

    fun updateTargetDate(newDate: LocalDate) {
        targetYear = newDate.year
        targetMonth = newDate.monthValue
        targetDay = newDate.dayOfMonth
        dayInputText = String.format(Locale.US, "%02d", targetDay)
        monthInputText = String.format(Locale.US, "%02d", targetMonth)
        yearInputText = String.format(Locale.US, "%04d", targetYear)
        isDateCorrectionEnabled = true
    }

    fun addDaysToTarget(deltaDays: Int) {
        try {
            val maxDays = YearMonth.of(targetYear, targetMonth).lengthOfMonth()
            val curDay = targetDay.coerceIn(1, maxDays)
            val curDate = LocalDate.of(targetYear, targetMonth, curDay)
            val nextDate = curDate.plusDays(deltaDays.toLong())
            updateTargetDate(nextDate)
        } catch (e: Exception) {
            // fallback
        }
    }

    fun addMonthsToTarget(deltaMonths: Int) {
        try {
            val curDate = LocalDate.of(targetYear, targetMonth, 1)
            val nextMonthDate = curDate.plusMonths(deltaMonths.toLong())
            val maxDays = nextMonthDate.lengthOfMonth()
            val validDay = targetDay.coerceIn(1, maxDays)
            updateTargetDate(LocalDate.of(nextMonthDate.year, nextMonthDate.monthValue, validDay))
        } catch (e: Exception) {
            // fallback
        }
    }

    fun addYearsToTarget(deltaYears: Int) {
        try {
            val newY = (targetYear + deltaYears).coerceIn(2020, 2060)
            val maxDays = YearMonth.of(newY, targetMonth).lengthOfMonth()
            val validDay = targetDay.coerceIn(1, maxDays)
            updateTargetDate(LocalDate.of(newY, targetMonth, validDay))
        } catch (e: Exception) {
            // fallback
        }
    }

    fun resetToDeviceTime() {
        val sysNow = LocalTime.now()
        targetHour12 = when (val h = sysNow.hour % 12) {
            0 -> 12
            else -> h
        }
        targetMinute = sysNow.minute
        targetIsPm = sysNow.hour >= 12
        hourInputText = String.format(Locale.US, "%02d", targetHour12)
        minuteInputText = String.format(Locale.US, "%02d", targetMinute)
        isTimeCorrectionEnabled = false
    }

    fun resetToDeviceDate() {
        val sysDate = LocalDate.now()
        targetYear = sysDate.year
        targetMonth = sysDate.monthValue
        targetDay = sysDate.dayOfMonth
        dayInputText = String.format(Locale.US, "%02d", targetDay)
        monthInputText = String.format(Locale.US, "%02d", targetMonth)
        yearInputText = String.format(Locale.US, "%04d", targetYear)
        isDateCorrectionEnabled = false
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.65f))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) { onDismiss() },
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = ColorAdminBg),
                    border = BorderStroke(1.5.dp, ColorGoldTitle),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .fillMaxWidth(0.92f)
                        .widthIn(max = 640.dp)
                        .fillMaxHeight(0.92f)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { /* prevent dismiss */ }
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(20.dp)
                    ) {
                        // شريط عنوان النافذة
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = CircleShape,
                                    color = ColorCardBg,
                                    border = BorderStroke(1.dp, ColorGoldTitle.copy(alpha = 0.6f)),
                                    modifier = Modifier.size(42.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.Schedule,
                                            contentDescription = null,
                                            tint = ColorGoldTitle,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "نافذة ضبط التاريخ والوقت",
                                        fontSize = 19.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = CairoFamily,
                                        color = ColorGoldTitle
                                    )
                                    Text(
                                        text = "تعديل الساعة والتاريخ للشاشة الرئيسية ومواقيت الصلاة",
                                        fontSize = 12.5.sp,
                                        fontFamily = CairoFamily,
                                        color = ColorTextDesc
                                    )
                                }
                            }

                            IconButton(
                                onClick = onDismiss,
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(ColorCardBg)
                                    .border(1.dp, ColorCardBorder, CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "إغلاق النافذة",
                                    tint = ColorGoldLight,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // المحتوى القابل للتمرير
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .verticalScroll(rememberScrollState()),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // 1. مفتاح تفعيل ضبط التاريخ والوقت
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(ColorCardBg)
                                    .border(1.dp, ColorCardBorder, RoundedCornerShape(12.dp))
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "تفعيل ضبط التاريخ والوقت يدوياً",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = CairoFamily,
                                        color = Color.White
                                    )
                                    Text(
                                        text = if (isTimeCorrectionEnabled || isDateCorrectionEnabled)
                                            "مفعّل (تعمل الساعة والتاريخ طبقاً للمضبوط هنا)"
                                        else
                                            "معطّل (تعمل الساعة والتاريخ تلقائياً طبقاً لتوقيت وتاريخ الجهاز)",
                                        fontSize = 12.sp,
                                        fontFamily = CairoFamily,
                                        color = if (isTimeCorrectionEnabled || isDateCorrectionEnabled) ColorGoldLight else ColorTextDesc
                                    )
                                }

                                Spacer(modifier = Modifier.width(10.dp))

                                Switch(
                                    checked = isTimeCorrectionEnabled || isDateCorrectionEnabled,
                                    onCheckedChange = {
                                        isTimeCorrectionEnabled = it
                                        isDateCorrectionEnabled = it
                                    },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = ColorGoldTitle,
                                        checkedTrackColor = ColorCardBorder,
                                        uncheckedThumbColor = ColorTextDesc.copy(alpha = 0.5f),
                                        uncheckedTrackColor = ColorAdminBg
                                    )
                                )
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // 2. بطاقة التاريخ الميلادي (السنة على اليسار واليوم على اليمين)
                            Card(
                                colors = CardDefaults.cardColors(containerColor = ColorCardBg),
                                border = BorderStroke(1.5.dp, if (isDateCorrectionEnabled) ColorGoldTitle else ColorCardBorder),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.CalendarMonth,
                                            contentDescription = null,
                                            tint = ColorGoldTitle,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "ضبط التاريخ الميلادي (السنة / الشهر / اليوم)",
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = CairoFamily,
                                            color = ColorGoldLight
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(14.dp))

                                    // صف مربعات التاريخ: السنة يسار، اليوم يمين
                                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.Center,
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            // 1. عمود السنة (4 أرقام) - على اليسار
                                            Column(
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                modifier = Modifier.width(96.dp)
                                            ) {
                                                IconButton(
                                                    onClick = { addYearsToTarget(1) },
                                                    modifier = Modifier
                                                        .size(38.dp)
                                                        .clip(CircleShape)
                                                        .background(ColorAdminBg)
                                                        .border(1.dp, ColorCardBorder, CircleShape)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.KeyboardArrowUp,
                                                        contentDescription = "زيادة السنة",
                                                        tint = ColorGoldTitle
                                                    )
                                                }

                                                Spacer(modifier = Modifier.height(6.dp))

                                                Box(
                                                    modifier = Modifier
                                                        .size(width = 92.dp, height = 64.dp)
                                                        .clip(RoundedCornerShape(12.dp))
                                                        .background(ColorAdminBg)
                                                        .border(
                                                            1.5.dp,
                                                            if (isYearFocused || isDateCorrectionEnabled) ColorGoldTitle else ColorCardBorder,
                                                            RoundedCornerShape(12.dp)
                                                        ),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    BasicTextField(
                                                        value = yearInputText,
                                                        onValueChange = { input ->
                                                            val digits = input.filter { it.isDigit() }.take(4)
                                                            yearInputText = digits
                                                            val parsed = digits.toIntOrNull()
                                                            if (parsed != null && parsed in 2020..2060) {
                                                                targetYear = parsed
                                                                val maxDays = YearMonth.of(targetYear, targetMonth).lengthOfMonth()
                                                                if (targetDay > maxDays) targetDay = maxDays
                                                                dayInputText = String.format(Locale.US, "%02d", targetDay)
                                                                isDateCorrectionEnabled = true
                                                            }
                                                        },
                                                        textStyle = TextStyle(
                                                            fontSize = 28.sp,
                                                            fontWeight = FontWeight.ExtraBold,
                                                            fontFamily = CairoFamily,
                                                            color = Color.White,
                                                            textAlign = TextAlign.Center
                                                        ),
                                                        cursorBrush = SolidColor(ColorGoldTitle),
                                                        keyboardOptions = KeyboardOptions(
                                                            keyboardType = KeyboardType.Number,
                                                            imeAction = ImeAction.Done
                                                        ),
                                                        keyboardActions = KeyboardActions(
                                                            onDone = {
                                                                val parsed = yearInputText.toIntOrNull()
                                                                val finalY = when {
                                                                    parsed == null || parsed < 2020 -> targetYear
                                                                    parsed > 2060 -> 2060
                                                                    else -> parsed
                                                                }
                                                                targetYear = finalY
                                                                yearInputText = String.format(Locale.US, "%04d", finalY)
                                                                isDateCorrectionEnabled = true
                                                                focusManager.clearFocus()
                                                            }
                                                        ),
                                                        singleLine = true,
                                                        modifier = Modifier
                                                            .fillMaxSize()
                                                            .onFocusChanged { focusState ->
                                                                isYearFocused = focusState.isFocused
                                                                if (!focusState.isFocused) {
                                                                    val parsed = yearInputText.toIntOrNull()
                                                                    val finalY = when {
                                                                        parsed == null || parsed < 2020 -> targetYear
                                                                        parsed > 2060 -> 2060
                                                                        else -> parsed
                                                                    }
                                                                    targetYear = finalY
                                                                    yearInputText = String.format(Locale.US, "%04d", finalY)
                                                                    isDateCorrectionEnabled = true
                                                                }
                                                            },
                                                        decorationBox = { innerTextField ->
                                                            Box(
                                                                contentAlignment = Alignment.Center,
                                                                modifier = Modifier.fillMaxSize()
                                                            ) {
                                                                innerTextField()
                                                            }
                                                        }
                                                    )
                                                }

                                                Spacer(modifier = Modifier.height(6.dp))

                                                IconButton(
                                                    onClick = { addYearsToTarget(-1) },
                                                    modifier = Modifier
                                                        .size(38.dp)
                                                        .clip(CircleShape)
                                                        .background(ColorAdminBg)
                                                        .border(1.dp, ColorCardBorder, CircleShape)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.KeyboardArrowDown,
                                                        contentDescription = "إنقاص السنة",
                                                        tint = ColorGoldTitle
                                                    )
                                                }

                                                Text(
                                                    text = "السنة",
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    fontFamily = CairoFamily,
                                                    color = ColorTextDesc,
                                                    modifier = Modifier.padding(top = 4.dp)
                                                )
                                            }

                                            // فاصل (/)
                                            Text(
                                                text = "/",
                                                fontSize = 32.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = ColorGoldTitle,
                                                modifier = Modifier
                                                    .padding(horizontal = 8.dp)
                                                    .offset(y = (-14).dp)
                                            )

                                            // 2. عمود الشهر (1-12) - في الوسط
                                            Column(
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                modifier = Modifier.width(78.dp)
                                            ) {
                                                IconButton(
                                                    onClick = { addMonthsToTarget(1) },
                                                    modifier = Modifier
                                                        .size(38.dp)
                                                        .clip(CircleShape)
                                                        .background(ColorAdminBg)
                                                        .border(1.dp, ColorCardBorder, CircleShape)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.KeyboardArrowUp,
                                                        contentDescription = "زيادة الشهر",
                                                        tint = ColorGoldTitle
                                                    )
                                                }

                                                Spacer(modifier = Modifier.height(6.dp))

                                                Box(
                                                    modifier = Modifier
                                                        .size(width = 74.dp, height = 64.dp)
                                                        .clip(RoundedCornerShape(12.dp))
                                                        .background(ColorAdminBg)
                                                        .border(
                                                            1.5.dp,
                                                            if (isMonthFocused || isDateCorrectionEnabled) ColorGoldTitle else ColorCardBorder,
                                                            RoundedCornerShape(12.dp)
                                                        ),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    BasicTextField(
                                                        value = monthInputText,
                                                        onValueChange = { input ->
                                                            val digits = input.filter { it.isDigit() }.take(2)
                                                            monthInputText = digits
                                                            val parsed = digits.toIntOrNull()
                                                            if (parsed != null && parsed in 1..12) {
                                                                targetMonth = parsed
                                                                val maxDays = YearMonth.of(targetYear, targetMonth).lengthOfMonth()
                                                                if (targetDay > maxDays) targetDay = maxDays
                                                                dayInputText = String.format(Locale.US, "%02d", targetDay)
                                                                isDateCorrectionEnabled = true
                                                            }
                                                        },
                                                        textStyle = TextStyle(
                                                            fontSize = 32.sp,
                                                            fontWeight = FontWeight.ExtraBold,
                                                            fontFamily = CairoFamily,
                                                            color = Color.White,
                                                            textAlign = TextAlign.Center
                                                        ),
                                                        cursorBrush = SolidColor(ColorGoldTitle),
                                                        keyboardOptions = KeyboardOptions(
                                                            keyboardType = KeyboardType.Number,
                                                            imeAction = ImeAction.Done
                                                        ),
                                                        keyboardActions = KeyboardActions(
                                                            onDone = {
                                                                val parsed = monthInputText.toIntOrNull()
                                                                val finalM = when {
                                                                    parsed == null || parsed <= 0 -> targetMonth
                                                                    parsed > 12 -> 12
                                                                    else -> parsed
                                                                }
                                                                targetMonth = finalM
                                                                val maxDays = YearMonth.of(targetYear, targetMonth).lengthOfMonth()
                                                                if (targetDay > maxDays) targetDay = maxDays
                                                                dayInputText = String.format(Locale.US, "%02d", targetDay)
                                                                monthInputText = String.format(Locale.US, "%02d", finalM)
                                                                isDateCorrectionEnabled = true
                                                                focusManager.clearFocus()
                                                            }
                                                        ),
                                                        singleLine = true,
                                                        modifier = Modifier
                                                            .fillMaxSize()
                                                            .onFocusChanged { focusState ->
                                                                isMonthFocused = focusState.isFocused
                                                                if (!focusState.isFocused) {
                                                                    val parsed = monthInputText.toIntOrNull()
                                                                    val finalM = when {
                                                                        parsed == null || parsed <= 0 -> targetMonth
                                                                        parsed > 12 -> 12
                                                                        else -> parsed
                                                                    }
                                                                    targetMonth = finalM
                                                                    val maxDays = YearMonth.of(targetYear, targetMonth).lengthOfMonth()
                                                                    if (targetDay > maxDays) targetDay = maxDays
                                                                    dayInputText = String.format(Locale.US, "%02d", targetDay)
                                                                    monthInputText = String.format(Locale.US, "%02d", finalM)
                                                                    isDateCorrectionEnabled = true
                                                                }
                                                            },
                                                        decorationBox = { innerTextField ->
                                                            Box(
                                                                contentAlignment = Alignment.Center,
                                                                modifier = Modifier.fillMaxSize()
                                                            ) {
                                                                innerTextField()
                                                            }
                                                        }
                                                    )
                                                }

                                                Spacer(modifier = Modifier.height(6.dp))

                                                IconButton(
                                                    onClick = { addMonthsToTarget(-1) },
                                                    modifier = Modifier
                                                        .size(38.dp)
                                                        .clip(CircleShape)
                                                        .background(ColorAdminBg)
                                                        .border(1.dp, ColorCardBorder, CircleShape)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.KeyboardArrowDown,
                                                        contentDescription = "إنقاص الشهر",
                                                        tint = ColorGoldTitle
                                                    )
                                                }

                                                Text(
                                                    text = "الشهر",
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    fontFamily = CairoFamily,
                                                    color = ColorTextDesc,
                                                    modifier = Modifier.padding(top = 4.dp)
                                                )
                                            }

                                            // فاصل (/)
                                            Text(
                                                text = "/",
                                                fontSize = 32.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = ColorGoldTitle,
                                                modifier = Modifier
                                                    .padding(horizontal = 8.dp)
                                                    .offset(y = (-14).dp)
                                            )

                                            // 3. عمود اليوم (1-31) - على اليمين
                                            Column(
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                modifier = Modifier.width(78.dp)
                                            ) {
                                                IconButton(
                                                    onClick = { addDaysToTarget(1) },
                                                    modifier = Modifier
                                                        .size(38.dp)
                                                        .clip(CircleShape)
                                                        .background(ColorAdminBg)
                                                        .border(1.dp, ColorCardBorder, CircleShape)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.KeyboardArrowUp,
                                                        contentDescription = "زيادة اليوم",
                                                        tint = ColorGoldTitle
                                                    )
                                                }

                                                Spacer(modifier = Modifier.height(6.dp))

                                                Box(
                                                    modifier = Modifier
                                                        .size(width = 74.dp, height = 64.dp)
                                                        .clip(RoundedCornerShape(12.dp))
                                                        .background(ColorAdminBg)
                                                        .border(
                                                            1.5.dp,
                                                            if (isDayFocused || isDateCorrectionEnabled) ColorGoldTitle else ColorCardBorder,
                                                            RoundedCornerShape(12.dp)
                                                        ),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    BasicTextField(
                                                        value = dayInputText,
                                                        onValueChange = { input ->
                                                            val digits = input.filter { it.isDigit() }.take(2)
                                                            dayInputText = digits
                                                            val parsed = digits.toIntOrNull()
                                                            val maxDays = try { YearMonth.of(targetYear, targetMonth).lengthOfMonth() } catch (e: Exception) { 31 }
                                                            if (parsed != null && parsed in 1..maxDays) {
                                                                targetDay = parsed
                                                                isDateCorrectionEnabled = true
                                                            }
                                                        },
                                                        textStyle = TextStyle(
                                                            fontSize = 32.sp,
                                                            fontWeight = FontWeight.ExtraBold,
                                                            fontFamily = CairoFamily,
                                                            color = Color.White,
                                                            textAlign = TextAlign.Center
                                                        ),
                                                        cursorBrush = SolidColor(ColorGoldTitle),
                                                        keyboardOptions = KeyboardOptions(
                                                            keyboardType = KeyboardType.Number,
                                                            imeAction = ImeAction.Done
                                                        ),
                                                        keyboardActions = KeyboardActions(
                                                            onDone = {
                                                                val maxDays = try { YearMonth.of(targetYear, targetMonth).lengthOfMonth() } catch (e: Exception) { 31 }
                                                                val parsed = dayInputText.toIntOrNull()
                                                                val finalD = when {
                                                                    parsed == null || parsed <= 0 -> targetDay
                                                                    parsed > maxDays -> maxDays
                                                                    else -> parsed
                                                                }
                                                                targetDay = finalD
                                                                dayInputText = String.format(Locale.US, "%02d", finalD)
                                                                isDateCorrectionEnabled = true
                                                                focusManager.clearFocus()
                                                            }
                                                        ),
                                                        singleLine = true,
                                                        modifier = Modifier
                                                            .fillMaxSize()
                                                            .onFocusChanged { focusState ->
                                                                isDayFocused = focusState.isFocused
                                                                if (!focusState.isFocused) {
                                                                    val maxDays = try { YearMonth.of(targetYear, targetMonth).lengthOfMonth() } catch (e: Exception) { 31 }
                                                                    val parsed = dayInputText.toIntOrNull()
                                                                    val finalD = when {
                                                                        parsed == null || parsed <= 0 -> targetDay
                                                                        parsed > maxDays -> maxDays
                                                                        else -> parsed
                                                                    }
                                                                    targetDay = finalD
                                                                    dayInputText = String.format(Locale.US, "%02d", finalD)
                                                                    isDateCorrectionEnabled = true
                                                                }
                                                            },
                                                        decorationBox = { innerTextField ->
                                                            Box(
                                                                contentAlignment = Alignment.Center,
                                                                modifier = Modifier.fillMaxSize()
                                                            ) {
                                                                innerTextField()
                                                            }
                                                        }
                                                    )
                                                }

                                                Spacer(modifier = Modifier.height(6.dp))

                                                IconButton(
                                                    onClick = { addDaysToTarget(-1) },
                                                    modifier = Modifier
                                                        .size(38.dp)
                                                        .clip(CircleShape)
                                                        .background(ColorAdminBg)
                                                        .border(1.dp, ColorCardBorder, CircleShape)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.KeyboardArrowDown,
                                                        contentDescription = "إنقاص اليوم",
                                                        tint = ColorGoldTitle
                                                    )
                                                }

                                                Text(
                                                    text = "اليوم",
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    fontFamily = CairoFamily,
                                                    color = ColorTextDesc,
                                                    modifier = Modifier.padding(top = 4.dp)
                                                )
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(14.dp))

                                    // أزرار التقديم والتأخير السريع بالتاريخ
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        listOf(
                                            "+1 يوم" to 1,
                                            "+7 أيام" to 7,
                                            "+1 شهر" to 30,
                                            "-1 يوم" to -1,
                                            "-7 أيام" to -7,
                                            "-1 شهر" to -30
                                        ).forEach { (label, deltaDays) ->
                                            OutlinedButton(
                                                onClick = { addDaysToTarget(deltaDays) },
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .height(34.dp),
                                                contentPadding = PaddingValues(horizontal = 2.dp, vertical = 0.dp),
                                                shape = RoundedCornerShape(8.dp),
                                                border = BorderStroke(1.dp, ColorCardBorder),
                                                colors = ButtonDefaults.outlinedButtonColors(
                                                    containerColor = ColorAdminBg,
                                                    contentColor = if (deltaDays > 0) ColorGoldLight else ColorTextDesc
                                                )
                                            ) {
                                                Text(
                                                    text = label,
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    fontFamily = CairoFamily
                                                )
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    // زر المزامنة مع تاريخ الجهاز
                                    OutlinedButton(
                                        onClick = { resetToDeviceDate() },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(38.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        border = BorderStroke(1.dp, ColorCardBorder),
                                        colors = ButtonDefaults.outlinedButtonColors(
                                            containerColor = ColorAdminBg,
                                            contentColor = ColorGoldTitle
                                        )
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Refresh,
                                            contentDescription = null,
                                            tint = ColorGoldTitle,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "إلغاء التعديل والمزامنة مع تاريخ الجهاز الآن",
                                            fontSize = 12.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = CairoFamily
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // 3. بطاقة الوقت (الساعة على اليسار والدقائق على اليمين)
                            Card(
                                colors = CardDefaults.cardColors(containerColor = ColorCardBg),
                                border = BorderStroke(1.5.dp, if (isTimeCorrectionEnabled) ColorGoldTitle else ColorCardBorder),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Schedule,
                                            contentDescription = null,
                                            tint = ColorGoldTitle,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "ضبط الوقت (الساعة والدقائق)",
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = CairoFamily,
                                            color = ColorGoldLight
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(14.dp))

                                    // صف مربعات الساعة الرقمية: الساعة يسار، الدقائق يمين
                                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.Center,
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            // عمود الساعات (1-12) - يسار
                                            Column(
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                modifier = Modifier.width(78.dp)
                                            ) {
                                                IconButton(
                                                    onClick = {
                                                        val nextH = if (targetHour12 == 12) 1 else targetHour12 + 1
                                                        targetHour12 = nextH
                                                        hourInputText = String.format(Locale.US, "%02d", nextH)
                                                        isTimeCorrectionEnabled = true
                                                    },
                                                    modifier = Modifier
                                                        .size(38.dp)
                                                        .clip(CircleShape)
                                                        .background(ColorAdminBg)
                                                        .border(1.dp, ColorCardBorder, CircleShape)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.KeyboardArrowUp,
                                                        contentDescription = "زيادة الساعة",
                                                        tint = ColorGoldTitle
                                                    )
                                                }

                                                Spacer(modifier = Modifier.height(6.dp))

                                                Box(
                                                    modifier = Modifier
                                                        .size(width = 74.dp, height = 64.dp)
                                                        .clip(RoundedCornerShape(12.dp))
                                                        .background(ColorAdminBg)
                                                        .border(
                                                            1.5.dp,
                                                            if (isHourFocused || isTimeCorrectionEnabled) ColorGoldTitle else ColorCardBorder,
                                                            RoundedCornerShape(12.dp)
                                                        ),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    BasicTextField(
                                                        value = hourInputText,
                                                        onValueChange = { input ->
                                                            val digits = input.filter { it.isDigit() }.take(2)
                                                            hourInputText = digits
                                                            val parsed = digits.toIntOrNull()
                                                            if (parsed != null && parsed in 1..12) {
                                                                targetHour12 = parsed
                                                                isTimeCorrectionEnabled = true
                                                            }
                                                        },
                                                        textStyle = TextStyle(
                                                            fontSize = 32.sp,
                                                            fontWeight = FontWeight.ExtraBold,
                                                            fontFamily = CairoFamily,
                                                            color = Color.White,
                                                            textAlign = TextAlign.Center
                                                        ),
                                                        cursorBrush = SolidColor(ColorGoldTitle),
                                                        keyboardOptions = KeyboardOptions(
                                                            keyboardType = KeyboardType.Number,
                                                            imeAction = ImeAction.Done
                                                        ),
                                                        keyboardActions = KeyboardActions(
                                                            onDone = {
                                                                val parsed = hourInputText.toIntOrNull()
                                                                val finalH = when {
                                                                    parsed == null || parsed <= 0 -> targetHour12
                                                                    parsed > 12 -> 12
                                                                    else -> parsed
                                                                }
                                                                targetHour12 = finalH
                                                                hourInputText = String.format(Locale.US, "%02d", finalH)
                                                                isTimeCorrectionEnabled = true
                                                                focusManager.clearFocus()
                                                            }
                                                        ),
                                                        singleLine = true,
                                                        modifier = Modifier
                                                            .fillMaxSize()
                                                            .onFocusChanged { focusState ->
                                                                isHourFocused = focusState.isFocused
                                                                if (!focusState.isFocused) {
                                                                    val parsed = hourInputText.toIntOrNull()
                                                                    val finalH = when {
                                                                        parsed == null || parsed <= 0 -> targetHour12
                                                                        parsed > 12 -> 12
                                                                        else -> parsed
                                                                    }
                                                                    targetHour12 = finalH
                                                                    hourInputText = String.format(Locale.US, "%02d", finalH)
                                                                    isTimeCorrectionEnabled = true
                                                                }
                                                            },
                                                        decorationBox = { innerTextField ->
                                                            Box(
                                                                contentAlignment = Alignment.Center,
                                                                modifier = Modifier.fillMaxSize()
                                                            ) {
                                                                innerTextField()
                                                            }
                                                        }
                                                    )
                                                }

                                                Spacer(modifier = Modifier.height(6.dp))

                                                IconButton(
                                                    onClick = {
                                                        val prevH = if (targetHour12 == 1) 12 else targetHour12 - 1
                                                        targetHour12 = prevH
                                                        hourInputText = String.format(Locale.US, "%02d", prevH)
                                                        isTimeCorrectionEnabled = true
                                                    },
                                                    modifier = Modifier
                                                        .size(38.dp)
                                                        .clip(CircleShape)
                                                        .background(ColorAdminBg)
                                                        .border(1.dp, ColorCardBorder, CircleShape)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.KeyboardArrowDown,
                                                        contentDescription = "إنقاص الساعة",
                                                        tint = ColorGoldTitle
                                                    )
                                                }

                                                Text(
                                                    text = "الساعة",
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    fontFamily = CairoFamily,
                                                    color = ColorTextDesc,
                                                    modifier = Modifier.padding(top = 4.dp)
                                                )
                                            }

                                            // فاصل (:)
                                            Text(
                                                text = ":",
                                                fontSize = 32.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = ColorGoldTitle,
                                                modifier = Modifier
                                                    .padding(horizontal = 8.dp)
                                                    .offset(y = (-14).dp)
                                            )

                                            // عمود الدقائق (0-59) - يمين
                                            Column(
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                modifier = Modifier.width(78.dp)
                                            ) {
                                                IconButton(
                                                    onClick = {
                                                        val nextM = if (targetMinute == 59) 0 else targetMinute + 1
                                                        targetMinute = nextM
                                                        minuteInputText = String.format(Locale.US, "%02d", nextM)
                                                        isTimeCorrectionEnabled = true
                                                    },
                                                    modifier = Modifier
                                                        .size(38.dp)
                                                        .clip(CircleShape)
                                                        .background(ColorAdminBg)
                                                        .border(1.dp, ColorCardBorder, CircleShape)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.KeyboardArrowUp,
                                                        contentDescription = "زيادة الدقيقة",
                                                        tint = ColorGoldTitle
                                                    )
                                                }

                                                Spacer(modifier = Modifier.height(6.dp))

                                                Box(
                                                    modifier = Modifier
                                                        .size(width = 74.dp, height = 64.dp)
                                                        .clip(RoundedCornerShape(12.dp))
                                                        .background(ColorAdminBg)
                                                        .border(
                                                            1.5.dp,
                                                            if (isMinuteFocused || isTimeCorrectionEnabled) ColorGoldTitle else ColorCardBorder,
                                                            RoundedCornerShape(12.dp)
                                                        ),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    BasicTextField(
                                                        value = minuteInputText,
                                                        onValueChange = { input ->
                                                            val digits = input.filter { it.isDigit() }.take(2)
                                                            minuteInputText = digits
                                                            val parsed = digits.toIntOrNull()
                                                            if (parsed != null && parsed in 0..59) {
                                                                targetMinute = parsed
                                                                isTimeCorrectionEnabled = true
                                                            }
                                                        },
                                                        textStyle = TextStyle(
                                                            fontSize = 32.sp,
                                                            fontWeight = FontWeight.ExtraBold,
                                                            fontFamily = CairoFamily,
                                                            color = Color.White,
                                                            textAlign = TextAlign.Center
                                                        ),
                                                        cursorBrush = SolidColor(ColorGoldTitle),
                                                        keyboardOptions = KeyboardOptions(
                                                            keyboardType = KeyboardType.Number,
                                                            imeAction = ImeAction.Done
                                                        ),
                                                        keyboardActions = KeyboardActions(
                                                            onDone = {
                                                                val parsed = minuteInputText.toIntOrNull()
                                                                val finalM = when {
                                                                    parsed == null || parsed < 0 -> targetMinute
                                                                    parsed > 59 -> 59
                                                                    else -> parsed
                                                                }
                                                                targetMinute = finalM
                                                                minuteInputText = String.format(Locale.US, "%02d", finalM)
                                                                isTimeCorrectionEnabled = true
                                                                focusManager.clearFocus()
                                                            }
                                                        ),
                                                        singleLine = true,
                                                        modifier = Modifier
                                                            .fillMaxSize()
                                                            .onFocusChanged { focusState ->
                                                                isMinuteFocused = focusState.isFocused
                                                                if (!focusState.isFocused) {
                                                                    val parsed = minuteInputText.toIntOrNull()
                                                                    val finalM = when {
                                                                        parsed == null || parsed < 0 -> targetMinute
                                                                        parsed > 59 -> 59
                                                                        else -> parsed
                                                                    }
                                                                    targetMinute = finalM
                                                                    minuteInputText = String.format(Locale.US, "%02d", finalM)
                                                                    isTimeCorrectionEnabled = true
                                                                }
                                                            },
                                                        decorationBox = { innerTextField ->
                                                            Box(
                                                                contentAlignment = Alignment.Center,
                                                                modifier = Modifier.fillMaxSize()
                                                            ) {
                                                                innerTextField()
                                                            }
                                                        }
                                                    )
                                                }

                                                Spacer(modifier = Modifier.height(6.dp))

                                                IconButton(
                                                    onClick = {
                                                        val prevM = if (targetMinute == 0) 59 else targetMinute - 1
                                                        targetMinute = prevM
                                                        minuteInputText = String.format(Locale.US, "%02d", prevM)
                                                        isTimeCorrectionEnabled = true
                                                    },
                                                    modifier = Modifier
                                                        .size(38.dp)
                                                        .clip(CircleShape)
                                                        .background(ColorAdminBg)
                                                        .border(1.dp, ColorCardBorder, CircleShape)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.KeyboardArrowDown,
                                                        contentDescription = "إنقاص الدقيقة",
                                                        tint = ColorGoldTitle
                                                    )
                                                }

                                                Text(
                                                    text = "الدقيقة",
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    fontFamily = CairoFamily,
                                                    color = ColorTextDesc,
                                                    modifier = Modifier.padding(top = 4.dp)
                                                )
                                            }

                                            Spacer(modifier = Modifier.width(14.dp))

                                            // اختيار صباحاً (ص) أو مساءً (م)
                                            Column(
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                verticalArrangement = Arrangement.Center,
                                                modifier = Modifier.offset(y = (-14).dp)
                                            ) {
                                                // زر صباحاً (ص)
                                                Box(
                                                    modifier = Modifier
                                                        .size(width = 46.dp, height = 34.dp)
                                                        .clip(RoundedCornerShape(8.dp))
                                                        .background(if (!targetIsPm) ColorGoldTitle else ColorAdminBg)
                                                        .border(
                                                            1.dp,
                                                            if (!targetIsPm) ColorGoldTitle else ColorCardBorder,
                                                            RoundedCornerShape(8.dp)
                                                        )
                                                        .clickable {
                                                            if (targetIsPm) {
                                                                targetIsPm = false
                                                                isTimeCorrectionEnabled = true
                                                            }
                                                        },
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        text = "ص",
                                                        fontSize = 16.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        fontFamily = CairoFamily,
                                                        color = if (!targetIsPm) Color(0xFF071F3D) else ColorTextDesc
                                                    )
                                                }

                                                Spacer(modifier = Modifier.height(8.dp))

                                                // زر مساءً (م)
                                                Box(
                                                    modifier = Modifier
                                                        .size(width = 46.dp, height = 34.dp)
                                                        .clip(RoundedCornerShape(8.dp))
                                                        .background(if (targetIsPm) ColorGoldTitle else ColorAdminBg)
                                                        .border(
                                                            1.dp,
                                                            if (targetIsPm) ColorGoldTitle else ColorCardBorder,
                                                            RoundedCornerShape(8.dp)
                                                        )
                                                        .clickable {
                                                            if (!targetIsPm) {
                                                                targetIsPm = true
                                                                isTimeCorrectionEnabled = true
                                                            }
                                                        },
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        text = "م",
                                                        fontSize = 16.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        fontFamily = CairoFamily,
                                                        color = if (targetIsPm) Color(0xFF071F3D) else ColorTextDesc
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(14.dp))

                                    // أزرار التقديم والتأخير السريع للوقت
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        listOf(
                                            "+15 د" to 15,
                                            "+1 ساعة" to 60,
                                            "+5 د" to 5,
                                            "-5 د" to -5,
                                            "-15 د" to -15,
                                            "-1 ساعة" to -60
                                        ).forEach { (label, deltaMin) ->
                                            OutlinedButton(
                                                onClick = { addMinutesToTarget(deltaMin) },
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .height(34.dp),
                                                contentPadding = PaddingValues(horizontal = 2.dp, vertical = 0.dp),
                                                shape = RoundedCornerShape(8.dp),
                                                border = BorderStroke(1.dp, ColorCardBorder),
                                                colors = ButtonDefaults.outlinedButtonColors(
                                                    containerColor = ColorAdminBg,
                                                    contentColor = if (deltaMin > 0) ColorGoldLight else ColorTextDesc
                                                )
                                            ) {
                                                Text(
                                                    text = label,
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    fontFamily = CairoFamily
                                                )
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    // زر المزامنة مع توقيت الجهاز
                                    OutlinedButton(
                                        onClick = { resetToDeviceTime() },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(38.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        border = BorderStroke(1.dp, ColorCardBorder),
                                        colors = ButtonDefaults.outlinedButtonColors(
                                            containerColor = ColorAdminBg,
                                            contentColor = ColorGoldTitle
                                        )
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Refresh,
                                            contentDescription = null,
                                            tint = ColorGoldTitle,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "إلغاء التعديل والمزامنة مع توقيت الجهاز الآن",
                                            fontSize = 12.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = CairoFamily
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // 4. بطاقة المقارنة والملخص داخل النافذة
                            val (calcOffsetHours, calcOffsetMinutes) = calculateOffsetsFromTarget(targetHour12, targetMinute, targetIsPm)
                            val totalOffsetMinutes = (calcOffsetHours * 60) + calcOffsetMinutes
                            val calcDateOffset = calculateDayOffsetFromTarget(targetYear, targetMonth, targetDay)
                            val sysNow = remember { LocalTime.now() }
                            val sysToday = remember { LocalDate.now() }
                            val sysH12 = when (val h = sysNow.hour % 12) {
                                0 -> 12
                                else -> h
                            }
                            val sysMarker = if (sysNow.hour < 12) "ص" else "م"

                            val curTargetDate = try {
                                val maxD = YearMonth.of(targetYear, targetMonth).lengthOfMonth()
                                LocalDate.of(targetYear, targetMonth, targetDay.coerceIn(1, maxD))
                            } catch (e: Exception) {
                                sysToday
                            }
                            val targetGregorianStr = HijriCalendarHelper.getGregorianDateString(curTargetDate)
                            val targetDayName = HijriCalendarHelper.getDayOfWeekArabic(curTargetDate)

                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(ColorCardBg)
                                    .border(
                                        1.dp,
                                        if (isTimeCorrectionEnabled || isDateCorrectionEnabled) ColorGoldTitle.copy(alpha = 0.7f) else ColorCardBorder,
                                        RoundedCornerShape(12.dp)
                                    )
                                    .padding(14.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(
                                            text = "تاريخ ووقت الجهاز الحالي",
                                            fontSize = 12.sp,
                                            fontFamily = CairoFamily,
                                            color = ColorTextDesc
                                        )
                                        Text(
                                            text = String.format(Locale.US, "%02d:%02d %s", sysH12, sysNow.minute, sysMarker),
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = CairoFamily,
                                            color = Color.White
                                        )
                                        Text(
                                            text = HijriCalendarHelper.getGregorianDateString(sysToday),
                                            fontSize = 12.sp,
                                            fontFamily = CairoFamily,
                                            color = ColorGoldLight
                                        )
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = if (isTimeCorrectionEnabled || isDateCorrectionEnabled) "التاريخ والوقت بعد الضبط" else "التاريخ والوقت (تلقائي)",
                                            fontSize = 12.sp,
                                            fontFamily = CairoFamily,
                                            color = if (isTimeCorrectionEnabled || isDateCorrectionEnabled) ColorGoldTitle else ColorTextDesc
                                        )
                                        Text(
                                            text = String.format(
                                                Locale.US,
                                                "%02d:%02d %s",
                                                targetHour12,
                                                targetMinute,
                                                if (targetIsPm) "م" else "ص"
                                            ),
                                            fontSize = 19.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontFamily = CairoFamily,
                                            color = if (isTimeCorrectionEnabled) ColorGoldLight else Color.White
                                        )
                                        Text(
                                            text = "$targetDayName، $targetGregorianStr",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = CairoFamily,
                                            color = if (isDateCorrectionEnabled) ColorGoldTitle else ColorTextDesc
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                val summaryMsg = when {
                                    !isTimeCorrectionEnabled && !isDateCorrectionEnabled -> "الساعة والتاريخ في الشاشة الرئيسية معتمدة على توقيت الجهاز تلقائياً"
                                    else -> {
                                        val parts = mutableListOf<String>()
                                        if (isDateCorrectionEnabled && calcDateOffset != 0) {
                                            if (calcDateOffset > 0) parts.add("تقديم التاريخ بمقدار $calcDateOffset يوم")
                                            else parts.add("تأخير التاريخ بمقدار ${-calcDateOffset} يوم")
                                        }
                                        if (isTimeCorrectionEnabled && totalOffsetMinutes != 0) {
                                            if (totalOffsetMinutes > 0) parts.add("تقديم الساعة بمقدار $totalOffsetMinutes دقيقة")
                                            else parts.add("تأخير الساعة بمقدار ${-totalOffsetMinutes} دقيقة")
                                        }
                                        if (parts.isEmpty()) "الوقت والتاريخ مطابقان لتوقيت الجهاز" else parts.joinToString("، ")
                                    }
                                }

                                Text(
                                    text = summaryMsg,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    fontFamily = CairoFamily,
                                    color = if ((isTimeCorrectionEnabled && totalOffsetMinutes != 0) || (isDateCorrectionEnabled && calcDateOffset != 0)) ColorGoldLight else ColorTextDesc
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // أزرار الحفظ والإلغاء في أسفل النافذة
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = onDismiss,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(46.dp),
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, ColorCardBorder),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = ColorCardBg,
                                    contentColor = ColorGoldTitle
                                )
                            ) {
                                Text(
                                    text = "إلغاء",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = CairoFamily
                                )
                            }

                            Button(
                                onClick = {
                                    val (calcH, calcM) = calculateOffsetsFromTarget(targetHour12, targetMinute, targetIsPm)
                                    val calcDateDays = calculateDayOffsetFromTarget(targetYear, targetMonth, targetDay)
                                    onSave(
                                        isTimeCorrectionEnabled,
                                        calcH,
                                        calcM,
                                        isDateCorrectionEnabled,
                                        calcDateDays,
                                        targetYear,
                                        targetMonth,
                                        targetDay,
                                        targetHour12,
                                        targetMinute,
                                        targetIsPm
                                    )
                                },
                                modifier = Modifier
                                    .weight(1.5f)
                                    .height(46.dp),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = ColorGoldTitle,
                                    contentColor = Color(0xFF071F3D)
                                )
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = Color(0xFF071F3D),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "حفظ وتطبيق على الرئيسية",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = CairoFamily,
                                    color = Color(0xFF071F3D)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
