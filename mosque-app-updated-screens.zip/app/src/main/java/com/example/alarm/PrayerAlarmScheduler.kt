package com.example.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.example.data.PrayerRepository
import com.example.model.PrayerType
import com.example.receiver.PrayerAlarmReceiver
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

object PrayerAlarmScheduler {

    private const val TAG = "PrayerAlarmScheduler"

    fun scheduleAllPrayers(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val repository = PrayerRepository(context)
        val schedule = repository.loadSchedule()
        val settings = repository.loadSettings()

        val now = LocalDateTime.now()
        val today = now.toLocalDate()
        val tomorrow = today.plusDays(1)

        scheduleForDate(context, alarmManager, repository, schedule, settings, today, now)
        scheduleForDate(context, alarmManager, repository, schedule, settings, tomorrow, now)
    }

    private fun scheduleForDate(
        context: Context,
        alarmManager: AlarmManager,
        repository: PrayerRepository,
        schedule: com.example.model.MosqueSchedule,
        settings: com.example.model.AppSettings,
        date: LocalDate,
        now: LocalDateTime
    ) {
        val monthData = schedule.months.find { it.month == date.monthValue }
            ?: schedule.months.firstOrNull() ?: return
        val dayData = monthData.days.find { it.day == date.dayOfMonth }
            ?: monthData.days.firstOrNull() ?: return

        val isFriday = date.dayOfWeek == DayOfWeek.FRIDAY

        fun parseTime(timeStr: String, isPm: Boolean = false): LocalTime {
            return try {
                val parts = timeStr.trim().split(":")
                var hour = parts[0].toInt()
                val min = parts[1].toInt()
                if (isPm && hour < 12) hour += 12
                LocalTime.of(hour, min)
            } catch (e: Exception) {
                LocalTime.of(12, 0)
            }
        }

        val fajrSecondTime = parseTime(dayData.fajrSecond)
        val fajrFirstTime = fajrSecondTime.minusMinutes(settings.fajrIntervalMinutes.toLong())
        val dhuhrTime = parseTime(dayData.dhuhr)
        val asrTime = parseTime(dayData.asr, isPm = true)
        val maghribTime = parseTime(dayData.maghrib, isPm = true)
        val ishaTime = parseTime(dayData.isha, isPm = true)

        data class PrayerScheduleItem(
            val type: PrayerType,
            val name: String,
            val baseTime: LocalTime,
            val hasIqama: Boolean
        )

        val items = mutableListOf<PrayerScheduleItem>()
        val fajr1Active = settings.firstAdhansMasterEnabled && settings.isFajrFirstEnabled
        if (fajr1Active) {
            items.add(PrayerScheduleItem(PrayerType.FAJR_FIRST, "الفجر الأول", fajrFirstTime, hasIqama = false))
        }
        items.add(PrayerScheduleItem(PrayerType.FAJR_SECOND, "الفجر الثاني", fajrSecondTime, hasIqama = true))

        val friday1Active = settings.firstAdhansMasterEnabled && settings.isFridayFirstEnabled
        if (isFriday) {
            if (friday1Active) {
                val fridayFirstTime = dhuhrTime.minusMinutes(settings.fridayFirstAdhanOffsetMinutes.toLong())
                items.add(PrayerScheduleItem(PrayerType.FRIDAY_FIRST, "الأذان الأول", fridayFirstTime, hasIqama = false))
                items.add(PrayerScheduleItem(PrayerType.FRIDAY_SECOND, "الأذان الثاني", dhuhrTime, hasIqama = true))
            } else {
                items.add(PrayerScheduleItem(PrayerType.FRIDAY_SECOND, "الظهر", dhuhrTime, hasIqama = true))
            }
        } else {
            items.add(PrayerScheduleItem(PrayerType.DHUHR, "الظهر", dhuhrTime, hasIqama = true))
        }

        items.add(PrayerScheduleItem(PrayerType.ASR, "العصر", asrTime, hasIqama = true))
        items.add(PrayerScheduleItem(PrayerType.MAGHRIB, "المغرب", maghribTime, hasIqama = true))
        items.add(PrayerScheduleItem(PrayerType.ISHA, "العشاء", ishaTime, hasIqama = true))

        val formatter = DateTimeFormatter.ofPattern("HH:mm")

        for (item in items) {
            val pConfig = settings.getPrayerConfig(item.type)
            val adhanAdjustedTime = item.baseTime.plusMinutes(pConfig.adhanOffsetMinutes.toLong())
            val adhanDateTime = LocalDateTime.of(date, adhanAdjustedTime)

            // Schedule Adhan
            if (pConfig.adhanEnabled && adhanDateTime.isAfter(now)) {
                val adhanSound = settings.getResolvedAdhanSound(item.type)
                val requestCode = (date.dayOfYear * 100) + item.type.ordinal
                val adhanIntent = Intent(context, PrayerAlarmReceiver::class.java).apply {
                    action = "com.example.ACTION_PRAYER_ALARM"
                    putExtra(PrayerAlarmReceiver.EXTRA_PRAYER_ID, item.type.id)
                    putExtra(PrayerAlarmReceiver.EXTRA_PRAYER_NAME, item.name)
                    putExtra(PrayerAlarmReceiver.EXTRA_PRAYER_TIME, adhanAdjustedTime.format(formatter))
                    putExtra(PrayerAlarmReceiver.EXTRA_MOSQUE_NAME, settings.mosqueName)
                    putExtra(PrayerAlarmReceiver.EXTRA_IS_IQAMA, false)
                    putExtra(PrayerAlarmReceiver.EXTRA_SOUND_URI, adhanSound)
                }
                val pendingIntent = PendingIntent.getBroadcast(
                    context,
                    requestCode,
                    adhanIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                val triggerMillis = adhanDateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                scheduleExact(alarmManager, triggerMillis, pendingIntent)
            }

            // Schedule Iqama (if prayer has iqama)
            if (item.hasIqama && pConfig.iqamaEnabled) {
                val iqamaTime = if (pConfig.isManualIqama && !pConfig.manualIqamaTime.isNullOrEmpty()) {
                    parseTime(pConfig.manualIqamaTime)
                } else {
                    adhanAdjustedTime.plusMinutes(pConfig.iqamaMinutes.toLong())
                }
                val iqamaDateTime = LocalDateTime.of(date, iqamaTime)
                if (iqamaDateTime.isAfter(now)) {
                    val iqamaSound = settings.getResolvedIqamaSound(item.type)
                    val requestCodeIqama = (date.dayOfYear * 100) + item.type.ordinal + 50
                    val iqamaIntent = Intent(context, PrayerAlarmReceiver::class.java).apply {
                        action = "com.example.ACTION_IQAMA_ALARM"
                        putExtra(PrayerAlarmReceiver.EXTRA_PRAYER_ID, item.type.id)
                        putExtra(PrayerAlarmReceiver.EXTRA_PRAYER_NAME, item.name)
                        putExtra(PrayerAlarmReceiver.EXTRA_PRAYER_TIME, iqamaTime.format(formatter))
                        putExtra(PrayerAlarmReceiver.EXTRA_MOSQUE_NAME, settings.mosqueName)
                        putExtra(PrayerAlarmReceiver.EXTRA_IS_IQAMA, true)
                        putExtra(PrayerAlarmReceiver.EXTRA_SOUND_URI, iqamaSound)
                    }
                    val pendingIntent = PendingIntent.getBroadcast(
                        context,
                        requestCodeIqama,
                        iqamaIntent,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    )
                    val triggerMillis = iqamaDateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                    scheduleExact(alarmManager, triggerMillis, pendingIntent)

                    // Schedule automatic audio state restoration after Iqama screen duration
                    val durationMins = pConfig.iqamaScreenDurationMinutes.toLong().coerceIn(2L, 60L)
                    val restoreDateTime = iqamaDateTime.plusMinutes(durationMins)
                    if (restoreDateTime.isAfter(now)) {
                        val restoreIntent = Intent(context, PrayerAlarmReceiver::class.java).apply {
                            action = PrayerAlarmReceiver.ACTION_RESTORE_IQAMA_SILENT
                        }
                        val pendingRestore = PendingIntent.getBroadcast(
                            context,
                            requestCodeIqama + 600,
                            restoreIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                        )
                        val restoreMillis = restoreDateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                        scheduleExact(alarmManager, restoreMillis, pendingRestore)
                    }
                }
            }
        }
    }

    private fun scheduleExact(alarmManager: AlarmManager, triggerMillis: Long, pendingIntent: PendingIntent) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, pendingIntent)
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerMillis, pendingIntent)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to schedule exact alarm", e)
        }
    }
}
