package com.example.data

import com.example.model.DayPrayers
import com.example.model.MonthPrayers
import com.example.model.MosqueSchedule
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.util.Locale
import kotlin.math.*

object PrayerCalculator {

    enum class CalculationMethod(
        val displayName: String,
        val fajrAngle: Double,
        val ishaAngle: Double,
        val ishaIntervalMinutes: Int? = null
    ) {
        MWL("رابطة العالم الإسلامي", 18.0, 17.0),
        MAKKAH("أم القرى (مكة المكرمة)", 18.5, 0.0, 90),
        EGYPT("الهيئة المصرية العامة للمساحة", 19.5, 17.5),
        ISNA("أمريكا الشمالية (ISNA)", 15.0, 15.0),
        KARACHI("جامعة العلوم الإسلامية بكراتشي", 18.0, 18.0)
    }

    enum class AsrMethod(val displayName: String, val shadowFactor: Double) {
        STANDARD("الجمهور (الشافعي والحنبلي والمالكي)", 1.0),
        HANAFI("المذهب الحنفي", 2.0)
    }

    fun calculateAnnualSchedule(
        year: Int,
        latitude: Double,
        longitude: Double,
        timeZone: ZoneId,
        mosqueName: String = "اسم المسجد",
        cityName: String = "",
        fajrIntervalMinutes: Int = 15,
        methodKey: String = "MWL",
        asrMethodKey: String = "STANDARD"
    ): MosqueSchedule {
        val method = CalculationMethod.entries.find { it.name.equals(methodKey, ignoreCase = true) }
            ?: CalculationMethod.MWL
        val asrMethod = AsrMethod.entries.find { it.name.equals(asrMethodKey, ignoreCase = true) }
            ?: AsrMethod.STANDARD

        val monthsList = mutableListOf<MonthPrayers>()

        for (m in 1..12) {
            val daysInMonth = try {
                YearMonth.of(year, m).lengthOfMonth()
            } catch (e: Exception) {
                30
            }
            val daysList = mutableListOf<DayPrayers>()

            for (d in 1..daysInMonth) {
                val date = LocalDate.of(year, m, d)
                val times = calculateDailyTimes(
                    date = date,
                    latitude = latitude,
                    longitude = longitude,
                    timeZone = timeZone,
                    fajrIntervalMinutes = fajrIntervalMinutes,
                    method = method,
                    asrMethod = asrMethod
                )
                daysList.add(
                    DayPrayers(
                        day = d,
                        fajrFirst = times.fajrFirst,
                        fajrSecond = times.fajrSecond,
                        sunrise = times.sunrise,
                        dhuhr = times.dhuhr,
                        asr = times.asr,
                        maghrib = times.maghrib,
                        isha = times.isha
                    )
                )
            }
            monthsList.add(MonthPrayers(month = m, days = daysList))
        }

        val desc = if (cityName.isNotEmpty()) {
            "حساب فلكي دقيق: $cityName (خط عرض: ${String.format(Locale.US, "%.4f", latitude)} | خط طول: ${String.format(Locale.US, "%.4f", longitude)})"
        } else {
            "حساب فلكي دقيق (خط عرض: ${String.format(Locale.US, "%.4f", latitude)} | خط طول: ${String.format(Locale.US, "%.4f", longitude)})"
        }

        return MosqueSchedule(
            mosque = mosqueName,
            version = "2.0-gps",
            description = desc,
            months = monthsList
        )
    }

    data class DailyTimes(
        val fajrFirst: String,
        val fajrSecond: String,
        val sunrise: String,
        val dhuhr: String,
        val asr: String,
        val maghrib: String,
        val isha: String
    )

    fun calculateDailyTimes(
        date: LocalDate,
        latitude: Double,
        longitude: Double,
        timeZone: ZoneId,
        fajrIntervalMinutes: Int = 15,
        method: CalculationMethod = CalculationMethod.MWL,
        asrMethod: AsrMethod = AsrMethod.STANDARD
    ): DailyTimes {
        val jd = julianDay(date.year, date.monthValue, date.dayOfMonth)
        val zonedDateTime = date.atStartOfDay(timeZone)
        val tzOffsetHours = zonedDateTime.offset.totalSeconds / 3600.0

        val d = jd - 2451545.0
        val g = fixAngle(357.529 + 0.98560028 * d)
        val q = fixAngle(280.459 + 0.98564736 * d)
        val l = fixAngle(q + 1.915 * sin(degToRad(g)) + 0.020 * sin(degToRad(2 * g)))
        val e = 23.439 - 0.00000036 * d
        val ra = fixAngle(radToDeg(atan2(cos(degToRad(e)) * sin(degToRad(l)), cos(degToRad(l))))) / 15.0
        val declination = radToDeg(asin(sin(degToRad(e)) * sin(degToRad(l))))
        val equationOfTime = (q / 15.0) - ra

        val noonUtc = 12.0 - (longitude / 15.0) - equationOfTime
        val dhuhrLocal = noonUtc + tzOffsetHours + (2.0 / 60.0) // 2 min precautionary buffer

        val sunriseSunsetAngle = -0.8333
        val sunriseSunsetHourAngle = hourAngle(sunriseSunsetAngle, latitude, declination)
        val sunriseLocal = dhuhrLocal - (sunriseSunsetHourAngle / 15.0)
        val sunsetLocal = dhuhrLocal + (sunriseSunsetHourAngle / 15.0)
        val maghribLocal = sunsetLocal + (2.0 / 60.0)

        val fajrHourAngle = hourAngle(-method.fajrAngle, latitude, declination)
        val fajrSecondLocal = dhuhrLocal - (fajrHourAngle / 15.0)
        val fajrFirstLocal = fajrSecondLocal - (fajrIntervalMinutes / 60.0)

        val minShadow = tan(degToRad(abs(latitude - declination)))
        val asrAltitude = radToDeg(atan(1.0 / (asrMethod.shadowFactor + minShadow)))
        val asrHourAngle = hourAngle(asrAltitude, latitude, declination)
        val asrLocal = dhuhrLocal + (asrHourAngle / 15.0)

        val ishaLocal = if (method.ishaIntervalMinutes != null) {
            maghribLocal + (method.ishaIntervalMinutes / 60.0)
        } else {
            val ishaHourAngle = hourAngle(-method.ishaAngle, latitude, declination)
            dhuhrLocal + (ishaHourAngle / 15.0)
        }

        return DailyTimes(
            fajrFirst = formatHour(fajrFirstLocal),
            fajrSecond = formatHour(fajrSecondLocal),
            sunrise = formatHour(sunriseLocal),
            dhuhr = formatHour(dhuhrLocal),
            asr = formatHour(asrLocal),
            maghrib = formatHour(maghribLocal),
            isha = formatHour(ishaLocal)
        )
    }

    private fun julianDay(year: Int, month: Int, day: Int): Double {
        var y = year
        var m = month
        if (m <= 2) {
            y -= 1
            m += 12
        }
        val a = floor(y / 100.0)
        val b = 2.0 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + day + b - 1524.5
    }

    private fun hourAngle(altitude: Double, latitude: Double, declination: Double): Double {
        val latRad = degToRad(latitude)
        val decRad = degToRad(declination)
        val altRad = degToRad(altitude)
        val cosH = (sin(altRad) - sin(latRad) * sin(decRad)) / (cos(latRad) * cos(decRad))
        val clampedCosH = cosH.coerceIn(-1.0, 1.0)
        return radToDeg(acos(clampedCosH))
    }

    private fun formatHour(hoursFloat: Double): String {
        var totalMinutes = (hoursFloat * 60.0).roundToInt()
        totalMinutes = (totalMinutes % 1440 + 1440) % 1440
        val h = totalMinutes / 60
        val m = totalMinutes % 60
        return String.format(Locale.US, "%02d:%02d", h, m)
    }

    private fun fixAngle(deg: Double): Double {
        var a = deg - 360.0 * floor(deg / 360.0)
        if (a < 0) a += 360.0
        return a
    }

    private fun degToRad(deg: Double) = deg * Math.PI / 180.0
    private fun radToDeg(rad: Double) = rad * 180.0 / Math.PI
}
