package com.example.data

import android.content.Context
import android.util.Log
import com.example.model.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class PrayerRepository(private val context: Context) {

    private val prefs = context.getSharedPreferences("mosque_prayer_prefs", Context.MODE_PRIVATE)
    private val customJsonFile = File(context.filesDir, "custom_prayer_times.json")
    private val settingsJsonFile = File(context.filesDir, "mosque_app_settings.json")

    init {
        // Ensure any previous schedule cache is cleared so the new annual schedule takes immediate effect
        val scheduleVersionKey = "active_schedule_file_version"
        val currentVersion = prefs.getString(scheduleVersionKey, "")
        val targetVersion = "2.0_shuhadaa_corrected"
        if (currentVersion != targetVersion) {
            try {
                if (customJsonFile.exists()) {
                    customJsonFile.delete()
                }
            } catch (e: Exception) {
                Log.e("PrayerRepository", "Error deleting old custom schedule file", e)
            }
            prefs.edit().putString(scheduleVersionKey, targetVersion).apply()
        }
    }

    fun loadSchedule(): MosqueSchedule {
        return try {
            val jsonString = if (customJsonFile.exists()) {
                customJsonFile.readText()
            } else {
                loadDefaultAssetJson()
            }
            parseSchedule(jsonString) ?: parseSchedule(loadDefaultAssetJson())!!
        } catch (e: Exception) {
            Log.e("PrayerRepository", "Error loading schedule, falling back to asset", e)
            parseSchedule(loadDefaultAssetJson())!!
        }
    }

    private fun loadDefaultAssetJson(): String {
        return context.assets.open("prayer_times_default.json").bufferedReader().use { it.readText() }
    }

    fun parseSchedule(jsonString: String): MosqueSchedule? {
        return try {
            val root = JSONObject(jsonString)
            val rawName = root.optString("mosque", "اسم المسجد")
            val mosqueName = if (rawName == "جامع التقوى الكبير") "اسم المسجد" else rawName
            val version = root.optString("version", "2.0")
            val description = root.optString("description", "")
            val monthsArray = root.getJSONArray("months")
            val monthsList = mutableListOf<MonthPrayers>()

            for (mIdx in 0 until monthsArray.length()) {
                val mObj = monthsArray.getJSONObject(mIdx)
                val monthNumber = mObj.getInt("month")
                val daysArray = mObj.getJSONArray("days")
                val daysList = mutableListOf<DayPrayers>()

                for (dIdx in 0 until daysArray.length()) {
                    val dObj = daysArray.getJSONObject(dIdx)
                    val fSecond = dObj.optString("fajr_second", dObj.optString("fajr", "05:00"))
                    val fFirst = dObj.optString("fajr_first", "")
                    val resolvedFajrFirst = if (fFirst.isNotEmpty()) {
                        fFirst
                    } else {
                        try {
                            val parts = fSecond.split(":")
                            val h = parts[0].toInt()
                            val m = parts[1].toInt()
                            val total = (h * 60 + m - 15 + 1440) % 1440
                            String.format(java.util.Locale.US, "%02d:%02d", total / 60, total % 60)
                        } catch (e: Exception) {
                            fSecond
                        }
                    }
                    daysList.add(
                        DayPrayers(
                            day = dObj.getInt("day"),
                            fajrFirst = resolvedFajrFirst,
                            fajrSecond = fSecond,
                            sunrise = dObj.optString("sunrise", "06:30"),
                            dhuhr = dObj.optString("dhuhr", "12:15"),
                            asr = dObj.optString("asr", "15:30"),
                            maghrib = dObj.optString("maghrib", "18:00"),
                            isha = dObj.optString("isha", "19:30")
                        )
                    )
                }
                monthsList.add(MonthPrayers(month = monthNumber, days = daysList))
            }
            MosqueSchedule(mosque = mosqueName, version = version, description = description, months = monthsList)
        } catch (e: Exception) {
            Log.e("PrayerRepository", "Failed to parse JSON", e)
            null
        }
    }

    fun parseScheduleFromCsv(csvText: String): MosqueSchedule? {
        return try {
            val lines = csvText.lines().map { it.trim() }.filter { it.isNotEmpty() }
            if (lines.isEmpty()) return null

            val delimiter = when {
                lines.first().contains(";") -> ";"
                lines.first().contains("\t") -> "\t"
                else -> ","
            }

            var headerIndex = -1
            var colDate = -1
            var colDay = 0
            var colMonth = 1
            var colFajr1 = -1
            var colFajr2 = 2
            var colSunrise = 3
            var colDhuhr = 4
            var colAsr = 5
            var colMaghrib = 6
            var colIsha = 7

            for (i in 0 until minOf(5, lines.size)) {
                val cols = lines[i].split(delimiter).map { it.trim().lowercase() }
                if (cols.any { it.contains("fajr") || it.contains("فجر") || it.contains("dhuhr") || it.contains("ظهر") }) {
                    headerIndex = i
                    cols.forEachIndexed { idx, col ->
                        val c = col.replace("\"", "").replace("'", "")
                        when {
                            c.contains("fajr_first") || c.contains("fajr1") || c.contains("فجر أول") || c.contains("فجر 1") || c.contains("الفجر الاول") -> colFajr1 = idx
                            c.contains("fajr_second") || c.contains("fajr2") || c.contains("فجر ثان") || c.contains("فجر 2") || (c.contains("fajr") && colFajr2 == -1) || (c.contains("فجر") && colFajr2 == -1) -> colFajr2 = idx
                            c.contains("sunrise") || c.contains("shuruq") || c.contains("shurooq") || c.contains("شروق") -> colSunrise = idx
                            c.contains("dhuhr") || c.contains("zuhr") || c.contains("ظهر") -> colDhuhr = idx
                            c.contains("asr") || c.contains("عصر") -> colAsr = idx
                            c.contains("maghrib") || c.contains("مغرب") -> colMaghrib = idx
                            c.contains("isha") || c.contains("عشاء") -> colIsha = idx
                            c.contains("date") || c.contains("تاريخ") -> colDate = idx
                            c.contains("day") || c.contains("يوم") -> colDay = idx
                            c.contains("month") || c.contains("شهر") -> colMonth = idx
                        }
                    }
                    break
                }
            }

            val startRow = if (headerIndex >= 0) headerIndex + 1 else 0
            val monthDaysMap = mutableMapOf<Int, MutableList<DayPrayers>>()

            for (r in startRow until lines.size) {
                val row = lines[r].split(delimiter).map { it.trim().replace("\"", "").replace("'", "") }
                if (row.size < 5) continue

                var day = row.getOrNull(colDay)?.toIntOrNull()
                var month = row.getOrNull(colMonth)?.toIntOrNull()

                if ((day == null || month == null || month !in 1..12 || day !in 1..31) && colDate >= 0 && colDate < row.size) {
                    val dateStr = row[colDate]
                    val parts = dateStr.split("-", "/", ".")
                    if (parts.size >= 3) {
                        val p0 = parts[0].toIntOrNull() ?: 0
                        val p1 = parts[1].toIntOrNull() ?: 0
                        val p2 = parts[2].toIntOrNull() ?: 0
                        if (p0 > 31) {
                            month = p1
                            day = p2
                        } else if (p2 > 31) {
                            if (p1 in 1..12) {
                                day = p0
                                month = p1
                            } else {
                                month = p0
                                day = p1
                            }
                        }
                    }
                }

                if (day == null || month == null || month !in 1..12 || day !in 1..31) continue

                fun cleanTime(t: String): String {
                    val cleaned = t.trim().replace("ص", "").replace("م", "").replace("AM", "", true).replace("PM", "", true).trim()
                    return if (cleaned.length == 4 && cleaned[1] == ':') "0$cleaned" else cleaned
                }

                val rawFajr2 = cleanTime(row.getOrNull(colFajr2)?.takeIf { it.isNotEmpty() } ?: "05:00")
                val rawFajr1 = if (colFajr1 >= 0 && colFajr1 < row.size && row[colFajr1].isNotEmpty()) {
                    cleanTime(row[colFajr1])
                } else {
                    try {
                        val fParts = rawFajr2.split(":")
                        val fHour = fParts[0].toInt()
                        val fMin = fParts[1].toInt()
                        val totalM = (fHour * 60 + fMin - 15 + 1440) % 1440
                        String.format("%02d:%02d", totalM / 60, totalM % 60)
                    } catch (e: Exception) {
                        rawFajr2
                    }
                }
                val rawSunrise = cleanTime(row.getOrNull(colSunrise)?.takeIf { it.isNotEmpty() } ?: "06:30")
                val rawDhuhr = cleanTime(row.getOrNull(colDhuhr)?.takeIf { it.isNotEmpty() } ?: "12:15")
                val rawAsr = cleanTime(row.getOrNull(colAsr)?.takeIf { it.isNotEmpty() } ?: "03:30")
                val rawMaghrib = cleanTime(row.getOrNull(colMaghrib)?.takeIf { it.isNotEmpty() } ?: "06:00")
                val rawIsha = cleanTime(row.getOrNull(colIsha)?.takeIf { it.isNotEmpty() } ?: "07:30")

                val dayPrayers = DayPrayers(
                    day = day,
                    fajrFirst = cleanTime(rawFajr1),
                    fajrSecond = cleanTime(rawFajr2),
                    sunrise = cleanTime(rawSunrise),
                    dhuhr = cleanTime(rawDhuhr),
                    asr = cleanTime(rawAsr),
                    maghrib = cleanTime(rawMaghrib),
                    isha = cleanTime(rawIsha)
                )
                monthDaysMap.getOrPut(month) { mutableListOf() }.add(dayPrayers)
            }

            if (monthDaysMap.isEmpty()) return null

            val monthsList = monthDaysMap.entries.sortedBy { it.key }.map { (m, dList) ->
                MonthPrayers(month = m, days = dList.sortedBy { it.day })
            }

            MosqueSchedule(
                mosque = "اسم المسجد",
                version = "2.0-csv",
                description = "مستورد من ملف CSV",
                months = monthsList
            )
        } catch (e: Exception) {
            Log.e("PrayerRepository", "Failed to parse CSV", e)
            null
        }
    }

    fun scheduleToJson(schedule: MosqueSchedule): String {
        val root = JSONObject()
        root.put("mosque", schedule.mosque)
        root.put("version", schedule.version)
        root.put("description", schedule.description)
        val monthsArray = JSONArray()
        schedule.months.forEach { month ->
            val mObj = JSONObject()
            mObj.put("month", month.month)
            val daysArray = JSONArray()
            month.days.forEach { day ->
                val dObj = JSONObject()
                dObj.put("day", day.day)
                dObj.put("fajr_first", day.fajrFirst)
                dObj.put("fajr_second", day.fajrSecond)
                dObj.put("sunrise", day.sunrise)
                dObj.put("dhuhr", day.dhuhr)
                dObj.put("asr", day.asr)
                dObj.put("maghrib", day.maghrib)
                dObj.put("isha", day.isha)
                daysArray.put(dObj)
            }
            mObj.put("days", daysArray)
            monthsArray.put(mObj)
        }
        root.put("months", monthsArray)
        return root.toString(2)
    }

    fun saveSchedule(schedule: MosqueSchedule): Boolean {
        return try {
            val jsonContent = scheduleToJson(schedule)
            customJsonFile.writeText(jsonContent)
            true
        } catch (e: Exception) {
            Log.e("PrayerRepository", "Failed to save schedule", e)
            false
        }
    }

    fun validateAndImportAny(content: String): Result<MosqueSchedule> {
        val trimmed = content.trim()
        val schedule = if (trimmed.startsWith("{")) {
            parseSchedule(trimmed)
        } else {
            parseScheduleFromCsv(trimmed) ?: parseSchedule(trimmed)
        }
        if (schedule == null || schedule.months.isEmpty()) {
            return Result.failure(IllegalArgumentException("تعذر استخراج جدول مواقيت الصلاة."))
        }
        return try {
            val jsonContent = scheduleToJson(schedule)
            customJsonFile.writeText(jsonContent)
            Result.success(schedule)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun restoreDefaultSchedule(): MosqueSchedule {
        if (customJsonFile.exists()) {
            customJsonFile.delete()
        }
        return loadSchedule()
    }

    fun hasCustomSchedule(): Boolean {
        return customJsonFile.exists()
    }

    companion object {
        fun isTvDevice(context: Context): Boolean {
            val uiModeManager = context.getSystemService(Context.UI_MODE_SERVICE) as? android.app.UiModeManager
            if (uiModeManager?.currentModeType == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION) {
                return true
            }
            val pm = context.packageManager
            return pm.hasSystemFeature(android.content.pm.PackageManager.FEATURE_LEANBACK) ||
                    pm.hasSystemFeature("android.hardware.type.television")
        }

        val defaultAdhanSounds = listOf(
            AudioFileItem(
                id = "adhan_aqsa",
                name = "أذان المسجد الأقصى - القدس",
                uri = "asset:///Adhan/أذان المسجد الأقصى - القدس.mp3",
                isBuiltIn = true
            ),
            AudioFileItem(
                id = "adhan_nabawi",
                name = "أذان المسجد النبوي - المدينة المنورة",
                uri = "asset:///Adhan/أذان المسجد النبوي - المدينة المنورة.mp3",
                isBuiltIn = true
            ),
            AudioFileItem(
                id = "adhan_abdulbasit",
                name = "عبدالباسط عبدالصمد - أذان مصر",
                uri = "asset:///Adhan/عبدالباسط عبدالصمد - أذان مصر.mp3",
                isBuiltIn = true
            ),
            AudioFileItem(
                id = "adhan_mulla",
                name = "علي بن أحمد ملا - المسجد الحرام",
                uri = "asset:///Adhan/علي بن أحمد ملا - المسجد الحرام.mp3",
                isBuiltIn = true
            ),
            AudioFileItem(
                id = "adhan_qatami",
                name = "ناصر القطامي - أذان",
                uri = "asset:///Adhan/ناصر القطامي - أذان.mp3",
                isBuiltIn = true
            )
        )

        val defaultFajrSounds = listOf(
            AudioFileItem(
                id = DEFAULT_FAJR_FIRST_ID,
                name = DEFAULT_FAJR_FIRST_NAME,
                uri = DEFAULT_FAJR_FIRST_URI,
                isBuiltIn = true,
                isDefault = true
            ),
            AudioFileItem(
                id = "fajr_kuwait",
                name = "أذان الفجر - الكويت",
                uri = "asset:///AdhanFajr/أذان الفجر - الكويت.mp3",
                isBuiltIn = true,
                isDefault = false
            ),
            AudioFileItem(
                id = "fajr_nabawi",
                name = "أذان الفجر - المسجد النبوي",
                uri = "asset:///AdhanFajr/أذان الفجر - المسجد النبوي.mp3",
                isBuiltIn = true,
                isDefault = false
            )
        )

        val defaultIqamaSounds = listOf(
            AudioFileItem(
                id = "iqama_dossari",
                name = "ياسر الدوسري - إقامة الصلاة",
                uri = "asset:///Iqama/ياسر الدوسري - إقامة الصلاة.mp3",
                isBuiltIn = true,
                isDefault = true
            )
        )
    }

    fun getDefaultSettings(): AppSettings {
        val isTv = isTvDevice(context)
        return AppSettings(
            orientationMode = "LANDSCAPE",
            swapLayoutSides = isTv,
            highlightCurrentPrayer = false,
            useCommonAdhan = false,
            applyIqamaSoundToAll = false,
            savedAdhanSounds = defaultAdhanSounds,
            savedFajrAdhanSounds = defaultFajrSounds,
            savedIqamaSounds = defaultIqamaSounds
        )
    }

    fun loadSettings(): AppSettings {
        return try {
            val base = if (settingsJsonFile.exists()) {
                val json = JSONObject(settingsJsonFile.readText())
                deserializeSettings(json)
            } else {
                val prefJson = prefs.getString("settings_json", null)
                if (prefJson != null) {
                    deserializeSettings(JSONObject(prefJson))
                } else {
                    getDefaultSettings()
                }
            }
            val withMaster = base
            if (withMaster.mosqueName == "جامع التقوى الكبير") {
                val migrated = withMaster.copy(mosqueName = "اسم المسجد")
                saveSettings(migrated)
                migrated
            } else {
                withMaster
            }
        } catch (e: Exception) {
            Log.e("PrayerRepository", "Failed to load settings, using defaults", e)
            getDefaultSettings()
        }
    }

    fun saveSettings(settings: AppSettings) {
        try {
            val json = serializeSettings(settings)
            val jsonString = json.toString(2)
            settingsJsonFile.writeText(jsonString)
            prefs.edit()
                .putString("settings_json", jsonString)
                .putBoolean("prayerInterfacesMasterEnabled", settings.prayerInterfacesMasterEnabled)
                .putBoolean("secondHomeInterfaceEnabled", settings.secondHomeInterfaceEnabled)
                .putString("selectedHomeInterface", settings.selectedHomeInterface)
                .putBoolean("isKioskModeEnabled", settings.isKioskModeEnabled)
                .putBoolean("isAutoStartHomeEnabled", settings.isAutoStartHomeEnabled)
                .commit()
        } catch (e: Exception) {
            Log.e("PrayerRepository", "Failed to save settings", e)
        }
    }

    private fun serializeSettings(s: AppSettings): JSONObject {
        val obj = JSONObject()
        obj.put("mosqueName", s.mosqueName)
        obj.put("titleText", s.titleText)
        obj.put("titleSizeSp", s.titleSizeSp)
        obj.put("logoScale", s.logoScale.toDouble())
        obj.put("showLogo", s.showLogo)
        obj.put("customLogoUri", s.customLogoUri ?: "")
        obj.put("showSeconds", s.showSeconds)
        obj.put("is24Hour", s.is24Hour)
        obj.put("isTimeCorrectionEnabled", s.isTimeCorrectionEnabled)
        obj.put("timeOffsetHours", s.timeOffsetHours)
        obj.put("timeOffsetMinutes", s.timeOffsetMinutes)
        obj.put("isDateCorrectionEnabled", s.isDateCorrectionEnabled)
        obj.put("gregorianDayOffset", s.gregorianDayOffset)
        obj.put("hijriDayOffset", s.hijriDayOffset)
        obj.put("isFridayKhutbahMode", s.isFridayKhutbahMode)
        obj.put("fridayKhutbahDurationMinutes", s.fridayKhutbahDurationMinutes)
        obj.put("clockSizeSp", s.clockSizeSp)
        obj.put("clockColorHex", s.clockColorHex)
        obj.put("clockDigitsColorHex", s.clockColorHex)
        obj.put("clockMarkerColorHex", s.clockColorHex)
        obj.put("clockBold", s.clockBold)
        obj.put("showDate", s.showDate)
        obj.put("showCountdowns", s.showCountdowns)
        obj.put("showIcons", s.showIcons)
        obj.put("showTitle", s.showTitle)

        obj.put("firstAdhansMasterEnabled", s.firstAdhansMasterEnabled)
        obj.put("isFajrFirstEnabled", s.isFajrFirstEnabled)
        obj.put("isFajrTwoAdhans", s.isFajrTwoAdhans)
        obj.put("isFridayFirstEnabled", s.isFridayFirstEnabled)
        obj.put("fajrIntervalMinutes", s.fajrIntervalMinutes)
        obj.put("fridayFirstAdhanOffsetMinutes", s.fridayFirstAdhanOffsetMinutes)
        obj.put("fridayCustomMessage", s.fridayCustomMessage)
        obj.put("fridayIqamaMinutes", s.fridayIqamaMinutes)
        obj.put("defaultPrePrayerMinutes", s.defaultPrePrayerMinutes)
        obj.put("prayerInterfacesMasterEnabled", s.prayerInterfacesMasterEnabled)
        obj.put("secondHomeInterfaceEnabled", s.secondHomeInterfaceEnabled)
        obj.put("selectedHomeInterface", s.selectedHomeInterface)
        obj.put("simulationModeEnabled", s.simulationModeEnabled)

        obj.put("keepScreenAwake", s.keepScreenAwake)
        obj.put("fullscreenMode", s.fullscreenMode)
        obj.put("orientationMode", s.orientationMode)
        obj.put("nightMode", s.nightMode)
        obj.put("backgroundOpacity", s.backgroundOpacity.toDouble())
        obj.put("overlayColorName", s.overlayColorName)
        obj.put("isAnimatedBackground", s.isAnimatedBackground)
        obj.put("swapLayoutSides", s.swapLayoutSides)
        obj.put("highlightCurrentPrayer", s.highlightCurrentPrayer)
        obj.put("prayerTableElementsSize", s.prayerTableElementsSize)
        obj.put("postPrayerAdhkarEnabled", s.postPrayerAdhkarEnabled)
        obj.put("postPrayerAdhkarDurationMinutes", s.postPrayerAdhkarDurationMinutes)

        obj.put("isAdminPinEnabled", s.isAdminPinEnabled)
        obj.put("adminPin", s.adminPin)
        obj.put("isKioskModeEnabled", s.isKioskModeEnabled)
        obj.put("isAutoStartHomeEnabled", s.isAutoStartHomeEnabled)

        obj.put("tickerRotationSeconds", s.tickerRotationSeconds)
        obj.put("isTickerRotating", s.isTickerRotating)
        obj.put("showTicker", s.showTicker)

        obj.put("calculationMethod", s.calculationMethod)
        obj.put("asrMethod", s.asrMethod)

        // Adhan & Iqama settings
        obj.put("useCommonAdhan", s.useCommonAdhan)
        obj.put("commonAdhanSound", s.commonAdhanSound)
        obj.put("commonAdhanName", s.commonAdhanName)
        obj.put("applyIqamaSoundToAll", s.applyIqamaSoundToAll)
        obj.put("defaultIqamaSound", s.defaultIqamaSound)
        obj.put("defaultIqamaName", s.defaultIqamaName)
        obj.put("globalIqamaScreenDurationMinutes", s.globalIqamaScreenDurationMinutes)

        // General Saved Adhan Sounds
        val adhanSoundsArr = JSONArray()
        s.savedAdhanSounds.forEach {
            val aObj = JSONObject()
            aObj.put("id", it.id)
            aObj.put("name", it.name)
            aObj.put("uri", it.uri)
            adhanSoundsArr.put(aObj)
        }
        obj.put("savedAdhanSounds", adhanSoundsArr)

        // Dedicated Fajr Adhan Sounds
        val fajrSoundsArr = JSONArray()
        s.savedFajrAdhanSounds.forEach {
            val fObj = JSONObject()
            fObj.put("id", it.id)
            fObj.put("name", it.name)
            fObj.put("uri", it.uri)
            fajrSoundsArr.put(fObj)
        }
        obj.put("savedFajrAdhanSounds", fajrSoundsArr)

        // Saved Iqama Sounds
        val iqamaSoundsArr = JSONArray()
        s.savedIqamaSounds.forEach {
            val iObj = JSONObject()
            iObj.put("id", it.id)
            iObj.put("name", it.name)
            iObj.put("uri", it.uri)
            iqamaSoundsArr.put(iObj)
        }
        obj.put("savedIqamaSounds", iqamaSoundsArr)

        // Iqama Screen Custom Config
        val iqCfgObj = JSONObject()
        iqCfgObj.put("backgroundColorHex", s.iqamaScreenCustomConfig.backgroundColorHex)
        iqCfgObj.put("frameColorHex", s.iqamaScreenCustomConfig.frameColorHex)
        iqCfgObj.put("frameOuterThicknessDp", s.iqamaScreenCustomConfig.frameOuterThicknessDp)
        iqCfgObj.put("frameInnerThicknessDp", s.iqamaScreenCustomConfig.frameInnerThicknessDp)
        iqCfgObj.put("titleText", s.iqamaScreenCustomConfig.titleText)
        iqCfgObj.put("titleSizeSp", s.iqamaScreenCustomConfig.titleSizeSp)
        iqCfgObj.put("instructionText", s.iqamaScreenCustomConfig.instructionText)
        iqCfgObj.put("instructionSizeSp", s.iqamaScreenCustomConfig.instructionSizeSp)
        iqCfgObj.put("iconSizeDp", s.iqamaScreenCustomConfig.iconSizeDp)
        obj.put("iqamaScreenCustomConfig", iqCfgObj)

        // Saved GPS location
        if (s.savedLocation != null) {
            val locObj = JSONObject()
            locObj.put("cityName", s.savedLocation.cityName)
            locObj.put("latitude", s.savedLocation.latitude)
            locObj.put("longitude", s.savedLocation.longitude)
            locObj.put("calculationMethod", s.savedLocation.calculationMethod)
            locObj.put("timestamp", s.savedLocation.timestamp)
            obj.put("savedLocation", locObj)
        }

        val messagesArr = JSONArray()
        s.tickerMessages.forEach { messagesArr.put(it) }
        obj.put("tickerMessages", messagesArr)

        obj.put("prayerInterfacesMasterEnabled", s.prayerInterfacesMasterEnabled)
        obj.put("secondHomeInterfaceEnabled", s.secondHomeInterfaceEnabled)
        obj.put("selectedHomeInterface", s.selectedHomeInterface)

        val periodConfigsObj = JSONObject()
        s.periodConfigs.forEach { (key, cfg) ->
            val pObj = JSONObject()
            pObj.put("periodId", cfg.periodId)
            pObj.put("displayName", cfg.displayName)
            pObj.put("enabled", cfg.enabled)
            pObj.put("designPreset", cfg.designPreset)
            pObj.put("customImageUri", cfg.customImageUri ?: "")
            pObj.put("bgGradientStartHex", cfg.bgGradientStartHex)
            pObj.put("bgGradientEndHex", cfg.bgGradientEndHex)
            pObj.put("frameColorHex", cfg.frameColorHex)
            pObj.put("frameThicknessDp", cfg.frameThicknessDp)
            pObj.put("customTitle", cfg.customTitle)
            pObj.put("customDhikr", cfg.customDhikr)
            pObj.put("iconName", cfg.iconName)
            pObj.put("opacity", cfg.opacity.toDouble())
            periodConfigsObj.put(key, pObj)
        }
        obj.put("periodConfigs", periodConfigsObj)

        val prayerConfigsObj = JSONObject()
        s.prayerConfigs.forEach { (key, cfg) ->
            val pObj = JSONObject()
            pObj.put("prayerId", cfg.prayerId)
            pObj.put("adhanEnabled", cfg.adhanEnabled)
            pObj.put("adhanSoundUri", cfg.adhanSoundUri ?: "")
            pObj.put("adhanSoundPreset", cfg.adhanSoundPreset)
            pObj.put("adhanSoundName", cfg.adhanSoundName ?: "")
            pObj.put("adhanOffsetMinutes", cfg.adhanOffsetMinutes)
            pObj.put("iqamaEnabled", cfg.iqamaEnabled)
            pObj.put("iqamaMinutes", cfg.iqamaMinutes)
            pObj.put("manualIqamaTime", cfg.manualIqamaTime ?: "")
            pObj.put("isManualIqama", cfg.isManualIqama)
            pObj.put("iqamaSoundUri", cfg.iqamaSoundUri ?: "")
            pObj.put("iqamaSoundPreset", cfg.iqamaSoundPreset)
            pObj.put("iqamaSoundName", cfg.iqamaSoundName ?: "")
            pObj.put("prePrayerEnabled", cfg.prePrayerEnabled)
            pObj.put("prePrayerMinutes", cfg.prePrayerMinutes)
            pObj.put("customBackgroundUri", cfg.customBackgroundUri ?: "")
            pObj.put("customIconUri", cfg.customIconUri ?: "")
            pObj.put("prayerScreenEnabled", cfg.prayerScreenEnabled)
            pObj.put("prayerScreenUri", cfg.prayerScreenUri ?: "")
            pObj.put("iqamaScreenEnabled", cfg.iqamaScreenEnabled)
            pObj.put("iqamaScreenUri", cfg.iqamaScreenUri ?: "")
            pObj.put("iqamaScreenDurationMinutes", cfg.iqamaScreenDurationMinutes)

            val pIqCfgObj = JSONObject()
            pIqCfgObj.put("backgroundColorHex", cfg.iqamaScreenCustomConfig.backgroundColorHex)
            pIqCfgObj.put("frameColorHex", cfg.iqamaScreenCustomConfig.frameColorHex)
            pIqCfgObj.put("frameOuterThicknessDp", cfg.iqamaScreenCustomConfig.frameOuterThicknessDp)
            pIqCfgObj.put("frameInnerThicknessDp", cfg.iqamaScreenCustomConfig.frameInnerThicknessDp)
            pIqCfgObj.put("titleText", cfg.iqamaScreenCustomConfig.titleText)
            pIqCfgObj.put("titleSizeSp", cfg.iqamaScreenCustomConfig.titleSizeSp)
            pIqCfgObj.put("instructionText", cfg.iqamaScreenCustomConfig.instructionText)
            pIqCfgObj.put("instructionSizeSp", cfg.iqamaScreenCustomConfig.instructionSizeSp)
            pIqCfgObj.put("iconSizeDp", cfg.iqamaScreenCustomConfig.iconSizeDp)
            pObj.put("iqamaScreenCustomConfig", pIqCfgObj)

            prayerConfigsObj.put(key, pObj)
        }
        obj.put("prayerConfigs", prayerConfigsObj)

        return obj
    }

    private fun deserializeSettings(obj: JSONObject): AppSettings {
        val messagesList = mutableListOf<String>()
        val messagesArr = obj.optJSONArray("tickerMessages")
        if (messagesArr != null) {
            for (i in 0 until messagesArr.length()) {
                messagesList.add(messagesArr.getString(i))
            }
        } else {
            messagesList.addAll(AppSettings().tickerMessages)
        }

        val prayerConfigs = mutableMapOf<String, SinglePrayerConfig>()
        val pConfigsObj = obj.optJSONObject("prayerConfigs")
        if (pConfigsObj != null) {
            val keys = pConfigsObj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val p = pConfigsObj.getJSONObject(k)
                prayerConfigs[k] = SinglePrayerConfig(
                    prayerId = p.optString("prayerId", k),
                    adhanEnabled = p.optBoolean("adhanEnabled", true),
                    adhanSoundUri = p.optString("adhanSoundUri", "").takeIf { it.isNotEmpty() },
                    adhanSoundPreset = p.optString("adhanSoundPreset", ""),
                    adhanSoundName = p.optString("adhanSoundName", "").takeIf { it.isNotEmpty() },
                    adhanOffsetMinutes = p.optInt("adhanOffsetMinutes", 0),
                    iqamaEnabled = p.optBoolean("iqamaEnabled", true),
                    iqamaMinutes = p.optInt("iqamaMinutes", 15),
                    manualIqamaTime = p.optString("manualIqamaTime", "").takeIf { it.isNotEmpty() },
                    isManualIqama = p.optBoolean("isManualIqama", false),
                    iqamaSoundUri = p.optString("iqamaSoundUri", "").takeIf { it.isNotEmpty() },
                    iqamaSoundPreset = p.optString("iqamaSoundPreset", ""),
                    iqamaSoundName = p.optString("iqamaSoundName", "").takeIf { it.isNotEmpty() },
                    prePrayerEnabled = p.optBoolean("prePrayerEnabled", true),
                    prePrayerMinutes = p.optInt("prePrayerMinutes", 10),
                    customBackgroundUri = p.optString("customBackgroundUri", "").takeIf { it.isNotEmpty() },
                    customIconUri = p.optString("customIconUri", "").takeIf { it.isNotEmpty() },
                    prayerScreenEnabled = p.optBoolean("prayerScreenEnabled", true),
                    prayerScreenUri = p.optString("prayerScreenUri", "").takeIf { it.isNotEmpty() },
                    iqamaScreenEnabled = p.optBoolean("iqamaScreenEnabled", true),
                    iqamaScreenUri = p.optString("iqamaScreenUri", "").takeIf { it.isNotEmpty() },
                    iqamaScreenDurationMinutes = p.optInt("iqamaScreenDurationMinutes", 5),
                    iqamaScreenCustomConfig = run {
                        val piqObj = p.optJSONObject("iqamaScreenCustomConfig")
                        if (piqObj != null) {
                            IqamaScreenCustomConfig(
                                backgroundColorHex = piqObj.optString("backgroundColorHex", "#EAF5EF"),
                                frameColorHex = piqObj.optString("frameColorHex", "#C9A646"),
                                frameOuterThicknessDp = piqObj.optInt("frameOuterThicknessDp", 4),
                                frameInnerThicknessDp = piqObj.optInt("frameInnerThicknessDp", 2),
                                titleText = piqObj.optString("titleText", "الصلاة قائمة"),
                                titleSizeSp = piqObj.optInt("titleSizeSp", 46),
                                instructionText = piqObj.optString("instructionText", "أغلقوا الهواتف أثابكم الله"),
                                instructionSizeSp = piqObj.optInt("instructionSizeSp", 46),
                                iconSizeDp = piqObj.optInt("iconSizeDp", 90)
                            )
                        } else {
                            IqamaScreenCustomConfig()
                        }
                    }
                )
            }
        }

        // Strictly guarantee SUNRISE has no Adhan and no Iqama configured or enabled
        val sunriseCfg = prayerConfigs[PrayerType.SUNRISE.id] ?: SinglePrayerConfig(PrayerType.SUNRISE.id)
        prayerConfigs[PrayerType.SUNRISE.id] = sunriseCfg.copy(
            adhanEnabled = false,
            adhanSoundUri = null,
            adhanSoundPreset = "",
            adhanSoundName = null,
            iqamaEnabled = false,
            iqamaSoundUri = null,
            iqamaSoundPreset = "",
            iqamaSoundName = null
        )

        // Strictly guarantee FAJR_FIRST does NOT have any general Adhan sounds
        val generalAdhanNames = defaultAdhanSounds.map { it.name }.toSet()
        val fajrFirstCfg = prayerConfigs[PrayerType.FAJR_FIRST.id] ?: SinglePrayerConfig(PrayerType.FAJR_FIRST.id)
        if (generalAdhanNames.contains(fajrFirstCfg.adhanSoundName) || defaultAdhanSounds.any { it.uri == fajrFirstCfg.adhanSoundUri }) {
            prayerConfigs[PrayerType.FAJR_FIRST.id] = fajrFirstCfg.copy(
                adhanSoundUri = null,
                adhanSoundPreset = "",
                adhanSoundName = null
            )
        }

        var savedLocation: GpsLocationData? = null
        val locObj = obj.optJSONObject("savedLocation")
        if (locObj != null) {
            savedLocation = GpsLocationData(
                cityName = locObj.optString("cityName", ""),
                latitude = locObj.optDouble("latitude", 0.0),
                longitude = locObj.optDouble("longitude", 0.0),
                calculationMethod = locObj.optString("calculationMethod", "MWL"),
                timestamp = locObj.optLong("timestamp", System.currentTimeMillis())
            )
        }

        val savedAdhanList = mutableListOf<AudioFileItem>()
        val adhanSoundsArr = obj.optJSONArray("savedAdhanSounds")
        if (adhanSoundsArr != null) {
            for (i in 0 until adhanSoundsArr.length()) {
                val aObj = adhanSoundsArr.getJSONObject(i)
                val id = aObj.optString("id", "audio_$i")
                val name = aObj.optString("name", "")
                val uri = aObj.optString("uri", "")
                val isBuiltIn = aObj.optBoolean("isBuiltIn", false)
                if (defaultAdhanSounds.none { it.id == id || it.uri == uri || it.name == name }) {
                    if (!isBuiltIn && uri.isNotBlank() && (uri.startsWith("content:") || uri.startsWith("file:") || uri.contains("/"))) {
                        savedAdhanList.add(
                            AudioFileItem(
                                id = id,
                                name = name,
                                uri = uri,
                                isBuiltIn = false
                            )
                        )
                    }
                }
            }
        }
        for (i in defaultAdhanSounds.indices.reversed()) {
            val item = defaultAdhanSounds[i]
            savedAdhanList.removeAll { it.id == item.id || it.uri == item.uri || it.name == item.name }
            savedAdhanList.add(0, item)
        }

        val savedFajrList = mutableListOf<AudioFileItem>()
        val fajrSoundsArr = obj.optJSONArray("savedFajrAdhanSounds")
        val excludedFajrIds = setOf("fajr_qatami", "fajr_afasy")
        if (fajrSoundsArr != null) {
            for (i in 0 until fajrSoundsArr.length()) {
                val fObj = fajrSoundsArr.getJSONObject(i)
                val id = fObj.optString("id", "fajr_$i")
                val name = fObj.optString("name", "")
                val uri = fObj.optString("uri", "")
                if (name in generalAdhanNames || id in excludedFajrIds || name.contains("القطامي") || name.contains("العفاسي") || name.contains("المعيقلي") || name.contains("بخاري") || name.contains("إسماعيل")) {
                    continue
                }
                val isOldDeletedFajr = (uri.contains("AdhanFajr/") || name.contains("فجر") || name.contains("Yaseen") || id.startsWith("fajr_")) && defaultFajrSounds.none { it.id == id || it.uri == uri || it.name == name }
                if (isOldDeletedFajr) continue

                if (defaultFajrSounds.none { it.id == id || it.uri == uri }) {
                    savedFajrList.add(
                        AudioFileItem(
                            id = id,
                            name = name,
                            uri = uri,
                            isBuiltIn = false,
                            isDefault = false
                        )
                    )
                }
            }
        }
        for (item in defaultFajrSounds) {
            val existingIndex = savedFajrList.indexOfFirst { it.id == item.id || it.uri == item.uri }
            if (existingIndex >= 0) {
                savedFajrList[existingIndex] = item
            } else {
                savedFajrList.add(item)
            }
        }
        // Ensure primary Fajr First (Yaseen Al Aassaf) is at index 0
        val defaultIdx = savedFajrList.indexOfFirst { it.id == DEFAULT_FAJR_FIRST_ID || it.isDefault }
        if (defaultIdx > 0) {
            val def = savedFajrList.removeAt(defaultIdx)
            savedFajrList.add(0, def)
        }

        val savedIqamaList = mutableListOf<AudioFileItem>()
        val iqamaSoundsArr = obj.optJSONArray("savedIqamaSounds")
        if (iqamaSoundsArr != null) {
            for (i in 0 until iqamaSoundsArr.length()) {
                val iObj = iqamaSoundsArr.getJSONObject(i)
                val id = iObj.optString("id", "iqama_$i")
                val name = iObj.optString("name", "")
                val uri = iObj.optString("uri", "")
                val isBuiltIn = iObj.optBoolean("isBuiltIn", false)
                val isOldDeletedIqama = (uri.contains("Iqama/") || name.contains("إقامة") || name.contains("العفاسي")) && !name.contains("ياسر الدوسري") && isBuiltIn
                if (isOldDeletedIqama) continue
                if (defaultIqamaSounds.none { it.id == id || it.uri == uri || it.name == name }) {
                    if (!isBuiltIn && uri.isNotBlank() && (uri.startsWith("content:") || uri.startsWith("file:") || uri.contains("/"))) {
                        savedIqamaList.add(
                            AudioFileItem(
                                id = id,
                                name = name,
                                uri = uri,
                                isBuiltIn = false
                            )
                        )
                    }
                }
            }
        }
        for (i in defaultIqamaSounds.indices.reversed()) {
            val item = defaultIqamaSounds[i]
            savedIqamaList.removeAll { it.id == item.id || it.uri == item.uri || it.name == item.name }
            savedIqamaList.add(0, item)
        }

        val iqCfgObj = obj.optJSONObject("iqamaScreenCustomConfig")
        val iqamaScreenCustomConfig = if (iqCfgObj != null) {
            IqamaScreenCustomConfig(
                backgroundColorHex = iqCfgObj.optString("backgroundColorHex", "#EAF5EF"),
                frameColorHex = iqCfgObj.optString("frameColorHex", "#C9A646"),
                frameOuterThicknessDp = iqCfgObj.optInt("frameOuterThicknessDp", 4),
                frameInnerThicknessDp = iqCfgObj.optInt("frameInnerThicknessDp", 2),
                titleText = iqCfgObj.optString("titleText", "الصلاة قائمة"),
                titleSizeSp = iqCfgObj.optInt("titleSizeSp", 46),
                instructionText = iqCfgObj.optString("instructionText", "أغلقوا الهواتف أثابكم الله"),
                instructionSizeSp = iqCfgObj.optInt("instructionSizeSp", 46),
                iconSizeDp = iqCfgObj.optInt("iconSizeDp", 90)
            )
        } else {
            IqamaScreenCustomConfig()
        }

        val periodConfigs = mutableMapOf<String, PeriodInterfaceConfig>()
        val periodConfigsObj = obj.optJSONObject("periodConfigs")
        if (periodConfigsObj != null) {
            val keys = periodConfigsObj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val p = periodConfigsObj.getJSONObject(k)
                periodConfigs[k] = PeriodInterfaceConfig(
                    periodId = p.optString("periodId", k),
                    displayName = p.optString("displayName", ""),
                    enabled = p.optBoolean("enabled", true),
                    designPreset = p.optString("designPreset", "ISLAMIC_ARCH"),
                    customImageUri = p.optString("customImageUri", "").takeIf { it.isNotEmpty() },
                    bgGradientStartHex = p.optString("bgGradientStartHex", "#09241B"),
                    bgGradientEndHex = p.optString("bgGradientEndHex", "#04150F"),
                    frameColorHex = p.optString("frameColorHex", "#C9A646"),
                    frameThicknessDp = p.optInt("frameThicknessDp", 3),
                    customTitle = p.optString("customTitle", ""),
                    customDhikr = p.optString("customDhikr", ""),
                    iconName = p.optString("iconName", "DEFAULT"),
                    opacity = p.optDouble("opacity", 0.85).toFloat()
                )
            }
        }

        val isTv = isTvDevice(context)
        val defaultOrientation = "LANDSCAPE"
        val defaultSwap = isTv

        return AppSettings(
            mosqueName = obj.optString("mosqueName", "اسم المسجد").let {
                if (it == "جامع التقوى الكبير") "اسم المسجد" else it
            },
            titleText = obj.optString("titleText", "مواقيت الصلاة"),
            titleSizeSp = obj.optInt("titleSizeSp", 24),
            logoScale = obj.optDouble("logoScale", 1.0).toFloat(),
            showLogo = obj.optBoolean("showLogo", true),
            customLogoUri = obj.optString("customLogoUri", "").takeIf { it.isNotEmpty() },
            swapLayoutSides = obj.optBoolean("swapLayoutSides", defaultSwap),
            showSeconds = obj.optBoolean("showSeconds", true),
            is24Hour = obj.optBoolean("is24Hour", false),
            isTimeCorrectionEnabled = obj.optBoolean("isTimeCorrectionEnabled", false),
            timeOffsetHours = obj.optInt("timeOffsetHours", 0),
            timeOffsetMinutes = obj.optInt("timeOffsetMinutes", 0),
            isDateCorrectionEnabled = obj.optBoolean("isDateCorrectionEnabled", false),
            gregorianDayOffset = obj.optInt("gregorianDayOffset", 0),
            hijriDayOffset = obj.optInt("hijriDayOffset", 0),
            isFridayKhutbahMode = obj.optBoolean("isFridayKhutbahMode", true),
            fridayKhutbahDurationMinutes = obj.optInt("fridayKhutbahDurationMinutes", 25),
            clockSizeSp = obj.optInt("clockSizeSp", com.example.model.DEFAULT_CLOCK_SIZE_SP),
            clockColorHex = obj.optString("clockColorHex",
                obj.optString("clockDigitsColorHex", com.example.model.DEFAULT_CLOCK_COLOR)
            ),
            clockDigitsColorHex = obj.optString("clockColorHex",
                obj.optString("clockDigitsColorHex", com.example.model.DEFAULT_CLOCK_COLOR)
            ),
            clockMarkerColorHex = obj.optString("clockColorHex",
                obj.optString("clockDigitsColorHex", com.example.model.DEFAULT_CLOCK_COLOR)
            ),
            clockBold = obj.optBoolean("clockBold", true),
            showDate = obj.optBoolean("showDate", true),
            showCountdowns = obj.optBoolean("showCountdowns", true),
            showIcons = obj.optBoolean("showIcons", true),
            showTitle = obj.optBoolean("showTitle", true),

            useCommonAdhan = obj.optBoolean("useCommonAdhan", false),
            commonAdhanSound = obj.optString("commonAdhanSound", ""),
            commonAdhanName = obj.optString("commonAdhanName", ""),
            savedAdhanSounds = savedAdhanList,
            savedFajrAdhanSounds = savedFajrList,

            applyIqamaSoundToAll = obj.optBoolean("applyIqamaSoundToAll", false),
            defaultIqamaSound = obj.optString("defaultIqamaSound", ""),
            defaultIqamaName = obj.optString("defaultIqamaName", ""),
            globalIqamaScreenDurationMinutes = obj.optInt("globalIqamaScreenDurationMinutes", 5),
            savedIqamaSounds = savedIqamaList,
            iqamaScreenCustomConfig = iqamaScreenCustomConfig,

            firstAdhansMasterEnabled = obj.optBoolean("firstAdhansMasterEnabled", true),
            isFajrFirstEnabled = obj.optBoolean("isFajrFirstEnabled", obj.optBoolean("isFajrTwoAdhans", true)),
            isFajrTwoAdhans = obj.optBoolean("isFajrTwoAdhans", true),
            isFridayFirstEnabled = obj.optBoolean("isFridayFirstEnabled", true),
            fajrIntervalMinutes = obj.optInt("fajrIntervalMinutes", 15),
            fridayFirstAdhanOffsetMinutes = obj.optInt("fridayFirstAdhanOffsetMinutes", 15),
            fridayCustomMessage = obj.optString("fridayCustomMessage", "يوم الجمعة عيد الأسبوع - أكثروا من الصلاة على النبي ﷺ"),
            fridayIqamaMinutes = obj.optInt("fridayIqamaMinutes", 15),

            defaultPrePrayerMinutes = obj.optInt("defaultPrePrayerMinutes", 10),
            prayerInterfacesMasterEnabled = obj.optBoolean("prayerInterfacesMasterEnabled", true),
            secondHomeInterfaceEnabled = obj.optBoolean("secondHomeInterfaceEnabled", false),
            selectedHomeInterface = obj.optString("selectedHomeInterface", "ABBASI_BLUE_GOLD"),
            periodConfigs = periodConfigs,

            keepScreenAwake = obj.optBoolean("keepScreenAwake", true),
            fullscreenMode = obj.optBoolean("fullscreenMode", true),
            orientationMode = obj.optString("orientationMode", defaultOrientation).let {
                if (it == "PORTRAIT" || it == "AUTO") "LANDSCAPE" else it
            },
            nightMode = obj.optString("nightMode", "AUTO"),
            backgroundOpacity = obj.optDouble("backgroundOpacity", 0.5).toFloat(),
            overlayColorName = obj.optString("overlayColorName", "DARK_GREEN"),
            isAnimatedBackground = obj.optBoolean("isAnimatedBackground", false),
            highlightCurrentPrayer = obj.optBoolean("highlightCurrentPrayer", false),
            prayerTableElementsSize = obj.optInt("prayerTableElementsSize", 18),
            postPrayerAdhkarEnabled = obj.optBoolean("postPrayerAdhkarEnabled", true),
            postPrayerAdhkarDurationMinutes = obj.optInt("postPrayerAdhkarDurationMinutes", 5),

            isAdminPinEnabled = obj.optBoolean("isAdminPinEnabled", false),
            adminPin = obj.optString("adminPin", "1234"),
            isKioskModeEnabled = obj.optBoolean("isKioskModeEnabled", false),
            isAutoStartHomeEnabled = obj.optBoolean("isAutoStartHomeEnabled", false),

            tickerMessages = messagesList,
            tickerRotationSeconds = obj.optInt("tickerRotationSeconds", 12),
            isTickerRotating = obj.optBoolean("isTickerRotating", true),
            showTicker = obj.optBoolean("showTicker", true),

            prayerConfigs = prayerConfigs,
            savedLocation = savedLocation,
            calculationMethod = obj.optString("calculationMethod", "MWL"),
            asrMethod = obj.optString("asrMethod", "STANDARD"),
            simulationModeEnabled = obj.optBoolean("simulationModeEnabled", false)
        )
    }
}
