package com.example.data

import java.time.LocalDate
import java.time.chrono.HijrahDate
import java.time.temporal.ChronoField

object HijriCalendarHelper {

    private val arabicDays = arrayOf(
        "الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"
    )

    private val hijriMonths = arrayOf(
        "محرم", "صفر", "ربيع الأول", "ربيع الآخر",
        "جمادى الأولى", "جمادى الآخرة", "رجب", "شعبان",
        "رمضان", "شوال", "ذو القعدة", "ذو الحجة"
    )

    private val gregorianMonthsArabic = arrayOf(
        "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
        "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
    )

    fun getDayOfWeekArabic(localDate: LocalDate): String {
        return when (localDate.dayOfWeek.value) {
            7 -> arabicDays[0] // Sunday
            1 -> arabicDays[1] // Monday
            2 -> arabicDays[2] // Tuesday
            3 -> arabicDays[3] // Wednesday
            4 -> arabicDays[4] // Thursday
            5 -> arabicDays[5] // Friday
            6 -> arabicDays[6] // Saturday
            else -> arabicDays[0]
        }
    }

    fun getHijriDateString(localDate: LocalDate, dayOffset: Int = 0): String {
        return try {
            val adjustedDate = if (dayOffset != 0) localDate.plusDays(dayOffset.toLong()) else localDate
            val hijrahDate = HijrahDate.from(adjustedDate)
            val day = hijrahDate.get(ChronoField.DAY_OF_MONTH)
            val month = hijrahDate.get(ChronoField.MONTH_OF_YEAR)
            val year = hijrahDate.get(ChronoField.YEAR)
            val monthName = if (month in 1..12) hijriMonths[month - 1] else ""
            "$day $monthName $year هـ"
        } catch (e: Exception) {
            "12 رمضان 1448 هـ"
        }
    }

    fun getGregorianDateString(localDate: LocalDate): String {
        val day = localDate.dayOfMonth
        val monthName = gregorianMonthsArabic[localDate.monthValue - 1]
        val year = localDate.year
        return "$day $monthName $year م"
    }
}
