package com.example

import com.example.model.DayPrayers
import com.example.model.MonthPrayers
import com.example.model.MosqueSchedule
import com.example.ui.settings.updateSchedulePrayerTime
import com.example.util.TimeAutoCorrectionHelper
import com.example.util.TimeParseResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TimeAutoCorrectionHelperTest {

    @Test
    fun testUserSpecifiedExamples() {
        val cases = mapOf(
            "4:34" to "04:34",
            "434" to "04:34",
            "415" to "04:15",
            "530" to "05:30",
            "945" to "09:45",
            "0415" to "04:15",
            "1205" to "12:05"
        )

        for ((input, expected) in cases) {
            val result = TimeAutoCorrectionHelper.parseAndCorrect(input)
            assertTrue("Expected Success for input: $input", result is TimeParseResult.Success)
            assertEquals(expected, (result as TimeParseResult.Success).formattedTime)
        }
    }

    @Test
    fun testArabicDigits() {
        val result = TimeAutoCorrectionHelper.parseAndCorrect("٤١٥")
        assertTrue(result is TimeParseResult.Success)
        assertEquals("04:15", (result as TimeParseResult.Success).formattedTime)

        val resultWithColon = TimeAutoCorrectionHelper.parseAndCorrect("٤:٣٤")
        assertTrue(resultWithColon is TimeParseResult.Success)
        assertEquals("04:34", (resultWithColon as TimeParseResult.Success).formattedTime)
    }

    @Test
    fun testInvalidMinutes() {
        // "475" -> hour = 4, minute = 75 (> 59)
        val result = TimeAutoCorrectionHelper.parseAndCorrect("475")
        assertTrue("Input 475 must be invalid due to 75 minutes", result is TimeParseResult.Error)

        val resultColon = TimeAutoCorrectionHelper.parseAndCorrect("04:75")
        assertTrue(resultColon is TimeParseResult.Error)

        val result60 = TimeAutoCorrectionHelper.parseAndCorrect("12:60")
        assertTrue(result60 is TimeParseResult.Error)
    }

    @Test
    fun testInvalidHours() {
        val result = TimeAutoCorrectionHelper.parseAndCorrect("25:00")
        assertTrue(result is TimeParseResult.Error)

        val result4Digits = TimeAutoCorrectionHelper.parseAndCorrect("2415")
        assertTrue(result4Digits is TimeParseResult.Error)
    }

    @Test
    fun testLiveAutoFormatDetection() {
        assertTrue(TimeAutoCorrectionHelper.shouldAutoFormatLive("0415"))
        assertTrue(TimeAutoCorrectionHelper.shouldAutoFormatLive("1205"))
        assertFalse(TimeAutoCorrectionHelper.shouldAutoFormatLive("04:15")) // already has colon
        assertFalse(TimeAutoCorrectionHelper.shouldAutoFormatLive("415")) // 3 digits wait for done/colon
        assertFalse(TimeAutoCorrectionHelper.shouldAutoFormatLive("41"))
    }

    @Test
    fun testUpdateSchedulePreservesOtherCellsAndMonths() {
        val initialDay = DayPrayers(
            day = 15,
            fajrFirst = "04:39",
            fajrSecond = "04:53",
            sunrise = "06:14",
            dhuhr = "11:54",
            asr = "03:08",
            maghrib = "05:33",
            isha = "06:52"
        )
        val month1 = MonthPrayers(1, listOf(initialDay))
        val month2Day = initialDay.copy(day = 20, dhuhr = "12:00")
        val month2 = MonthPrayers(2, listOf(month2Day))
        val initialSchedule = MosqueSchedule(months = listOf(month1, month2))

        // Modify Dhuhr on day 15 in month 1 to "12:05"
        val updatedSchedule = updateSchedulePrayerTime(
            currentSchedule = initialSchedule,
            monthNum = 1,
            dayNum = 15,
            prayerField = "dhuhr",
            newTime = "12:05"
        )

        // Verify day 15 month 1 dhuhr changed
        val updatedDay1 = updatedSchedule.months.first { it.month == 1 }.days.first { it.day == 15 }
        assertEquals("12:05", updatedDay1.dhuhr)

        // Verify other prayers of day 15 were untouched
        assertEquals("04:53", updatedDay1.fajrSecond)
        assertEquals("06:14", updatedDay1.sunrise)
        assertEquals("03:08", updatedDay1.asr)
        assertEquals("05:33", updatedDay1.maghrib)
        assertEquals("06:52", updatedDay1.isha)

        // Verify month 2 was untouched
        val month2Result = updatedSchedule.months.first { it.month == 2 }.days.first { it.day == 20 }
        assertEquals("12:00", month2Result.dhuhr)
    }

    @Test
    fun testInvalidInputReversionBehavior() {
        val originalTime = "04:39"
        val invalidInput = "475"
        val parseResult = TimeAutoCorrectionHelper.parseAndCorrect(invalidInput)

        val finalTime = when (parseResult) {
            is TimeParseResult.Success -> parseResult.formattedTime
            is TimeParseResult.Error -> originalTime // revert to original
        }

        assertEquals(originalTime, finalTime)
    }
}
