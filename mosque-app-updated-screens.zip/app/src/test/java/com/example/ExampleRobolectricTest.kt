package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.PrayerCalculator
import com.example.data.PrayerRepository
import com.example.model.AudioFileItem
import com.example.model.PrayerType
import com.example.model.SinglePrayerConfig
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read app_name string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("مواقيت المسجد", appName)
    }

    @Test
    fun `test default switches are OFF upon initial launch as requested`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = PrayerRepository(context)
        val defaultSettings = repo.getDefaultSettings()

        // Requirement 2: Both switches must be OFF by default
        assertFalse("تطبيق صوت الأذان على جميع الأذانات must be OFF by default", defaultSettings.useCommonAdhan)
        assertFalse("تطبيق صوت الإقامة على جميع الإقامات must be OFF by default", defaultSettings.applyIqamaSoundToAll)
    }

    @Test
    fun `test no default sound returns 'لم يتم اختيار صوت'`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = PrayerRepository(context)
        val defaultSettings = repo.getDefaultSettings()

        // Dhuhr has no sound chosen by default
        assertEquals("لم يتم اختيار صوت", defaultSettings.getResolvedAdhanTitle(PrayerType.DHUHR))
        assertEquals("لم يتم اختيار صوت", defaultSettings.getResolvedAdhanTitle(PrayerType.FAJR_FIRST))
        assertEquals("لم يتم اختيار صوت", defaultSettings.getResolvedIqamaTitle(PrayerType.DHUHR))
        assertEquals("لم يتم اختيار صوت", defaultSettings.getResolvedIqamaTitle(PrayerType.ASR))
    }

    @Test
    fun `test turning switch ON stays ON and persists in settings`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = PrayerRepository(context)
        val initialSettings = repo.getDefaultSettings()

        // Toggle useCommonAdhan to ON
        val modifiedSettings = initialSettings.copy(
            useCommonAdhan = true,
            applyIqamaSoundToAll = true
        ).withPrayerConfig(
            initialSettings.getPrayerConfig(PrayerType.DHUHR).copy(adhanEnabled = true, iqamaEnabled = true)
        )

        repo.saveSettings(modifiedSettings)
        val reloadedSettings = repo.loadSettings()

        assertTrue("useCommonAdhan must stay ON after saving", reloadedSettings.useCommonAdhan)
        assertTrue("applyIqamaSoundToAll must stay ON after saving", reloadedSettings.applyIqamaSoundToAll)
        assertTrue("Dhuhr adhanEnabled must stay ON", reloadedSettings.getPrayerConfig(PrayerType.DHUHR).adhanEnabled)
        assertTrue("Dhuhr iqamaEnabled must stay ON", reloadedSettings.getPrayerConfig(PrayerType.DHUHR).iqamaEnabled)
    }

    @Test
    fun `test independent sound selection for each prayer`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = PrayerRepository(context)
        val initialSettings = repo.getDefaultSettings()

        val dhuhrSound = AudioFileItem("dhuhr_1", "أذان بصوت الشيخ أحمد", "file:///path/dhuhr.mp3")
        val asrSound = AudioFileItem("asr_1", "أذان بصوت المقرئ خالد", "file:///path/asr.mp3")
        val dhuhrIqama = AudioFileItem("iq_dhuhr", "إقامة الظهر الهادئة", "file:///path/iqama_dhuhr.mp3")

        val modified = initialSettings.copy(
            savedAdhanSounds = listOf(dhuhrSound, asrSound),
            savedIqamaSounds = listOf(dhuhrIqama)
        ).withPrayerConfig(
            initialSettings.getPrayerConfig(PrayerType.DHUHR).copy(
                adhanSoundUri = dhuhrSound.uri,
                adhanSoundName = dhuhrSound.name,
                iqamaSoundUri = dhuhrIqama.uri,
                iqamaSoundName = dhuhrIqama.name
            )
        ).withPrayerConfig(
            initialSettings.getPrayerConfig(PrayerType.ASR).copy(
                adhanSoundUri = asrSound.uri,
                adhanSoundName = asrSound.name
            )
        )

        repo.saveSettings(modified)
        val reloaded = repo.loadSettings()

        assertEquals(dhuhrSound.uri, reloaded.getResolvedAdhanSound(PrayerType.DHUHR))
        assertEquals("أذان بصوت الشيخ أحمد", reloaded.getResolvedAdhanTitle(PrayerType.DHUHR))
        assertEquals(asrSound.uri, reloaded.getResolvedAdhanSound(PrayerType.ASR))
        assertEquals("أذان بصوت المقرئ خالد", reloaded.getResolvedAdhanTitle(PrayerType.ASR))

        assertEquals(dhuhrIqama.uri, reloaded.getResolvedIqamaSound(PrayerType.DHUHR))
        assertEquals("إقامة الظهر الهادئة", reloaded.getResolvedIqamaTitle(PrayerType.DHUHR))
        assertEquals("لم يتم اختيار صوت", reloaded.getResolvedIqamaTitle(PrayerType.ASR))
    }

    @Test
    fun `test Fajr First has dedicated sound library and does not mix with general library`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = PrayerRepository(context)
        val initialSettings = repo.getDefaultSettings()

        val fajrSound = AudioFileItem("fajr_audio_1", "أذان الفجر الأول بصوت الشيخ فاروق", "file:///path/fajr1.mp3")
        val generalSound = AudioFileItem("gen_1", "أذان عام للمسجد", "file:///path/gen.mp3")

        val updated = initialSettings.copy(
            useCommonAdhan = true, // even if common adhan is ON!
            commonAdhanSound = generalSound.uri,
            commonAdhanName = generalSound.name,
            savedFajrAdhanSounds = listOf(fajrSound),
            savedAdhanSounds = listOf(generalSound)
        ).withPrayerConfig(
            initialSettings.getPrayerConfig(PrayerType.FAJR_FIRST).copy(
                adhanSoundUri = fajrSound.uri,
                adhanSoundName = fajrSound.name
            )
        )

        repo.saveSettings(updated)
        val reloaded = repo.loadSettings()

        // Fajr First must use its own sound from fajr library
        assertEquals(fajrSound.uri, reloaded.getResolvedAdhanSound(PrayerType.FAJR_FIRST))
        assertEquals("أذان الفجر الأول بصوت الشيخ فاروق", reloaded.getResolvedAdhanTitle(PrayerType.FAJR_FIRST))

        // Other prayers use common adhan sound
        assertEquals(generalSound.uri, reloaded.getResolvedAdhanSound(PrayerType.DHUHR))
        assertEquals(generalSound.uri, reloaded.getResolvedAdhanSound(PrayerType.ASR))
    }

    @Test
    fun `test Fajr first and second calculation`() {
        val formatter = DateTimeFormatter.ofPattern("HH:mm")
        val fajrSecondTime = LocalTime.of(4, 30)
        var fajrInterval = 15
        var fajrFirstTime = fajrSecondTime.minusMinutes(fajrInterval.toLong())
        assertEquals("04:15", fajrFirstTime.format(formatter))

        fajrInterval = 20
        fajrFirstTime = fajrSecondTime.minusMinutes(fajrInterval.toLong())
        assertEquals("04:10", fajrFirstTime.format(formatter))
    }

    @Test
    fun `test Iqama calculation`() {
        val formatter = DateTimeFormatter.ofPattern("HH:mm")
        val adhanTime = LocalTime.of(4, 30)
        var iqamaMins = 20
        var iqamaTime = adhanTime.plusMinutes(iqamaMins.toLong())
        assertEquals("04:50", iqamaTime.format(formatter))

        iqamaMins = 30
        iqamaTime = adhanTime.plusMinutes(iqamaMins.toLong())
        assertEquals("05:00", iqamaTime.format(formatter))
    }

    @Test
    fun `test Fajr First, Friday First and Sunrise have no Iqama`() {
        assertFalse("Fajr First must not have Iqama", PrayerType.FAJR_FIRST.hasIqama)
        assertFalse("Friday First must not have Iqama", PrayerType.FRIDAY_FIRST.hasIqama)
        assertFalse("Sunrise must not have Iqama", PrayerType.SUNRISE.hasIqama)
        assertTrue("Fajr Second must have Iqama", PrayerType.FAJR_SECOND.hasIqama)
        assertTrue("Dhuhr must have Iqama", PrayerType.DHUHR.hasIqama)
        assertTrue("Asr must have Iqama", PrayerType.ASR.hasIqama)
        assertTrue("Maghrib must have Iqama", PrayerType.MAGHRIB.hasIqama)
        assertTrue("Isha must have Iqama", PrayerType.ISHA.hasIqama)
        assertTrue("Friday Second must have Iqama", PrayerType.FRIDAY_SECOND.hasIqama)
    }

    @Test
    fun `test astronomical calculation for 365 days by GPS`() {
        val schedule = PrayerCalculator.calculateAnnualSchedule(
            year = 2026,
            latitude = 33.3152,
            longitude = 44.3661,
            timeZone = ZoneId.of("Asia/Baghdad"),
            cityName = "بغداد"
        )
        assertEquals(12, schedule.months.size)
        val jan = schedule.months.find { it.month == 1 }!!
        assertEquals(31, jan.days.size)
        val day1 = jan.days.find { it.day == 1 }!!
        assertTrue(day1.fajrSecond.matches(Regex("\\d{2}:\\d{2}")))
        assertTrue(day1.sunrise.matches(Regex("\\d{2}:\\d{2}")))
        assertTrue(day1.dhuhr.matches(Regex("\\d{2}:\\d{2}")))
        assertTrue(day1.asr.matches(Regex("\\d{2}:\\d{2}")))
        assertTrue(day1.maghrib.matches(Regex("\\d{2}:\\d{2}")))
        assertTrue(day1.isha.matches(Regex("\\d{2}:\\d{2}")))
    }

    @Test
    fun `test stop action in AdhanForegroundService stops current audio without clearing alarms`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val stopIntent = android.content.Intent(context, com.example.service.AdhanForegroundService::class.java).apply {
            action = com.example.service.AdhanForegroundService.ACTION_STOP_ADHAN
        }
        val service = org.robolectric.Robolectric.buildService(com.example.service.AdhanForegroundService::class.java, stopIntent).create().startCommand(0, 0)
        assertNotNull(service)
        assertFalse(com.example.audio.PrayerAudioPlaybackManager.isAnyAudioPlaying())
    }

    @Test
    fun `test friday prayer naming matches toggle state`() {
        // When enabled
        assertEquals("الأذان الأول", PrayerType.FRIDAY_FIRST.displayName(true))
        assertEquals("الأذان الثاني", PrayerType.FRIDAY_SECOND.displayName(true))

        // When disabled: second prayer becomes Dhuhr
        assertEquals("الظهر", PrayerType.FRIDAY_SECOND.displayName(false))
    }

    @Test
    fun `test MainActivity builds and creates cleanly`() {
        val controller = org.robolectric.Robolectric.buildActivity(MainActivity::class.java).setup()
        val activity = controller.get()
        assertNotNull(activity)
        assertFalse(activity.isFinishing)
    }

    @Test
    fun `test all written audio names in libraries link to actual audio files and are matched`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = PrayerRepository(context)
        val defaultSettings = repo.getDefaultSettings()

        // 1. General Adhan (5 designated files)
        val generalAdhanItems = defaultSettings.savedAdhanSounds
        assertEquals(5, generalAdhanItems.size)
        for (item in generalAdhanItems) {
            assertTrue("General adhan '${item.name}' must be matched", com.example.audio.AudioRegistry.isAudioMatched(item.name))
            assertTrue("General adhan URI '${item.uri}' must be matched", com.example.audio.AudioRegistry.isAudioMatched(item.uri))
            val matched = com.example.audio.AudioRegistry.findMatchedAudio(item.name)
            assertNotNull("Audio file for '${item.name}' must exist and be found", matched)
            assertTrue("Asset path for '${item.name}' must point to Adhan directory", matched!!.assetPath?.startsWith("Adhan/") == true)
        }

        // 2. Fajr First Adhan (3 files placed by user in folder)
        val fajrItems = defaultSettings.savedFajrAdhanSounds
        assertEquals(3, fajrItems.size)
        val expectedFajrNames = listOf(
            "أذان الفجر - المسجد الحرام",
            "أذان الفجر - الكويت",
            "أذان الفجر - المسجد النبوي"
        )
        for (item in fajrItems) {
            assertTrue("Fajr item '${item.name}' must be one of the 3 user files", item.name in expectedFajrNames)
            assertTrue("Fajr adhan '${item.name}' must be matched", com.example.audio.AudioRegistry.isAudioMatched(item.name))
            assertTrue("Fajr adhan URI '${item.uri}' must be matched", com.example.audio.AudioRegistry.isAudioMatched(item.uri))
            val matched = com.example.audio.AudioRegistry.findMatchedAudio(item.name)
            assertNotNull("Audio file for '${item.name}' must exist and be found", matched)
            assertTrue("Asset path for '${item.name}' must point to AdhanFajr directory", matched!!.assetPath?.startsWith("AdhanFajr/") == true)
        }

        // 3. Iqama (Exclusively the 1 file sent by the user)
        val iqamaItems = defaultSettings.savedIqamaSounds
        assertEquals(1, iqamaItems.size)
        assertEquals("ياسر الدوسري - إقامة الصلاة", iqamaItems[0].name)
        for (item in iqamaItems) {
            assertTrue("Iqama '${item.name}' must be matched", com.example.audio.AudioRegistry.isAudioMatched(item.name))
            assertTrue("Iqama URI '${item.uri}' must be matched", com.example.audio.AudioRegistry.isAudioMatched(item.uri))
            val matched = com.example.audio.AudioRegistry.findMatchedAudio(item.name)
            assertNotNull("Audio file for '${item.name}' must exist and be found", matched)
            assertTrue("Asset path for '${item.name}' must point to Iqama directory", matched!!.assetPath?.startsWith("Iqama/") == true)
        }
    }

    @Test
    fun `test AdhanPlayer successfully plays matched audio without error`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val player = com.example.audio.AdhanPlayer(context)

        // Test playing a general adhan
        val successAdhan = player.playAdhan("أذان المسجد الأقصى - القدس")
        assertTrue("Adhan playback must succeed", successAdhan)
        assertTrue("AdhanPlayer must be in playing state", player.isPlayingAdhan())
        player.stop()
        assertFalse("AdhanPlayer must stop cleanly", player.isPlayingAdhan())

        // Test playing Fajr Adhan (Al-Masjid Al-Haram)
        val successFajr = player.playAdhan("أذان الفجر - المسجد الحرام")
        assertTrue("Fajr playback must succeed", successFajr)
        player.stop()

        // Test playing Yasser Al-Dossari Iqama
        val successIqama = player.playAdhan("ياسر الدوسري - إقامة الصلاة")
        assertTrue("Iqama playback must succeed", successIqama)
        player.stop()
    }
}


