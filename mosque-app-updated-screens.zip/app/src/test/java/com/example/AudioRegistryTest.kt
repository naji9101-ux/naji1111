package com.example

import com.example.audio.AudioNameNormalizer
import com.example.audio.AudioRegistry
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment

@RunWith(RobolectricTestRunner::class)
class AudioRegistryTest {

    @Test
    fun testAudioNameNormalizer_stripExtension() {
        assertEquals("أذان ياسر الدوسري", AudioNameNormalizer.stripExtension("أذان ياسر الدوسري.mp3"))
        assertEquals("أذان ماهر المعيقلي", AudioNameNormalizer.stripExtension("أذان ماهر المعيقلي.wav"))
        assertEquals("أذان عبدالباسط عبدالصمد", AudioNameNormalizer.stripExtension("أذان عبدالباسط عبدالصمد.m4a"))
        assertEquals("أذان الفجر ياسر الدوسري", AudioNameNormalizer.stripExtension("أذان الفجر ياسر الدوسري.mp3"))
    }

    @Test
    fun testAudioNameNormalizer_whitespaceNormalization() {
        val input = "  أذان   ياسر   الدوسري  "
        val normalized = AudioNameNormalizer.normalizeSpaces(input)
        assertEquals("أذان ياسر الدوسري", normalized)
    }

    @Test
    fun testAudioRegistry_emptyAssetsAndDefaults() {
        val context = RuntimeEnvironment.getApplication()
        AudioRegistry.rescan(context)

        // With bundled assets removed, searching for missing audios returns null
        assertNull(AudioRegistry.findMatchedAudio("أذان غير موجود"))
        assertFalse(AudioRegistry.isAudioMatched("أذان غير موجود"))

        // Verify AppSettings defaults
        val settings = com.example.model.AppSettings()
        assertTrue(settings.savedAdhanSounds.isEmpty())
        assertTrue(settings.savedFajrAdhanSounds.isEmpty())
        assertTrue(settings.savedIqamaSounds.isEmpty())
        assertEquals("لم يتم اختيار صوت", settings.getResolvedAdhanTitle(com.example.model.PrayerType.DHUHR))
    }

    @Test
    fun testAudioRegistry_discoversInternalStorageAudio() {
        val context = RuntimeEnvironment.getApplication()
        val customAudioDir = java.io.File(context.filesDir, "audio").apply { mkdirs() }
        val testFile = java.io.File(customAudioDir, "أذان مخصص تجريبي.mp3")
        testFile.writeBytes(ByteArray(100))

        AudioRegistry.rescan(context)

        val matched = AudioRegistry.findMatchedAudio("أذان مخصص تجريبي")
        assertNotNull("Should discover custom audio in internal storage", matched)
        assertEquals("أذان مخصص تجريبي", matched?.baseName)
        assertTrue(AudioRegistry.isAudioMatched("أذان مخصص تجريبي"))

        testFile.delete()
    }

    @Test
    fun testAudioRegistry_exclusiveAdhanLibrary() {
        val context = RuntimeEnvironment.getApplication()
        AudioRegistry.rescan(context)

        val adhanItems = AudioRegistry.getDiscoveredAdhanItems()
        val expectedAdhanNames = listOf(
            "أذان المسجد الأقصى - القدس",
            "أذان المسجد النبوي - المدينة المنورة",
            "عبدالباسط عبدالصمد - أذان مصر",
            "علي بن أحمد ملا - المسجد الحرام",
            "ناصر القطامي - أذان"
        )
        // Verify all discovered adhans are exclusively within the expected list
        val adhanItemNames = adhanItems.map { it.name }
        assertTrue(
            "Adhan library must contain exclusively the designated adhans, but got: $adhanItemNames",
            adhanItemNames.all { it in expectedAdhanNames }
        )
        assertFalse(
            "Adhan library must NOT contain Fajr First adhan",
            adhanItemNames.any { it.contains("فجر") || it.contains("Yaseen", ignoreCase = true) }
        )
        assertFalse(
            "Adhan library must NOT contain Iqama",
            adhanItemNames.any { it.contains("إقامة") || it.contains("اقامة") }
        )

        // Verify Fajr First contains exclusively the 3 files put by the user
        val fajrItems = AudioRegistry.getDiscoveredFajrItems()
        val fajrItemNames = fajrItems.map { it.name }
        val expectedFajrNames = listOf(
            "أذان الفجر - المسجد الحرام",
            "أذان الفجر - الكويت",
            "أذان الفجر - المسجد النبوي"
        )
        assertEquals(3, fajrItemNames.size)
        assertTrue("Fajr items must match expected 3 files", fajrItemNames.containsAll(expectedFajrNames))
        assertTrue(
            "Fajr 1st library must NOT contain general adhans",
            fajrItemNames.none { it in expectedAdhanNames }
        )

        // Verify Shurooq (Sunrise) has NO adhan
        val settings = com.example.model.AppSettings()
        assertNull(
            "Sunrise must NEVER have an adhan sound",
            settings.getResolvedAdhanSound(com.example.model.PrayerType.SUNRISE)
        )

        // Verify Iqama library contains exclusively the sent Iqama file
        val iqamaItems = AudioRegistry.getDiscoveredIqamaItems()
        val iqamaItemNames = iqamaItems.map { it.name }
        assertEquals(listOf("ياسر الدوسري - إقامة الصلاة"), iqamaItemNames)
    }

    @Test
    fun testNasserAlQatamiAdhanPlayback() {
        val context = RuntimeEnvironment.getApplication()
        AudioRegistry.initialize(context)

        // Verify discovery and matching
        val soundTitle = "ناصر القطامي - أذان"
        assertTrue("Nasser Al Qatami must be matched by title", AudioRegistry.isAudioMatched(soundTitle))
        val matched = AudioRegistry.findMatchedAudio(soundTitle)
        assertNotNull("Matched audio must not be null", matched)
        assertEquals("ناصر القطامي - أذان", matched?.baseName)
        assertEquals("Adhan/ناصر القطامي - أذان.mp3", matched?.assetPath)

        // Verify playable file preparation
        val playable = AudioRegistry.getPlayableFile(context, matched!!)
        assertNotNull("Playable file for Nasser Al Qatami must exist and not be null", playable)
        assertTrue("Playable file must have valid length", (playable?.length() ?: 0) > 0)

        // Verify AdhanPlayer can play it
        val player = com.example.audio.AdhanPlayer(context)
        val started = player.playAdhan(soundTitle)
        assertTrue("Playback must start successfully", started)
        assertTrue("Player must be in playing state", player.isPlayingAdhan())
        player.stop()
        assertFalse("Player must stop cleanly", player.isPlayingAdhan())
    }

    @Test
    fun testFajrAndIqamaPlayback() {
        val context = RuntimeEnvironment.getApplication()
        AudioRegistry.initialize(context)
        val player = com.example.audio.AdhanPlayer(context)

        // Test all 3 Fajr sounds
        val fajrSounds = listOf(
            "أذان الفجر - المسجد الحرام",
            "أذان الفجر - الكويت",
            "أذان الفجر - المسجد النبوي"
        )
        for (fajr in fajrSounds) {
            assertTrue("Fajr sound '$fajr' must be matched", AudioRegistry.isAudioMatched(fajr))
            val matched = AudioRegistry.findMatchedAudio(fajr)
            assertNotNull("Matched audio for '$fajr' must not be null", matched)
            val playable = AudioRegistry.getPlayableFile(context, matched!!)
            assertNotNull("Playable file for '$fajr' must not be null", playable)
            assertTrue("Playable file for '$fajr' must have length > 0", (playable?.length() ?: 0) > 0)

            val started = player.playAdhan(fajr)
            assertTrue("Playback for '$fajr' must start", started)
            assertTrue(player.isPlayingAdhan())
            player.stop()
            assertFalse(player.isPlayingAdhan())
        }

        // Test Iqama sound
        val iqamaSound = "ياسر الدوسري - إقامة الصلاة"
        assertTrue("Iqama sound must be matched", AudioRegistry.isAudioMatched(iqamaSound))
        val matchedIqama = AudioRegistry.findMatchedAudio(iqamaSound)
        assertNotNull("Matched audio for Iqama must not be null", matchedIqama)
        val playableIqama = AudioRegistry.getPlayableFile(context, matchedIqama!!)
        assertNotNull("Playable file for Iqama must not be null", playableIqama)
        assertTrue("Playable file for Iqama must have length > 0", (playableIqama?.length() ?: 0) > 0)

        val startedIqama = player.playAdhan(iqamaSound)
        assertTrue("Playback for Iqama must start", startedIqama)
        assertTrue(player.isPlayingAdhan())
        player.stop()
        assertFalse(player.isPlayingAdhan())
    }
}
